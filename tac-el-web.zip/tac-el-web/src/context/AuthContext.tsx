import React, { createContext, useContext, useEffect, useRef, useState } from 'react';
import type { User } from '@supabase/supabase-js';
import { supabase } from '../supabase';
import { authService, rowToProfile } from '../services/authService';
import { subscribePresence } from '../lib/realtime';
import { UserProfile } from '../types';

interface AuthContextType {
  user: User | null;
  profile: UserProfile | null;
  loading: boolean;
  /** Kept for compatibility with existing components that show a "service
   *  unavailable" banner. Firestore's per-project read/write quota doesn't
   *  have a direct Postgres equivalent; this now flips on for any repeated
   *  connection/auth failure talking to Supabase (paused project, no
   *  network, etc.) rather than a specific quota error code. */
  quotaExceeded: boolean;
  setQuotaExceeded: (exhausted: boolean) => void;
  refreshProfile: () => Promise<void>;
  /** Set right after a brand-new profile row is created (new Google account,
   *  or first login after email confirmation) so the UI can show a one-time
   *  "here's your TAC ID" banner — see App.tsx. Firebase's Google *popup*
   *  could show this immediately in JoinChurch itself; Supabase's Google
   *  *redirect* leaves and re-enters the app, so the reveal has to happen
   *  here instead, after the user lands back. */
  newTacId: string | null;
  clearNewTacId: () => void;
}

const AuthContext = createContext<AuthContextType>({
  user: null,
  profile: null,
  loading: true,
  quotaExceeded: false,
  setQuotaExceeded: () => {},
  refreshProfile: async () => {},
  newTacId: null,
  clearNewTacId: () => {},
});

export const useAuth = () => useContext(AuthContext);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [quotaExceeded, setQuotaExceeded] = useState(false);
  const [newTacId, setNewTacId] = useState<string | null>(null);
  const provisioning = useRef<Set<string>>(new Set());

  const refreshProfile = async () => {
    if (!user) return;
    try {
      const p = await authService.getCurrentUserProfile(user.id);
      if (p) setProfile(p);
    } catch (e) {
      setQuotaExceeded(true);
    }
  };

  const clearNewTacId = () => setNewTacId(null);

  useEffect(() => {
    let profileChannelCleanup: (() => void) | null = null;

    const handleSession = (sessionUser: User | null) => {
      setUser(sessionUser);

      if (profileChannelCleanup) {
        profileChannelCleanup();
        profileChannelCleanup = null;
      }

      if (!sessionUser) {
        setProfile(null);
        setLoading(false);
        return;
      }

      // Realtime subscription to this one profile row, refetching on any
      // change to it (role promotion by an admin, online/office updates, …).
      const channel = supabase
        .channel(`profile:${sessionUser.id}`)
        .on(
          'postgres_changes',
          { event: '*', schema: 'public', table: 'profiles', filter: `id=eq.${sessionUser.id}` },
          async () => {
            const p = await authService.getCurrentUserProfile(sessionUser.id);
            if (p) setProfile(p);
          }
        )
        .subscribe();
      profileChannelCleanup = () => supabase.removeChannel(channel);

      // Initial load — and, if this is a brand-new auth user with no
      // profiles row yet, create one (this is the Supabase equivalent of
      // the old auto-provisioning in Firestore's onSnapshot "doesn't
      // exist yet" branch).
      (async () => {
        try {
          const existing = await authService.getCurrentUserProfile(sessionUser.id);
          if (existing) {
            setProfile(existing);
          } else if (!provisioning.current.has(sessionUser.id)) {
            provisioning.current.add(sessionUser.id);
            const meta = sessionUser.user_metadata || {};
            const name =
              meta.full_name || meta.name || sessionUser.email?.split('@')[0] || 'Assembly Member';
            const created = await authService.createProfileForNewUser(
              sessionUser.id,
              sessionUser.email || '',
              name
            );
            setProfile(created);
            setNewTacId(created.userId || null);
          }
          // Came in through the Admin/Presbytery screen with Google? Ask the
          // server to verify the passcode and promote — never decided in the browser.
          const claim = authService.consumePendingClaim();
          if (claim) {
            const label = claim.role === 'admin' ? 'Admin' : 'Presbytery';
            const note = (msg: string) => { try { sessionStorage.setItem('tac_claim_error', msg); } catch { /* ignore */ } };
            const current = await authService.getCurrentUserProfile(sessionUser.id);
            const alreadyHasRole = !!current && (current.role === 'admin' || (claim.role === 'presbytery' && current.role === 'presbytery'));
            if (alreadyHasRole) {
              if (current) setProfile(current);
            } else if (claim.role === 'admin' && !claim.passcode.trim()) {
              note(`You signed in with Google without the ${label} passcode, so you were signed in as a member. Open the ${label} sign-in again, type the passcode first, then tap the Google button.`);
            } else {
              try {
                await authService.claimRole(claim.role, claim.passcode);
                const promoted = await authService.getCurrentUserProfile(sessionUser.id);
                if (promoted) setProfile(promoted);
                // The sign-in can be processed twice; make sure the older copy of the profile can't win.
                setTimeout(async () => {
                  try {
                    const again = await authService.getCurrentUserProfile(sessionUser.id);
                    if (again) setProfile(again);
                  } catch { /* ignore */ }
                }, 1500);
              } catch (claimErr: any) {
                console.warn('Role claim failed:', claimErr);
                note(`${label} access was not granted: ${claimErr?.message || 'the passcode could not be verified.'} You are signed in as a member.`);
              }
            }
          }
        } catch (err) {
          console.warn('Profile load/provision failed:', err);
          setQuotaExceeded(true);
        } finally {
          setLoading(false);
        }
      })();
    };

    // If the first sign-in check fails or never answers, don't leave the person on the splash screen forever.
    const loadingGuard = setTimeout(() => setLoading(false), 15000);
    supabase.auth.getSession().then(({ data }) => {
      handleSession(data.session?.user ?? null);
    }).catch((err) => {
      console.warn('Could not read the saved session:', err);
      setLoading(false);
    });

    const { data: authListener } = supabase.auth.onAuthStateChange((_event, session) => {
      handleSession(session?.user ?? null);
    });

    return () => {
      clearTimeout(loadingGuard);
      authListener.subscription.unsubscribe();
      if (profileChannelCleanup) profileChannelCleanup();
    };
  }, []);

  // Online presence: a lightweight persisted "last seen" on the profile row
  // (used for "members online in the last 5 minutes" type queries), plus an
  // ephemeral Realtime Presence channel every signed-in client joins, which
  // is what powers instantaneous "who's online right now" indicators without
  // hitting the database on every heartbeat.
  useEffect(() => {
    if (!user) return;

    const heartbeat = async () => {
      try {
        await supabase
          .from('profiles')
          .update({ online: true, last_seen: new Date().toISOString() })
          .eq('id', user.id);
      } catch {
        /* best-effort — a missed heartbeat isn't worth surfacing to the user */
      }
    };
    heartbeat();
    const interval = setInterval(heartbeat, 60000);

    const { unsubscribe } = subscribePresence(
      'presence:online',
      { key: user.id, meta: { name: profile?.name || 'Member' } },
      () => {
        /* Individual screens (HomeView, etc.) read this channel themselves
           for a live roster; AuthContext just needs to keep this client
           "present" for as long as they're signed in. */
      }
    );

    return () => {
      clearInterval(interval);
      unsubscribe();
      supabase
        .from('profiles')
        .update({ online: false, last_seen: new Date().toISOString() })
        .eq('id', user.id)
        .then(() => {}, () => {});
    };
  }, [user, profile?.name]);

  return (
    <AuthContext.Provider
      value={{ user, profile, loading, quotaExceeded, setQuotaExceeded, refreshProfile, newTacId, clearNewTacId }}
    >
      {children}
    </AuthContext.Provider>
  );
};
