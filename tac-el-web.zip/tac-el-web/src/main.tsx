import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import { ErrorBoundary } from './components/ErrorBoundary';
import { startNativeShell } from './lib/nativeShell';
import './index.css';

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <ErrorBoundary>
      <App />
    </ErrorBoundary>
  </StrictMode>,
);

// Lets the app install and receive notifications. Only in the real (built) app, or when testing with ?sw=1.
if ('serviceWorker' in navigator && !(window as any).Capacitor?.isNativePlatform?.() && (import.meta.env.PROD || window.location.search.includes('sw=1'))) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/sw.js').catch((err) => console.warn('Service worker not registered:', err));
  });
}

startNativeShell();
