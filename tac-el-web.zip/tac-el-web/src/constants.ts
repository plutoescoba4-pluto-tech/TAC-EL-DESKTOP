export const CHURCH_NAME = "The Apostolic Church Ghana";
export const CHURCH_SHORT_NAME = "TAC GHANA";
export const DISTRICT = "Madina District";
export const ASSEMBLY = "EastLegon Assembly";
export const FULL_CHURCH_NAME = "The Apostolic Church Ghana EastLegon Assembly";

// The site icon shown on sign-up, login and the dashboard. It is a file inside the app (public/icons),
// not a link to another website, so it always loads. Replace public/icons/icon-512.png to change it.
export const CHURCH_LOGO = "/icons/icon-512.png";
