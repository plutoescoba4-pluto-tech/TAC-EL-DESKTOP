/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { OfflineBanner } from './components/shared/OfflineBanner';
import React, { useState, useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import { settingsService } from './services/settingsService';
import { HomeConfig } from './types';
import Landing from './components/Landing';
import Auth from './components/Auth';
import Dashboard from './components/Dashboard';
import DesktopWelcome from './components/desktop/DesktopWelcome';
import DesktopLoading from './components/desktop/DesktopLoading';
import { desktopApi, isDesktopApp } from './lib/desktop';
import { appFlow } from './lib/device';
import WrongDevice from './components/entry/WrongDevice';

const AppContent: React.FC = () => {
  const { user, profile, loading, newTacId, clearNewTacId } = useAuth();
  const [config, setConfig] = useState<HomeConfig | null>(null);
  const [desktopReady, setDesktopReady] = useState(false);   // the desktop app's "Loading your chats" screen has finished

  useEffect(() => {
    // Load theme from localStorage
    const savedTheme = localStorage.getItem('theme') || 'light';
    document.documentElement.setAttribute('data-theme', savedTheme);
    if (savedTheme === 'dark') {
      document.documentElement.classList.add('dark');
    }

    const unsub = settingsService.subscribeHomeConfig((cfg) => {
      if (cfg) setConfig(cfg);
    });
    return unsub;
  }, []);

  // In the desktop app the window is small while signing in and grows into the full app once linked.
  const signedIn = !!(user && profile);
  const flow = appFlow();
  const computerFlow = flow === 'computer';
  useEffect(() => {
    if (loading) return;
    if (isDesktopApp) desktopApi?.setMode(signedIn ? 'main' : 'link');   // the desktop app resizes its window
    if (!signedIn) setDesktopReady(false);
  }, [signedIn, loading]);

  // NOTE: this default logo URL still points at the old Firebase Storage
  // bucket. It's a public asset link (not an auth call), so it keeps working
  // for now, but it's worth re-hosting somewhere permanent — see
  // MIGRATION_NOTES.md.
  const logo = config?.logoUrl || '/icons/icon-512.png';

  if (loading) {
    return (
      <div className="min-h-dvh flex flex-col items-center justify-center bg-tac-blue-dark">
        <div className="animate-pulse flex flex-col items-center gap-6">
           <img src={logo} alt="Church Logo" className="w-40 h-40 object-contain filter drop-shadow-2xl" />
           <div className="space-y-2 text-center">
             <h2 className="text-white font-black uppercase tracking-[0.3em] text-xs">The Apostolic Church Ghana</h2>
             <p className="text-white/40 text-[9px] font-bold uppercase tracking-[0.2em]">{config?.id || 'East Legon Assembly'}</p>
             <div className="h-1 w-24 bg-tac-red mx-auto rounded-full mt-2" />
           </div>
        </div>
      </div>
    );
  }

  if (flow === 'wrong-computer' || flow === 'wrong-phone') {
    return <WrongDevice kind={flow} />;
  }

  if (computerFlow && signedIn && !desktopReady) {
    return <DesktopLoading onDone={() => setDesktopReady(true)} />;
  }

  return (
    <div className="relative min-h-dvh overflow-x-hidden">
      <OfflineBanner />
      {/* Dynamic Watermark Logo */}
      <div className="watermark">
        <img src={logo} alt="Watermark" />
      </div>

      {/* One-time reveal for a brand-new TAC ID. Firebase's Google *popup*
          flow could show this inline on the JoinChurch screen right after
          signup; Supabase's *redirect* flow leaves and re-enters the app, so
          the earliest safe place to show it is here, once landed. */}
      {newTacId && (
        <div className="fixed top-4 inset-x-4 z-[999] max-w-md mx-auto bg-emerald-600 text-white rounded-2xl shadow-2xl px-5 py-4 flex items-center justify-between gap-4">
          <div>
            <p className="text-[10px] font-black uppercase tracking-widest opacity-80">Welcome to Fellowship!</p>
            <p className="text-sm font-black tracking-widest">Your TAC ID: {newTacId}</p>
          </div>
          <button onClick={clearNewTacId} className="text-xs font-black uppercase opacity-80 hover:opacity-100">
            Dismiss
          </button>
        </div>
      )}

      <Routes>
        <Route path="/" element={user && profile ? <Navigate to="/dashboard" /> : computerFlow ? <DesktopWelcome /> : <Landing />} />
        <Route path="/login" element={user && profile ? <Navigate to="/dashboard" /> : computerFlow ? <DesktopWelcome /> : <Auth />} />
        <Route path="/register" element={user && profile ? <Navigate to="/dashboard" /> : computerFlow ? <DesktopWelcome /> : <Auth />} />
        <Route path="/dashboard/*" element={<Dashboard />} />
      </Routes>
    </div>
  );
};

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <AppContent />
      </AuthProvider>
    </BrowserRouter>
  );
}

