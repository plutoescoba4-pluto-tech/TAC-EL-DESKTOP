import FloatingAssistiveTab from '../FloatingAssistiveTab';

export { FloatingAssistiveTab };
export default FloatingAssistiveTab;
