import { FEATURES } from '../../lib/features';
import React from 'react';
import { useNavigate, useLocation, Link } from 'react-router-dom';
import { 
  Home, 
  BookOpen, 
  Calendar, 
  Users, 
  MessageSquare, 
  Heart, 
  Image as ImageIcon,
  Bell, 
  LogOut, 
  User as UserIcon, 
  Settings, 
  Shield, 
  Info, 
  ScrollText, 
  Music4, 
  Headphones, 
  Zap, 
  UserCheck,
  Briefcase,
  Globe,
  ShieldAlert,
  IdCard,
  MonitorSmartphone,
} from 'lucide-react';
import { ASSEMBLY, CHURCH_LOGO } from '../../constants';
import { UserProfile } from '../../types';

interface SidebarNavProps {
  isOpen: boolean;
  profile: UserProfile;
  onClose: () => void;
  onSignOut: () => void;
  siteLogo?: string;
}

export const SidebarNav: React.FC<SidebarNavProps> = ({
  isOpen,
  profile,
  onClose,
  onSignOut,
  siteLogo
}) => {
  const navigate = useNavigate();
  const location = useLocation();

  const isAdmin = profile.role === 'admin';
  const isPresbytery = profile.role === 'presbytery';
  const isStaff = isAdmin || isPresbytery;

  const NavItem = ({ to, icon, label, badge }: { to: string; icon: React.ReactNode; label: string; badge?: string }) => {
    const isActive = location.pathname === to || (to !== '/dashboard' && location.pathname.startsWith(to));
    return (
      <Link
        to={to}
        onClick={onClose}
        className={`flex items-center justify-between px-3.5 py-2.5 rounded-2xl text-xs font-black uppercase tracking-wider transition-all ${
          isActive 
            ? 'bg-tac-blue text-white shadow-lg shadow-tac-blue/20' 
            : 'text-white/70 hover:bg-white/10 hover:text-white'
        }`}
      >
        <div className="flex items-center gap-3">
          <span className="shrink-0">{icon}</span>
          <span className="truncate">{label}</span>
        </div>
        {badge && (
          <span className="bg-tac-red text-white text-[9px] px-2 py-0.5 rounded-full font-black">
            {badge}
          </span>
        )}
      </Link>
    );
  };

  const NavGroup = ({ title, children }: { title: string; children: React.ReactNode }) => (
    <div className="pt-4 first:pt-0 space-y-1">
      <p className="px-3 text-[10px] font-black uppercase tracking-[0.2em] text-white/30 mb-1.5">
        {title}
      </p>
      {children}
    </div>
  );

  return (
    <aside
      className={`fixed inset-y-0 left-0 w-[280px] bg-tac-blue-dark z-50 flex flex-col shadow-2xl transition-transform duration-300 ${
        isOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
      }`}
    >
      <div className="p-6 pt-8 overflow-y-auto flex-1">
        {/* Church Branding */}
        <div 
          className="flex items-center gap-3.5 mb-8 px-1 cursor-pointer" 
          onClick={() => { navigate('/dashboard'); onClose(); }}
        >
          <div className="w-13 h-13 bg-white rounded-2xl flex items-center justify-center p-2 shadow-2xl ring-4 ring-white/10 shrink-0">
            <img src={siteLogo || CHURCH_LOGO} alt="Church Logo" className="w-full h-full object-contain" />
          </div>
          <div className="min-w-0">
            <h2 className="text-white font-black text-sm leading-none uppercase tracking-tight truncate">TAC GHANA</h2>
            <p className="text-tac-red text-[9px] uppercase font-bold tracking-[0.18em] mt-1.5 truncate">{ASSEMBLY}</p>
            <p className="text-white/40 text-[8px] uppercase font-bold tracking-widest mt-0.5 truncate">Madina District</p>
          </div>
        </div>

        {/* Navigation Categories */}
        <div className="space-y-1">
          <NavGroup title="Main">
            <NavItem to="/dashboard" icon={<Home size={18} />} label="Home" />
            <NavItem to="/dashboard/sermons" icon={<BookOpen size={18} />} label="Sermons" />
            <NavItem to="/dashboard/events" icon={<Calendar size={18} />} label="Events" />
            <NavItem to="/dashboard/gallery" icon={<ImageIcon size={18} />} label="Gallery" />
          </NavGroup>

          <NavGroup title="Spiritual">
            {FEATURES.bible && <NavItem to="/dashboard/bible" icon={<BookOpen size={18} />} label="Scriptures (Bible)" />}
            <NavItem to="/dashboard/hymns" icon={<Music4 size={18} />} label="Hymns (TAC)" />
            <NavItem to="/dashboard/conference" icon={<Headphones size={18} />} label="Voice Sanctuary" />
            <NavItem to="/dashboard/conduct" icon={<ScrollText size={18} />} label="Protocol & Conduct" />
            <NavItem to="/dashboard/build-in-christ" icon={<BookOpen size={18} />} label="Build in Christ" />
          </NavGroup>

          <NavGroup title="Ministry & Clubs">
            <NavItem to="/dashboard/chat" icon={<MessageSquare size={18} />} label="Church Chat" />
            <NavItem to="/dashboard/messages" icon={<MessageSquare size={18} />} label="Messages" />
            <NavItem to="/dashboard/notification-settings" icon={<Bell size={18} />} label="Notifications" />
            <NavItem to="/dashboard/linked-devices" icon={<MonitorSmartphone size={18} />} label="Linked Devices" />
            <NavItem to="/dashboard/teams" icon={<Users size={18} />} label="Clubs & Wings" />
            <NavItem to="/dashboard/notices" icon={<Bell size={18} />} label="Notices" />
            <NavItem to="/dashboard/network" icon={<Zap size={18} />} label="Assembly Network" />
            {isStaff && <NavItem to="/dashboard/updates" icon={<Zap size={18} />} label="Updates Pipeline" />}
          </NavGroup>

          {/* Portals depending on role */}
          {isPresbytery && (
            <NavGroup title="Presbytery Council">
              <NavItem to="/dashboard/presbytery" icon={<UserCheck size={18} />} label="Presbytery Portal" />
            </NavGroup>
          )}

          {isAdmin && (
            <NavGroup title="Secretariat & Admin">
              <NavItem to="/dashboard/admin/inbox" icon={<Shield size={18} />} label="Admin Inbox" />
              <NavItem to="/dashboard/admin/members" icon={<Users size={18} />} label="Member Directory" />
              <NavItem to="/dashboard/admin-portal" icon={<Briefcase size={18} />} label="Admin Hub" />
              <NavItem to="/dashboard/office" icon={<Briefcase size={18} />} label="Office & Finance" />
              <NavItem to="/dashboard/admin/settings" icon={<Settings size={18} />} label="Site Settings" />
              <NavItem to="/dashboard/admin/website" icon={<Globe size={18} />} label="Website" />
              <NavItem to="/dashboard/admin/chat-reports" icon={<ShieldAlert size={18} />} label="Chat Reports" />
              <NavItem to="/dashboard/admin/tac-id" icon={<IdCard size={18} />} label="Member IDs" />
              <NavItem to="/dashboard/admin/chat-wallpapers" icon={<ImageIcon size={18} />} label="Chat Wallpapers" />
            </NavGroup>
          )}

          <NavGroup title="Personal">
            <NavItem to="/dashboard/give" icon={<Heart size={18} />} label="Giving / Tithes" />
            <NavItem to="/dashboard/profile" icon={<UserIcon size={18} />} label="My Profile" />
            <NavItem to="/dashboard/info" icon={<Info size={18} />} label="Church Info" />
          </NavGroup>
        </div>
      </div>

      {/* User profile footer */}
      <div className="p-4 space-y-3 bg-black/20 border-t border-white/5 shrink-0">
        <div className="bg-white/5 rounded-2xl p-3 flex items-center gap-3">
          <div className={`w-9 h-9 rounded-full flex items-center justify-center text-sm font-bold text-white shadow-inner ${profile.color || 'bg-tac-blue'} shrink-0`}>
            {profile.picUrl ? <img src={profile.picUrl} alt={profile.name} className="w-full h-full object-cover rounded-full" /> : profile.name[0]}
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-white text-xs font-black truncate">{profile.name}</p>
            <p className="text-white/40 text-[9px] uppercase font-bold tracking-widest">{profile.role}</p>
          </div>
          {profile.userId && (
            <span className="text-[9px] font-mono text-tac-blue-light font-bold bg-white/10 px-1.5 py-0.5 rounded">
              {profile.userId}
            </span>
          )}
        </div>
        <button
          onClick={onSignOut}
          className="w-full flex items-center justify-center gap-2 px-3 py-2.5 bg-red-500/10 hover:bg-red-500 text-red-400 hover:text-white rounded-xl text-xs font-black uppercase tracking-wider transition-all active:scale-95"
        >
          <LogOut size={16} />
          Sign Out
        </button>
      </div>
    </aside>
  );
};
export default SidebarNav;
