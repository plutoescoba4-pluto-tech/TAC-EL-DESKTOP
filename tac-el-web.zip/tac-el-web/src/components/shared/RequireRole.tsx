/**
 * RequireRole — route-level access guard.
 *
 * IMPORTANT: hiding a sidebar link is NOT access control. Every sensitive
 * route must be wrapped in this so a member typing the URL directly (e.g.
 * /dashboard/admin/users) is actually blocked, not just kept from seeing
 * the link.
 *
 * Usage:
 *   <Route path="/admin/users" element={
 *     <RequireRole allow={['admin']} isAdmin={isAdmin} isPresbytery={isPresbytery}>
 *       <UserManagement />
 *     </RequireRole>
 *   } />
 *
 * For group-leader routes, pass isGroupLeader (computed async via
 * clubsService.isUserAnyClubLeader — see Dashboard.tsx).
 *
 * For office routes: there is currently NO real data model for "who holds
 * which office" (AssignOffices.tsx doesn't persist anything yet — see the
 * TODO there). Until that exists, office routes are restricted to admin
 * only as a safe default — NOT left open to all members.
 */
import React from 'react';
import { Navigate } from 'react-router-dom';

type Role = 'member' | 'presbytery' | 'admin' | 'groupLeader' | 'office';

interface RequireRoleProps {
  allow: Role[];
  isAdmin: boolean;
  isPresbytery?: boolean;
  isGroupLeader?: boolean;
  isOffice?: boolean;
  checking?: boolean; // true while an async permission check (e.g. club leadership) is in flight
  children: React.ReactNode;
}

export const RequireRole: React.FC<RequireRoleProps> = ({
  allow,
  isAdmin,
  isPresbytery = false,
  isGroupLeader = false,
  isOffice = false,
  checking = false,
  children,
}) => {
  // Admin can always see everything — matches "admin manages everything" from the design.
  if (isAdmin) return <>{children}</>;

  if (checking) {
    return (
      <div className="flex items-center justify-center py-24 text-gray-400 text-sm">
        Checking access…
      </div>
    );
  }

  const authorized =
    (allow.includes('presbytery') && isPresbytery) ||
    (allow.includes('groupLeader') && isGroupLeader) ||
    (allow.includes('office') && isOffice);

  if (!authorized) {
    return <Navigate to="/dashboard/home" replace />;
  }

  return <>{children}</>;
};
