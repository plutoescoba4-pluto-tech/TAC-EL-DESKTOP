import React, { useState } from 'react';
import { Play, Download, Copy, Check, ExternalLink } from 'lucide-react';
import { Sermon } from '../../types';

/** Copies text. Falls back to a hidden textarea where the clipboard API is blocked. */
export async function copyText(text: string): Promise<boolean> {
  try { await navigator.clipboard.writeText(text); return true; } catch { /* fall through */ }
  try {
    const ta = document.createElement('textarea');
    ta.value = text; ta.style.position = 'fixed'; ta.style.opacity = '0';
    document.body.appendChild(ta); ta.select();
    const ok = document.execCommand('copy'); document.body.removeChild(ta); return ok;
  } catch { return false; }
}

/** Saves a file to the phone. Falls back to opening the link when the server does not allow a direct download. */
export async function downloadFile(url: string, name: string): Promise<void> {
  try {
    const r = await fetch(url);
    if (!r.ok) throw new Error('bad status');
    const blob = await r.blob();
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob); a.download = name; document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 4000);
  } catch {
    window.open(url, '_blank', 'noopener');
  }
}

function youTubeEmbed(url: string): string | null {
  const m = url.match(/(?:youtu\.be\/|youtube\.com\/(?:watch\?v=|embed\/|shorts\/|live\/))([A-Za-z0-9_-]{11})/);
  return m ? `https://www.youtube.com/embed/${m[1]}` : null;
}
const isDirectVideo = (u: string) => /^data:video/.test(u) || /\.(mp4|webm|ogg|mov|m4v)($|\?)/i.test(u);

const fileName = (s: Sermon, ext: string) => `${(s.title || 'sermon').replace(/[^\w\- ]+/g, '').trim().replace(/\s+/g, '-').slice(0, 60) || 'sermon'}.${ext}`;
const extOf = (u: string, fallback: string) => (u.split('?')[0].match(/\.([a-z0-9]{2,4})$/i)?.[1] || fallback).toLowerCase();

const Btn: React.FC<{ onClick?: () => void; href?: string; icon: React.ReactNode; label: string }> = ({ onClick, href, icon, label }) => {
  const cls = 'inline-flex items-center gap-1.5 px-3 py-2 rounded-xl text-[11px] font-black uppercase tracking-wide bg-gray-50 dark:bg-slate-700 text-tac-blue hover:bg-tac-blue hover:text-white transition-all';
  return href
    ? <a href={href} target="_blank" rel="noopener noreferrer" className={cls} onClick={(e) => e.stopPropagation()}>{icon}{label}</a>
    : <button type="button" onClick={(e) => { e.stopPropagation(); onClick?.(); }} className={cls}>{icon}{label}</button>;
};

const CopyBtn: React.FC<{ text: string; label?: string }> = ({ text, label = 'Copy link' }) => {
  const [done, setDone] = useState(false);
  return (
    <Btn
      onClick={async () => { if (await copyText(text)) { setDone(true); setTimeout(() => setDone(false), 1800); } }}
      icon={done ? <Check size={14} /> : <Copy size={14} />}
      label={done ? 'Copied' : label}
    />
  );
};

/** Shows only what the sermon actually has: cover, audio player, video player, link. Plus Download and Copy buttons. */
export const SermonMedia: React.FC<{ sermon: Sermon; compact?: boolean }> = ({ sermon, compact }) => {
  const { audioUrl, videoUrl, coverUrl, linkUrl } = sermon;
  const embed = videoUrl ? youTubeEmbed(videoUrl) : null;
  const hasAny = !!(audioUrl || videoUrl || coverUrl || linkUrl);
  if (!hasAny) return null;
  return (
    <div className="space-y-3" onClick={(e) => e.stopPropagation()}>
      {videoUrl && embed && (
        <div className="aspect-video w-full rounded-2xl overflow-hidden bg-black">
          <iframe src={embed} title={sermon.title} className="w-full h-full" allow="accelerometer; autoplay; clipboard-write; encrypted-media; picture-in-picture" allowFullScreen />
        </div>
      )}
      {videoUrl && !embed && isDirectVideo(videoUrl) && (
        <video controls preload="metadata" poster={coverUrl} src={videoUrl} className="w-full max-h-72 rounded-2xl bg-black" />
      )}
      {coverUrl && !(videoUrl && (embed || isDirectVideo(videoUrl))) && (
        <img src={coverUrl} alt="" loading="lazy" className={`w-full object-cover rounded-2xl ${compact ? 'max-h-40' : 'max-h-64'}`} />
      )}
      {audioUrl && <audio controls preload="none" src={audioUrl} className="w-full" />}
      <div className="flex flex-wrap gap-2">
        {audioUrl && <Btn onClick={() => downloadFile(audioUrl, fileName(sermon, extOf(audioUrl, 'mp3')))} icon={<Download size={14} />} label="Download audio" />}
        {videoUrl && isDirectVideo(videoUrl) && <Btn onClick={() => downloadFile(videoUrl, fileName(sermon, extOf(videoUrl, 'mp4')))} icon={<Download size={14} />} label="Download video" />}
        {coverUrl && <Btn onClick={() => downloadFile(coverUrl, fileName(sermon, extOf(coverUrl, 'jpg')))} icon={<Download size={14} />} label="Download picture" />}
        {audioUrl && <CopyBtn text={audioUrl} label="Copy audio link" />}
        {videoUrl && <CopyBtn text={videoUrl} label="Copy video link" />}
        {linkUrl && <CopyBtn text={linkUrl} label="Copy link" />}
        {videoUrl && !embed && !isDirectVideo(videoUrl) && <Btn href={videoUrl} icon={<Play size={14} />} label="Watch" />}
        {linkUrl && <Btn href={linkUrl} icon={<ExternalLink size={14} />} label="Open link" />}
      </div>
    </div>
  );
};
export default SermonMedia;
