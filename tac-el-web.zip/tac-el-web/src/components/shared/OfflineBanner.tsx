import React, { useEffect, useState } from 'react';

/** A thin bar at the top when the phone has no internet. The app itself still opens. */
export const OfflineBanner: React.FC = () => {
  const [online, setOnline] = useState(typeof navigator === 'undefined' ? true : navigator.onLine);
  useEffect(() => {
    const on = () => setOnline(true);
    const off = () => setOnline(false);
    window.addEventListener('online', on);
    window.addEventListener('offline', off);
    return () => { window.removeEventListener('online', on); window.removeEventListener('offline', off); };
  }, []);
  if (online) return null;
  return (
    <div className="fixed top-0 inset-x-0 z-[1000] bg-slate-800 text-white text-[11px] font-bold text-center py-1 pt-[max(0.25rem,env(safe-area-inset-top))]">
      You are offline. Messages and church data will load when you are back online.
    </div>
  );
};
export default OfflineBanner;
