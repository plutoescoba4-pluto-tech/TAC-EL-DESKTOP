import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Home, MessageSquare, Mic, Heart, User } from 'lucide-react';

interface BottomNavProps {
  unreadChatCount?: number;
  unreadNoticesCount?: number;
}


export const BottomNav: React.FC<BottomNavProps> = ({ unreadChatCount = 0, unreadNoticesCount = 0 }) => {
  const navigate = useNavigate();
  const location = useLocation();

  const allNavItems = [
    { id: 'home', label: 'Home', icon: Home, path: '/dashboard' },
    { id: 'chat', label: 'Chat', icon: MessageSquare, path: '/dashboard/chat-menu', also: ['/dashboard/chat', '/dashboard/network'], badge: unreadChatCount },
    { id: 'voice', label: 'Voice', icon: Mic, path: '/dashboard/conference' },
    { id: 'give', label: 'Give', icon: Heart, path: '/dashboard/give' },
    { id: 'profile', label: 'Profile', icon: User, path: '/dashboard/profile' }
  ];
  const navItems = allNavItems;

  return (
    <nav className="fixed bottom-0 inset-x-0 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-t border-[var(--Bdr)] z-40 lg:hidden px-2 py-1 safe-area-pb shadow-lg">
      <div className="flex items-center justify-around max-w-lg mx-auto">
        {navItems.map((item) => {
          const isActive = location.pathname === item.path || (item.path !== '/dashboard' && [item.path, ...((item as any).also || [])].some((p) => location.pathname.startsWith(p)));
          const Icon = item.icon;

          return (
            <button
              key={item.id}
              onClick={() => navigate(item.path)}
              className={`relative flex flex-col items-center justify-center py-1.5 px-3 rounded-2xl transition-all active:scale-90 ${
                isActive ? 'text-tac-blue font-black' : 'text-gray-400 dark:text-gray-500 hover:text-gray-700 dark:hover:text-gray-300'
              }`}
            >
              <div className="relative">
                <Icon size={22} className={isActive ? 'stroke-[2.5px]' : 'stroke-2'} />
                {item.badge && item.badge > 0 ? (
                  <span className="absolute -top-1.5 -right-2 bg-tac-red text-white text-[9px] font-black w-4 h-4 rounded-full flex items-center justify-center ring-2 ring-white dark:ring-slate-900">
                    {item.badge > 9 ? '9+' : item.badge}
                  </span>
                ) : null}
              </div>
              <span className={`text-[10px] mt-1 tracking-tight ${isActive ? 'font-black' : 'font-semibold'}`}>
                {item.label}
              </span>
              {isActive && (
                <div className="w-1.5 h-1.5 rounded-full bg-tac-blue mt-0.5" />
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
};
export default BottomNav;
