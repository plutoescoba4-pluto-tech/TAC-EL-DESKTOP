import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Radio, Headphones, X, ChevronRight } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface LivePopoverProps {
  room: { id: string; title: string; hostName?: string } | null;
  onClose: () => void;
}

export const LivePopover: React.FC<LivePopoverProps> = ({ room, onClose }) => {
  const navigate = useNavigate();
  if (!room) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ y: 50, opacity: 0, scale: 0.95 }}
        animate={{ y: 0, opacity: 1, scale: 1 }}
        exit={{ y: 50, opacity: 0, scale: 0.95 }}
        className="fixed bottom-20 lg:bottom-6 right-4 lg:right-6 z-50 max-w-sm w-full p-4 bg-gradient-to-r from-tac-blue-dark via-slate-900 to-tac-blue text-white rounded-3xl shadow-2xl border border-white/20 flex items-center justify-between gap-3 overflow-hidden"
      >
        <div 
          onClick={() => navigate('/dashboard/conference')}
          className="flex items-center gap-3 cursor-pointer flex-1 min-w-0"
        >
          <div className="relative w-10 h-10 rounded-2xl bg-tac-red/20 text-tac-red flex items-center justify-center shrink-0 border border-tac-red/30">
            <Radio size={20} className="animate-pulse" />
            <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-tac-red rounded-full animate-ping" />
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-1.5">
              <span className="text-[9px] font-black uppercase text-tac-red tracking-widest">LIVE AUDIO</span>
              <span className="text-white/40">·</span>
              <span className="text-[10px] text-white/70 truncate">{room.hostName || 'Sanctuary'}</span>
            </div>
            <h4 className="text-xs font-black uppercase tracking-tight text-white truncate">
              {room.title || 'Global Assembly Prayer'}
            </h4>
          </div>
        </div>

        <div className="flex items-center gap-1.5 shrink-0">
          <button
            onClick={() => navigate('/dashboard/conference')}
            className="p-2 bg-tac-blue hover:bg-blue-600 text-white rounded-xl text-xs font-black transition-all flex items-center gap-1 active:scale-95 shadow-md"
          >
            <Headphones size={14} />
            <span className="hidden sm:inline">Join</span>
          </button>
          <button
            onClick={onClose}
            className="p-1.5 text-white/60 hover:text-white rounded-full hover:bg-white/10 transition-colors"
          >
            <X size={16} />
          </button>
        </div>
      </motion.div>
    </AnimatePresence>
  );
};
export default LivePopover;
