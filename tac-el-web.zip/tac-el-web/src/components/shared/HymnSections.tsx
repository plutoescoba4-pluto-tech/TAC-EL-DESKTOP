import React, { useState } from 'react';
import { ArrowUp, ArrowDown, Trash2, Plus, Wand2 } from 'lucide-react';
import type { HymnSection } from '../../types';
import { parseHymnText, sectionLabels } from '../../lib/hymnParse';

/** Shows a hymn as numbered verses and choruses, in singing order (members, presbytery, admin). */
export const HymnSectionsView: React.FC<{ sections: HymnSection[] }> = ({ sections }) => {
  const labels = sectionLabels(sections);
  if (!sections.length) return <p className="text-sm text-gray-400 italic">No lyrics yet.</p>;
  return (
    <div className="space-y-6">
      {sections.map((s, i) =>
        s.type === 'chorus' ? (
          <div key={i} className="bg-tac-blue/5 dark:bg-tac-blue/10 p-6 rounded-2xl border border-tac-blue/10 dark:border-tac-blue/20">
            <p className="text-[10px] font-black text-tac-blue italic uppercase tracking-widest mb-2 text-center">Chorus</p>
            <p className="text-xl font-serif text-tac-blue-dark dark:text-white/90 leading-relaxed text-center italic whitespace-pre-line">{s.text}</p>
          </div>
        ) : (
          <div key={i} className="space-y-2">
            <p className="text-[10px] font-black text-tac-blue/30 dark:text-white/30 uppercase tracking-widest">{labels[i]}</p>
            <p className="text-lg font-serif text-tac-blue-dark dark:text-white/80 leading-relaxed whitespace-pre-line">{s.text}</p>
          </div>
        )
      )}
    </div>
  );
};

/**
 * Admin editor: paste a whole hymn and split it into verses and choruses, then fix any part.
 * tone="dark" is for the dark blue panel inside the hymnal screen.
 */
export const HymnSectionsEditor: React.FC<{
  sections: HymnSection[];
  onChange: (s: HymnSection[]) => void;
  tone?: 'light' | 'dark';
}> = ({ sections, onChange, tone = 'light' }) => {
  const [paste, setPaste] = useState('');
  const dark = tone === 'dark';
  const field = dark
    ? 'w-full bg-white/5 border border-white/10 rounded-xl px-3 py-2.5 text-sm outline-none focus:border-white/30 font-serif text-white'
    : 'w-full bg-gray-50 dark:bg-slate-800 border border-[var(--Bdr)] rounded-xl px-3 py-2.5 text-sm outline-none focus:border-tac-blue font-serif';
  const label = dark ? 'text-[10px] font-black uppercase tracking-widest text-white/40' : 'text-[11px] font-black uppercase tracking-wider text-gray-500';
  const mini = dark ? 'p-1.5 rounded-lg bg-white/10 text-white/80 hover:bg-white/20' : 'p-1.5 rounded-lg bg-gray-100 dark:bg-white/10 text-gray-500 hover:text-tac-blue';
  const labels = sectionLabels(sections);

  const split = () => {
    const parsed = parseHymnText(paste);
    if (!parsed.length) return;
    if (sections.length && !window.confirm('Replace the parts below with the pasted hymn?')) return;
    onChange(parsed);
    setPaste('');
  };
  const update = (i: number, patch: Partial<HymnSection>) => onChange(sections.map((s, k) => (k === i ? { ...s, ...patch } : s)));
  const move = (i: number, d: number) => {
    const j = i + d;
    if (j < 0 || j >= sections.length) return;
    const next = [...sections];
    [next[i], next[j]] = [next[j], next[i]];
    onChange(next);
  };

  return (
    <div className="space-y-4">
      <div className="space-y-2">
        <label className={label}>Paste the whole hymn</label>
        <textarea rows={6} value={paste} onChange={(e) => setPaste(e.target.value)} className={field}
          placeholder={'1. First verse lines...\n\nChorus\nChorus lines...\n\n2. Second verse...\n\nChorus'} />
        <p className={dark ? 'text-[11px] text-white/50' : 'text-[11px] text-gray-500'}>
          Leave an empty line between parts. Start a part with the word <b>Chorus</b> to mark a chorus. A part that is only the word
          Chorus repeats the chorus. You can fix any part afterwards.
        </p>
        <button type="button" onClick={split} disabled={!paste.trim()}
          className={`inline-flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-black uppercase tracking-wider disabled:opacity-40 ${dark ? 'bg-white text-tac-blue-dark' : 'bg-tac-blue text-white'}`}>
          <Wand2 size={14} /> Split into verses and chorus
        </button>
      </div>

      {sections.length > 0 && (
        <div className="space-y-3">
          <label className={label}>Parts in singing order</label>
          {sections.map((s, i) => (
            <div key={i} className={`rounded-2xl p-3 space-y-2 ${s.type === 'chorus' ? (dark ? 'bg-white/10' : 'bg-tac-blue/5') : (dark ? 'bg-white/5' : 'bg-white dark:bg-slate-900 border border-[var(--Bdr)]')}`}>
              <div className="flex items-center justify-between gap-2">
                <span className={`text-[11px] font-black uppercase tracking-widest ${s.type === 'chorus' ? 'text-tac-blue italic' : (dark ? 'text-white/60' : 'text-gray-400')} ${dark && s.type === 'chorus' ? '!text-white' : ''}`}>{labels[i]}</span>
                <div className="flex items-center gap-1">
                  <button type="button" className={`${mini} text-[10px] font-black uppercase`} onClick={() => update(i, { type: s.type === 'chorus' ? 'verse' : 'chorus' })}>
                    {s.type === 'chorus' ? 'Make verse' : 'Make chorus'}
                  </button>
                  <button type="button" className={mini} onClick={() => move(i, -1)} title="Move up"><ArrowUp size={14} /></button>
                  <button type="button" className={mini} onClick={() => move(i, 1)} title="Move down"><ArrowDown size={14} /></button>
                  <button type="button" className={`${mini} !text-red-400`} onClick={() => onChange(sections.filter((_, k) => k !== i))} title="Delete this part"><Trash2 size={14} /></button>
                </div>
              </div>
              <textarea rows={Math.max(3, s.text.split('\n').length + 1)} value={s.text} onChange={(e) => update(i, { text: e.target.value })} className={field} />
            </div>
          ))}
        </div>
      )}

      <div className="flex gap-2">
        <button type="button" onClick={() => onChange([...sections, { type: 'verse', text: '' }])} className={`${mini} inline-flex items-center gap-1 px-3 text-[10px] font-black uppercase`}><Plus size={12} /> Verse</button>
        <button type="button" onClick={() => onChange([...sections, { type: 'chorus', text: '' }])} className={`${mini} inline-flex items-center gap-1 px-3 text-[10px] font-black uppercase`}><Plus size={12} /> Chorus</button>
      </div>
    </div>
  );
};
