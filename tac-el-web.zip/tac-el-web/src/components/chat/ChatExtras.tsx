import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Bell, BellOff, Ban, ShieldAlert, X } from 'lucide-react';
import { chatService, Reaction } from '../../services/chatService';
import { chatSafetyService, BLOCK_REASONS, MyBlock, MuteTarget } from '../../services/chatSafetyService';
import { notifyMutesChanged } from '../../lib/chatUnread';

/**
 * WhatsApp-style chat extras shared by the group chat and direct messages:
 * reactions, muting, blocking (with a reason that goes to the admins), and the
 * "your chat is paused" notice. The rules are enforced by the database (06b-chat-features.sql).
 */

/* ------------------------------------------------------------------ reactions */

export const QUICK_REACTIONS = ['👍', '❤️', '😂', '😮', '😢', '🙏'];

/** All reactions for the conversation, grouped by message id, kept live. */
export function useReactions(scope: 'group' | 'dm'): Record<string, Reaction[]> {
  const [byMessage, setBy] = useState<Record<string, Reaction[]>>({});
  useEffect(() => {
    const unsub = chatService.subscribeReactions(scope, (rows) => {
      const m: Record<string, Reaction[]> = {};
      rows.forEach((r) => { (m[r.messageId] ||= []).push(r); });
      setBy(m);
    });
    return () => unsub();
  }, [scope]);
  return byMessage;
}

/** The row of quick emojis shown in a message's options menu. */
export const ReactionPicker: React.FC<{ mine?: string; onPick: (emoji: string | null) => void }> = ({ mine, onPick }) => (
  <div className="flex items-center justify-between gap-1 px-2 py-2 mb-1 rounded-2xl bg-gray-50 dark:bg-white/5">
    {QUICK_REACTIONS.map((e) => (
      <button
        key={e}
        type="button"
        onClick={() => onPick(e === mine ? null : e)}
        className={`w-9 h-9 rounded-full text-xl flex items-center justify-center transition-transform active:scale-90 ${e === mine ? 'bg-tac-blue/15 ring-2 ring-tac-blue/40' : 'hover:bg-white dark:hover:bg-white/10'}`}
        aria-label={`React with ${e}`}
      >
        {e}
      </button>
    ))}
  </div>
);

/** Small emoji chips under a message. Tapping yours removes it; tapping another replaces yours. */
export const ReactionChips: React.FC<{ reactions?: Reaction[]; myId?: string; onReact: (emoji: string | null) => void }> = ({ reactions, myId, onReact }) => {
  if (!reactions || reactions.length === 0) return null;
  const counts = new Map<string, number>();
  reactions.forEach((r) => counts.set(r.emoji, (counts.get(r.emoji) || 0) + 1));
  const mine = reactions.find((r) => r.userId === myId)?.emoji;
  return (
    <div className="flex flex-wrap gap-1 mt-1">
      {[...counts.entries()].map(([emoji, n]) => (
        <button
          key={emoji}
          type="button"
          onClick={(e) => { e.stopPropagation(); onReact(emoji === mine ? null : emoji); }}
          className={`flex items-center gap-1 px-1.5 py-0.5 rounded-full text-[12px] border ${emoji === mine ? 'bg-tac-blue/10 border-tac-blue/40' : 'bg-white/70 dark:bg-white/10 border-black/10 dark:border-white/10'}`}
        >
          <span>{emoji}</span>
          {n > 1 && <span className="text-[10px] font-bold text-gray-600 dark:text-gray-300">{n}</span>}
        </button>
      ))}
    </div>
  );
};

/* --------------------------------------------------------------------- muting */

const MUTE_OPTIONS: { label: string; hours: number | null }[] = [
  { label: 'Mute for 8 hours', hours: 8 },
  { label: 'Mute for 1 week', hours: 24 * 7 },
  { label: 'Mute always', hours: null },
];

/** Bell button for the chat header. target = 'group' or the other person's id. */
export const MuteButton: React.FC<{ userId?: string; target: MuteTarget }> = ({ userId, target }) => {
  const [open, setOpen] = useState(false);
  const [muted, setMuted] = useState(false);
  const [until, setUntil] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const box = useRef<HTMLDivElement>(null);

  const load = useCallback(async () => {
    if (!userId) return;
    const m = await chatSafetyService.getMutes(userId);
    setMuted(target in m);
    setUntil(m[target] ?? null);
  }, [userId, target]);
  useEffect(() => { load(); }, [load]);
  useEffect(() => {
    if (!open) return;
    const close = (e: MouseEvent) => { if (box.current && !box.current.contains(e.target as Node)) setOpen(false); };
    document.addEventListener('mousedown', close);
    return () => document.removeEventListener('mousedown', close);
  }, [open]);

  const act = async (fn: () => Promise<void>) => {
    try { setError(null); await fn(); await load(); notifyMutesChanged(); setOpen(false); }
    catch (e: any) { setError(e.message); }
  };

  return (
    <div className="relative" ref={box}>
      <button
        type="button"
        onClick={() => setOpen(!open)}
        className={`p-2.5 rounded-full transition-all ${muted ? 'text-tac-red' : 'text-gray-400 hover:text-tac-blue'} hover:bg-gray-100 dark:hover:bg-white/5`}
        title={muted ? 'Muted' : 'Mute notifications'}
      >
        {muted ? <BellOff size={18} /> : <Bell size={18} />}
      </button>
      {open && (
        <div className="absolute right-0 top-full mt-1 z-50 w-56 bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-gray-100 dark:border-white/10 p-1.5">
          {muted && (
            <p className="px-3 py-2 text-[11px] text-gray-500">
              {until ? `Muted until ${new Date(until).toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' })}` : 'Muted always'}
            </p>
          )}
          {MUTE_OPTIONS.map((o) => (
            <button key={o.label} type="button" onClick={() => act(() => chatSafetyService.mute(userId!, target, o.hours))}
              className="w-full text-left px-3 py-2.5 text-sm font-bold rounded-xl hover:bg-gray-50 dark:hover:bg-white/5">{o.label}</button>
          ))}
          {muted && (
            <button type="button" onClick={() => act(() => chatSafetyService.unmute(userId!, target))}
              className="w-full text-left px-3 py-2.5 text-sm font-bold rounded-xl text-tac-blue hover:bg-gray-50 dark:hover:bg-white/5">Unmute</button>
          )}
          {error && <p className="px-3 py-2 text-[11px] text-tac-red">{error}</p>}
        </div>
      )}
    </div>
  );
};

/* ------------------------------------------------------------------- blocking */

/** Whether I have blocked this person right now (the other person is never told). */
export function useDmBlock(myId?: string, otherId?: string) {
  const [block, setBlock] = useState<MyBlock | null>(null);
  const refresh = useCallback(async () => {
    if (!myId || !otherId) return;
    const all = await chatSafetyService.getMyBlocks(myId);
    setBlock(all.find((b) => b.blockedId === otherId) ?? null);
  }, [myId, otherId]);
  useEffect(() => { refresh(); }, [refresh]);
  return { block, refresh };
}

/** Header button: blocks (with a reason) or, if already blocked, unblocks. */
export const BlockButton: React.FC<{ name: string; blocked: boolean; onOpen: () => void }> = ({ name, blocked, onOpen }) => (
  <button type="button" onClick={onOpen} title={blocked ? `Unblock ${name}` : `Block ${name}`}
    className={`p-2.5 rounded-full transition-all hover:bg-gray-100 dark:hover:bg-white/5 ${blocked ? 'text-tac-red' : 'text-gray-400 hover:text-tac-red'}`}>
    <Ban size={18} />
  </button>
);

export const BlockDialog: React.FC<{ name: string; onClose: () => void; onDone: () => void; otherId: string }> = ({ name, onClose, onDone, otherId }) => {
  const [reason, setReason] = useState('');
  const [note, setNote] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const confirm = async () => {
    if (!reason) { setError('Please choose a reason.'); return; }
    setBusy(true); setError(null);
    try { await chatSafetyService.blockUser(otherId, reason, note); onDone(); }
    catch (e: any) { setError(e.message); setBusy(false); }
  };

  return (
    <div className="fixed inset-0 z-[170] flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm" onClick={onClose}>
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 shadow-2xl max-w-sm w-full border border-gray-100 dark:border-white/10 max-h-[90vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-start justify-between mb-3">
          <div className="w-12 h-12 rounded-full bg-red-50 dark:bg-red-500/10 text-tac-red flex items-center justify-center"><ShieldAlert size={24} /></div>
          <button type="button" onClick={onClose} className="p-2 text-gray-400"><X size={18} /></button>
        </div>
        <h3 className="text-lg font-black text-tac-blue-dark dark:text-white mb-1">Block {name}?</h3>
        <p className="text-xs text-gray-500 dark:text-gray-400 mb-4">
          They won't be told. Their direct messages will stop reaching you. The group chat is not affected.
          Your reason and the last 5 messages between you will be sent to the church admins to review.
        </p>
        <p className="text-[10px] font-black uppercase tracking-widest text-gray-400 mb-2">Why are you blocking them?</p>
        <div className="space-y-1.5 mb-3">
          {BLOCK_REASONS.map((r) => (
            <label key={r.id} className={`flex items-center gap-3 px-3 py-2.5 rounded-xl border cursor-pointer text-sm font-semibold ${reason === r.id ? 'border-tac-blue bg-tac-blue/5' : 'border-gray-100 dark:border-white/10'}`}>
              <input type="radio" name="block-reason" className="accent-[#1d4ed8]" checked={reason === r.id} onChange={() => setReason(r.id)} />
              {r.label}
            </label>
          ))}
        </div>
        <textarea rows={3} value={note} onChange={(e) => setNote(e.target.value)} maxLength={1000} placeholder="Tell the admins more (optional)"
          className="w-full rounded-xl border border-gray-200 dark:border-white/10 bg-transparent px-3 py-2.5 text-sm outline-none focus:border-tac-blue mb-3 dark:text-white" />
        {error && <p className="text-xs text-tac-red mb-3">{error}</p>}
        <div className="grid grid-cols-2 gap-3">
          <button type="button" onClick={onClose} className="py-3 rounded-2xl bg-gray-100 dark:bg-white/5 text-gray-500 font-black text-[11px] uppercase tracking-widest">Cancel</button>
          <button type="button" onClick={confirm} disabled={busy} className="py-3 rounded-2xl bg-tac-red text-white font-black text-[11px] uppercase tracking-widest disabled:opacity-60">
            {busy ? 'Blocking…' : 'Block & report'}
          </button>
        </div>
      </div>
    </div>
  );
};

/** Shown in place of the message box while the person is blocked. */
export const BlockedBar: React.FC<{ name: string; block: MyBlock; onUnblocked: () => void }> = ({ name, block, onUnblocked }) => {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const unblock = async () => {
    setBusy(true); setError(null);
    try { await chatSafetyService.unblockUser(block.blockedId); onUnblocked(); }
    catch (e: any) { setError(e.message); setBusy(false); }
  };
  return (
    <div className="p-3 bg-red-50 dark:bg-red-500/10 border-t border-red-100 dark:border-red-500/20 text-center shrink-0 z-30">
      <p className="text-sm font-bold text-tac-red">You blocked {name}.</p>
      {block.locked ? (
        <p className="text-xs text-gray-600 dark:text-gray-300 mt-1">
          An admin is keeping this block in place{block.releaseAt ? ` until ${new Date(block.releaseAt).toLocaleDateString([], { dateStyle: 'medium' })}` : ''}.
        </p>
      ) : (
        <button type="button" onClick={unblock} disabled={busy} className="mt-1 text-xs font-black uppercase tracking-widest text-tac-blue disabled:opacity-60">
          {busy ? 'Unblocking…' : 'Unblock'}
        </button>
      )}
      {error && <p className="text-xs text-tac-red mt-1">{error}</p>}
    </div>
  );
};

/* ----------------------------------------------------------------- suspension */

/** When an admin has paused this person's chat, until when (null = not paused). */
export function useMySuspension(myId?: string): string | null {
  const [until, setUntil] = useState<string | null>(null);
  useEffect(() => {
    if (!myId) return;
    let alive = true;
    const load = () => chatSafetyService.getMySuspensionUntil(myId).then((u) => { if (alive) setUntil(u); }).catch(() => {});
    load();
    const t = setInterval(load, 5 * 60 * 1000);
    return () => { alive = false; clearInterval(t); };
  }, [myId]);
  return until;
}

export const SuspendedNotice: React.FC<{ until: string }> = ({ until }) => (
  <div className="p-3 bg-amber-50 dark:bg-amber-500/10 border-t border-amber-100 dark:border-amber-500/20 text-center shrink-0 z-30">
    <p className="text-sm font-bold text-amber-700 dark:text-amber-300">Your chat access is paused by an admin until {new Date(until).toLocaleDateString([], { dateStyle: 'medium' })}.</p>
    <p className="text-xs text-gray-500 dark:text-gray-400 mt-0.5">You can still read messages.</p>
  </div>
);
