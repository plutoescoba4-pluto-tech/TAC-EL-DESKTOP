import React, { useEffect, useState } from 'react';
import { Image as ImageIcon, Check, Sun, Moon, Smartphone, X, RotateCcw } from 'lucide-react';
import {
  useChatTheme, fetchWallpaperLibrary, uploadMyWallpaper, mergeTheme, themeVars, themeAttrs, wallpaperProps,
  BUBBLE_COLOURS, THEIRS_COLOURS, PRESET_WALLPAPERS, TEXT_LABEL, readableOn,
  type LibraryWallpaper, type TextSize, type ChatMode,
} from '../../lib/chatTheme';

/**
 * Chat look: wallpaper (church library, presets, or your own photo), bubble colours, text size, light/dark.
 *  - scope given (a chat is open): "Only this chat" switch, so one chat can look different.
 *  - no scope (Profile): changes the default for every chat.
 */
interface Props { uid?: string | null; scope?: string; scopeLabel?: string; onClose?: () => void; compact?: boolean }

const Swatch: React.FC<{ colour: string; active: boolean; onClick: () => void; label: string }> = ({ colour, active, onClick, label }) => (
  <button type="button" aria-label={label} onClick={onClick}
    className={`relative w-9 h-9 rounded-full border-2 transition-all active:scale-90 ${active ? 'border-tac-blue scale-110' : 'border-black/10'}`}
    style={{ backgroundColor: colour }}>
    {active && <Check size={16} className="absolute inset-0 m-auto" style={{ color: readableOn(colour) }} />}
  </button>
);

const ChatThemePanel: React.FC<Props> = ({ uid, scope, scopeLabel, onClose, compact }) => {
  const { theme: current, hasOverride, update, resetChat, resetAll } = useChatTheme(uid, scope);
  const { theme: defaults } = useChatTheme(uid, undefined);
  const [onlyThis, setOnlyThis] = useState<boolean>(false);
  const [library, setLibrary] = useState<LibraryWallpaper[]>([]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => { fetchWallpaperLibrary().then(setLibrary).catch(() => {}); }, []);
  useEffect(() => { if (scope && hasOverride) setOnlyThis(true); }, [scope, hasOverride]);

  const target: 'all' | 'chat' = scope && onlyThis ? 'chat' : 'all';
  const shown = target === 'chat' ? current : defaults;
  const set = (patch: Parameters<typeof update>[0]) => { setError(null); update(patch, target); };

  const upload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file || !uid) return;
    setBusy(true); setError(null);
    try { set({ wallpaper: await uploadMyWallpaper(uid, file) }); }
    catch (err: any) { setError(err?.message || 'Could not use that picture.'); }
    finally { setBusy(false); }
  };

  const label = 'text-[10px] font-black uppercase tracking-widest text-gray-400 mb-2';
  const preview = mergeTheme(defaults, target === 'chat' ? current : undefined);
  const wp = wallpaperProps(preview.wallpaper);

  return (
    <div className="space-y-5 text-left">
      {onClose && (
        <div className="flex items-center justify-between">
          <h4 className="text-sm font-black uppercase text-tac-blue tracking-widest">Chat look</h4>
          <button onClick={onClose} className="p-1.5 hover:bg-gray-100 dark:hover:bg-white/5 rounded-full" aria-label="Close"><X size={16} className="dark:text-white" /></button>
        </div>
      )}

      {scope && (
        <div className="flex rounded-xl bg-gray-100 dark:bg-white/5 p-1 text-[11px] font-black uppercase tracking-wider">
          <button type="button" onClick={() => setOnlyThis(true)} className={`flex-1 py-2 rounded-lg ${onlyThis ? 'bg-white dark:bg-slate-700 shadow text-tac-blue' : 'text-gray-500'}`}>{scopeLabel ? `Only ${scopeLabel}` : 'Only this chat'}</button>
          <button type="button" onClick={() => setOnlyThis(false)} className={`flex-1 py-2 rounded-lg ${!onlyThis ? 'bg-white dark:bg-slate-700 shadow text-tac-blue' : 'text-gray-500'}`}>All chats</button>
        </div>
      )}

      {/* live preview */}
      <div {...themeAttrs(preview)} style={themeVars(preview)} className="chat-scope rounded-2xl overflow-hidden border border-black/5">
        <div className={`p-4 space-y-2 ${wp.className} bg-[#efeae2] dark:bg-[#0b141a]`} style={wp.style}>
          <div className="flex justify-start"><div className="chat-bubble-theirs px-3 py-1.5 rounded-xl rounded-tl-none bg-white dark:bg-[#202c33] shadow-sm max-w-[75%]"><span className="chat-msg-text text-[#111b21] dark:text-slate-100">Peace be with you. See you on Sunday!</span></div></div>
          <div className="flex justify-end"><div className="chat-bubble-mine px-3 py-1.5 rounded-xl rounded-tr-none bg-[#d9fdd3] dark:bg-[#005c4b] shadow-sm max-w-[75%]"><span className="chat-msg-text text-[#111b21] dark:text-slate-100">Amen, God bless you</span></div></div>
        </div>
      </div>

      <div>
        <p className={label}>Wallpaper</p>
        <div className="grid grid-cols-4 gap-2">
          <label className="aspect-square rounded-xl border-2 border-dashed border-tac-blue/40 flex flex-col items-center justify-center gap-1 text-tac-blue cursor-pointer active:scale-95 text-center">
            <ImageIcon size={18} />
            <span className="text-[9px] font-black uppercase leading-tight px-1">{busy ? 'Saving…' : 'My photo'}</span>
            <input type="file" accept="image/*" className="hidden" onChange={upload} disabled={busy} />
          </label>
          {library.map((w) => (
            <button key={w.id} type="button" onClick={() => set({ wallpaper: w.url })} title={w.name}
              className={`aspect-square rounded-xl border-2 overflow-hidden active:scale-95 ${shown.wallpaper === w.url ? 'border-tac-blue scale-105' : 'border-black/5'}`}>
              <img src={w.url} alt={w.name} className="w-full h-full object-cover" loading="lazy" />
            </button>
          ))}
          {PRESET_WALLPAPERS.map((c) => (
            <button key={c} type="button" onClick={() => set({ wallpaper: c })} aria-label={`Colour ${c}`}
              className={`aspect-square rounded-xl border-2 active:scale-95 ${shown.wallpaper === c ? 'border-tac-blue scale-105' : 'border-black/5'}`} style={{ backgroundColor: c }} />
          ))}
        </div>
        {shown.wallpaper && <button type="button" onClick={() => set({ wallpaper: '' })} className="mt-2 text-[10px] font-black uppercase tracking-widest text-gray-400 underline">Remove wallpaper</button>}
        {error && <p className="mt-2 text-[11px] font-bold text-tac-red">{error}</p>}
      </div>

      {!compact && (
        <>
          <div>
            <p className={label}>My messages</p>
            <div className="flex flex-wrap gap-2">
              <Swatch colour="#d9fdd3" label="Default" active={!shown.mine} onClick={() => set({ mine: '' })} />
              {BUBBLE_COLOURS.map((c) => <Swatch key={c} colour={c} label={c} active={shown.mine === c} onClick={() => set({ mine: c })} />)}
            </div>
          </div>
          <div>
            <p className={label}>Other people's messages</p>
            <div className="flex flex-wrap gap-2">
              <Swatch colour="#ffffff" label="Default" active={!shown.theirs} onClick={() => set({ theirs: '' })} />
              {THEIRS_COLOURS.slice(1).map((c) => <Swatch key={c} colour={c} label={c} active={shown.theirs === c} onClick={() => set({ theirs: c })} />)}
            </div>
          </div>
        </>
      )}

      <div>
        <p className={label}>Text size</p>
        <div className="grid grid-cols-4 gap-2">
          {(Object.keys(TEXT_LABEL) as TextSize[]).map((s) => (
            <button key={s} type="button" onClick={() => set({ size: s })}
              className={`py-2.5 rounded-xl text-[11px] font-black uppercase tracking-wide border-2 ${(shown.size || 'normal') === s ? 'border-tac-blue text-tac-blue bg-tac-blue/5' : 'border-black/5 text-gray-500'}`}>{TEXT_LABEL[s]}</button>
          ))}
        </div>
      </div>

      <div>
        <p className={label}>Light or dark</p>
        <div className="grid grid-cols-3 gap-2">
          {([['app', 'Like the app', <Smartphone size={14} key="a" />], ['light', 'Light', <Sun size={14} key="l" />], ['dark', 'Dark', <Moon size={14} key="d" />]] as [ChatMode, string, React.ReactNode][]).map(([m, text, icon]) => (
            <button key={m} type="button" onClick={() => set({ mode: m })}
              className={`py-2.5 rounded-xl text-[11px] font-black uppercase tracking-wide border-2 flex items-center justify-center gap-1.5 ${(shown.mode || 'app') === m ? 'border-tac-blue text-tac-blue bg-tac-blue/5' : 'border-black/5 text-gray-500'}`}>{icon}{text}</button>
          ))}
        </div>
      </div>

      <div className="flex gap-2">
        {scope && hasOverride && (
          <button type="button" onClick={resetChat} className="flex-1 py-2.5 bg-gray-100 dark:bg-white/5 text-gray-600 dark:text-gray-300 rounded-xl text-[10px] font-black uppercase tracking-widest flex items-center justify-center gap-1.5"><RotateCcw size={12} />Use my default for this chat</button>
        )}
        <button type="button" onClick={() => { if (window.confirm('Put every chat back to the plain look?')) resetAll(); }} className="flex-1 py-2.5 bg-gray-100 dark:bg-white/5 text-gray-600 dark:text-gray-300 rounded-xl text-[10px] font-black uppercase tracking-widest">Reset everything</button>
      </div>
    </div>
  );
};

export default ChatThemePanel;
