import { pauseOthers } from '../../lib/singleAudio';
import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Mic, Pause, Play, Square, Trash2, Send, ChevronLeft, Volume2 } from 'lucide-react';
import { MAX_BINARY_FILE_BYTES } from '../../lib/image-utils';

interface WhatsAppAudioRecorderProps {
  isOpen: boolean;
  onClose: () => void;
  onSend: (audioBlob: Blob, dataUrl: string, durationSeconds: number) => void;
  onError?: (errMessage: string) => void;
  maxDurationSeconds?: number;
  /** Hold-to-record: the parent says 'send' when the finger lifts, or 'cancel' when it slid away. */
  releaseSignal?: { kind: 'send' | 'cancel'; n: number } | null;
}

export const WhatsAppAudioRecorder: React.FC<WhatsAppAudioRecorderProps> = ({
  isOpen,
  onClose,
  onSend,
  onError,
  maxDurationSeconds = 90,
  releaseSignal = null
}) => {
  const [isRecording, setIsRecording] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [isFinished, setIsFinished] = useState(false);
  const [seconds, setSeconds] = useState(0);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const [audioBlob, setAudioBlob] = useState<Blob | null>(null);
  const [isPlayingPreview, setIsPlayingPreview] = useState(false);
  const [previewProgress, setPreviewProgress] = useState(0);
  const [waveformBars, setWaveformBars] = useState<number[]>(new Array(28).fill(8));

  const streamRef = useRef<MediaStream | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const timerRef = useRef<any>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const animFrameRef = useRef<number | null>(null);
  const previewAudioRef = useRef<HTMLAudioElement | null>(null);
  // Refs mirroring isRecording/isPaused for the animation loop below — a plain
  // closure over React state here would go stale (the loop is defined once,
  // state updates don't re-create it), which was silently freezing the live
  // waveform the whole time recording was active.
  const isRecordingLiveRef = useRef(false);
  const isPausedLiveRef = useRef(false);

  useEffect(() => { isRecordingLiveRef.current = isRecording; }, [isRecording]);
  useEffect(() => { isPausedLiveRef.current = isPaused; }, [isPaused]);

  // Initialize recording when overlay opens
  useEffect(() => {
    if (isOpen) {
      startRecording();
    } else {
      cleanupAll();
    }
    return () => {
      cleanupAll();
    };
  }, [isOpen]);

  const cleanupAll = () => {
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }
    if (animFrameRef.current) {
      cancelAnimationFrame(animFrameRef.current);
      animFrameRef.current = null;
    }
    if (previewAudioRef.current) {
      previewAudioRef.current.pause();
      previewAudioRef.current = null;
    }
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      try {
        mediaRecorderRef.current.stop();
      } catch (e) {
        // ignore
      }
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(t => t.stop());
      streamRef.current = null;
    }
    if (audioContextRef.current && audioContextRef.current.state !== 'closed') {
      audioContextRef.current.close().catch(() => {});
      audioContextRef.current = null;
    }
    if (audioUrl) {
      URL.revokeObjectURL(audioUrl);
    }
    setIsRecording(false);
    setIsPaused(false);
    setIsFinished(false);
    setAudioUrl(null);
    setAudioBlob(null);
    setSeconds(0);
    setIsPlayingPreview(false);
    setPreviewProgress(0);
  };

  const startRecording = async () => {
    try {
      chunksRef.current = [];
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true,
          channelCount: 1
        }
      });
      streamRef.current = stream;

      // Audio Analyzer for Real-time Waveforms
      try {
        const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
        if (AudioCtx) {
          const audioCtx = new AudioCtx();
          audioContextRef.current = audioCtx;
          const source = audioCtx.createMediaStreamSource(stream);
          const analyser = audioCtx.createAnalyser();
          analyser.fftSize = 64;
          analyser.smoothingTimeConstant = 0.8;
          source.connect(analyser);
          analyserRef.current = analyser;

          const dataArray = new Uint8Array(analyser.frequencyBinCount);
          const updateWaveforms = () => {
            if (analyserRef.current && !isPausedLiveRef.current && isRecordingLiveRef.current) {
              analyserRef.current.getByteFrequencyData(dataArray);
              const bars: number[] = [];
              const count = 28;
              const step = Math.max(1, Math.floor(dataArray.length / count));
              for (let i = 0; i < count; i++) {
                const val = dataArray[i * step] || 0;
                // Scale height between 6px and 54px
                const height = Math.max(6, Math.min(54, (val / 255) * 54));
                bars.push(height);
              }
              setWaveformBars(bars);
            }
            animFrameRef.current = requestAnimationFrame(updateWaveforms);
          };
          animFrameRef.current = requestAnimationFrame(updateWaveforms);
        }
      } catch (err) {
        console.warn('AudioContext visualizer not supported or failed to init:', err);
      }

      // Recorder Setup
      const options: MediaRecorderOptions = {};
      if (MediaRecorder.isTypeSupported('audio/webm;codecs=opus')) {
        options.mimeType = 'audio/webm;codecs=opus';
      } else if (MediaRecorder.isTypeSupported('audio/webm')) {
        options.mimeType = 'audio/webm';
      } else if (MediaRecorder.isTypeSupported('audio/mp4')) {
        options.mimeType = 'audio/mp4';
      }
      options.audioBitsPerSecond = 32000;

      const recorder = new MediaRecorder(stream, options);
      mediaRecorderRef.current = recorder;

      recorder.ondataavailable = (e) => {
        if (e.data && e.data.size > 0) {
          chunksRef.current.push(e.data);
        }
      };

      recorder.onstop = () => {
        const mimeType = recorder.mimeType || 'audio/webm';
        const blob = new Blob(chunksRef.current, { type: mimeType });

        if (blob.size > MAX_BINARY_FILE_BYTES) {
          if (onError) {
            onError(`Voice recording is too long (${Math.round(blob.size / 1024)} KB). Maximum allowed is 6 MB. Please record a shorter note.`);
          }
          cleanupAll();
          onClose();
          return;
        }

        const url = URL.createObjectURL(blob);
        setAudioBlob(blob);
        setAudioUrl(url);
        setIsFinished(true);
        setIsRecording(false);
        setIsPaused(false);
      };

      recorder.start(250); // Slice data every 250ms
      setIsRecording(true);
      setIsPaused(false);
      setIsFinished(false);
      setSeconds(0);

      if (timerRef.current) clearInterval(timerRef.current);
      timerRef.current = setInterval(() => {
        setSeconds((prev) => {
          const next = prev + 1;
          if (next >= maxDurationSeconds) {
            // Auto stop when reaching max duration
            handleStopRecording();
          }
          return next;
        });
      }, 1000);
    } catch (err: any) {
      console.error('Failed to start recording:', err);
      if (onError) {
        onError('Could not access microphone. Please check browser permissions.');
      }
      onClose();
    }
  };

  const handlePauseResume = () => {
    if (!mediaRecorderRef.current) return;

    if (isRecording && !isPaused) {
      try {
        if (mediaRecorderRef.current.state === 'recording') {
          mediaRecorderRef.current.pause();
        }
        setIsPaused(true);
        if (timerRef.current) clearInterval(timerRef.current);
      } catch (e) {
        console.warn('Pause error:', e);
      }
    } else if (isRecording && isPaused) {
      try {
        if (mediaRecorderRef.current.state === 'paused') {
          mediaRecorderRef.current.resume();
        }
        setIsPaused(false);
        timerRef.current = setInterval(() => {
          setSeconds((prev) => {
            const next = prev + 1;
            if (next >= maxDurationSeconds) {
              handleStopRecording();
            }
            return next;
          });
        }, 1000);
      } catch (e) {
        console.warn('Resume error:', e);
      }
    }
  };

  const handleStopRecording = () => {
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }
    if (animFrameRef.current) {
      cancelAnimationFrame(animFrameRef.current);
      animFrameRef.current = null;
    }
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      try {
        mediaRecorderRef.current.stop();
      } catch (e) {
        console.warn('Stop error:', e);
      }
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(t => t.stop());
    }
  };

  const togglePreviewPlay = () => {
    if (!audioUrl) return;

    if (!previewAudioRef.current) {
      const audio = new Audio(audioUrl);
      previewAudioRef.current = audio;

      audio.ontimeupdate = () => {
        if (audio.duration) {
          setPreviewProgress((audio.currentTime / audio.duration) * 100);
        }
      };

      audio.onended = () => {
        setIsPlayingPreview(false);
        setPreviewProgress(0);
      };
    }

    if (isPlayingPreview) {
      previewAudioRef.current.pause();
      setIsPlayingPreview(false);
    } else {
      pauseOthers(previewAudioRef.current);
      previewAudioRef.current.play().then(() => {
        setIsPlayingPreview(true);
      }).catch(err => {
        console.error('Playback error:', err);
      });
    }
  };

  const handleCancelAndDiscard = () => {
    cleanupAll();
    onClose();
  };

  // Finger lifted (hold-to-record): send it, unless it was a slide-away or under a second (a slip of the thumb)
  useEffect(() => {
    if (!releaseSignal || !isOpen) return;
    if (releaseSignal.kind === 'cancel' || seconds < 1) handleCancelAndDiscard();
    else handleFinalSend();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [releaseSignal?.n]);

  const handleFinalSend = () => {
    // If still actively recording, stop and send immediately
    if (isRecording && mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      if (timerRef.current) clearInterval(timerRef.current);
      
      const currentSeconds = Math.max(1, seconds);
      const mimeType = mediaRecorderRef.current.mimeType || 'audio/webm';
      
      mediaRecorderRef.current.onstop = () => {
        const blob = new Blob(chunksRef.current, { type: mimeType });
        if (blob.size > MAX_BINARY_FILE_BYTES) {
          if (onError) onError('Audio exceeds the 6 MB limit. Please record a shorter message.');
          cleanupAll();
          onClose();
          return;
        }

        const reader = new FileReader();
        reader.onload = (e) => {
          const dataUrl = e.target?.result as string;
          onSend(blob, dataUrl, currentSeconds);
          cleanupAll();
          onClose();
        };
        reader.readAsDataURL(blob);
      };

      mediaRecorderRef.current.stop();
      if (streamRef.current) {
        streamRef.current.getTracks().forEach(t => t.stop());
      }
      return;
    }

    // If already stopped/reviewed
    if (audioBlob) {
      const reader = new FileReader();
      reader.onload = (e) => {
        const dataUrl = e.target?.result as string;
        onSend(audioBlob, dataUrl, Math.max(1, seconds));
        cleanupAll();
        onClose();
      };
      reader.readAsDataURL(audioBlob);
    }
  };

  const formatTime = (totalSecs: number) => {
    const mins = Math.floor(totalSecs / 60);
    const secs = totalSecs % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, y: 100 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: 100 }}
        transition={{ type: 'spring', damping: 25, stiffness: 280 }}
        className="fixed inset-0 z-[250] bg-[#0b141a] text-white flex flex-col justify-between font-sans select-none"
        style={{ touchAction: 'none' }}
      >
        {/* Top Header */}
        <div className="flex items-center justify-between px-5 pt-12 pb-4 border-b border-white/10 bg-[#111b21]">
          <button
            type="button"
            onClick={handleCancelAndDiscard}
            className="flex items-center gap-1.5 text-gray-300 hover:text-white px-2 py-1 -ml-2 rounded-xl active:bg-white/10 transition-colors"
          >
            <ChevronLeft size={24} />
            <span className="text-sm font-semibold">Back</span>
          </button>

          <div className="flex items-center gap-2">
            {isRecording && !isPaused && (
              <span className="w-2.5 h-2.5 rounded-full bg-red-500 animate-ping inline-block" />
            )}
            <h2 className="text-sm font-black tracking-wide uppercase text-white/90">
              {isFinished ? 'Review Audio Note' : isPaused ? 'Recording Paused' : 'Voice Message'}
            </h2>
          </div>

          <button
            type="button"
            onClick={handleCancelAndDiscard}
            className="p-2 text-gray-400 hover:text-red-400 rounded-full hover:bg-white/5 active:scale-95 transition-all"
            title="Discard recording"
          >
            <Trash2 size={20} />
          </button>
        </div>

        {/* Center Visualizer & Time Counter */}
        <div className="flex-1 flex flex-col items-center justify-center px-6 py-8">
          {/* Glowing Microphone Bubble */}
          <div className="relative mb-6">
            <motion.div
              animate={{
                scale: isRecording && !isPaused ? [1, 1.15, 1] : 1,
                boxShadow: isRecording && !isPaused 
                  ? ['0 0 0 0 rgba(37, 211, 102, 0.4)', '0 0 0 25px rgba(37, 211, 102, 0)', '0 0 0 0 rgba(37, 211, 102, 0)']
                  : '0 0 0 0 rgba(0,0,0,0)'
              }}
              transition={{ repeat: Infinity, duration: 1.8, ease: 'easeInOut' }}
              className={`w-28 h-28 sm:w-32 sm:h-32 rounded-full flex items-center justify-center text-white shadow-2xl transition-colors ${
                isFinished 
                  ? 'bg-[#00a884]' 
                  : isPaused 
                  ? 'bg-amber-500' 
                  : 'bg-[#25D366]'
              }`}
            >
              {isFinished ? (
                <Volume2 size={48} className="animate-pulse" />
              ) : (
                <Mic size={48} />
              )}
            </motion.div>
          </div>

          {/* Time Counter */}
          <div className="flex items-center gap-3 mb-4">
            <div className={`w-3 h-3 rounded-full ${isPaused ? 'bg-amber-400' : isFinished ? 'bg-emerald-400' : 'bg-red-500 animate-pulse'}`} />
            <span className="text-4xl sm:text-5xl font-black tabular-nums tracking-wider text-white">
              {formatTime(seconds)}
            </span>
          </div>

          {/* Status Label */}
          <p className="text-xs font-bold uppercase tracking-widest text-white/50 mb-8">
            {isFinished 
              ? 'Ready to send • Listen or record again' 
              : isPaused 
              ? 'Paused • Tap mic to resume' 
              : `Recording... (${maxDurationSeconds - seconds}s max limit)`}
          </p>

          {/* WhatsApp Audio Waveform Display */}
          <div className="w-full max-w-md bg-[#111b21] border border-white/10 rounded-3xl p-5 shadow-2xl">
            {isFinished && audioUrl ? (
              // Playback Preview Controls
              <div className="flex items-center gap-4">
                <button
                  type="button"
                  onClick={togglePreviewPlay}
                  className="w-14 h-14 rounded-full bg-[#00a884] text-white flex items-center justify-center shrink-0 shadow-lg active:scale-95 transition-all"
                >
                  {isPlayingPreview ? <Pause size={24} /> : <Play size={24} className="ml-1" />}
                </button>
                <div className="flex-1">
                  <div className="h-2 bg-white/10 rounded-full overflow-hidden relative">
                    <div 
                      className="h-full bg-[#00a884] transition-all duration-150"
                      style={{ width: `${previewProgress}%` }}
                    />
                  </div>
                  <div className="flex justify-between text-[11px] text-white/50 font-bold mt-2">
                    <span>{isPlayingPreview ? 'Playing voice note' : 'Tap to preview audio'}</span>
                    <span>{formatTime(seconds)}</span>
                  </div>
                </div>
              </div>
            ) : (
              // Live Interactive Soundwaves
              <div>
                <div className="h-16 flex items-center justify-between gap-1 px-1">
                  {waveformBars.map((height, i) => (
                    <div
                      key={i}
                      className={`w-1.5 sm:w-2 rounded-full transition-all duration-75 ${
                        isPaused 
                          ? 'bg-amber-400/50' 
                          : isRecording 
                          ? 'bg-[#25D366]' 
                          : 'bg-white/20'
                      }`}
                      style={{
                        height: isPaused ? '10px' : `${height}px`,
                        opacity: isRecording ? Math.min(1, 0.4 + height / 50) : 0.3
                      }}
                    />
                  ))}
                </div>
                <div className="flex justify-between items-center text-[10px] uppercase font-bold tracking-widest text-white/40 pt-2 border-t border-white/5 mt-2">
                  <span>Sound Waveforms</span>
                  <span>Audio Level</span>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Bottom Mobile Action Buttons Bar */}
        <div className="bg-[#111b21] border-t border-white/10 px-6 py-6 pb-10">
          <div className="max-w-md mx-auto flex items-center justify-between gap-4">
            {/* Discard / Delete */}
            <button
              type="button"
              onClick={handleCancelAndDiscard}
              className="flex flex-col items-center gap-1.5 text-gray-400 hover:text-red-400 p-2 active:scale-90 transition-transform"
            >
              <div className="w-12 h-12 rounded-full bg-white/5 border border-white/10 flex items-center justify-center">
                <Trash2 size={20} />
              </div>
              <span className="text-[10px] font-bold uppercase tracking-wider">Discard</span>
            </button>

            {/* Middle Control: Pause/Resume if recording, or Stop if active */}
            {!isFinished ? (
              <div className="flex items-center gap-3">
                {/* Pause / Resume */}
                <button
                  type="button"
                  onClick={handlePauseResume}
                  className="flex flex-col items-center gap-1.5 text-gray-300 p-2 active:scale-90 transition-transform"
                >
                  <div className={`w-12 h-12 rounded-full flex items-center justify-center border ${
                    isPaused ? 'bg-amber-500/20 border-amber-500 text-amber-400' : 'bg-white/5 border-white/10 text-white'
                  }`}>
                    {isPaused ? <Play size={20} className="ml-0.5" /> : <Pause size={20} />}
                  </div>
                  <span className="text-[10px] font-bold uppercase tracking-wider">
                    {isPaused ? 'Resume' : 'Pause'}
                  </span>
                </button>

                {/* Stop & Review */}
                <button
                  type="button"
                  onClick={handleStopRecording}
                  className="flex flex-col items-center gap-1.5 text-gray-300 p-2 active:scale-90 transition-transform"
                >
                  <div className="w-12 h-12 rounded-full bg-red-500/10 border border-red-500/30 text-red-400 flex items-center justify-center">
                    <Square size={18} />
                  </div>
                  <span className="text-[10px] font-bold uppercase tracking-wider">Stop</span>
                </button>
              </div>
            ) : (
              // If finished, option to record again
              <button
                type="button"
                onClick={() => {
                  cleanupAll();
                  startRecording();
                }}
                className="flex flex-col items-center gap-1.5 text-gray-300 p-2 active:scale-90 transition-transform"
              >
                <div className="w-12 h-12 rounded-full bg-white/5 border border-white/10 flex items-center justify-center">
                  <Mic size={20} />
                </div>
                <span className="text-[10px] font-bold uppercase tracking-wider">Re-record</span>
              </button>
            )}

            {/* Send Button */}
            <button
              type="button"
              onClick={handleFinalSend}
              className="flex flex-col items-center gap-1.5 active:scale-95 transition-transform"
            >
              <div className="w-14 h-14 rounded-full bg-[#00a884] text-white flex items-center justify-center shadow-lg shadow-[#00a884]/30 hover:bg-[#029676]">
                <Send size={24} className="ml-0.5" />
              </div>
              <span className="text-[10px] font-black uppercase tracking-wider text-[#25D366]">Send</span>
            </button>
          </div>
        </div>
      </motion.div>
    </AnimatePresence>
  );
};
