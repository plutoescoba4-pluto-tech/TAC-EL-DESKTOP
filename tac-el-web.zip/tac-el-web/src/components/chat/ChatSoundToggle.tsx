import React, { useState } from 'react';
import { Volume2, VolumeX } from 'lucide-react';
import { isChatSoundOn, setChatSoundOn, playMessageSound } from '../../lib/chatSound';

/** Small header button to mute/unmute the new-message sound (per device). */
export const ChatSoundToggle: React.FC = () => {
  const [on, setOn] = useState(isChatSoundOn());
  return (
    <button
      onClick={() => {
        const next = !on;
        setChatSoundOn(next);
        setOn(next);
        if (next) playMessageSound(); // preview so it's obvious what you turned on
      }}
      className="p-2.5 text-gray-400 hover:text-tac-blue hover:bg-gray-50 dark:hover:bg-white/5 rounded-full transition-all"
      title={on ? 'Mute message sounds' : 'Unmute message sounds'}
    >
      {on ? <Volume2 size={18} /> : <VolumeX size={18} />}
    </button>
  );
};
export default ChatSoundToggle;
