import React, { useState, useEffect, useRef } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { motion, AnimatePresence, useDragControls } from 'motion/react';
import { 
  Book, 
  Search, 
  X, 
  MessageSquare, 
  Sparkles, 
  ChevronRight,
  Send,
  Zap,
  BookOpen,
  History,
  Trash2,
  Heart,
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  ExternalLink
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { localCollection } from '../lib/localCollection';

import { bibleData, BIBLE_BOOKS, BIBLE_CHAPTER_COUNTS } from '../data/bibleData';
import { trackActivity, getMemberContext, clearMemberHistory } from '../services/memberMemoryService';

const FloatingAssistiveTab: React.FC = () => {
  const { user, profile } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [isOpen, setIsOpen] = useState(false);
  const [activeMode, setActiveMode] = useState<'menu' | 'bible' | 'seek'>('menu');
  const [bibleVersion, setBibleVersion] = useState('kjv');
  const [currentBook, setCurrentBook] = useState('Genesis');
  const [currentChapter, setCurrentChapter] = useState(1);
  const [bibleId, setBibleId] = useState('de4e12af7f28f599-01'); // Default KJV
  const [bibleContent, setBibleContent] = useState<{number: number, text: string}[]>([]);
  const [isLoadingBible, setIsLoadingBible] = useState(false);
  const [chatMessages, setChatMessages] = useState<{role: 'user' | 'model', content: string}[]>([]);
  const [suggestions, setSuggestions] = useState<{verses: any[], topics: string[], questions: string[]} | null>(null);
  const [isLoadingSuggestions, setIsLoadingSuggestions] = useState(false);
  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [activeModel, setActiveModel] = useState<string | null>(null);
  const [hasNewReminder, setHasNewReminder] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [speakingMessageIndex, setSpeakingMessageIndex] = useState<number | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  const recognitionRef = useRef<any>(null);

  // Fetch Bible Content
  useEffect(() => {
    const fetchBible = async () => {
      setIsLoadingBible(true);
      try {
        // We need to get the book ID first (Genesis -> GEN)
        // For simplicity, we'll use a mapping or just assume standard abbreviations
        const bookMap: {[key: string]: string} = {
          'Genesis': 'GEN', 'Exodus': 'EXO', 'Leviticus': 'LEV', 'Numbers': 'NUM', 'Deuteronomy': 'DEU',
          'Joshua': 'JOS', 'Judges': 'JDG', 'Ruth': 'RUT', '1 Samuel': '1SA', '2 Samuel': '2SA',
          '1 Kings': '1KI', '2 Kings': '2KI', '1 Chronicles': '1CH', '2 Chronicles': '2CH',
          'Ezra': 'EZR', 'Nehemiah': 'NEH', 'Esther': 'EST', 'Job': 'JOB', 'Psalms': 'PSA',
          'Proverbs': 'PRO', 'Ecclesiastes': 'ECC', 'Song of Solomon': 'SNG', 'Isaiah': 'ISA',
          'Jeremiah': 'JER', 'Lamentations': 'LAM', 'Ezekiel': 'EZK', 'Daniel': 'DAN',
          'Hosea': 'HOS', 'Joel': 'JOE', 'Amos': 'AMO', 'Obadiah': 'OBA', 'Jonah': 'JON',
          'Micah': 'MIC', 'Nahum': 'NAM', 'Habakkuk': 'HAB', 'Zephaniah': 'ZEP', 'Haggai': 'HAG',
          'Zechariah': 'ZEC', 'Malachi': 'MAL', 'Matthew': 'MAT', 'Mark': 'MRK', 'Luke': 'LUK',
          'John': 'JHN', 'Acts': 'ACT', 'Romans': 'ROM', '1 Corinthians': '1CO', '2 Corinthians': '2CO',
          'Galatians': 'GAL', 'Ephesians': 'EPH', 'Philippians': 'PHP', 'Colossians': 'COL',
          '1 Thessalonians': '1TH', '2 Thessalonians': '2TH', '1 Timothy': '1TI', '2 Timothy': '2TI',
          'Titus': 'TIT', 'Philemon': 'PHM', 'Hebrews': 'HEB', 'James': 'JAS', '1 Peter': '1PE',
          '2 Peter': '2PE', '1 John': '1JN', '2 John': '2JN', '3 John': '3JN', 'Jude': 'JUD',
          'Revelation': 'REV'
        };

        const bookId = bookMap[currentBook] || currentBook.substring(0, 3).toUpperCase();
        const chapterId = `${bookId}.${currentChapter}`;
        
        // Use our proxy
        const response = await fetch(`/api/bible/bibles/${bibleId}/chapters/${chapterId}?content-type=json`);
        const data = await response.json();

        // Check for our simplified fallback format first (from server)
        if (data.data?.simplifiedVerses) {
          setBibleContent(data.data.simplifiedVerses);
          setIsLoadingBible(false);
          return;
        }

        if (data.data?.content) {
          // api.bible returns complex content, we need to extract verses
          // This handles both the real API format and some common variations
          let verses: {number: number, text: string}[] = [];
          
          if (Array.isArray(data.data.content)) {
            verses = data.data.content.flatMap((c: any) => {
              if (c.type === 'tag' && c.name === 'para') {
                return (c.items || []).filter((i: any) => i.type === 'verse').map((v: any) => ({
                  number: parseInt(v.attrs?.number || "0"),
                  text: (v.items || []).filter((it: any) => it.type === 'text').map((it: any) => it.text).join('')
                }));
              }
              return [];
            });
          } else if (typeof data.data.content === 'string') {
            // Handle HTML content if that's what we got
            const div = document.createElement('div');
            div.innerHTML = data.data.content;
            const paragraphs = div.querySelectorAll('p');
            paragraphs.forEach(p => {
              const vRange = p.querySelectorAll('.v');
              vRange.forEach(v => {
                const num = parseInt(v.textContent || '0');
                const text = v.nextSibling?.textContent || '';
                if (num > 0) verses.push({ number: num, text });
              });
            });
          }
          
          if (verses.length > 0) {
            setBibleContent(verses);
            setIsLoadingBible(false);
            return;
          }
        }

        // Fallback to bible-api.com if proxy fails or returns nothing
        const ver = bibleVersion.toLowerCase();
        const fallbackRes = await fetch(`https://bible-api.com/${currentBook}+${currentChapter}?translation=${ver}`);
        const fallbackData = await fallbackRes.json();
        
        if (fallbackData.verses) {
          setBibleContent(fallbackData.verses.map((v: any) => ({ number: v.verse, text: v.text })));
          return;
        }

        // If we reach here, we have no content
        setBibleContent([{ number: 0, text: "Scripture selection currently unavailable. Please try another version or book." }]);

      } catch (error) {
        console.error("Bible fetch error:", error);
      } finally {
        setIsLoadingBible(false);
      }
    };

    if (activeMode === 'bible') {
      fetchBible();
    }
  }, [bibleId, currentBook, currentChapter, activeMode]);

  // iPhone-style floating menu dimensions vs Full Screen dimensions
  const isFullScreen = activeMode !== 'menu';
  
  const currentBibleContent = bibleData[bibleVersion]?.books[currentBook]?.chapters[currentChapter];
  
  // Kin AI's chat history has no table yet (see MIGRATION_NOTES.md) —
  // stored locally per device via localCollection, oldest-first to match
  // the conversation's natural reading order.
  useEffect(() => {
    if (!user) return;
    const stored = localCollection.list<any>(user.id, 'seek_chat').slice().reverse();
    setChatMessages(stored.map(m => ({ role: m.role, content: m.content })));
  }, [user]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [chatMessages, isTyping]);

  useEffect(() => {
    // Basic reminder simulation
    const checkReminders = () => {
       const now = new Date();
       const hour = now.getHours();
       const lastReminder = localStorage.getItem('last_prayer_reminder');
       const today = now.toDateString();
       
       if (lastReminder !== today) {
          // Check for Morning (6-9), Afternoon (12-14), Night (20-22)
          if ((hour >= 6 && hour <= 9) || (hour >= 12 && hour <= 14) || (hour >= 20 && hour <= 22)) {
             setHasNewReminder(true);
             localStorage.setItem('last_prayer_reminder', today);
          }
       }
    };
    
    const interval = setInterval(checkReminders, 60000);
    checkReminders();
    return () => clearInterval(interval);
  }, []);

  // Voice Recognition Setup
  useEffect(() => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRecognition) {
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.continuous = false;
      recognitionRef.current.interimResults = false;
      recognitionRef.current.lang = 'en-US';

      recognitionRef.current.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        setInputText(transcript);
        setIsRecording(false);
      };

      recognitionRef.current.onerror = (event: any) => {
        console.error('Speech recognition error:', event.error);
        setIsRecording(false);
      };

      recognitionRef.current.onend = () => {
        setIsRecording(false);
      };
    }
  }, []);

  const toggleRecording = () => {
    if (!recognitionRef.current) {
      console.warn("Speech recognition is not supported in your browser.");
      return;
    }

    if (isRecording) {
      recognitionRef.current.stop();
    } else {
      recognitionRef.current.start();
      setIsRecording(true);
    }
  };

  const speakText = (text: string, index: number) => {
    if (speakingMessageIndex === index) {
      window.speechSynthesis.cancel();
      setSpeakingMessageIndex(null);
      return;
    }

    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 1.15; // Brisk, responsive pace
    utterance.pitch = 1.05; // Slightly clearer tone
    
    // Choose a pleasant voice if available
    const voices = window.speechSynthesis.getVoices();
    const preferredVoice = voices.find(v => v.name.includes('Google') || v.name.includes('Premium')) || voices[0];
    if (preferredVoice) utterance.voice = preferredVoice;

    utterance.onend = () => setSpeakingMessageIndex(null);
    utterance.onerror = () => setSpeakingMessageIndex(null);

    setSpeakingMessageIndex(index);
    window.speechSynthesis.speak(utterance);
  };

  const speakVerse = (number: number, text: string) => {
    const fullText = `Verse ${number}. ${text}`;
    const utterance = new SpeechSynthesisUtterance(fullText);
    utterance.rate = 1.0;
    utterance.pitch = 1.0;
    
    // Choose a clear voice
    const voices = window.speechSynthesis.getVoices();
    const preferredVoice = voices.find(v => v.name.includes('Google') || v.name.includes('Premium') || v.lang === 'en-GB') || voices[0];
    if (preferredVoice) utterance.voice = preferredVoice;

    window.speechSynthesis.cancel();
    window.speechSynthesis.speak(utterance);
    setSpeakingMessageIndex(number + 1000); // Use offset for bible verses
  };

  const speakChapter = () => {
    if (bibleContent.length === 0) return;
    const fullText = `${currentBook} Chapter ${currentChapter}. ` + bibleContent.map(v => `Verse ${v.number}. ${v.text}`).join(' ');
    const utterance = new SpeechSynthesisUtterance(fullText);
    utterance.rate = 1.0;

    window.speechSynthesis.cancel();
    window.speechSynthesis.speak(utterance);
    setSpeakingMessageIndex(999); // Magic index for whole chapter
  };

  const stopSpeaking = () => {
    window.speechSynthesis.cancel();
    setSpeakingMessageIndex(null);
  };

  const saveFavorite = async (question: string, answer: string) => {
    if (!user) return;
    try {
      localCollection.add(user.id, 'seek_favorites', { question, answer });
      // Silent success or subtle feedback could go here
    } catch (e) {
      console.error("Save favorite error:", e);
    }
  };

  const navigateToVerse = (reference: string) => {
    // Basic parser for "Book Chapter:Verse"
    const parts = reference.match(/((?:[123]\s?)?[A-Z][a-z]+(?:\s[A-Z][a-z]+)?)\s(\d+):(\d+)/);
    if (parts) {
      const book = parts[1];
      const chapter = parseInt(parts[2]);
      if (BIBLE_BOOKS.includes(book as any)) {
        setCurrentBook(book);
        setCurrentChapter(chapter);
        setActiveMode('bible');
      }
    }
  };

  const renderMessageContent = (content: string) => {
    // Regex for common Bible references like John 3:16 or 1 John 1:9
    const verseRegex = /\b(?:[123]\s?)?[A-Z][a-z]+(?:\s[A-Z][a-z]+)?\s\d{1,3}:\d{1,3}\b/g;
    const parts = content.split(verseRegex);
    const matches = content.match(verseRegex);

    if (!matches) return content;

    const elements: React.ReactNode[] = [];
    parts.forEach((part, i) => {
      elements.push(part);
      if (matches[i]) {
        elements.push(
          <button
            key={i}
            onClick={() => navigateToVerse(matches[i])}
            className="text-tac-blue dark:text-tac-gold font-black underline decoration-dotted underline-offset-4 hover:opacity-70 transition-opacity mx-1 cursor-pointer"
          >
            {matches[i]}
          </button>
        );
      }
    });

    return elements;
  };

  useEffect(() => {
    if (activeMode === 'seek' && user) {
      fetchSuggestions();
    }
  }, [activeMode, user]);

  const fetchSuggestions = async () => {
    if (!user) return;
    setIsLoadingSuggestions(true);
    try {
      const context = await getMemberContext(user.id);
      if (!context) {
        setIsLoadingSuggestions(false);
        return;
      }
      const res = await fetch('/api/seek/suggestions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ memberContext: context })
      });
      const data = await res.json();
      setSuggestions(data);
    } catch (err) {
      console.error("Fetch suggestions error:", err);
    } finally {
      setIsLoadingSuggestions(false);
    }
  };

  const handleSeek = async (overrideMsg?: string) => {
    const userMsg = (overrideMsg || inputText).trim();
    if (!userMsg) return;
    
    setInputText('');
    setIsTyping(true);
    setActiveModel(null);

    if (user) {
      // Track question
      trackActivity(user.id, 'question', { question: userMsg, timestamp: new Date().toISOString() });
      
      localCollection.add(user.id, 'seek_chat', { role: 'user', content: userMsg });
    }

    try {
      // Get Member Context
      const memberContext = user ? await getMemberContext(user.id) : null;
      
      const res = await fetch('/api/seek/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: userMsg,
          history: chatMessages.slice(-10), // Keep session history
          memberContext
        })
      });

      const data = await res.json();
      
      if (!res.ok) {
        throw new Error(data.error || `Server responded with ${res.status}`);
      }

      const responseText = data.text || "I am reflecting on the word...";
      setActiveModel(data.model || null);
      
      if (user) {
        // Track answer in memory
        trackActivity(user.id, 'question', { question: userMsg, answer: responseText, timestamp: new Date().toISOString() });
        
        localCollection.add(user.id, 'seek_chat', { role: 'model', content: responseText });
      } else {
        setChatMessages(prev => [...prev, { role: 'model', content: responseText }]);
      }
    } catch (err) {
      console.error("Seek Error:", err);
      const fallbackMsg = "Connecting...";
      if (user) {
        localCollection.add(user.id, 'seek_chat', { role: 'model', content: fallbackMsg });
      }
      // Re-trigger silently if it's a silent error
      setTimeout(() => handleSeek(userMsg), 3000);
    } finally {
      setIsTyping(false);
    }
  };

  const [isDeleting, setIsDeleting] = useState(false);

  // Mark session on open
  useEffect(() => {
    if (isOpen && user) {
      trackActivity(user.id, 'session', {});
    }
  }, [isOpen, user]);

  const clearHistory = async () => {
    try {
      if (user) {
        localCollection.clear(user.id, 'seek_chat');
        await clearMemberHistory(user.id);
      }
      setChatMessages([]);
      setIsDeleting(false);
    } catch (e) {
      console.error(e);
      setChatMessages([]);
      setIsDeleting(false);
    }
  };

  return (
    <>
      {/* Delete Confirmation Modal for Chat History */}
      <AnimatePresence>
        {isDeleting && (
          <div className="fixed inset-0 z-[10000] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
             <motion.div 
               initial={{ scale: 0.9, opacity: 0 }}
               animate={{ scale: 1, opacity: 1 }}
               exit={{ scale: 0.9, opacity: 0 }}
               className="bg-white dark:bg-slate-900 rounded-[2.5rem] p-8 shadow-2xl max-w-sm w-full border border-gray-100 dark:border-white/10"
             >
                <div className="w-16 h-16 bg-red-50 dark:bg-red-500/10 text-tac-red rounded-full flex items-center justify-center mx-auto mb-6">
                   <Trash2 size={32} />
                </div>
                <h3 className="text-xl font-black text-tac-blue-dark dark:text-white uppercase tracking-widest text-center mb-2">Clear History?</h3>
                <p className="text-sm text-gray-500 dark:text-gray-400 text-center mb-8 font-medium">This will permanently delete your conversation with Seek AI.</p>
                <div className="grid grid-cols-2 gap-4">
                   <button 
                     onClick={() => setIsDeleting(false)}
                     className="py-4 bg-gray-100 dark:bg-white/5 text-gray-500 rounded-2xl font-black uppercase text-[10px] tracking-widest hover:bg-gray-200 transition-all font-sans"
                   >
                     Cancel
                   </button>
                   <button 
                     onClick={clearHistory}
                     className="py-4 bg-tac-red text-white rounded-2xl font-black uppercase text-[10px] tracking-widest shadow-lg shadow-tac-red/20 hover:scale-105 active:scale-95 transition-all font-sans"
                   >
                     Clear All
                   </button>
                </div>
             </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* The Floating Trigger Button */}
      {!isOpen && (
        <div className="fixed bottom-20 right-5 sm:right-8 z-[9900]">
          <motion.div
            drag
            dragConstraints={{ left: -300, right: 0, top: -600, bottom: 0 }}
            whileHover={{ scale: 1.08 }}
            whileTap={{ scale: 0.92 }}
            onClick={() => {
              setIsOpen(true);
              setHasNewReminder(false);
            }}
            className="w-14 h-14 bg-tac-blue-dark shadow-2xl rounded-2xl flex items-center justify-center cursor-pointer border border-white/20 group relative hover:border-tac-gold/50 transition-all"
            title="Open Holy Bible & Seek AI Assistant"
          >
            <BookOpen className="text-white group-hover:rotate-12 transition-transform" size={24} />
            {/* Notification Dot */}
            {hasNewReminder && (
              <div className="absolute -top-1 -right-1 w-4 h-4 bg-tac-red rounded-full border-2 border-white animate-pulse shadow-lg" />
            )}
          </motion.div>
        </div>
      )}

      {/* The Expanded Modal View with Backdrop */}
      <AnimatePresence>
        {isOpen && (
          <div className="fixed inset-0 z-[9990] flex items-center justify-center p-3 sm:p-6 overflow-hidden">
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsOpen(false)}
              className="absolute inset-0 bg-black/60 backdrop-blur-md"
            />

            {/* Modal Card */}
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              transition={{ type: "spring", damping: 25, stiffness: 300 }}
              className={`relative z-[9995] bg-white dark:bg-slate-900 shadow-2xl border border-gray-100 dark:border-white/10 overflow-hidden flex flex-col w-full ${
                activeMode === 'menu' 
                  ? 'max-w-md h-auto max-h-[85vh] rounded-[2rem]' 
                  : 'max-w-4xl h-[90vh] sm:h-[85vh] max-h-[850px] rounded-[2rem] sm:rounded-[2.5rem]'
              }`}
            >
              {/* Main Modal Header */}
              <div className="px-4 sm:px-5 py-3.5 sm:py-4 bg-tac-blue-dark text-white flex items-center justify-between shrink-0 shadow-md sticky top-0 z-30">
                 <div className="flex items-center gap-3">
                    {activeMode !== 'menu' && (
                      <button 
                        onClick={() => setActiveMode('menu')}
                        className="p-1.5 hover:bg-white/10 rounded-xl transition-colors flex items-center gap-1 group"
                        title="Back to menu"
                      >
                        <ChevronRight size={20} className="rotate-180 group-hover:-translate-x-0.5 transition-transform" />
                        <span className="text-[10px] font-black uppercase tracking-widest hidden sm:inline">Menu</span>
                      </button>
                    )}
                    <div className="w-9 h-9 bg-white/10 rounded-xl flex items-center justify-center">
                      {activeMode === 'menu' ? <Sparkles size={18} className="text-tac-gold" /> : 
                       activeMode === 'bible' ? <BookOpen size={18} /> : <Zap size={18} className="text-tac-gold" />}
                    </div>
                    <div>
                      <h3 className="font-black uppercase tracking-widest text-[11px] leading-none mb-1">
                        {activeMode === 'menu' ? 'Build In Christ Assistant' : 
                         activeMode === 'bible' ? 'Holy Bible Reader' : 'Seek AI Assistant'}
                      </h3>
                      <p className="text-[9px] text-white/50 font-bold uppercase tracking-widest leading-none">
                        {activeMode === 'menu' ? 'Select scripture or AI guidance' : 
                         activeMode === 'bible' ? 'The Word of God' : 'Scriptural Guidance & Answers'}
                      </p>
                    </div>
                 </div>

                 <div className="flex items-center gap-2">
                   {activeMode === 'bible' && (
                     <button
                       onClick={() => setActiveMode('seek')}
                       className="px-3 py-1.5 bg-tac-red hover:bg-red-600 text-white text-[9px] font-black uppercase tracking-widest rounded-xl flex items-center gap-1.5 transition-all shadow-md active:scale-95"
                     >
                       <Zap size={12} />
                       <span className="hidden sm:inline">Seek AI</span>
                     </button>
                   )}
                   {activeMode === 'seek' && (
                     <button
                       onClick={() => setActiveMode('bible')}
                       className="px-3 py-1.5 bg-tac-blue hover:bg-blue-600 text-white text-[9px] font-black uppercase tracking-widest rounded-xl flex items-center gap-1.5 transition-all shadow-md active:scale-95"
                     >
                       <BookOpen size={12} />
                       <span className="hidden sm:inline">Bible</span>
                     </button>
                   )}
                   <button 
                     onClick={() => {
                       setIsOpen(false);
                       setActiveMode('menu');
                     }}
                     className="p-2 hover:bg-white/10 rounded-full transition-colors text-white/80 hover:text-white"
                     title="Close"
                   >
                     <X size={20} />
                   </button>
                 </div>
              </div>

              {/* Main Content Area */}
              <div className="flex-1 overflow-hidden relative flex flex-col">
                 {/* Top Reading Audio Status */}
                 <AnimatePresence>
                    {speakingMessageIndex !== null && (
                      <motion.div 
                        initial={{ y: -50, opacity: 0 }}
                        animate={{ y: 0, opacity: 1 }}
                        exit={{ y: -50, opacity: 0 }}
                        className="bg-tac-blue text-white py-2 px-5 flex items-center justify-between z-[40] shadow-md shrink-0"
                      >
                         <div className="flex items-center gap-3">
                            <Volume2 size={16} className="animate-pulse" />
                            <span className="text-[10px] font-black uppercase tracking-widest">
                              {speakingMessageIndex === 999 ? `Reading ${currentBook} ${currentChapter}` : 'Reading Scripture Verse'}
                            </span>
                         </div>
                         <button onClick={stopSpeaking} className="p-1 hover:bg-white/20 rounded-full transition-colors">
                            <X size={16} />
                         </button>
                      </motion.div>
                    )}
                 </AnimatePresence>

                 <AnimatePresence mode="wait">
                    {/* MENU MODE */}
                    {activeMode === 'menu' && (
                      <motion.div
                        key="menu"
                        initial={{ opacity: 0, scale: 0.98 }}
                        animate={{ opacity: 1, scale: 1 }}
                        exit={{ opacity: 0, scale: 0.98 }}
                        className="p-6 space-y-4 overflow-y-auto"
                      >
                         <MenuOption 
                           icon={<BookOpen size={24} className="text-tac-blue" />}
                           title="The Holy Bible"
                           desc="Read scriptures in KJV, Akuapem Twi, Ga, and ASV."
                           onClick={() => setActiveMode('bible')}
                         />
                         <MenuOption 
                           icon={<Zap size={24} className="text-tac-red" />}
                           title="Seek AI Assistant"
                           desc="Ask questions, get biblical guidance and prayers."
                           onClick={() => setActiveMode('seek')}
                         />
                         
                         <div className="p-5 bg-gray-50 dark:bg-white/5 rounded-3xl border border-dashed border-gray-200 dark:border-white/10">
                            <div className="flex items-center gap-2 mb-2">
                               <Heart size={18} className="text-tac-gold" />
                               <h4 className="text-[10px] font-black uppercase text-tac-blue tracking-widest">Assembly Prayer Notice</h4>
                            </div>
                            <p className="text-xs text-gray-500 dark:text-gray-400 font-medium leading-relaxed">Join the global assembly prayer room or meditate on today's scripture.</p>
                         </div>
                      </motion.div>
                    )}

                    {/* BIBLE MODE */}
                    {activeMode === 'bible' && (
                      <motion.div
                        key="bible"
                        initial={{ opacity: 0, x: 20 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: -20 }}
                        className="flex flex-col h-full bg-white dark:bg-slate-900 overflow-hidden"
                      >
                          {/* Bible Controls Header */}
                          <div className="p-3 border-b border-gray-100 dark:border-white/10 flex flex-wrap items-center justify-between gap-2 bg-gray-50 dark:bg-white/5 shrink-0 z-20">
                             <div className="flex items-center gap-1.5 flex-wrap">
                                <select 
                                  value={bibleId}
                                  onChange={(e) => setBibleId(e.target.value)}
                                  className="bg-tac-blue/10 text-tac-blue border-none text-[9px] font-black uppercase tracking-tight outline-none cursor-pointer hover:bg-tac-blue/20 px-2.5 py-1.5 rounded-lg transition-colors"
                                >
                                   <optgroup label="English">
                                      <option value="de4e12af7f28f599-01">KJV</option>
                                      <option value="06125adad2d5898a-01">ASV</option>
                                      <option value="65eec8e0b60e656b-01">FBV</option>
                                      <option value="9879dbb7cfe39e4d-01">WEB</option>
                                   </optgroup>
                                   <optgroup label="Ghana Languages">
                                      <option value="asw">Akuapem Twi</option>
                                      <option value="gab">Ga Bible</option>
                                   </optgroup>
                                </select>
                                
                                <select 
                                  value={currentBook}
                                  onChange={(e) => { setCurrentBook(e.target.value); setCurrentChapter(1); }}
                                  className="bg-black/5 dark:bg-white/10 text-tac-blue-dark dark:text-white border-none text-[9px] font-black uppercase tracking-tight outline-none cursor-pointer hover:bg-black/10 px-2.5 py-1.5 rounded-lg transition-colors"
                                >
                                   {BIBLE_BOOKS.map(book => (
                                     <option key={book} value={book}>{book}</option>
                                   ))}
                                </select>

                                <select 
                                  value={currentChapter}
                                  onChange={(e) => setCurrentChapter(parseInt(e.target.value))}
                                  className="bg-tac-blue/10 text-tac-blue border-none text-[9px] font-black uppercase tracking-tight outline-none cursor-pointer hover:bg-tac-blue/20 px-2.5 py-1.5 rounded-lg transition-colors"
                                >
                                   {Array.from({ length: BIBLE_CHAPTER_COUNTS[currentBook] || 1 }, (_, i) => i + 1).map(ch => (
                                      <option key={ch} value={ch}>Ch {ch}</option>
                                   ))}
                                </select>
                             </div>

                             <button 
                               onClick={() => {
                                 setIsOpen(false);
                                 navigate('/dashboard/bible');
                               }}
                               className="px-3 py-1.5 bg-tac-blue text-white rounded-lg text-[9px] font-black uppercase tracking-widest flex items-center gap-1.5 hover:bg-tac-blue-dark transition-all shadow-sm shrink-0"
                             >
                               <ExternalLink size={12} />
                               <span>Full Reader</span>
                             </button>
                          </div>
                         
                          {/* Bible Verses Area */}
                          <div className="flex-1 overflow-y-auto p-4 sm:p-8 lg:p-12 max-w-3xl mx-auto w-full">
                             <div className="mb-8 text-center">
                                <h1 className="text-2xl sm:text-3xl font-black text-tac-blue-dark dark:text-white mb-1">{currentBook} {currentChapter}</h1>
                                <p className="text-[10px] font-black uppercase tracking-[0.2em] text-tac-blue/60">
                                   {bibleVersion === 'ASW' ? 'Ghana Bible (Akuapem Twi)' : 
                                    bibleVersion === 'BSW' ? 'Ghana Bible (Asante Twi)' : 
                                    bibleVersion === 'GAB' ? 'Ghana Bible (Ga Language)' : 
                                    'The Word of Life'}
                                </p>
                                <div className="mt-4 flex justify-center gap-3">
                                   <button 
                                     onClick={speakingMessageIndex === 999 ? stopSpeaking : speakChapter}
                                     className={`flex items-center gap-2 px-5 py-2 rounded-full font-black uppercase tracking-widest text-[10px] transition-all ${
                                       speakingMessageIndex === 999 
                                         ? 'bg-tac-red text-white shadow-lg' 
                                         : 'bg-tac-blue text-white hover:bg-tac-blue-dark shadow-md'
                                     }`}
                                   >
                                     {speakingMessageIndex === 999 ? <VolumeX size={14} /> : <Volume2 size={14} />}
                                     {speakingMessageIndex === 999 ? 'Stop Reading' : 'Listen Chapter'}
                                   </button>
                                </div>
                             </div>
                             
                             <div className="space-y-4 text-base sm:text-lg font-serif text-gray-800 dark:text-gray-200 leading-relaxed">
                                {isLoadingBible ? (
                                   <div className="flex flex-col items-center justify-center py-16 gap-3">
                                      <div className="w-8 h-8 border-4 border-tac-blue border-t-transparent rounded-full animate-spin" />
                                      <p className="text-[10px] font-black uppercase tracking-widest text-tac-blue/60">Opening Scripture...</p>
                                   </div>
                                ) : bibleContent.length > 0 ? (
                                   bibleContent.map((verse) => (
                                      <div 
                                        key={verse.number} 
                                        className={`group relative p-3 rounded-2xl transition-all cursor-pointer ${
                                          speakingMessageIndex === verse.number + 1000 
                                            ? 'bg-tac-blue/10 border-l-4 border-tac-blue' 
                                            : 'hover:bg-gray-50 dark:hover:bg-white/5 border border-transparent hover:border-gray-200 dark:hover:border-white/10'
                                        }`}
                                      >
                                         <p onClick={() => speakVerse(verse.number, verse.text)}>
                                            <span className="text-tac-blue font-black mr-3 text-xs italic tracking-widest select-none">{verse.number}</span>
                                            {verse.text}
                                         </p>
                                         <div className="mt-2 flex items-center gap-3 opacity-0 group-hover:opacity-100 transition-opacity pt-1 border-t border-gray-100 dark:border-white/5">
                                            <button 
                                              onClick={() => speakVerse(verse.number, verse.text)}
                                              className="text-[9px] font-black uppercase tracking-wider text-tac-blue flex items-center gap-1 hover:underline"
                                            >
                                               <Volume2 size={12} /> Read Verse
                                            </button>
                                            <button 
                                              onClick={() => {
                                                handleSeek(`Explain ${currentBook} ${currentChapter}:${verse.number} - "${verse.text}"`);
                                                setActiveMode('seek');
                                              }}
                                              className="text-[9px] font-black uppercase tracking-wider text-tac-red flex items-center gap-1 hover:underline"
                                            >
                                               <Zap size={12} /> Ask Seek AI
                                            </button>
                                         </div>
                                      </div>
                                   ))
                                ) : (
                                   <div className="text-center py-16">
                                      <p className="text-gray-400 italic">Scripture selection unavailable in this version.</p>
                                   </div>
                                )}
                             </div>
                          </div>
                      </motion.div>
                    )}

                    {/* SEEK AI MODE */}
                    {activeMode === 'seek' && (
                      <motion.div
                        key="seek"
                        initial={{ opacity: 0, x: 20 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: -20 }}
                        className="flex flex-col h-full overflow-hidden bg-[var(--Bg)] dark:bg-slate-950"
                      >
                         <div className="px-5 py-3 bg-white dark:bg-slate-900 flex items-center justify-between border-b border-gray-100 dark:border-white/10 shadow-sm shrink-0 z-10">
                            <div className="flex items-center gap-3">
                               <div className="w-8 h-8 bg-tac-blue text-white rounded-xl flex items-center justify-center shadow-md">
                                  <Sparkles size={16} />
                               </div>
                               <div>
                                  <h4 className="text-xs font-black uppercase text-tac-blue-dark dark:text-white tracking-widest leading-none mb-0.5">Seek AI Assistant</h4>
                                  <div className="flex items-center gap-1.5">
                                     <div className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse" />
                                     <span className="text-[9px] font-black uppercase text-green-500 tracking-widest">Faithful & Ready</span>
                                  </div>
                               </div>
                            </div>
                            <button 
                              onClick={() => setIsDeleting(true)} 
                              className="p-2 bg-gray-50 dark:bg-white/5 text-gray-400 hover:text-tac-red rounded-xl transition-all"
                              title="Clear chat history"
                            >
                               <Trash2 size={16} />
                            </button>
                         </div>
                         
                         {/* Messages List */}
                         <div ref={scrollRef} className="flex-1 p-4 sm:p-6 lg:px-[12%] overflow-y-auto space-y-6 scroll-smooth pb-28">
                            {chatMessages.length === 0 && (
                              <div className="py-8 space-y-6">
                                 <div className="text-center opacity-70 flex flex-col items-center">
                                    <div className="w-16 h-16 bg-tac-blue/10 rounded-[2rem] flex items-center justify-center mb-4 text-tac-blue">
                                       <Book size={32} />
                                    </div>
                                    <h3 className="text-lg font-black uppercase tracking-[0.15em] text-tac-blue-dark dark:text-white mb-2">Divine Wisdom Awaits</h3>
                                    <p className="text-xs font-medium max-w-xs leading-relaxed text-gray-500">Ask Seek AI anything about scripture, theology, or daily spiritual encouragement.</p>
                                 </div>

                                 <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 max-w-lg mx-auto">
                                    {[
                                      "How can I grow my faith?",
                                      "Verses for anxiety and peace",
                                      "Explain the Great Commission",
                                      "A short prayer for family"
                                    ].map((q, idx) => (
                                      <button 
                                        key={idx}
                                        onClick={() => handleSeek(q)}
                                        className="p-3 bg-white dark:bg-slate-900 border border-gray-100 dark:border-white/5 rounded-2xl text-left hover:border-tac-blue/40 hover:bg-tac-blue/5 transition-all group shadow-sm"
                                      >
                                        <p className="text-[11px] font-bold text-tac-blue-dark dark:text-white mb-1 leading-tight group-hover:text-tac-blue transition-colors">{q}</p>
                                        <div className="flex items-center gap-1 text-[8px] font-black uppercase tracking-widest text-tac-blue/40 group-hover:text-tac-blue">
                                           Ask Seek <ChevronRight size={10} />
                                        </div>
                                      </button>
                                    ))}
                                 </div>
                              </div>
                            )}

                            {chatMessages.map((msg, i) => (
                              <motion.div 
                                key={i} 
                                initial={{ opacity: 0, y: 10 }}
                                animate={{ opacity: 1, y: 0 }}
                                className={`flex flex-col ${msg.role === 'user' ? 'items-end' : 'items-start'}`}
                              >
                                 <div className={`max-w-[90%] sm:max-w-[85%] p-4 sm:p-5 rounded-[2rem] text-sm font-medium leading-relaxed shadow-sm relative group ${
                                   msg.role === 'user' 
                                     ? 'bg-tac-blue text-white rounded-br-none shadow-md shadow-tac-blue/10 font-bold' 
                                     : 'bg-white dark:bg-slate-900 text-gray-800 dark:text-gray-200 rounded-bl-none border border-gray-100 dark:border-white/5'
                                 }`}>
                                   {renderMessageContent(msg.content)}
                                   
                                   {msg.role === 'model' && (
                                     <div className="flex items-center justify-between mt-3 border-t border-gray-50 dark:border-white/5 pt-3">
                                        <div className="flex items-center gap-2">
                                          <button 
                                            onClick={() => speakText(msg.content, i)}
                                            className={`p-1.5 rounded-xl transition-all ${
                                              speakingMessageIndex === i 
                                                ? 'bg-tac-blue text-white shadow-md' 
                                                : 'bg-gray-50 dark:bg-white/5 text-gray-400 hover:text-tac-blue'
                                            }`}
                                          >
                                            {speakingMessageIndex === i ? <VolumeX size={14} /> : <Volume2 size={14} />}
                                          </button>
                                          <button 
                                            onClick={() => saveFavorite(chatMessages[i-1]?.content || "Bible Question", msg.content)}
                                            className="p-1.5 bg-gray-50 dark:bg-white/5 text-gray-400 hover:text-tac-red rounded-xl transition-all"
                                            title="Save to favorites"
                                          >
                                            <Heart size={14} />
                                          </button>
                                        </div>
                                        <span className="text-[9px] font-black uppercase tracking-widest text-tac-blue/30 italic">Faithful Wisdom</span>
                                     </div>
                                   )}
                                 </div>
                              </motion.div>
                            ))}
                            
                            {isTyping && (
                              <div className="flex justify-start">
                                 <div className="bg-white dark:bg-slate-900 p-4 rounded-[2rem] rounded-bl-none border border-tac-blue/10 flex items-center gap-3 shadow-sm">
                                    <div className="flex gap-1.5">
                                       <motion.div animate={{ scale: [1, 1.5, 1] }} transition={{ repeat: Infinity, duration: 1 }} className="w-1.5 h-1.5 bg-tac-blue rounded-full" />
                                       <motion.div animate={{ scale: [1, 1.5, 1] }} transition={{ repeat: Infinity, duration: 1, delay: 0.2 }} className="w-1.5 h-1.5 bg-tac-blue rounded-full" />
                                       <motion.div animate={{ scale: [1, 1.5, 1] }} transition={{ repeat: Infinity, duration: 1, delay: 0.4 }} className="w-1.5 h-1.5 bg-tac-blue rounded-full" />
                                    </div>
                                    <span className="text-[9px] font-black uppercase tracking-[0.2em] text-tac-blue/50">Seek AI is reflecting...</span>
                                 </div>
                              </div>
                            )}
                         </div>
                         
                         {/* Input Bar Pinned at Bottom */}
                         <div className="p-2 sm:p-4 bg-white dark:bg-slate-900 border-t border-gray-100 dark:border-white/10 shrink-0 z-30 sticky bottom-0">
                            <div className="max-w-2xl mx-auto flex items-center gap-1.5 sm:gap-2 w-full">
                               <button 
                                 onClick={toggleRecording}
                                 className={`w-9 h-9 sm:w-10 sm:h-10 flex items-center justify-center rounded-xl transition-all shrink-0 ${isRecording ? 'bg-tac-red text-white animate-pulse shadow-lg' : 'bg-gray-100 dark:bg-white/5 text-gray-400 hover:text-tac-blue'}`}
                                 title={isRecording ? "Stop voice recording" : "Voice input"}
                               >
                                 {isRecording ? <MicOff size={16} className="sm:w-[18px] sm:h-[18px]" /> : <Mic size={16} className="sm:w-[18px] sm:h-[18px]" />}
                               </button>

                               <input 
                                 value={inputText}
                                 onChange={(e) => setInputText(e.target.value)}
                                 onKeyDown={(e) => e.key === 'Enter' && handleSeek()}
                                 placeholder={isRecording ? "Listening..." : "Ask Seek AI..."}
                                 className="flex-1 min-w-[50px] bg-gray-50 dark:bg-slate-800 border border-gray-100 dark:border-white/5 rounded-2xl px-3 sm:px-4 py-2 sm:py-2.5 text-xs font-bold text-tac-blue-dark dark:text-white placeholder:text-gray-400 outline-none focus:ring-2 focus:ring-tac-blue/30 transition-all"
                               />

                               <button 
                                 onClick={() => handleSeek()}
                                 disabled={!inputText.trim() || isTyping}
                                 className="w-9 h-9 sm:w-10 sm:h-10 bg-tac-blue text-white rounded-xl flex items-center justify-center shadow-md active:scale-95 transition-all disabled:opacity-40 shrink-0 cursor-pointer hover:bg-tac-blue-dark"
                                 title="Send message"
                               >
                                  <Send size={16} className="sm:w-[18px] sm:h-[18px]" />
                               </button>
                               <button 
                                 onClick={() => setIsDeleting(true)}
                                 className="w-9 h-9 sm:w-10 sm:h-10 bg-gray-100 dark:bg-white/5 text-gray-400 hover:text-tac-red rounded-xl flex items-center justify-center transition-all shrink-0"
                                 title="Clear all chat history"
                               >
                                  <Trash2 size={15} className="sm:w-4 sm:h-4" />
                               </button>
                            </div>
                         </div>
                      </motion.div>
                    )}
                 </AnimatePresence>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </>
  );
};

const MenuOption: React.FC<{ icon: React.ReactNode; title: string; desc: string; onClick: () => void }> = ({ icon, title, desc, onClick }) => (
  <button 
    onClick={onClick}
    className="flex items-center gap-4 p-5 bg-white dark:bg-slate-800 border border-[var(--Bdr)] rounded-[2rem] hover:border-tac-blue/20 hover:shadow-xl hover:shadow-tac-blue/5 transition-all text-left group"
  >
    <div className="w-14 h-14 bg-gray-50 dark:bg-white/5 rounded-2xl flex items-center justify-center group-hover:scale-110 transition-transform">
      {icon}
    </div>
    <div className="flex-1">
      <h4 className="font-black text-tac-blue-dark dark:text-white uppercase tracking-widest text-[11px] mb-1">{title}</h4>
      <p className="text-[10px] text-gray-400 font-medium leading-tight">{desc}</p>
    </div>
    <ChevronRight size={16} className="text-gray-300 group-hover:text-tac-blue group-hover:translate-x-1 transition-all" />
  </button>
);

export default FloatingAssistiveTab;
