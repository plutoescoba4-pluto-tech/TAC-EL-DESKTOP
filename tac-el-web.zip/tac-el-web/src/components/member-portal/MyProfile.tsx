import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '../../context/AuthContext';
import { authService } from '../../services/authService';
import { compressImage } from '../../lib/image-utils';
import { User, Phone, Mail, Briefcase, Calendar, ShieldCheck, Check, Sparkles, Camera, Sun, Moon } from 'lucide-react';
import { Card, Button, Badge } from '../ui';

export const MyProfile: React.FC = () => {
  const { profile, refreshProfile } = useAuth();
  const [editing, setEditing] = useState(false);
  const [formData, setFormData] = useState({
    name: profile?.name || '',
    phone: profile?.phone || '',
    occupation: profile?.occupation || '',
    dateOfBirth: profile?.dateOfBirth || ''
  });
  const [saving, setSaving] = useState(false);
  const [success, setSuccess] = useState(false);
  const [uploadingPhoto, setUploadingPhoto] = useState(false);
  const [darkMode, setDarkMode] = useState(() => localStorage.getItem('theme') === 'dark');
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (darkMode) {
      document.documentElement.setAttribute('data-theme', 'dark');
      document.documentElement.classList.add('dark');
      localStorage.setItem('theme', 'dark');
    } else {
      document.documentElement.setAttribute('data-theme', 'light');
      document.documentElement.classList.remove('dark');
      localStorage.setItem('theme', 'light');
    }
  }, [darkMode]);

  if (!profile) return null;

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      await authService.updateProfile(profile.uid, formData);
      await refreshProfile();
      setSuccess(true);
      setEditing(false);
      setTimeout(() => setSuccess(false), 3000);
    } finally {
      setSaving(false);
    }
  };

  const handlePhotoSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploadingPhoto(true);
    try {
      const reader = new FileReader();
      const dataUrl: string = await new Promise((resolve, reject) => {
        reader.onload = () => resolve(reader.result as string);
        reader.onerror = reject;
        reader.readAsDataURL(file);
      });
      // compressImage keeps this well under Firestore's 1MB document limit —
      // see lib/image-utils.ts for the size ceilings this respects.
      const compressed = await compressImage(dataUrl, 500, 500, 0.7);
      await authService.updateProfile(profile.uid, { picUrl: compressed });
      await refreshProfile();
      setSuccess(true);
      setTimeout(() => setSuccess(false), 3000);
    } catch (err) {
      console.error('[MyProfile] photo upload failed', err);
    } finally {
      setUploadingPhoto(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  return (
    <div className="max-w-3xl mx-auto p-4 sm:p-6 space-y-6">
      {/* Header Profile Banner */}
      <div className="bg-gradient-to-r from-tac-blue-dark via-slate-900 to-tac-blue text-white rounded-3xl p-6 sm:p-8 relative overflow-hidden shadow-xl">
        <div className="flex flex-col sm:flex-row items-center sm:items-start gap-6 relative z-10 text-center sm:text-left">
          <div
            className={`w-24 h-24 rounded-3xl flex items-center justify-center text-3xl font-black text-white shadow-2xl ring-4 ring-white/20 shrink-0 relative group cursor-pointer ${profile.color || 'bg-tac-blue'}`}
            onClick={() => fileInputRef.current?.click()}
          >
            {profile.picUrl ? <img src={profile.picUrl} alt={profile.name} className="w-full h-full object-cover rounded-3xl" /> : profile.name[0]}
            <div className="absolute inset-0 rounded-3xl bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
              {uploadingPhoto ? (
                <span className="w-5 h-5 border-2 border-white/40 border-t-white rounded-full animate-spin" />
              ) : (
                <Camera size={20} className="text-white" />
              )}
            </div>
            <input ref={fileInputRef} type="file" accept="image/*" className="hidden" onChange={handlePhotoSelect} />
          </div>

          <div className="flex-1 space-y-2">
            <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2">
              <h2 className="text-2xl font-black uppercase tracking-tight">{profile.name}</h2>
              <Badge variant="blue">{profile.role}</Badge>
            </div>
            <p className="text-white/70 text-xs font-medium flex items-center justify-center sm:justify-start gap-2">
              <Mail size={14} />
              {profile.email}
            </p>
            <div className="pt-2 flex flex-wrap items-center justify-center sm:justify-start gap-3">
              <div className="px-3 py-1.5 bg-white/10 rounded-xl text-xs font-mono font-bold tracking-wider border border-white/10">
                TAC ID: <span className="text-tac-blue-light font-black">{profile.userId || 'TAC-EL-MEMBER'}</span>
              </div>
              <div className="flex items-center gap-1.5 text-emerald-400 text-xs font-bold">
                <ShieldCheck size={16} />
                <span>Verified Assembly Member</span>
              </div>
            </div>
          </div>

          <Button
            variant="ghost"
            onClick={() => setEditing(!editing)}
            className="text-white hover:bg-white/10 border border-white/20 self-center sm:self-start"
          >
            {editing ? 'Cancel' : 'Edit Profile'}
          </Button>
        </div>

        {/* Dark mode toggle */}
        <div className="mt-4 pt-4 border-t border-white/10 flex items-center justify-between relative z-10">
          <div className="flex items-center gap-2 text-white/70 text-xs font-bold">
            {darkMode ? <Moon size={16} /> : <Sun size={16} />}
            <span>{darkMode ? 'Dark Mode' : 'Light Mode'}</span>
          </div>
          <button
            type="button"
            onClick={() => setDarkMode(!darkMode)}
            aria-label="Toggle dark mode"
            className={`w-12 h-6 rounded-full p-1 transition-colors ${darkMode ? 'bg-tac-blue-light' : 'bg-white/20'}`}
          >
            <div className={`w-4 h-4 bg-white rounded-full transition-transform ${darkMode ? 'translate-x-6' : 'translate-x-0'}`} />
          </button>
        </div>
      </div>

      {success && (
        <div className="p-4 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 rounded-2xl flex items-center gap-2 text-emerald-600 dark:text-emerald-400 text-xs font-bold">
          <Check size={16} />
          Profile updated successfully!
        </div>
      )}

      {/* Profile Details Form / View */}
      <Card>
        <h3 className="text-sm font-black uppercase tracking-wider text-tac-blue-dark dark:text-white mb-6">
          Member Credentials & Information
        </h3>

        {editing ? (
          <form onSubmit={handleSave} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
                  Full Name
                </label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full px-4 py-3 bg-gray-50 dark:bg-slate-800 border border-[var(--Bdr)] rounded-2xl text-sm outline-none focus:border-tac-blue text-[var(--Text)] dark:text-white"
                />
              </div>

              <div>
                <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
                  Phone Number
                </label>
                <input
                  type="tel"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  className="w-full px-4 py-3 bg-gray-50 dark:bg-slate-800 border border-[var(--Bdr)] rounded-2xl text-sm outline-none focus:border-tac-blue text-[var(--Text)] dark:text-white"
                />
              </div>

              <div>
                <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
                  Occupation / Profession
                </label>
                <input
                  type="text"
                  value={formData.occupation}
                  onChange={(e) => setFormData({ ...formData, occupation: e.target.value })}
                  className="w-full px-4 py-3 bg-gray-50 dark:bg-slate-800 border border-[var(--Bdr)] rounded-2xl text-sm outline-none focus:border-tac-blue text-[var(--Text)] dark:text-white"
                />
              </div>

              <div>
                <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
                  Date of Birth
                </label>
                <input
                  type="date"
                  value={formData.dateOfBirth}
                  onChange={(e) => setFormData({ ...formData, dateOfBirth: e.target.value })}
                  className="w-full px-4 py-3 bg-gray-50 dark:bg-slate-800 border border-[var(--Bdr)] rounded-2xl text-sm outline-none focus:border-tac-blue text-[var(--Text)] dark:text-white min-w-0 max-w-full box-border"
                />
              </div>
            </div>

            <div className="pt-4 flex justify-end gap-3">
              <Button type="button" variant="ghost" onClick={() => setEditing(false)}>
                Cancel
              </Button>
              <Button type="submit" loading={saving} variant="primary">
                Save Changes
              </Button>
            </div>
          </form>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 text-sm">
            <div className="flex items-center gap-3 p-4 bg-gray-50 dark:bg-white/5 rounded-2xl border border-[var(--Bdr)]">
              <Phone className="text-tac-blue shrink-0" size={20} />
              <div>
                <p className="text-[10px] font-black uppercase tracking-wider text-gray-400">Phone</p>
                <p className="font-bold text-[var(--Text)] dark:text-white">{profile.phone || 'Not provided'}</p>
              </div>
            </div>

            <div className="flex items-center gap-3 p-4 bg-gray-50 dark:bg-white/5 rounded-2xl border border-[var(--Bdr)]">
              <Briefcase className="text-tac-blue shrink-0" size={20} />
              <div>
                <p className="text-[10px] font-black uppercase tracking-wider text-gray-400">Occupation</p>
                <p className="font-bold text-[var(--Text)] dark:text-white">{profile.occupation || 'Member'}</p>
              </div>
            </div>

            <div className="flex items-center gap-3 p-4 bg-gray-50 dark:bg-white/5 rounded-2xl border border-[var(--Bdr)]">
              <Calendar className="text-tac-blue shrink-0" size={20} />
              <div>
                <p className="text-[10px] font-black uppercase tracking-wider text-gray-400">Date of Birth</p>
                <p className="font-bold text-[var(--Text)] dark:text-white">{profile.dateOfBirth || 'Not provided'}</p>
              </div>
            </div>

            <div className="flex items-center gap-3 p-4 bg-gray-50 dark:bg-white/5 rounded-2xl border border-[var(--Bdr)]">
              <User className="text-tac-blue shrink-0" size={20} />
              <div>
                <p className="text-[10px] font-black uppercase tracking-wider text-gray-400">Membership Date</p>
                <p className="font-bold text-[var(--Text)] dark:text-white">
                  {profile.joinedDate ? new Date(profile.joinedDate).toLocaleDateString() : 'Active'}
                </p>
              </div>
            </div>
          </div>
        )}
      </Card>
    </div>
  );
};
export default MyProfile;
