import React from 'react';
import NotificationView from '../sections/NotificationView';

export const Notifications: React.FC = () => {
  return <NotificationView />;
};
export default Notifications;
