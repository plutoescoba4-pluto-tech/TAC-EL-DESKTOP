import React, { useState, useEffect } from 'react';
import { useAuth } from '../../../context/AuthContext';
import { clubsService, ClubInstruction, ClubMeetingNote } from '../../../services/clubsService';
import { Team } from '../../../types';
import { Users, BookOpen, AlertCircle, FileText, ChevronRight } from 'lucide-react';
import { Card, Button, Badge } from '../../ui';
import MyApplications from './MyApplications';
import ClubSpace from './ClubSpace';

interface MyClubsProps {
  onBrowseMore: () => void;
}

export const MyClubs: React.FC<MyClubsProps> = ({ onBrowseMore }) => {
  const { profile } = useAuth();
  const [clubs, setClubs] = useState<Team[]>([]);
  const [selectedClub, setSelectedClub] = useState<Team | null>(null);
  const [roles, setRoles] = useState<Record<string, string>>({});
  const [notes, setNotes] = useState<ClubMeetingNote[]>([]);
  const [instructions, setInstructions] = useState<ClubInstruction[]>([]);

  useEffect(() => {
    if (!profile?.uid) return;
    let alive = true;
    // The clubs this person really belongs to, from the database. Refreshes by itself, so a newly approved club appears at once.
    const load = () => Promise.all([clubsService.getClubs(), clubsService.getMyMemberships(profile.uid)]).then(([all, mine]) => {
      if (!alive) return;
      const mineIds = Object.keys(mine);
      setRoles(mine as Record<string, string>);
      const filtered = all.filter((c) => mineIds.includes(c.id));
      setClubs(filtered);
      setSelectedClub((cur) => (cur && filtered.some((c) => c.id === cur.id) ? cur : (filtered[0] ?? null)));
    }).catch(() => {});
    load();
    const t = setInterval(load, 15000);
    window.addEventListener('focus', load);
    return () => { alive = false; clearInterval(t); window.removeEventListener('focus', load); };
  }, [profile?.uid]);

  useEffect(() => {
    if (selectedClub) {
      clubsService.getMeetingNotes(selectedClub.id).then(setNotes);
      clubsService.getInstructions(selectedClub.id).then(setInstructions);
    }
  }, [selectedClub]);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h3 className="text-lg font-black uppercase tracking-tight text-tac-blue-dark dark:text-white">
            My Enrolled Ministries & Clubs
          </h3>
          <p className="text-xs text-[var(--Sub)]">
            Stay up to date with executive directives, fellowship notes, and duties
          </p>
        </div>
        <Button size="sm" variant="outline" onClick={onBrowseMore}>
          Browse More Clubs
        </Button>
      </div>

      <MyApplications />

      {clubs.length === 0 && (
        <p className="text-xs text-[var(--Sub)]">You are not in a club yet. Tap Browse More Clubs to apply.</p>
      )}

      <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-none">
        {clubs.map((club) => (
          <button
            key={club.id}
            onClick={() => setSelectedClub(club)}
            className={`px-4 py-2.5 rounded-2xl text-xs font-black uppercase tracking-wider whitespace-nowrap transition-all ${
              selectedClub?.id === club.id
                ? 'bg-tac-blue text-white shadow-md'
                : 'bg-white dark:bg-slate-900 border border-[var(--Bdr)] text-[var(--Text)] dark:text-white hover:bg-gray-50'
            }`}
          >
            {club.name}
          </button>
        ))}
      </div>

      {selectedClub && <ClubSpace key={selectedClub.id} club={selectedClub} myRole={roles[selectedClub.id] || 'member'} />}
    </div>
  );
};
export default MyClubs;
