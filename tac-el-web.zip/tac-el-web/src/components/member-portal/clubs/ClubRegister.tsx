import React, { useState } from 'react';
import { useAuth } from '../../../context/AuthContext';
import { clubsService } from '../../../services/clubsService';
import { authService } from '../../../services/authService';
import { Team } from '../../../types';
import { UserPlus, CheckCircle2, AlertCircle } from 'lucide-react';
import { Modal, Button } from '../../ui';

interface ClubRegisterProps {
  club: Team | null;
  isOpen: boolean;
  onClose: () => void;
  onRegistered: () => void;
}

export const ClubRegister: React.FC<ClubRegisterProps> = ({ club, isOpen, onClose, onRegistered }) => {
  const { user, profile, refreshProfile } = useAuth();
  const [phone, setPhone] = useState(profile?.phone || '');
  const [statement, setStatement] = useState('');
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Keep the field in sync once the profile finishes loading.
  React.useEffect(() => { setPhone(profile?.phone || ''); }, [profile?.phone, isOpen]);

  if (!club) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;

    if (!phone.trim()) {
      setError('Please enter a phone number so the club leaders can reach you.');
      return;
    }
    setLoading(true);
    setError(null);
    try {
      // Leaders contact applicants by phone — save it to the profile if it
      // changed. (Applicants can only ever apply as a regular member; the
      // admin is the only one who can make someone a leader.)
      if (phone.trim() !== (profile?.phone || '')) {
        await authService.updateProfile(user.id, { phone: phone.trim() });
        await refreshProfile();
      }
      await clubsService.joinClub(club.id, {
        uid: user.id,
        name: profile?.name || 'Member',
        role: 'member',
        joinedAt: new Date().toISOString(),
        phone: phone.trim(),
        email: profile?.email,
        status: 'pending'
      }, statement);
      setSuccess(true);
      setTimeout(() => {
        setSuccess(false);
        onRegistered();
        onClose();
      }, 2000);
    } catch (err: any) {
      setError(err?.message || 'Could not submit your application. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={`Join ${club.name}`}
      description="Submit your application to become an active serving member in this ministry wing."
    >
      {success ? (
        <div className="py-8 text-center space-y-3">
          <CheckCircle2 size={48} className="text-emerald-500 mx-auto animate-bounce" />
          <h4 className="text-base font-black text-emerald-600 uppercase tracking-wide">Application Submitted!</h4>
          <p className="text-xs text-[var(--Sub)]">Your request to join {club.name} is awaiting approval from the club leader.</p>
        </div>
      ) : (
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
              Applicant Name
            </label>
            <input
              type="text"
              disabled
              value={profile?.name || ''}
              className="w-full px-4 py-3 bg-gray-100 dark:bg-slate-800 rounded-2xl text-sm font-bold text-[var(--Text)] dark:text-white"
            />
          </div>

          <div>
            <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
              TAC ID
            </label>
            <input
              type="text"
              disabled
              value={profile?.userId || 'Not assigned yet'}
              className="w-full px-4 py-3 bg-gray-100 dark:bg-slate-800 rounded-2xl text-sm font-mono font-bold text-tac-blue"
            />
          </div>

          <div>
            <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
              Phone Number
            </label>
            <input
              type="tel"
              inputMode="tel"
              required
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              placeholder="e.g. 024 000 0000"
              className="w-full min-w-0 px-4 py-3 bg-gray-50 dark:bg-slate-800 border border-[var(--Bdr)] rounded-2xl text-sm outline-none focus:border-tac-blue text-[var(--Text)] dark:text-white"
            />
          </div>

          <div>
            <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
              Why do you want to join? (optional)
            </label>
            <textarea
              rows={3}
              value={statement}
              onChange={(e) => setStatement(e.target.value)}
              placeholder="Tell the leaders a little about yourself, your skills or your interest"
              className="w-full min-w-0 px-4 py-3 bg-gray-50 dark:bg-slate-800 border border-[var(--Bdr)] rounded-2xl text-sm outline-none focus:border-tac-blue text-[var(--Text)] dark:text-white"
            />
          </div>

          {error && (
            <div className="p-3 rounded-xl bg-red-50 dark:bg-red-950/30 text-tac-red text-xs font-medium flex items-start gap-2">
              <AlertCircle size={14} className="shrink-0 mt-0.5" /> <span>{error}</span>
            </div>
          )}

          <div className="pt-4 flex justify-end gap-3">
            <Button type="button" variant="ghost" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit" variant="primary" loading={loading} icon={<UserPlus size={16} />}>
              Confirm Registration
            </Button>
          </div>
        </form>
      )}
    </Modal>
  );
};
export default ClubRegister;
