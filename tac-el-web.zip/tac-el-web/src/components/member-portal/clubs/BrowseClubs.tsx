import React, { useState, useEffect } from 'react';
import { clubsService } from '../../../services/clubsService';
import { Team } from '../../../types';
import { Users, UserPlus, CheckCircle2, ChevronRight, Flame, Heart, Shield, Music, Globe } from 'lucide-react';
import { Card, Button, Badge } from '../../ui';
import { useAuth } from '../../../context/AuthContext';

interface BrowseClubsProps {
  onSelectClub?: (club: Team) => void;
  onRegisterClick?: (club: Team) => void;
}

export const BrowseClubs: React.FC<BrowseClubsProps> = ({ onSelectClub, onRegisterClick }) => {
  const [clubs, setClubs] = useState<Team[]>([]);
  const [loading, setLoading] = useState(true);
  const { user } = useAuth();
  // where I stand in each club: waiting, or approved. Refreshes by itself so an approval shows up without reopening the app.
  const [mine, setMine] = useState<Record<string, { role: string; status: 'active' | 'pending' }>>({});
  useEffect(() => {
    if (!user?.id) return;
    let alive = true;
    const load = () => clubsService.getMyMembershipsDetailed(user.id).then((m) => { if (alive) setMine(m); }).catch(() => {});
    load();
    const t = setInterval(load, 15000);
    const onShow = () => { if (document.visibilityState === 'visible') load(); };
    document.addEventListener('visibilitychange', onShow);
    window.addEventListener('focus', load);
    return () => { alive = false; clearInterval(t); document.removeEventListener('visibilitychange', onShow); window.removeEventListener('focus', load); };
  }, [user?.id]);

  useEffect(() => {
    clubsService.getClubs().then((res) => {
      setClubs(res);
      setLoading(false);
    });
  }, []);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h3 className="text-lg font-black uppercase tracking-tight text-tac-blue-dark dark:text-white">
            Assembly Clubs & Movements
          </h3>
          <p className="text-xs text-[var(--Sub)]">
            Join a fellowship wing to serve, grow spiritually, and connect
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {clubs.map((club) => (
          <Card key={club.id} className="hover:border-tac-blue transition-all">
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className={`w-12 h-12 rounded-2xl ${club.color || 'bg-tac-blue'} text-white flex items-center justify-center font-black text-lg shadow-md`}>
                  {club.name[0]}
                </div>
                <div>
                  <h4 className="font-black text-sm text-tac-blue-dark dark:text-white uppercase tracking-wide">
                    {club.name}
                  </h4>
                  <p className="text-[11px] text-[var(--Sub)] mt-0.5 line-clamp-1">
                    {club.desc}
                  </p>
                </div>
              </div>
              <Badge variant="blue">{club.members || 30}+ Members</Badge>
            </div>

            <div className="mt-4 pt-4 border-t border-[var(--Bdr)] flex items-center justify-between">
              <span className="text-[10px] font-black uppercase text-gray-400 tracking-wider">
                Weekly Fellowship
              </span>
              {mine[club.id]?.status === 'active' ? (
                <span className="inline-flex items-center gap-1.5 text-[11px] font-black uppercase tracking-wider text-emerald-600 bg-emerald-50 px-3 py-2 rounded-xl">
                  <CheckCircle2 size={14} /> You are a member
                </span>
              ) : mine[club.id]?.status === 'pending' ? (
                <span className="inline-flex items-center gap-1.5 text-[11px] font-black uppercase tracking-wider text-amber-700 bg-amber-50 px-3 py-2 rounded-xl">
                  Waiting for approval
                </span>
              ) : (
                <Button
                  size="sm"
                  variant="primary"
                  onClick={() => onRegisterClick ? onRegisterClick(club) : null}
                  icon={<UserPlus size={14} />}
                >
                  Join Movement
                </Button>
              )}
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
};
export default BrowseClubs;
