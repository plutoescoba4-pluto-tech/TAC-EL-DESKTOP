import React, { useCallback, useEffect, useState } from 'react';
import { useAuth } from '../../../context/AuthContext';
import { clubApplicationsService, MyApplication } from '../../../services/clubApplicationsService';
import { Clock, XCircle, Send, CalendarClock, MessageSquare } from 'lucide-react';
import { Card, Badge } from '../../ui';

/**
 * "My applications": clubs the person applied to and is still waiting on, with the leaders' questions and
 * interview invitations (and a box to reply), plus applications that were not accepted.
 */
const when = (iso?: string) => (iso ? new Date(iso).toLocaleString('en-GB', { dateStyle: 'medium', timeStyle: 'short' }) : '');

export const MyApplications: React.FC = () => {
  const { profile } = useAuth();
  const [apps, setApps] = useState<MyApplication[]>([]);
  const [reply, setReply] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(() => {
    if (profile?.uid) clubApplicationsService.getMyApplications(profile.uid).then(setApps).catch(() => {});
  }, [profile?.uid]);
  useEffect(() => { load(); const t = setInterval(load, 20000); return () => clearInterval(t); }, [load]);

  if (apps.length === 0) return null;

  const send = async (clubId: string) => {
    if (!profile) return;
    setBusy(clubId); setError(null);
    try {
      await clubApplicationsService.send({ clubId, applicantId: profile.uid, senderId: profile.uid, kind: 'answer', body: reply[clubId] || '' });
      setReply((r) => ({ ...r, [clubId]: '' }));
      load();
    } catch (e: any) { setError(e?.message || 'Could not send your reply.'); }
    finally { setBusy(null); }
  };

  return (
    <div className="space-y-3">
      <h3 className="text-sm font-black uppercase tracking-tight text-tac-blue-dark dark:text-white">My Applications</h3>
      {apps.map((a) => (
        <Card key={a.clubId}>
          <div className="flex items-center justify-between gap-2">
            <h4 className="text-xs font-black uppercase tracking-wider text-tac-blue-dark dark:text-white">{a.clubName}</h4>
            {a.status === 'pending'
              ? <Badge variant="amber"><span className="inline-flex items-center gap-1"><Clock size={12} />Waiting for approval</span></Badge>
              : <Badge variant="red"><span className="inline-flex items-center gap-1"><XCircle size={12} />Not accepted</span></Badge>}
          </div>

          {a.status === 'declined' && (
            <p className="text-xs text-[var(--Sub)] mt-3">{a.declinedNote || 'The club leaders did not accept this application this time. You are welcome to try another club.'}</p>
          )}

          {a.status === 'pending' && (
            <div className="mt-3 space-y-2">
              {a.messages.length === 0 && <p className="text-xs text-[var(--Sub)]">The club leaders have your request. You will get a notification when there is a decision, a question or an interview invitation.</p>}
              {a.messages.map((m) => (
                <div key={m.id} className={`p-3 rounded-2xl text-xs border ${m.kind === 'answer' ? 'bg-gray-50 dark:bg-white/5 border-[var(--Bdr)] ml-6' : 'bg-tac-blue/5 border-tac-blue/20 mr-6'}`}>
                  <div className="flex items-center justify-between gap-2 text-[10px] font-black uppercase tracking-wider text-gray-400">
                    <span className="inline-flex items-center gap-1">
                      {m.kind === 'interview' ? <CalendarClock size={12} /> : <MessageSquare size={12} />}
                      {m.kind === 'answer' ? 'You' : m.kind === 'interview' ? 'Interview invitation' : 'Question from the leaders'}
                    </span>
                    <span>{when(m.createdAt)}</span>
                  </div>
                  {m.kind === 'interview' && <p className="mt-1 font-bold text-tac-blue-dark dark:text-white">{when(m.interviewAt) || 'Time to be agreed'}{m.interviewPlace ? ` · ${m.interviewPlace}` : ''}</p>}
                  {m.body && <p className="mt-1 text-[var(--Text)] dark:text-white whitespace-pre-wrap">{m.body}</p>}
                </div>
              ))}
              <div className="flex gap-2 pt-1">
                <input value={reply[a.clubId] || ''} onChange={(e) => setReply((r) => ({ ...r, [a.clubId]: e.target.value }))} placeholder="Write a reply to the leaders…"
                  className="flex-1 rounded-xl border border-[var(--Bdr)] bg-transparent px-3 py-2 text-xs text-[var(--Text)] dark:text-white outline-none focus:border-tac-blue" />
                <button type="button" disabled={busy === a.clubId || !(reply[a.clubId] || '').trim()} onClick={() => send(a.clubId)}
                  className="px-3 rounded-xl bg-tac-blue text-white disabled:opacity-50" aria-label="Send reply"><Send size={14} /></button>
              </div>
            </div>
          )}
        </Card>
      ))}
      {error && <p className="text-[11px] font-bold text-tac-red">{error}</p>}
    </div>
  );
};
export default MyApplications;
