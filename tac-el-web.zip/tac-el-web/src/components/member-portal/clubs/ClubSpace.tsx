import React, { useEffect, useRef, useState } from 'react';
import { MessageSquare, Bell, CalendarDays, Clock, Send, Trash2, FileText } from 'lucide-react';
import { useAuth } from '../../../context/AuthContext';
import { Team } from '../../../types';
import { clubExtrasService } from '../../../services/pendingSchemaServices';
import { clubsService, ClubInstruction, ClubMeetingNote } from '../../../services/clubsService';
import { noticeCommentsService, NoticeComment, isOfficerRole } from '../../../services/clubOfficersService';
import { ClubNoticeComposer, ClubEventsPanel, ClubTimetablePanel } from '../../sections/ClubOfficerPanels';

type Tab = 'chat' | 'notices' | 'calendar' | 'timetable' | 'notes';
const TABS: { id: Tab; label: string; icon: React.ReactNode }[] = [
  { id: 'chat', label: 'Chat', icon: <MessageSquare size={16} /> },
  { id: 'notices', label: 'Notices', icon: <Bell size={16} /> },
  { id: 'calendar', label: 'Calendar', icon: <CalendarDays size={16} /> },
  { id: 'timetable', label: 'Timetable', icon: <Clock size={16} /> },
  { id: 'notes', label: 'Notes', icon: <FileText size={16} /> },
];

/** What an approved club member sees inside their club: chat, notices with comments, calendar, timetable, notes. */
export const ClubSpace: React.FC<{ club: Team; myRole: string }> = ({ club, myRole }) => {
  const { profile } = useAuth();
  const isOfficer = isOfficerRole(myRole);
  const [tab, setTab] = useState<Tab>(() => {
    try { return (sessionStorage.getItem('tac_club_tab') as Tab) || 'chat'; } catch { return 'chat'; }
  });
  const pick = (t: Tab) => { setTab(t); try { sessionStorage.setItem('tac_club_tab', t); } catch { /* fine */ } };

  return (
    <div className="space-y-4">
      <div className="flex gap-2 overflow-x-auto -mx-1 px-1 pb-1">
        {TABS.map((t) => (
          <button key={t.id} onClick={() => pick(t.id)}
            className={`shrink-0 inline-flex items-center gap-1.5 px-4 py-2 rounded-full text-xs font-black uppercase tracking-wider border transition-all ${tab === t.id ? 'bg-tac-blue text-white border-tac-blue shadow' : 'bg-white dark:bg-slate-900 text-[var(--Sub)] border-[var(--Bdr)]'}`}>
            {t.icon}{t.label}
          </button>
        ))}
      </div>
      {tab === 'chat' && <ClubChat clubId={club.id} />}
      {tab === 'notices' && <ClubNotices clubId={club.id} isOfficer={isOfficer} />}
      {tab === 'calendar' && <ClubEventsPanel clubId={club.id} canEdit={isOfficer} authorId={profile?.uid || ''} />}
      {tab === 'timetable' && <ClubTimetablePanel clubId={club.id} canEdit={isOfficer} authorId={profile?.uid || ''} />}
      {tab === 'notes' && <ClubNotes clubId={club.id} />}
    </div>
  );
};

const ClubChat: React.FC<{ clubId: string }> = ({ clubId }) => {
  const { profile } = useAuth();
  const [msgs, setMsgs] = useState<any[]>([]);
  const [text, setText] = useState('');
  const [err, setErr] = useState('');
  const endRef = useRef<HTMLDivElement>(null);
  useEffect(() => clubExtrasService.subscribeChat(clubId, setMsgs), [clubId]);
  useEffect(() => { endRef.current?.scrollIntoView({ block: 'end' }); }, [msgs.length]);
  const send = async () => {
    const t = text.trim();
    if (!t || !profile) return;
    setText(''); setErr('');
    try { await clubExtrasService.sendChat(clubId, profile.uid, profile.name, t); }
    catch (e: any) { setText(t); setErr(e?.message || 'Message not sent.'); }
  };
  return (
    <div className="flex flex-col h-[60vh] min-h-[320px] bg-[#e5ddd5] dark:bg-slate-900 rounded-3xl border border-[var(--Bdr)] overflow-hidden">
      <div className="flex-1 overflow-y-auto p-3 space-y-2">
        {msgs.length === 0 && <p className="text-center text-xs text-[var(--Sub)] py-10">No messages yet. Say hello.</p>}
        {msgs.map((m) => {
          const mine = m.senderId === profile?.uid;
          return (
            <div key={m.id} className={`flex ${mine ? 'justify-end' : 'justify-start'}`}>
              <div className={`px-3 py-2 rounded-2xl text-sm max-w-[85%] shadow-sm ${mine ? 'bg-[#d9fdd3] dark:bg-[#005c4b] rounded-tr-none text-gray-800 dark:text-white' : 'bg-white dark:bg-[#202c33] rounded-tl-none text-gray-800 dark:text-white'}`}>
                {!mine && <p className="text-[10px] font-black text-tac-blue dark:text-tac-blue-light mb-0.5">{m.senderName}</p>}
                <p className="leading-snug whitespace-pre-wrap break-words">{m.text}</p>
                <p className="text-[9px] text-gray-400 text-right mt-0.5">{m.time}</p>
              </div>
            </div>
          );
        })}
        <div ref={endRef} />
      </div>
      {err && <p className="text-[11px] text-red-600 px-4 py-1 bg-white/70">{err}</p>}
      <div className="p-2 bg-[#f0f2f5] dark:bg-slate-900 flex gap-2 items-center">
        <input value={text} onChange={(e) => setText(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && send()}
          placeholder="Type a message" className="flex-1 h-11 rounded-full px-4 text-sm bg-white dark:bg-white/5 dark:text-white outline-none" />
        <button onClick={send} className="w-11 h-11 rounded-full bg-[#128c7e] text-white flex items-center justify-center active:scale-95"><Send size={18} /></button>
      </div>
    </div>
  );
};

const ClubNotices: React.FC<{ clubId: string; isOfficer: boolean }> = ({ clubId, isOfficer }) => {
  const { profile } = useAuth();
  const [notices, setNotices] = useState<ClubInstruction[]>([]);
  const [comments, setComments] = useState<NoticeComment[]>([]);
  const [drafts, setDrafts] = useState<Record<string, string>>({});
  const [err, setErr] = useState('');
  const load = () => {
    clubsService.getInstructions(clubId).then(setNotices).catch(() => {});
    noticeCommentsService.list(clubId).then(setComments).catch((e) => setErr(e?.message || ''));
  };
  useEffect(() => { load(); const t = setInterval(load, 20000); return () => clearInterval(t); }, [clubId]);
  const add = async (id: string) => {
    const body = (drafts[id] || '').trim();
    if (!body || !profile) return;
    setDrafts((d) => ({ ...d, [id]: '' })); setErr('');
    try { await noticeCommentsService.add(clubId, id, profile.uid, body); load(); }
    catch (e: any) { setDrafts((d) => ({ ...d, [id]: body })); setErr(e?.message || 'Could not comment.'); }
  };
  return (
    <div className="space-y-4">
      {isOfficer && profile && <ClubNoticeComposer clubId={clubId} issuerId={profile.uid} onPosted={load} />}
      {err && <p className="text-xs text-red-600">{err}</p>}
      {notices.length === 0 && <p className="text-center text-sm text-[var(--Sub)] py-10">No notices yet.</p>}
      {notices.map((n) => {
        const cs = comments.filter((c) => c.noticeId === n.id);
        return (
          <div key={n.id} className="bg-white dark:bg-slate-800 rounded-3xl border border-[var(--Bdr)] p-4 shadow-sm">
            <p className="font-black text-tac-blue-dark dark:text-white">{n.title}</p>
            <p className="text-sm text-[var(--Sub)] mt-1 whitespace-pre-wrap">{n.directive}</p>
            <p className="text-[10px] text-gray-400 mt-2">{n.issuedBy} · {n.date}</p>
            <div className="mt-3 pt-3 border-t border-[var(--Bdr)] space-y-2">
              {cs.map((c) => (
                <div key={c.id} className="flex items-start gap-2 text-xs">
                  <div className="flex-1 bg-gray-50 dark:bg-white/5 rounded-xl px-3 py-2">
                    <span className="font-black text-tac-blue-dark dark:text-white">{c.authorName}</span>
                    <span className="text-[var(--Sub)]"> {c.body}</span>
                  </div>
                  {(c.authorId === profile?.uid || isOfficer) && (
                    <button aria-label="Delete comment" onClick={() => noticeCommentsService.remove(c.id).then(load)} className="p-1.5 text-gray-400"><Trash2 size={14} /></button>
                  )}
                </div>
              ))}
              <div className="flex gap-2">
                <input value={drafts[n.id] || ''} onChange={(e) => setDrafts((d) => ({ ...d, [n.id]: e.target.value }))}
                  onKeyDown={(e) => e.key === 'Enter' && add(n.id)} placeholder="Write a comment"
                  className="flex-1 h-10 rounded-full px-4 text-xs bg-gray-50 dark:bg-white/5 dark:text-white border border-[var(--Bdr)] outline-none" />
                <button onClick={() => add(n.id)} className="w-10 h-10 rounded-full bg-tac-blue text-white flex items-center justify-center active:scale-95"><Send size={15} /></button>
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
};

const ClubNotes: React.FC<{ clubId: string }> = ({ clubId }) => {
  const [notes, setNotes] = useState<ClubMeetingNote[]>([]);
  useEffect(() => { clubsService.getMeetingNotes(clubId).then(setNotes).catch(() => {}); }, [clubId]);
  if (!notes.length) return <p className="text-center text-sm text-[var(--Sub)] py-10">No meeting notes yet.</p>;
  return (
    <div className="space-y-3">
      {notes.map((n) => (
        <div key={n.id} className="bg-white dark:bg-slate-800 rounded-2xl border border-[var(--Bdr)] p-4 text-sm">
          <div className="flex justify-between"><p className="font-black text-tac-blue-dark dark:text-white">{n.title}</p><span className="text-[10px] text-gray-400">{n.date}</span></div>
          <p className="text-[var(--Sub)] mt-1 whitespace-pre-wrap">{n.content}</p>
        </div>
      ))}
    </div>
  );
};
export default ClubSpace;
