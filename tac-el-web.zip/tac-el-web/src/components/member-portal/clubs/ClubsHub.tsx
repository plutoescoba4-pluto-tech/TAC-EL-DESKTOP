import React, { useState } from 'react';
import { Team } from '../../../types';
import { BrowseClubs } from './BrowseClubs';
import { ClubRegister } from './ClubRegister';
import { MyClubs } from './MyClubs';

type Tab = 'browse' | 'mine';

export const ClubsHub: React.FC = () => {
  const [tab, setTab] = useState<Tab>('browse');
  const [selectedClub, setSelectedClub] = useState<Team | null>(null);
  const [modalOpen, setModalOpen] = useState(false);

  const handleRegisterClick = (club: Team) => {
    setSelectedClub(club);
    setModalOpen(true);
  };

  const handleRegistered = () => {
    setModalOpen(false);
    setTab('mine'); // jump straight to "My Clubs" so the pending application is visible
  };

  return (
    <div className="max-w-4xl mx-auto p-4 sm:p-6 space-y-6">
      <div className="flex gap-2 bg-gray-100 dark:bg-white/5 p-1 rounded-2xl w-fit">
        <button
          onClick={() => setTab('browse')}
          className={`px-4 py-2 rounded-xl text-xs font-black uppercase tracking-wider transition-colors ${
            tab === 'browse' ? 'bg-white dark:bg-slate-800 shadow text-tac-blue' : 'text-gray-500'
          }`}
        >
          Browse Clubs
        </button>
        <button
          onClick={() => setTab('mine')}
          className={`px-4 py-2 rounded-xl text-xs font-black uppercase tracking-wider transition-colors ${
            tab === 'mine' ? 'bg-white dark:bg-slate-800 shadow text-tac-blue' : 'text-gray-500'
          }`}
        >
          My Clubs
        </button>
      </div>

      {tab === 'browse' ? (
        <BrowseClubs onRegisterClick={handleRegisterClick} />
      ) : (
        <MyClubs onBrowseMore={() => setTab('browse')} />
      )}

      <ClubRegister
        club={selectedClub}
        isOpen={modalOpen}
        onClose={() => setModalOpen(false)}
        onRegistered={handleRegistered}
      />
    </div>
  );
};

export default ClubsHub;
