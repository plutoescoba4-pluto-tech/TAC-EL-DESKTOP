import React from 'react';
import DirectMessageView from '../sections/DirectMessageView';

export const DirectMessages: React.FC = () => {
  return <DirectMessageView />;
};
export default DirectMessages;
