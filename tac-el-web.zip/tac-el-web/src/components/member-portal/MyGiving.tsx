import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { givingService, Pledge } from '../../services/givingService';
import { Donation } from '../../types';
import { Heart, CreditCard, Smartphone, CheckCircle2, History, ArrowUpRight, ShieldCheck, Sparkles } from 'lucide-react';
import { Card, Button, Badge } from '../ui';

export const MyGiving: React.FC = () => {
  const { user, profile } = useAuth();
  const [donations, setDonations] = useState<Donation[]>([]);
  const [pledges, setPledges] = useState<Pledge[]>([]);
  const [amount, setAmount] = useState<string>('50');
  const [type, setType] = useState<Donation['type']>('tithe');
  const [channel, setChannel] = useState<'momo' | 'card'>('momo');
  const [phone, setPhone] = useState(profile?.phone || '');
  const [network, setNetwork] = useState<'MTN' | 'Vodafone' | 'AirtelTigo'>('MTN');
  const [loading, setLoading] = useState(false);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  useEffect(() => {
    if (user?.id) {
      givingService.getUserDonations(user.id).then(setDonations);
      givingService.getPledges(user.id).then(setPledges);
    }
  }, [user]);

  const handleGive = async (e: React.FormEvent) => {
    e.preventDefault();
    const numAmount = parseFloat(amount);
    if (!numAmount || numAmount <= 0) return;

    setLoading(true);
    try {
      // Simulate Paystack Ghana Mobile Money / Card confirmation
      const ref = `TAC-PAY-${Date.now()}`;
      await givingService.recordDonation({
        userId: user?.id || 'guest',
        userName: profile?.name || 'Member',
        amount: numAmount,
        type,
        date: new Date().toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' }),
        reference: ref,
        channel: channel === 'momo' ? `${network} MoMo` : 'Visa/Mastercard'
      });

      const updated = await givingService.getUserDonations(user?.id || '');
      setDonations(updated);
      setSuccessMsg(`Payment of GHS ${numAmount.toFixed(2)} received! Thank you for supporting the Kingdom.`);
      setTimeout(() => setSuccessMsg(null), 5000);
    } finally {
      setLoading(false);
    }
  };

  const totalGiven = donations.reduce((acc, d) => acc + (d.amount || 0), 0);

  return (
    <div className="max-w-4xl mx-auto p-4 sm:p-6 space-y-6">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-tac-blue-dark via-slate-900 to-tac-blue text-white rounded-3xl p-6 sm:p-8 relative overflow-hidden shadow-xl">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 relative z-10">
          <div>
            <div className="flex items-center gap-2 text-tac-red font-black text-xs uppercase tracking-widest mb-1">
              <Heart size={16} />
              <span>Kingdom Partnership</span>
            </div>
            <h2 className="text-2xl font-black uppercase tracking-tight">Assembly Giving & Tithes</h2>
            <p className="text-white/70 text-xs mt-1">
              Secure Mobile Money (MTN, Telecel, AirtelTigo) & Card via Paystack
            </p>
          </div>

          <div className="bg-white/10 backdrop-blur-md rounded-2xl p-4 border border-white/10 text-right">
            <span className="text-[10px] font-black uppercase tracking-widest text-white/50 block">Total Lifetime Given</span>
            <span className="text-2xl font-black text-emerald-400">GHS {totalGiven.toFixed(2)}</span>
          </div>
        </div>
      </div>

      {successMsg && (
        <div className="p-4 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 rounded-2xl flex items-center gap-3 text-emerald-600 dark:text-emerald-400 text-xs font-bold animate-fadeIn">
          <CheckCircle2 size={18} className="shrink-0" />
          <span>{successMsg}</span>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Donation Form */}
        <div className="lg:col-span-2">
          <Card>
            <h3 className="text-sm font-black uppercase tracking-wider text-tac-blue-dark dark:text-white mb-4">
              Make a Contribution
            </h3>

            <form onSubmit={handleGive} className="space-y-4">
              {/* Type Selection */}
              <div>
                <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-2">
                  Category
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {(['tithe', 'offering', 'welfare', 'other'] as const).map((cat) => (
                    <button
                      key={cat}
                      type="button"
                      onClick={() => setType(cat)}
                      className={`p-3 rounded-2xl border text-xs font-black uppercase tracking-wider transition-all ${
                        type === cat
                          ? 'bg-tac-blue text-white border-tac-blue shadow-md shadow-tac-blue/20'
                          : 'bg-gray-50 dark:bg-white/5 border-[var(--Bdr)] text-[var(--Text)] dark:text-white hover:bg-gray-100'
                      }`}
                    >
                      {cat}
                    </button>
                  ))}
                </div>
              </div>

              {/* Amount Quick Select & Custom */}
              <div>
                <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-2">
                  Amount (GHS)
                </label>
                <div className="flex flex-wrap gap-2 mb-3">
                  {['20', '50', '100', '200', '500'].map((val) => (
                    <button
                      key={val}
                      type="button"
                      onClick={() => setAmount(val)}
                      className={`px-3.5 py-1.5 rounded-xl border text-xs font-bold transition-all ${
                        amount === val
                          ? 'bg-tac-blue-dark text-white border-tac-blue-dark'
                          : 'bg-gray-50 dark:bg-white/5 border-[var(--Bdr)] hover:bg-gray-100 dark:hover:bg-white/10'
                      }`}
                    >
                      GH₵ {val}
                    </button>
                  ))}
                </div>
                <input
                  type="number"
                  min="1"
                  step="any"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  placeholder="Enter amount in GHS"
                  className="w-full px-4 py-3 bg-gray-50 dark:bg-slate-800 border border-[var(--Bdr)] rounded-2xl text-lg font-black outline-none focus:border-tac-blue text-[var(--Text)] dark:text-white"
                />
              </div>

              {/* Payment Method */}
              <div>
                <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-2">
                  Payment Method
                </label>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => setChannel('momo')}
                    className={`p-3.5 rounded-2xl border flex items-center justify-center gap-2 text-xs font-black uppercase tracking-wider transition-all ${
                      channel === 'momo'
                        ? 'bg-amber-500/10 border-amber-500 text-amber-600 dark:text-amber-400'
                        : 'border-[var(--Bdr)] text-gray-400 hover:bg-gray-50'
                    }`}
                  >
                    <Smartphone size={18} />
                    Mobile Money
                  </button>
                  <button
                    type="button"
                    onClick={() => setChannel('card')}
                    className={`p-3.5 rounded-2xl border flex items-center justify-center gap-2 text-xs font-black uppercase tracking-wider transition-all ${
                      channel === 'card'
                        ? 'bg-tac-blue/10 border-tac-blue text-tac-blue'
                        : 'border-[var(--Bdr)] text-gray-400 hover:bg-gray-50'
                    }`}
                  >
                    <CreditCard size={18} />
                    Bank Card
                  </button>
                </div>
              </div>

              {channel === 'momo' && (
                <div className="space-y-3 p-4 bg-amber-50/50 dark:bg-amber-950/20 border border-amber-200/50 dark:border-amber-800/50 rounded-2xl">
                  <div className="flex gap-2">
                    {(['MTN', 'Vodafone', 'AirtelTigo'] as const).map((net) => (
                      <button
                        key={net}
                        type="button"
                        onClick={() => setNetwork(net)}
                        className={`flex-1 py-2 rounded-xl text-xs font-black uppercase transition-all ${
                          network === net
                            ? 'bg-amber-500 text-white shadow-sm'
                            : 'bg-white dark:bg-slate-900 border border-amber-200 dark:border-amber-800 text-[var(--Text)] dark:text-white'
                        }`}
                      >
                        {net}
                      </button>
                    ))}
                  </div>
                  <div>
                    <label className="block text-[10px] font-black uppercase tracking-wider text-gray-500 mb-1">
                      {network} Wallet Number
                    </label>
                    <input
                      type="tel"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      placeholder="024 XXX XXXX"
                      className="w-full px-3 py-2 bg-white dark:bg-slate-900 border border-amber-200 dark:border-amber-800 rounded-xl text-sm font-bold outline-none"
                    />
                  </div>
                </div>
              )}

              <Button
                type="submit"
                variant="primary"
                size="lg"
                loading={loading}
                className="w-full"
                icon={<ShieldCheck size={18} />}
              >
                Pay GH₵ {parseFloat(amount || '0').toFixed(2)} via Paystack
              </Button>
            </form>
          </Card>
        </div>

        {/* History & Pledges */}
        <div className="space-y-6">
          <Card>
            <div className="flex items-center justify-between mb-4">
              <h4 className="text-xs font-black uppercase tracking-wider text-tac-blue-dark dark:text-white flex items-center gap-1.5">
                <History size={16} />
                Recent Giving
              </h4>
              <Badge variant="green">{donations.length} records</Badge>
            </div>

            <div className="space-y-3 max-h-80 overflow-y-auto pr-1">
              {donations.length === 0 ? (
                <p className="text-xs text-[var(--Sub)] text-center py-6">
                  No giving records found yet.
                </p>
              ) : (
                donations.slice(0, 10).map((d) => (
                  <div key={d.id} className="p-3 bg-gray-50 dark:bg-white/5 rounded-2xl border border-[var(--Bdr)] flex items-center justify-between text-xs">
                    <div>
                      <p className="font-black uppercase tracking-wide text-tac-blue-dark dark:text-white">{d.type}</p>
                      <p className="text-[10px] text-[var(--Sub)]">{d.date}</p>
                    </div>
                    <span className="font-mono font-black text-emerald-600 dark:text-emerald-400">
                      +GH₵ {d.amount?.toFixed(2)}
                    </span>
                  </div>
                ))
              )}
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
};
export default MyGiving;
