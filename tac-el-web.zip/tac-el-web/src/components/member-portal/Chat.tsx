import React from 'react';
import ChatView from '../sections/ChatView';

export const Chat: React.FC = () => {
  return <ChatView />;
};
export default Chat;
