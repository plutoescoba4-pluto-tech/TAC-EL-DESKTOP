import React from 'react';
import { useNavigate } from 'react-router-dom';
import { MessageSquare, Users, ChevronRight } from 'lucide-react';
import { useChatUnread } from '../../lib/chatUnread';

/** Phone "Chat" tab: pick the Church chat (everyone) or the Network chat (people and private messages). */
export const ChatChooser: React.FC = () => {
  const navigate = useNavigate();
  const unread = useChatUnread();
  const dmUnread = Object.values(unread.dmBySender || {}).reduce((a, b) => a + b, 0);

  const Card: React.FC<{ icon: React.ReactNode; title: string; text: string; badge?: number; onClick: () => void }> = ({ icon, title, text, badge, onClick }) => (
    <button
      type="button"
      onClick={onClick}
      className="w-full flex items-center gap-4 p-5 bg-white dark:bg-slate-900 border border-[var(--Bdr)] rounded-3xl shadow-sm active:scale-[0.98] transition-all text-left"
    >
      <div className="w-14 h-14 rounded-2xl bg-tac-blue/10 text-tac-blue flex items-center justify-center shrink-0">{icon}</div>
      <div className="min-w-0 flex-1">
        <p className="text-base font-black text-tac-blue-dark dark:text-white leading-tight">{title}</p>
        <p className="text-xs text-[var(--Sub)] mt-1 leading-snug">{text}</p>
      </div>
      {badge && badge > 0 ? (
        <span className="min-w-[22px] h-[22px] px-1.5 bg-tac-red text-white text-[11px] font-black rounded-full flex items-center justify-center">{badge > 99 ? '99+' : badge}</span>
      ) : null}
      <ChevronRight size={20} className="text-gray-300 shrink-0" />
    </button>
  );

  return (
    <div className="p-4 max-w-xl mx-auto space-y-4">
      <div className="pt-2">
        <h2 className="text-xl font-black text-tac-blue-dark dark:text-white uppercase tracking-tight">Chat</h2>
        <p className="text-xs text-[var(--Sub)] mt-1">Where would you like to chat?</p>
      </div>
      <Card
        icon={<MessageSquare size={28} />}
        title="Church Chat"
        text="The assembly fellowship group. Everyone in the church is here."
        badge={unread.global}
        onClick={() => navigate('/dashboard/chat')}
      />
      <Card
        icon={<Users size={28} />}
        title="Network Chat"
        text="Find people in the Assembly Network and message them privately."
        badge={dmUnread}
        onClick={() => navigate('/dashboard/network')}
      />
    </div>
  );
};
export default ChatChooser;
