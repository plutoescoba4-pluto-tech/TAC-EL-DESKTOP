import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { prayerRequestsService } from '../../services/pendingSchemaServices';
import { Heart, Send, Mic, ShieldAlert, CheckCircle2, Lock, Sparkles, Play, Pause } from 'lucide-react';
import { Card, Button, Badge } from '../ui';
import { WhatsAppAudioRecorder } from '../chat/WhatsAppAudioRecorder';

export const PrayerRequests: React.FC = () => {
  const { user, profile } = useAuth();
  const [requests, setRequests] = useState<any[]>([]);
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [confidential, setConfidential] = useState(false);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const [showRecorder, setShowRecorder] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);

  useEffect(() => {
    if (!user) return;
    return prayerRequestsService.subscribeMine(user.id, setRequests);
  }, [user]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !content.trim()) return;

    setSubmitting(true);
    setSubmitError(null);
    try {
      await prayerRequestsService.submit({
        userId: user?.id || 'guest',
        userName: profile?.name || 'Assembly Member',
        userKinId: profile?.userId || 'TAC-EL-MEMBER',
        title: title.trim(),
        content: content.trim(),
        confidential, // if true, only presbytery/pastor can see
        audioVoiceNote: audioUrl || null,
      });

      setTitle('');
      setContent('');
      setAudioUrl(null);
      setSubmitted(true);
      setTimeout(() => setSubmitted(false), 4000);
    } catch (err: any) {
      // This was failing silently before — the submit error was never
      // caught, so nothing told you it hadn't gone through.
      console.error('Prayer request submit failed:', err);
      setSubmitError(
        err?.message?.includes('relation') || err?.code === '42P01'
          ? "This feature isn't fully set up on the server yet — please let the admin know."
          : (err?.message || 'Could not send your prayer request. Please check your connection and try again.')
      );
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto p-4 sm:p-6 space-y-6">
      <div className="bg-gradient-to-r from-tac-blue-dark via-slate-900 to-tac-blue text-white rounded-3xl p-6 sm:p-8 relative overflow-hidden shadow-xl">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl bg-tac-red/20 text-tac-red flex items-center justify-center border border-tac-red/30">
            <Heart size={28} />
          </div>
          <div>
            <h2 className="text-2xl font-black uppercase tracking-tight">Sanctuary Prayer Altar</h2>
            <p className="text-white/70 text-xs mt-0.5">
              Submit your burdens, thanksgiving, and prayer requests to the Presbytery and Intercessory Ministry
            </p>
          </div>
        </div>
      </div>

      {submitted && (
        <div className="p-4 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 rounded-2xl flex items-center gap-3 text-emerald-600 dark:text-emerald-400 text-xs font-bold animate-fadeIn">
          <CheckCircle2 size={18} className="shrink-0" />
          <span>Your prayer petition has been received on the altar. The elders are praying over your request.</span>
        </div>
      )}

      {submitError && (
        <div className="p-4 bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900 rounded-2xl flex items-center justify-between gap-3 text-tac-red text-xs font-bold animate-fadeIn">
          <span>{submitError}</span>
          <button onClick={() => setSubmitError(null)} className="shrink-0 text-[10px] uppercase opacity-70 hover:opacity-100">Dismiss</button>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-2">
          <Card>
            <h3 className="text-sm font-black uppercase tracking-wider text-tac-blue-dark dark:text-white mb-4">
              Submit Prayer Request
            </h3>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
                  Prayer Focus / Subject
                </label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g. Healing and Strength, Examination Favour, Family Breakthrough"
                  className="w-full px-4 py-3 bg-gray-50 dark:bg-slate-800 border border-[var(--Bdr)] rounded-2xl text-sm font-bold outline-none focus:border-tac-blue text-[var(--Text)] dark:text-white"
                />
              </div>

              <div>
                <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
                  Prayer Request Details
                </label>
                <textarea
                  required
                  rows={4}
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  placeholder="Share details of what you desire the Lord to do..."
                  className="w-full px-4 py-3 bg-gray-50 dark:bg-slate-800 border border-[var(--Bdr)] rounded-2xl text-sm outline-none focus:border-tac-blue text-[var(--Text)] dark:text-white"
                />
              </div>

              <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setShowRecorder(true)}
                  className={`px-4 py-2.5 rounded-2xl border text-xs font-black uppercase tracking-wider flex items-center gap-2 transition-all ${
                    audioUrl 
                      ? 'bg-emerald-500/10 border-emerald-500 text-emerald-600' 
                      : 'bg-gray-50 dark:bg-white/5 border-[var(--Bdr)] text-gray-500 hover:text-tac-blue'
                  }`}
                >
                  <Mic size={16} />
                  <span>{audioUrl ? 'Voice Note Attached ✓' : 'Record Audio Prayer'}</span>
                </button>

                <label className="flex items-center gap-2 text-xs font-bold text-[var(--Sub)] cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={confidential}
                    onChange={(e) => setConfidential(e.target.checked)}
                    className="w-4 h-4 rounded text-tac-blue"
                  />
                  <Lock size={14} className="text-amber-500" />
                  <span>Presbytery / Elders Eyes Only</span>
                </label>
              </div>

              <Button
                type="submit"
                variant="primary"
                size="lg"
                loading={submitting}
                className="w-full mt-4"
                icon={<Send size={16} />}
              >
                Place Request on Altar
              </Button>
            </form>
          </Card>
        </div>

        <div>
          <Card>
            <div className="flex items-center justify-between mb-4">
              <h4 className="text-xs font-black uppercase tracking-wider text-tac-blue-dark dark:text-white">
                My Prayer Petitions
              </h4>
              <Badge variant="blue">{requests.length}</Badge>
            </div>

            <div className="space-y-3 max-h-96 overflow-y-auto pr-1">
              {requests.length === 0 ? (
                <p className="text-xs text-[var(--Sub)] text-center py-8">
                  No petitions submitted yet.
                </p>
              ) : (
                requests.map((r) => (
                  <div key={r.id} className="p-3 bg-gray-50 dark:bg-white/5 rounded-2xl border border-[var(--Bdr)] space-y-1.5 text-xs">
                    <div className="flex items-start justify-between">
                      <p className="font-bold text-tac-blue-dark dark:text-white">{r.title}</p>
                      <Badge variant={r.status === 'interceding' ? 'amber' : 'green'}>{r.status}</Badge>
                    </div>
                    <p className="text-[var(--Sub)] line-clamp-2">{r.content}</p>
                    {r.confidential && (
                      <span className="text-[9px] font-black text-amber-500 flex items-center gap-1">
                        <Lock size={10} /> Confidential
                      </span>
                    )}
                  </div>
                ))
              )}
            </div>
          </Card>
        </div>
      </div>

      <WhatsAppAudioRecorder
        isOpen={showRecorder}
        onClose={() => setShowRecorder(false)}
        onSend={(_blob, dataUrl) => {
          setAudioUrl(dataUrl);
          setShowRecorder(false);
        }}
      />
    </div>
  );
};
export default PrayerRequests;
