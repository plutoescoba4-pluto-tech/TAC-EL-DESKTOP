import React, { useState, useEffect } from 'react';
import { clubsService } from '../../services/clubsService';
import { CLUB_ROLE_LABEL } from '../../services/clubOfficersService';
import { useAuth } from '../../context/AuthContext';
import { Users, Calendar, Award, CheckCircle2, Clock, Sparkles } from 'lucide-react';
import { Card, Button, Badge } from '../ui';

export const MyServing: React.FC = () => {
  const { profile } = useAuth();

  // The clubs this person really belongs to, with their role in each (from the database).
  const [myClubs, setMyClubs] = useState<{ id: string; name: string; role: string }[]>([]);
  useEffect(() => {
    if (!profile?.uid) return;
    Promise.all([clubsService.getClubs(), clubsService.getMyMemberships(profile.uid)]).then(([all, mine]) => {
      setMyClubs(all.filter((c) => mine[c.id]).map((c) => ({ id: c.id, name: c.name, role: mine[c.id] })));
    });
  }, [profile?.uid]);

  const upcomingDuties = [
    { id: '1', role: 'Scripture Reader', service: 'Sunday Divine Service', date: 'Next Sunday, 8:00 AM', status: 'confirmed' },
    { id: '2', role: 'Protocol & Welcoming', service: 'Mid-Week Teaching Service', date: 'Wednesday, 6:30 PM', status: 'pending' }
  ];

  return (
    <div className="max-w-4xl mx-auto p-4 sm:p-6 space-y-6">
      <div className="bg-gradient-to-r from-tac-blue-dark via-slate-900 to-tac-blue text-white rounded-3xl p-6 sm:p-8 relative overflow-hidden shadow-xl">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl bg-tac-blue/20 text-tac-blue-light flex items-center justify-center border border-tac-blue/30">
            <Award size={28} />
          </div>
          <div>
            <h2 className="text-2xl font-black uppercase tracking-tight">My Serving & Ministries</h2>
            <p className="text-white/70 text-xs mt-0.5">
              Faithful stewardship and active ministry involvement at TAC-EL
            </p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <h3 className="text-sm font-black uppercase tracking-wider text-tac-blue-dark dark:text-white mb-4 flex items-center gap-2">
            <Calendar size={18} className="text-tac-blue" />
            Upcoming Roster & Duty Assignments
          </h3>

          <div className="space-y-3">
            {upcomingDuties.map((duty) => (
              <div key={duty.id} className="p-4 bg-gray-50 dark:bg-white/5 rounded-2xl border border-[var(--Bdr)] space-y-2">
                <div className="flex items-center justify-between">
                  <h4 className="font-black text-xs uppercase tracking-wide text-tac-blue-dark dark:text-white">{duty.role}</h4>
                  <Badge variant={duty.status === 'confirmed' ? 'green' : 'amber'}>{duty.status}</Badge>
                </div>
                <div className="flex items-center justify-between text-xs text-[var(--Sub)]">
                  <span>{duty.service}</span>
                  <span className="font-bold flex items-center gap-1 text-[var(--Text)] dark:text-white">
                    <Clock size={12} />
                    {duty.date}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </Card>

        <Card>
          <h3 className="text-sm font-black uppercase tracking-wider text-tac-blue-dark dark:text-white mb-4 flex items-center gap-2">
            <Users size={18} className="text-tac-blue" />
            My Active Ministry Wings
          </h3>

          <div className="space-y-3">
            {myClubs.length === 0 && (
              <p className="text-xs text-[var(--Sub)] py-4 text-center">You have not joined a club yet. Open Clubs to apply.</p>
            )}
            {myClubs.map((c) => (
              <div key={c.id} className="p-4 bg-tac-blue/5 dark:bg-white/5 border border-tac-blue/15 rounded-2xl flex items-center justify-between">
                <div>
                  <h4 className="font-black text-xs uppercase tracking-wide text-tac-blue-dark dark:text-white">
                    {c.name}
                  </h4>
                  <p className="text-[10px] text-[var(--Sub)] mt-0.5">{CLUB_ROLE_LABEL[c.role] || 'Member'}</p>
                </div>
                <Badge variant="blue">Enrolled</Badge>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
};
export default MyServing;
