import React from 'react';
import { UserCheck, Shield, BookOpen, Users } from 'lucide-react';
import { Card } from '../ui';

interface RoleSelectProps {
  currentRole: string;
  onSelectRole: (role: string) => void;
}

export const RoleSelect: React.FC<RoleSelectProps> = ({ currentRole, onSelectRole }) => {
  const presbyteryRoles = [
    { id: 'resident_minister', label: 'Resident Minister / Pastor', desc: 'Assembly spiritual oversight & pulpit administration', icon: BookOpen },
    { id: 'presiding_elder', label: 'Presiding Elder', desc: 'Council head, administrative & assembly direction', icon: Shield },
    { id: 'executive_elder', label: 'Executive Elder', desc: 'Discipline, member welfare & spiritual operations', icon: UserCheck },
    { id: 'wing_patron', label: 'Ministry Wing Overseer', desc: 'Patron and spiritual guardian for wings/clubs', icon: Users }
  ];

  return (
    <div className="space-y-4">
      <div className="text-left">
        <h3 className="text-sm font-black uppercase tracking-wider text-tac-blue-dark dark:text-white">
          Active Presbytery Capacity
        </h3>
        <p className="text-xs text-[var(--Sub)]">
          Select your operational seat for this session
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {presbyteryRoles.map((r) => {
          const Icon = r.icon;
          const isSelected = currentRole === r.id;
          return (
            <button
              key={r.id}
              onClick={() => onSelectRole(r.id)}
              className={`p-4 rounded-2xl border text-left transition-all flex items-start gap-3.5 ${
                isSelected
                  ? 'bg-amber-500/10 border-amber-500 text-amber-700 dark:text-amber-300 ring-2 ring-amber-500/20 shadow-md'
                  : 'bg-white dark:bg-slate-900 border-[var(--Bdr)] text-[var(--Text)] dark:text-white hover:border-amber-400'
              }`}
            >
              <div className={`p-2.5 rounded-xl ${isSelected ? 'bg-amber-500 text-white' : 'bg-amber-500/10 text-amber-600'} shrink-0`}>
                <Icon size={20} />
              </div>
              <div className="min-w-0">
                <h4 className="font-black text-xs uppercase tracking-wide truncate">{r.label}</h4>
                <p className="text-[10px] text-[var(--Sub)] mt-0.5 line-clamp-2">{r.desc}</p>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
};
export default RoleSelect;
