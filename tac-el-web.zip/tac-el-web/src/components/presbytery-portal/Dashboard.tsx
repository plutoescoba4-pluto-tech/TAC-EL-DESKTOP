import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { prayerRequestsService } from '../../services/pendingSchemaServices';
import { noticesService } from '../../services/contentService';
import { UserCheck, Shield, Heart, Bell, ScrollText, Users, ArrowUpRight, Radio, CheckCircle2, Trash2 } from 'lucide-react';
import { Card, Button, Badge } from '../ui';
import { RoleSelect } from './RoleSelect';

interface DashboardProps {
  onNavigateTab?: (tab: string) => void;
}

export const Dashboard: React.FC<DashboardProps> = ({ onNavigateTab }) => {
  const { profile } = useAuth();
  const [currentRole, setCurrentRole] = useState('presiding_elder');
  const [prayerCount, setPrayerCount] = useState(0);
  const [pendingNotices, setPendingNotices] = useState(0);
  const [urgentPetitions, setUrgentPetitions] = useState<any[]>([]);

  const loadPrayerQueue = () => {
    // The full "waiting" (status='interceding') queue, not just a 5-item
    // preview — this is also what the council works through and clears.
    prayerRequestsService.getWaiting(100).then((rows) => {
      setPrayerCount(rows.length);
      setUrgentPetitions(rows);
    }).catch(() => {});
  };

  useEffect(() => {
    loadPrayerQueue();

    noticesService.getPendingNotices().then((rows) => {
      setPendingNotices(rows.length);
    }).catch(() => {});
  }, []);

  const handleMarkAnswered = async (id: string) => {
    try {
      await prayerRequestsService.markAnswered(id);
      setUrgentPetitions((prev) => prev.filter((p) => p.id !== id));
      setPrayerCount((c) => Math.max(0, c - 1));
    } catch (e) {
      console.error('Failed to mark prayer as answered:', e);
    }
  };

  const handleDeletePrayer = async (id: string) => {
    if (!window.confirm('Remove this prayer request from the altar?')) return;
    try {
      await prayerRequestsService.remove(id);
      setUrgentPetitions((prev) => prev.filter((p) => p.id !== id));
      setPrayerCount((c) => Math.max(0, c - 1));
    } catch (e) {
      console.error('Failed to delete prayer request:', e);
    }
  };

  return (
    <div className="max-w-4xl mx-auto p-4 sm:p-6 space-y-6">
      <div className="bg-gradient-to-r from-amber-950 via-slate-900 to-amber-900 text-white rounded-3xl p-6 sm:p-8 relative overflow-hidden shadow-xl border border-amber-500/20">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 relative z-10">
          <div>
            <div className="flex items-center gap-2 text-amber-400 font-black text-xs uppercase tracking-widest mb-1">
              <Shield size={16} />
              <span>Presbytery Sanctuary High Council</span>
            </div>
            <h2 className="text-2xl font-black uppercase tracking-tight">Elders Council Portal</h2>
            <p className="text-white/70 text-xs mt-1">
              Pastoral oversight, prayer petitions altar, and assembly governance
            </p>
          </div>

          <div className="bg-white/10 backdrop-blur-md rounded-2xl p-4 border border-white/10 text-right">
            <span className="text-[10px] font-black uppercase tracking-widest text-amber-400/80 block">Active Clearance</span>
            <span className="text-base font-black uppercase text-amber-300">{profile?.role || 'Presbytery'}</span>
          </div>
        </div>
      </div>

      {/* Role Switcher */}
      <RoleSelect currentRole={currentRole} onSelectRole={setCurrentRole} />

      {/* Quick Metrics */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <Card className="text-center p-4">
          <Heart size={20} className="text-tac-red mx-auto mb-1" />
          <span className="text-[10px] font-black uppercase text-gray-400">Prayer Petitions</span>
          <p className="text-2xl font-black text-tac-blue-dark dark:text-white mt-1">{prayerCount}</p>
        </Card>
        <Card className="text-center p-4">
          <Bell size={20} className="text-amber-500 mx-auto mb-1" />
          <span className="text-[10px] font-black uppercase text-gray-400">Notice Approvals</span>
          <p className="text-2xl font-black text-tac-blue-dark dark:text-white mt-1">{pendingNotices}</p>
        </Card>
        <Card className="text-center p-4">
          <Users size={20} className="text-tac-blue mx-auto mb-1" />
          <span className="text-[10px] font-black uppercase text-gray-400">Ministry Wings</span>
          <p className="text-2xl font-black text-tac-blue-dark dark:text-white mt-1">8</p>
        </Card>
        <Card className="text-center p-4">
          <UserCheck size={20} className="text-emerald-500 mx-auto mb-1" />
          <span className="text-[10px] font-black uppercase text-gray-400">Active Elders</span>
          <p className="text-2xl font-black text-tac-blue-dark dark:text-white mt-1">5</p>
        </Card>
      </div>

      {/* Pastoral Prayer Petitions Altar */}
      <Card>
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-xs font-black uppercase tracking-wider text-tac-blue-dark dark:text-white flex items-center gap-1.5">
            <Heart size={16} className="text-tac-red" />
            Member Petitions & Intercession Altar
          </h3>
          <Badge variant="red">{urgentPetitions.length} Awaiting Prayer</Badge>
        </div>

        <div className="space-y-3">
          {urgentPetitions.length === 0 ? (
            <p className="py-6 text-center text-xs text-[var(--Sub)]">
              No confidential prayer petitions at this time.
            </p>
          ) : (
            urgentPetitions.map((p) => (
              <div key={p.id} className="p-3.5 bg-gray-50 dark:bg-white/5 rounded-2xl border border-[var(--Bdr)] space-y-2 text-xs">
                <div className="flex justify-between items-start">
                  <h4 className="font-bold text-tac-blue-dark dark:text-white">{p.title}</h4>
                  <span className="text-[10px] text-gray-400">{p.userName || 'Member'}</span>
                </div>
                <p className="text-[var(--Sub)] line-clamp-2">{p.content}</p>
                <div className="flex items-center gap-2 pt-1">
                  <button
                    onClick={() => handleMarkAnswered(p.id)}
                    className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-emerald-50 dark:bg-emerald-900/20 text-emerald-600 dark:text-emerald-400 text-[10px] font-black uppercase tracking-widest hover:bg-emerald-600 hover:text-white transition-all"
                  >
                    <CheckCircle2 size={12} /> Mark Answered
                  </button>
                  <button
                    onClick={() => handleDeletePrayer(p.id)}
                    className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-red-50 dark:bg-red-900/20 text-tac-red text-[10px] font-black uppercase tracking-widest hover:bg-tac-red hover:text-white transition-all"
                  >
                    <Trash2 size={12} /> Remove
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      </Card>
    </div>
  );
};
export default Dashboard;
