import React, { useState, useEffect } from 'react';
import { clubsService } from '../../services/clubsService';
import { Team } from '../../types';
import { Shield, Users, Activity, Eye, ChevronRight, CheckCircle2 } from 'lucide-react';
import { Card, Button, Badge } from '../ui';

export const ClubOversight: React.FC = () => {
  const [clubs, setClubs] = useState<Team[]>([]);
  const [selectedClub, setSelectedClub] = useState<Team | null>(null);
  const [rosterCount, setRosterCount] = useState<number>(0);

  useEffect(() => {
    clubsService.getClubs().then((all) => {
      setClubs(all);
      if (all.length > 0) setSelectedClub(all[0]);
    });
  }, []);

  useEffect(() => {
    if (selectedClub) {
      clubsService.getRoster(selectedClub.id).then(r => setRosterCount(r.length));
    }
  }, [selectedClub]);

  return (
    <div className="max-w-4xl mx-auto p-4 sm:p-6 space-y-6">
      <div>
        <h2 className="text-xl font-black text-tac-blue-dark dark:text-white uppercase tracking-tight">
          Ministry Wings & Club Oversight
        </h2>
        <p className="text-xs text-[var(--Sub)]">
          Presbytery supervisory dashboard over movements, spiritual growth, and leadership
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {clubs.map((c) => (
          <Card
            key={c.id}
            onClick={() => setSelectedClub(c)}
            className={`cursor-pointer transition-all ${
              selectedClub?.id === c.id
                ? 'border-tac-blue ring-2 ring-tac-blue/20 shadow-lg'
                : 'hover:border-gray-300 dark:hover:border-white/20'
            }`}
          >
            <div className="flex items-center gap-3">
              <div className={`w-10 h-10 rounded-2xl ${c.color || 'bg-tac-blue'} text-white font-black flex items-center justify-center`}>
                {c.name[0]}
              </div>
              <div className="min-w-0">
                <h4 className="font-bold text-xs text-tac-blue-dark dark:text-white uppercase truncate">{c.name}</h4>
                <p className="text-[10px] text-gray-400">{c.members || 25}+ Brethren</p>
              </div>
            </div>
          </Card>
        ))}
      </div>

      {selectedClub && (
        <Card className="border-t-4 border-t-tac-blue">
          <div className="flex items-start justify-between gap-4 mb-4">
            <div>
              <span className="text-[10px] font-black uppercase tracking-wider text-tac-blue">
                Presbytery Supervision Report
              </span>
              <h3 className="text-base font-black uppercase text-tac-blue-dark dark:text-white mt-0.5">
                {selectedClub.name}
              </h3>
              <p className="text-xs text-[var(--Sub)] mt-1">{selectedClub.desc}</p>
            </div>
            <Badge variant="blue">{rosterCount} Enrolled</Badge>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
            <div className="p-3 bg-gray-50 dark:bg-white/5 rounded-2xl border border-[var(--Bdr)] text-center">
              <span className="text-[10px] uppercase font-bold text-gray-400">Spiritual Health</span>
              <p className="text-sm font-black text-emerald-600 mt-1">Excellent (94%)</p>
            </div>
            <div className="p-3 bg-gray-50 dark:bg-white/5 rounded-2xl border border-[var(--Bdr)] text-center">
              <span className="text-[10px] uppercase font-bold text-gray-400">Weekly Attendance</span>
              <p className="text-sm font-black text-tac-blue mt-1">Active (~{selectedClub.members || 35})</p>
            </div>
            <div className="p-3 bg-gray-50 dark:bg-white/5 rounded-2xl border border-[var(--Bdr)] text-center">
              <span className="text-[10px] uppercase font-bold text-gray-400">Presbytery Patron</span>
              <p className="text-sm font-black text-[var(--Text)] dark:text-white mt-1">Elder Assigned</p>
            </div>
          </div>
        </Card>
      )}
    </div>
  );
};
export default ClubOversight;
