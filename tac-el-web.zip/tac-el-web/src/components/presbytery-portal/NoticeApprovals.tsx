import React, { useState, useEffect } from 'react';
import { noticesService } from '../../services/contentService';
import { CheckCircle2, XCircle, Bell, Clock } from 'lucide-react';
import { Card, Button, Badge } from '../ui';

export const NoticeApprovals: React.FC = () => {
  const [pendingNotices, setPendingNotices] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const loadNotices = async () => {
    setLoading(true);
    try {
      setPendingNotices(await noticesService.getPendingNotices());
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadNotices();
  }, []);

  const handleApprove = async (id: string) => {
    await noticesService.approveNotice(id);
    await loadNotices();
  };

  const handleReject = async (id: string) => {
    await noticesService.deleteNotice(id);
    await loadNotices();
  };

  return (
    <div className="max-w-4xl mx-auto p-4 sm:p-6 space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-xl font-black text-tac-blue-dark dark:text-white uppercase tracking-tight">
            Notice & Announcement Approvals
          </h2>
          <p className="text-xs text-[var(--Sub)]">
            Review notices submitted by ministries before publication to the Assembly
          </p>
        </div>
      </div>

      <Card>
        <div className="flex items-center justify-between mb-4">
          <span className="text-xs font-black uppercase tracking-wider text-gray-500">
            Pending Submissions ({pendingNotices.length})
          </span>
          <Badge variant="amber">Editorial Gatekeeper</Badge>
        </div>

        {pendingNotices.length === 0 ? (
          <div className="text-center py-12 space-y-2">
            <CheckCircle2 size={36} className="text-emerald-500 mx-auto" />
            <h4 className="text-sm font-bold text-[var(--Text)] dark:text-white">All Clear!</h4>
            <p className="text-xs text-[var(--Sub)]">No pending announcements awaiting presbytery review.</p>
          </div>
        ) : (
          <div className="divide-y divide-[var(--Bdr)]">
            {pendingNotices.map((n) => (
              <div key={n.id} className="py-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <Badge variant="blue">{n.type === 'urg' ? 'Urgent' : n.type === 'pin' ? 'Pinned' : 'General'}</Badge>
                    <h4 className="font-bold text-sm text-tac-blue-dark dark:text-white">{n.title}</h4>
                  </div>
                  <p className="text-xs text-[var(--Sub)] line-clamp-2">{n.body}</p>
                  <p className="text-[10px] text-gray-400">Submitted by: {n.author || 'Ministry Leader'}</p>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => handleReject(n.id)}
                    icon={<XCircle size={14} className="text-red-500" />}
                  >
                    Reject
                  </Button>
                  <Button
                    size="sm"
                    variant="primary"
                    onClick={() => handleApprove(n.id)}
                    icon={<CheckCircle2 size={14} />}
                  >
                    Approve & Publish
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}
      </Card>
    </div>
  );
};
export default NoticeApprovals;
