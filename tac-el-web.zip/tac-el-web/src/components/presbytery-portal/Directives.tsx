import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { directivesService } from '../../services/directivesService';
import { ScrollText, Plus, Send, ShieldAlert, CheckCircle2 } from 'lucide-react';
import { Card, Button, Badge } from '../ui';

export const Directives: React.FC = () => {
  const { profile } = useAuth();
  const [directives, setDirectives] = useState<any[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [scope, setScope] = useState<'assembly_wide' | 'leaders_only' | 'wings_only'>('assembly_wide');
  const [saving, setSaving] = useState(false);

  // directives (per your schema) has one plain `message` column — no
  // title/scope columns yet, so they're packed into the message text as
  // "[scope] Title\n\nBody" and parsed back out on read. See MIGRATION_NOTES.md
  // if you'd rather add real columns for these.
  const parseDirective = (d: any) => {
    const match = /^\[(.+?)\]\s([^\n]*)\n\n([\s\S]*)$/.exec(d.message || '');
    return {
      id: d.id,
      scope: match?.[1] || 'assembly_wide',
      title: match?.[2] || d.message || '',
      content: match ? match[3] : '',
      issuedBy: d.fromName || 'Presbytery Council',
      date: new Date(d.createdAt).toLocaleDateString('en-GB'),
    };
  };

  const loadDirectives = async () => {
    try {
      const rows = await directivesService.getDirectives();
      setDirectives(rows.map(parseDirective));
    } catch (e) {
      // ignore
    }
  };

  useEffect(() => {
    loadDirectives();
  }, []);

  const handleIssue = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !content.trim()) return;

    setSaving(true);
    try {
      const packedMessage = `[${scope}] ${title.trim()}\n\n${content.trim()}`;
      await directivesService.sendDirective(profile?.uid || '', packedMessage);

      setTitle('');
      setContent('');
      setShowForm(false);
      await loadDirectives();
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto p-4 sm:p-6 space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-xl font-black text-tac-blue-dark dark:text-white uppercase tracking-tight">
            Pastoral & Council Directives
          </h2>
          <p className="text-xs text-[var(--Sub)]">
            Issue ecclesiastical proclamations, communion directives, and official resolutions
          </p>
        </div>

        <Button
          variant="primary"
          onClick={() => setShowForm(!showForm)}
          icon={<Plus size={16} />}
        >
          {showForm ? 'Cancel' : 'Issue Directive'}
        </Button>
      </div>

      {showForm && (
        <Card className="border-amber-500 animate-fadeIn">
          <h3 className="text-sm font-black uppercase tracking-wider text-tac-blue-dark dark:text-white mb-4">
            New Presbytery Directive
          </h3>

          <form onSubmit={handleIssue} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
                  Directive Title
                </label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g. 21-Day Assembly Fasting & Consecration Protocol"
                  className="w-full px-4 py-2.5 bg-gray-50 dark:bg-slate-800 border border-[var(--Bdr)] rounded-2xl text-sm font-bold outline-none"
                />
              </div>

              <div>
                <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
                  Circulation Scope
                </label>
                <select
                  value={scope}
                  onChange={(e) => setScope(e.target.value as any)}
                  className="w-full px-4 py-2.5 bg-gray-50 dark:bg-slate-800 border border-[var(--Bdr)] rounded-2xl text-sm font-bold outline-none"
                >
                  <option value="assembly_wide">Assembly-Wide (All Members)</option>
                  <option value="leaders_only">Group Leaders & Officers Only</option>
                  <option value="wings_only">Wing Executives Only</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
                Directive Text & Scriptural Backing
              </label>
              <textarea
                required
                rows={5}
                value={content}
                onChange={(e) => setContent(e.target.value)}
                placeholder="Declare the instructions, biblical grounding, timings, and expectations..."
                className="w-full px-4 py-3 bg-gray-50 dark:bg-slate-800 border border-[var(--Bdr)] rounded-2xl text-sm outline-none"
              />
            </div>

            <div className="flex justify-end gap-3 pt-2">
              <Button type="button" variant="ghost" onClick={() => setShowForm(false)}>
                Cancel
              </Button>
              <Button type="submit" variant="primary" loading={saving} icon={<Send size={16} />}>
                Seal & Proclaim Directive
              </Button>
            </div>
          </form>
        </Card>
      )}

      <div className="space-y-4">
        {directives.length === 0 ? (
          <Card>
            <p className="py-8 text-center text-xs text-[var(--Sub)]">
              No directives on record. Click "Issue Directive" to publish the first pastoral proclamation.
            </p>
          </Card>
        ) : (
          directives.map((dir) => (
            <Card key={dir.id} className="border-l-4 border-l-amber-500">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-2">
                <div className="flex items-center gap-2">
                  <Badge variant="amber">{dir.scope?.replace('_', ' ').toUpperCase()}</Badge>
                  <h4 className="font-black text-sm uppercase text-tac-blue-dark dark:text-white">
                    {dir.title}
                  </h4>
                </div>
                <span className="text-[10px] text-gray-400">{dir.date}</span>
              </div>
              <p className="text-xs text-[var(--Text)] dark:text-gray-300 whitespace-pre-wrap leading-relaxed">
                {dir.content}
              </p>
              <p className="text-[10px] text-[var(--Sub)] mt-3">
                Issued By: <span className="font-bold">{dir.issuedBy}</span>
              </p>
            </Card>
          ))
        )}
      </div>
    </div>
  );
};
export default Directives;
