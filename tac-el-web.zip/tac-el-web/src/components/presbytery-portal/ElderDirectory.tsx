import React, { useEffect, useMemo, useState } from 'react';
import { Phone, Mail, Search, IdCard } from 'lucide-react';
import { Card, Badge } from '../ui';
import { supabase } from '../../supabase';
import { rowToProfile } from '../../services/authService';
import { UserProfile } from '../../types';

/** Real list: everyone an administrator has set to the Presbytery role. Nothing is typed in by hand here. */
export const ElderDirectory: React.FC = () => {
  const [search, setSearch] = useState('');
  const [people, setPeople] = useState<UserProfile[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const load = async () => {
    setError('');
    const { data, error: err } = await supabase.from('profiles').select('*').eq('role', 'presbytery').order('full_name', { ascending: true });
    if (err) setError(err.message);
    else setPeople((data || []).map(rowToProfile));
    setLoading(false);
  };

  useEffect(() => {
    load();
    // keep the list live when an admin changes someone's role
    const ch = supabase.channel('presbytery-directory')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'profiles' }, () => load())
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, []);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return people;
    return people.filter((p) =>
      p.name.toLowerCase().includes(q) ||
      (p.userId || '').toLowerCase().includes(q) ||
      (p.offices || []).join(' ').toLowerCase().includes(q) ||
      (p.occupation || '').toLowerCase().includes(q));
  }, [people, search]);

  return (
    <div className="max-w-4xl mx-auto p-4 sm:p-6 space-y-6">
      <div>
        <h2 className="text-xl font-black text-tac-blue-dark dark:text-white uppercase tracking-tight">Presbytery Council Directory</h2>
        <p className="text-xs text-[var(--Sub)]">Ministers, Elders and Deaconesses serving East Legon Assembly. The list follows the roles set by the administrator.</p>
      </div>

      <div className="flex items-center gap-3 bg-white dark:bg-slate-900 border border-[var(--Bdr)] rounded-2xl px-4 py-3">
        <Search size={18} className="text-gray-400" />
        <input
          type="text" value={search} onChange={(e) => setSearch(e.target.value)}
          placeholder="Search by name, TAC ID or office..."
          className="bg-transparent border-none outline-none text-sm text-[var(--Text)] dark:text-white font-medium w-full"
        />
      </div>

      {loading && <p className="text-xs text-[var(--Sub)] text-center py-8">Loading...</p>}
      {error && <p className="text-xs text-red-600 text-center py-4">Could not load the directory: {error}</p>}
      {!loading && !error && filtered.length === 0 && (
        <Card><p className="py-8 text-center text-xs text-[var(--Sub)]">
          {people.length === 0 ? 'No one has been set as Presbytery yet. An administrator can do this under Membership, by editing the member and choosing the Presbytery role.' : 'No match.'}
        </p></Card>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filtered.map((p) => (
          <Card key={p.uid} className="hover:border-amber-500 transition-all">
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-center gap-3 min-w-0">
                {p.picUrl
                  ? <img src={p.picUrl} alt="" className="w-12 h-12 rounded-2xl object-cover shrink-0" />
                  : <div className="w-12 h-12 rounded-2xl bg-amber-500/10 text-amber-600 flex items-center justify-center font-black text-lg shrink-0">{p.name?.[0]?.toUpperCase() || 'E'}</div>}
                <div className="min-w-0">
                  <h4 className="font-black text-sm text-tac-blue-dark dark:text-white uppercase break-words">{p.name}</h4>
                  <p className="text-[11px] font-bold text-amber-600 dark:text-amber-400 break-words">
                    {(p.offices && p.offices.length ? p.offices.join(', ') : 'Presbytery')}
                  </p>
                </div>
              </div>
              {p.joinedDate && <Badge variant="amber">Since {new Date(p.joinedDate).getFullYear()}</Badge>}
            </div>

            <div className="mt-4 pt-3 border-t border-[var(--Bdr)] space-y-2 text-xs">
              {p.userId && (
                <p className="flex items-center gap-1.5 text-[11px] text-[var(--Sub)] font-medium"><IdCard size={14} /> TAC ID: <span className="font-bold text-[var(--Text)] dark:text-white">{p.userId}</span></p>
              )}
              {p.occupation && (
                <p className="text-[11px] text-[var(--Sub)] font-medium">Profession: <span className="font-bold text-[var(--Text)] dark:text-white">{p.occupation}</span></p>
              )}
              <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-gray-500">
                {p.phone && <a href={`tel:${p.phone}`} className="flex items-center gap-1.5 hover:text-amber-500 transition-colors"><Phone size={14} /><span>{p.phone}</span></a>}
                {p.email && <a href={`mailto:${p.email}`} className="flex items-center gap-1.5 hover:text-amber-500 transition-colors break-all"><Mail size={14} /><span>{p.email}</span></a>}
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
};
export default ElderDirectory;
