import React from 'react';
import { useNavigate } from 'react-router-dom';
import { MessageSquare, Mic, Bell, Calendar, BookOpen, Heart, Music4, Image as ImageIcon, Landmark, Send, CheckSquare, Users, User } from 'lucide-react';

const s = 22;
const SECTIONS = [
  { title: 'Leadership', cards: [
    { label: 'Directives', hint: 'Send to the office', to: '/dashboard/presbytery/directives', icon: <Send size={s} /> },
    { label: 'Approvals', hint: 'Notices to approve', to: '/dashboard/presbytery/approvals', icon: <CheckSquare size={s} /> },
    { label: 'Treasury', hint: 'Giving reports (view)', to: '/dashboard/office/treasurer', icon: <Landmark size={s} /> },
    { label: 'Elders', hint: 'Elders directory', to: '/dashboard/presbytery/elders', icon: <Users size={s} /> },
  ]},
  { title: 'Church', cards: [
    { label: 'Chat', hint: 'Fellowship and private', to: '/dashboard/chat-menu', icon: <MessageSquare size={s} /> },
    { label: 'Voice room', hint: 'Prayer and meetings', to: '/dashboard/conference', icon: <Mic size={s} /> },
    { label: 'Notices', hint: 'Announcements', to: '/dashboard/notices', icon: <Bell size={s} /> },
    { label: 'Events', hint: 'Programmes', to: '/dashboard/events', icon: <Calendar size={s} /> },
    { label: 'Sermons', hint: 'Messages', to: '/dashboard/sermons', icon: <BookOpen size={s} /> },
    { label: 'Prayer', hint: 'Prayer requests', to: '/dashboard/prayers', icon: <Heart size={s} /> },
    { label: 'Hymns', hint: 'Hymn book', to: '/dashboard/hymns', icon: <Music4 size={s} /> },
    { label: 'Gallery', hint: 'Photos', to: '/dashboard/gallery', icon: <ImageIcon size={s} /> },
    { label: 'Me', hint: 'Profile and settings', to: '/dashboard/profile', icon: <User size={s} /> },
  ]},
];

export const PresbyteryHome: React.FC = () => {
  const navigate = useNavigate();
  return (
    <div className="space-y-7 pb-24">
      <div>
        <h1 className="text-2xl font-black font-serif text-tac-blue-dark dark:text-white">Presbytery</h1>
        <p className="text-xs text-[var(--Sub)] mt-1">Tap a card to open it.</p>
      </div>
      {SECTIONS.map((sec) => (
        <section key={sec.title} className="space-y-3">
          <h2 className="text-[11px] font-black uppercase tracking-[0.2em] text-[var(--Sub)]">{sec.title}</h2>
          <div className="flex gap-3 overflow-x-auto snap-x snap-mandatory pb-2 -mx-4 px-4 sm:mx-0 sm:px-0 sm:grid sm:grid-cols-3 lg:grid-cols-5 sm:overflow-visible">
            {sec.cards.map((c) => (
              <button key={c.to} onClick={() => navigate(c.to)}
                className="snap-start shrink-0 w-[8.5rem] sm:w-auto text-left bg-white dark:bg-slate-900 border border-[var(--Bdr)] rounded-2xl p-4 shadow-sm active:scale-95 transition-all">
                <div className="w-11 h-11 rounded-2xl bg-tac-blue/10 text-tac-blue flex items-center justify-center">{c.icon}</div>
                <p className="mt-3 text-sm font-black text-tac-blue-dark dark:text-white leading-tight">{c.label}</p>
                <p className="text-[11px] text-[var(--Sub)] mt-0.5 leading-snug">{c.hint}</p>
              </button>
            ))}
          </div>
        </section>
      ))}
    </div>
  );
};
export default PresbyteryHome;
