import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useOfficerClubs, ClubTabs } from './useOfficerClubs';
import { clubsService, ClubAttendance, ClubMember } from '../../services/clubsService';
import { Calendar, CheckCircle2, UserCheck, Clock, Save, History } from 'lucide-react';
import { Card, Button, Badge } from '../ui';

export const Attendance: React.FC = () => {
  const { profile } = useAuth();
  const { clubs, selected: selectedClub, setSelected: setSelectedClub, loading: clubsLoading } = useOfficerClubs();
  const [members, setMembers] = useState<ClubMember[]>([]);
  const [history, setHistory] = useState<ClubAttendance[]>([]);
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [topic, setTopic] = useState('');
  const [presentUids, setPresentUids] = useState<Set<string>>(new Set());
  const [saving, setSaving] = useState(false);
  const [savedSuccess, setSavedSuccess] = useState(false);

  useEffect(() => {
    clubsService.getRoster(selectedClub).then((res) => {
      setMembers(res);
      setPresentUids(new Set(res.map(m => m.uid))); // Default all checked
    });
    clubsService.getAttendanceHistory(selectedClub).then(setHistory);
  }, [selectedClub]);

  const toggleMember = (uid: string) => {
    const next = new Set(presentUids);
    if (next.has(uid)) {
      next.delete(uid);
    } else {
      next.add(uid);
    }
    setPresentUids(next);
  };

  const handleSaveAttendance = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      await clubsService.recordAttendance(selectedClub, {
        clubId: selectedClub,
        date,
        topic: topic.trim() || 'Weekly Fellowship',
        attendeeIds: Array.from(presentUids),
        totalPresent: presentUids.size,
        recordedBy: profile?.name || 'Leader'
      });

      const updatedHistory = await clubsService.getAttendanceHistory(selectedClub);
      setHistory(updatedHistory);
      setSavedSuccess(true);
      setTimeout(() => setSavedSuccess(false), 3000);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto p-4 sm:p-6 space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-xl font-black text-tac-blue-dark dark:text-white uppercase tracking-tight">
            Roll-Call & Attendance Tracker
          </h2>
          <p className="text-xs text-[var(--Sub)]">
            Mark weekly meeting attendance for accountability and pastoral follow-up
          </p>
        </div>

        <ClubTabs clubs={clubs} value={selectedClub} onChange={setSelectedClub} loading={clubsLoading} />
      </div>

      {savedSuccess && (
        <div className="p-4 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 rounded-2xl flex items-center gap-2 text-emerald-600 dark:text-emerald-400 text-xs font-bold animate-fadeIn">
          <CheckCircle2 size={16} />
          Attendance record logged successfully!
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <Card>
            <form onSubmit={handleSaveAttendance} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
                    Meeting Date
                  </label>
                  <input
                    type="date"
                    required
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    className="w-full px-4 py-2.5 bg-gray-50 dark:bg-slate-800 border border-[var(--Bdr)] rounded-2xl text-sm font-bold outline-none min-w-0 max-w-full box-border"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
                    Topic / Activity
                  </label>
                  <input
                    type="text"
                    value={topic}
                    onChange={(e) => setTopic(e.target.value)}
                    placeholder="e.g. Bible Study & Intercession"
                    className="w-full px-4 py-2.5 bg-gray-50 dark:bg-slate-800 border border-[var(--Bdr)] rounded-2xl text-sm outline-none"
                  />
                </div>
              </div>

              <div className="pt-2">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-xs font-black uppercase tracking-wider text-gray-500">
                    Roll Call ({presentUids.size} / {members.length} Present)
                  </span>
                  <button
                    type="button"
                    onClick={() => {
                      if (presentUids.size === members.length) {
                        setPresentUids(new Set());
                      } else {
                        setPresentUids(new Set(members.map(m => m.uid)));
                      }
                    }}
                    className="text-xs font-bold text-tac-blue hover:underline"
                  >
                    Toggle All
                  </button>
                </div>

                <div className="space-y-2 max-h-80 overflow-y-auto pr-1">
                  {members.map((m) => {
                    const isPresent = presentUids.has(m.uid);
                    return (
                      <div
                        key={m.uid}
                        onClick={() => toggleMember(m.uid)}
                        className={`p-3 rounded-2xl border flex items-center justify-between cursor-pointer transition-all ${
                          isPresent
                            ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-800 dark:text-emerald-300'
                            : 'bg-gray-50 dark:bg-white/5 border-[var(--Bdr)] text-gray-400'
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          <UserCheck size={18} className={isPresent ? 'text-emerald-500' : 'text-gray-300'} />
                          <span className="text-xs font-bold text-[var(--Text)] dark:text-white">{m.name}</span>
                        </div>
                        <Badge variant={isPresent ? 'green' : 'gray'}>
                          {isPresent ? 'Present' : 'Absent'}
                        </Badge>
                      </div>
                    );
                  })}
                </div>
              </div>

              <Button
                type="submit"
                variant="primary"
                size="lg"
                loading={saving}
                className="w-full mt-4"
                icon={<Save size={16} />}
              >
                Save Attendance ({presentUids.size} Present)
              </Button>
            </form>
          </Card>
        </div>

        <div>
          <Card>
            <div className="flex items-center justify-between mb-4">
              <h4 className="text-xs font-black uppercase tracking-wider text-tac-blue-dark dark:text-white flex items-center gap-1.5">
                <History size={16} />
                Recent Records
              </h4>
              <Badge variant="blue">{history.length}</Badge>
            </div>

            <div className="space-y-3 max-h-96 overflow-y-auto pr-1">
              {history.length === 0 ? (
                <p className="text-xs text-[var(--Sub)] text-center py-6">
                  No previous attendance records found.
                </p>
              ) : (
                history.map((h) => (
                  <div key={h.id} className="p-3 bg-gray-50 dark:bg-white/5 rounded-2xl border border-[var(--Bdr)] text-xs space-y-1">
                    <div className="flex justify-between items-center font-bold">
                      <span className="text-tac-blue-dark dark:text-white">{h.date}</span>
                      <span className="text-emerald-600 font-black">{h.totalPresent} Present</span>
                    </div>
                    <p className="text-[10px] text-[var(--Sub)]">{h.topic}</p>
                  </div>
                ))
              )}
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
};
export default Attendance;
