import React, { useCallback, useEffect, useState } from 'react';
import { clubsService, ClubMember } from '../../services/clubsService';
import { clubApplicationsService, AppMessage } from '../../services/clubApplicationsService';
import { useAuth } from '../../context/AuthContext';
import { CheckCircle2, XCircle, MessageSquare, CalendarClock, StickyNote, ChevronDown, ChevronUp } from 'lucide-react';
import { Card, Badge } from '../ui';
import { useOfficerClubs, ClubTabs } from './useOfficerClubs';

/**
 * Join Approvals (for a club's Patron, Leader, Assistant and Secretary, and admins).
 * For each person who applied: read what they wrote, ask a question, invite them to an interview,
 * keep a private note, then approve or decline. The applicant is notified at every step.
 */
const when = (iso?: string) => (iso ? new Date(iso).toLocaleString('en-GB', { dateStyle: 'medium', timeStyle: 'short' }) : '');

const kindLabel: Record<string, string> = { answer: 'Applicant', question: 'Question', interview: 'Interview', note: 'Private note', declined: 'Declined' };

const Thread: React.FC<{ messages: AppMessage[]; meId?: string }> = ({ messages, meId }) => (
  <div className="space-y-2">
    {messages.length === 0 && <p className="text-[11px] text-[var(--Sub)]">Nothing yet. Ask a question or invite them to an interview.</p>}
    {messages.map((m) => (
      <div key={m.id} className={`p-3 rounded-2xl text-xs border ${m.kind === 'answer' ? 'bg-gray-50 dark:bg-white/5 border-[var(--Bdr)]' : m.kind === 'note' ? 'bg-amber-50 dark:bg-amber-950/20 border-amber-200/60' : 'bg-tac-blue/5 border-tac-blue/20'}`}>
        <div className="flex justify-between gap-2 text-[10px] font-black uppercase tracking-wider text-gray-400">
          <span>{kindLabel[m.kind] || m.kind}{m.kind !== 'answer' && m.senderName ? ` · ${m.senderId === meId ? 'You' : m.senderName}` : ''}</span>
          <span>{when(m.createdAt)}</span>
        </div>
        {m.kind === 'interview' && (
          <p className="mt-1 font-bold text-tac-blue-dark dark:text-white">{when(m.interviewAt) || 'Time to be agreed'}{m.interviewPlace ? ` · ${m.interviewPlace}` : ''}</p>
        )}
        {m.body && <p className="mt-1 text-[var(--Text)] dark:text-white whitespace-pre-wrap">{m.body}</p>}
      </div>
    ))}
  </div>
);

const Applicant: React.FC<{ clubId: string; m: ClubMember; onDone: () => void }> = ({ clubId, m, onDone }) => {
  const { profile } = useAuth();
  const [open, setOpen] = useState(false);
  const [thread, setThread] = useState<AppMessage[]>([]);
  const [mode, setMode] = useState<'' | 'question' | 'interview' | 'note' | 'decline'>('');
  const [text, setText] = useState('');
  const [at, setAt] = useState('');
  const [place, setPlace] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(() => clubApplicationsService.getThread(clubId, m.uid).then(setThread), [clubId, m.uid]);
  useEffect(() => { load(); const t = setInterval(load, 20000); return () => clearInterval(t); }, [load]);

  const run = async (fn: () => Promise<void>, after?: () => void) => {
    setBusy(true); setError(null);
    try { await fn(); after?.(); await load(); }
    catch (e: any) { setError(e?.message || 'Something went wrong. Please try again.'); }
    finally { setBusy(false); }
  };

  const send = () => {
    if (!profile || !mode || mode === 'decline') return;
    return run(() => clubApplicationsService.send({
      clubId, applicantId: m.uid, senderId: profile.uid, kind: mode, body: text,
      interviewAt: mode === 'interview' && at ? new Date(at).toISOString() : undefined, interviewPlace: place,
    }), () => { setText(''); setAt(''); setPlace(''); setMode(''); });
  };

  const input = 'w-full rounded-xl border border-[var(--Bdr)] bg-transparent px-3 py-2 text-xs text-[var(--Text)] dark:text-white outline-none focus:border-tac-blue';
  const chip = (id: typeof mode, label: string, icon: React.ReactNode) => (
    <button type="button" onClick={() => setMode(mode === id ? '' : id)} className={`px-3 py-1.5 rounded-xl text-[10px] font-black uppercase tracking-wide flex items-center gap-1.5 ${mode === id ? 'bg-tac-blue text-white' : 'bg-gray-100 dark:bg-white/5 text-[var(--Sub)]'}`}>{icon}{label}</button>
  );
  const fromApplicant = thread.filter((x) => x.kind === 'answer').length;

  return (
    <div className="py-4 space-y-3">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <button type="button" onClick={() => setOpen(!open)} className="flex items-center gap-3 text-left">
          <div className="w-10 h-10 rounded-2xl bg-amber-500/10 text-amber-600 font-black flex items-center justify-center text-sm">{(m.name || '?')[0]}</div>
          <div>
            <h4 className="font-bold text-xs text-tac-blue-dark dark:text-white">{m.name || 'Member'}</h4>
            <p className="text-[10px] text-gray-400">{m.joinedAt ? `Applied: ${new Date(m.joinedAt).toLocaleDateString('en-GB')}` : 'Waiting for a decision'}{fromApplicant ? ` · ${fromApplicant} message${fromApplicant > 1 ? 's' : ''} from them` : ''}</p>
            <p className="text-[10px] text-[var(--Sub)]">{m.email || ''}{m.phone ? ` · ${m.phone}` : ' · No phone'}</p>
          </div>
          {open ? <ChevronUp size={16} className="text-gray-400" /> : <ChevronDown size={16} className="text-gray-400" />}
        </button>
        <div className="flex items-center gap-2">
          <button type="button" disabled={busy} onClick={() => run(() => clubApplicationsService.decide(clubId, m.uid, 'approve'), onDone)}
            className="px-3 py-2 rounded-xl bg-emerald-600 text-white text-[10px] font-black uppercase tracking-wide flex items-center gap-1.5 disabled:opacity-50"><CheckCircle2 size={14} />Approve</button>
          <button type="button" disabled={busy} onClick={() => { setOpen(true); setMode('decline'); }}
            className="px-3 py-2 rounded-xl bg-tac-red/10 text-tac-red text-[10px] font-black uppercase tracking-wide flex items-center gap-1.5 disabled:opacity-50"><XCircle size={14} />Decline</button>
        </div>
      </div>

      {open && (
        <div className="space-y-3 pl-0 sm:pl-12">
          <Thread messages={thread} meId={profile?.uid} />
          <div className="flex flex-wrap gap-2">
            {chip('question', 'Ask a question', <MessageSquare size={12} />)}
            {chip('interview', 'Invite to interview', <CalendarClock size={12} />)}
            {chip('note', 'Private note', <StickyNote size={12} />)}
          </div>
          {mode === 'interview' && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              <input type="datetime-local" className={input} value={at} onChange={(e) => setAt(e.target.value)} />
              <input className={input} placeholder="Where? e.g. Church office" value={place} onChange={(e) => setPlace(e.target.value)} />
            </div>
          )}
          {(mode === 'question' || mode === 'interview' || mode === 'note') && (
            <>
              <textarea className={input} rows={3} value={text} onChange={(e) => setText(e.target.value)}
                placeholder={mode === 'question' ? 'Type your question for the applicant…' : mode === 'interview' ? 'Anything they should bring or know (optional)' : 'Only the club officers can see this note'} />
              <button type="button" disabled={busy || (mode !== 'interview' && !text.trim()) || (mode === 'interview' && !at)} onClick={send}
                className="px-4 py-2 rounded-xl bg-tac-blue text-white text-[10px] font-black uppercase tracking-wide disabled:opacity-50">{busy ? 'Sending…' : mode === 'note' ? 'Save note' : 'Send to applicant'}</button>
            </>
          )}
          {mode === 'decline' && (
            <div className="space-y-2">
              <textarea className={input} rows={2} value={text} onChange={(e) => setText(e.target.value)} placeholder="A short, kind reason (optional). The applicant will see it." />
              <button type="button" disabled={busy} onClick={() => run(() => clubApplicationsService.decide(clubId, m.uid, 'decline', text), onDone)}
                className="px-4 py-2 rounded-xl bg-tac-red text-white text-[10px] font-black uppercase tracking-wide disabled:opacity-50">{busy ? 'Declining…' : 'Confirm decline'}</button>
            </div>
          )}
          {error && <p className="text-[11px] font-bold text-tac-red">{error}</p>}
        </div>
      )}
      {!open && error && <p className="text-[11px] font-bold text-tac-red">{error}</p>}
    </div>
  );
};

export const RegistrationApprovals: React.FC = () => {
  const { clubs, selected: selectedClub, setSelected: setSelectedClub, loading: clubsLoading } = useOfficerClubs();
  const [pendingMembers, setPendingMembers] = useState<ClubMember[]>([]);
  const [loading, setLoading] = useState(false);

  const loadPending = useCallback(async () => {
    if (!selectedClub) { setPendingMembers([]); return; }
    setLoading(true);
    const roster = await clubsService.getRoster(selectedClub);
    setPendingMembers(roster.filter((m) => m.status === 'pending'));
    setLoading(false);
  }, [selectedClub]);

  useEffect(() => { loadPending(); }, [loadPending]);
  useEffect(() => { const t = setInterval(loadPending, 30000); return () => clearInterval(t); }, [loadPending]);

  return (
    <div className="max-w-4xl mx-auto p-4 sm:p-6 space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-xl font-black text-tac-blue-dark dark:text-white uppercase tracking-tight">Join Approvals</h2>
          <p className="text-xs text-[var(--Sub)]">Review applicants, ask questions, invite them to an interview, then approve or decline</p>
        </div>
        <ClubTabs clubs={clubs} value={selectedClub} onChange={setSelectedClub} loading={clubsLoading} />
      </div>

      <Card>
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs font-black uppercase tracking-wider text-gray-500">Waiting for a decision ({pendingMembers.length})</span>
          <Badge variant="amber">Applicants are notified</Badge>
        </div>
        {loading && pendingMembers.length === 0 ? (
          <p className="text-xs text-[var(--Sub)] py-8 text-center">Loading…</p>
        ) : pendingMembers.length === 0 ? (
          <div className="text-center py-12 space-y-2">
            <CheckCircle2 size={36} className="text-emerald-500 mx-auto" />
            <h4 className="text-sm font-bold text-[var(--Text)] dark:text-white">All caught up!</h4>
            <p className="text-xs text-[var(--Sub)]">No applications are waiting.</p>
          </div>
        ) : (
          <div className="divide-y divide-[var(--Bdr)]">
            {pendingMembers.map((m) => <Applicant key={m.uid} clubId={selectedClub} m={m} onDone={loadPending} />)}
          </div>
        )}
      </Card>
    </div>
  );
};

export default RegistrationApprovals;
