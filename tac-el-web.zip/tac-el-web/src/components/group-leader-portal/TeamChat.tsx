import React from 'react';
import ChatView from '../sections/ChatView';

export const TeamChat: React.FC = () => {
  return (
    <div className="h-[calc(100dvh-8rem)]">
      <ChatView />
    </div>
  );
};
export default TeamChat;
