import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useOfficerClubs, ClubTabs } from './useOfficerClubs';
import { clubsService, ClubInstruction } from '../../services/clubsService';
import { AlertCircle, Plus, Send, ShieldAlert, CheckCircle2 } from 'lucide-react';
import { Card, Button, Badge } from '../ui';

export const Instructions: React.FC = () => {
  const { profile } = useAuth();
  const { clubs, selected: selectedClub, setSelected: setSelectedClub, loading: clubsLoading } = useOfficerClubs();
  const [instructions, setInstructions] = useState<ClubInstruction[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [title, setTitle] = useState('');
  const [directive, setDirective] = useState('');
  const [priority, setPriority] = useState<'normal' | 'high' | 'urgent'>('normal');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    clubsService.getInstructions(selectedClub).then(setInstructions);
  }, [selectedClub]);

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !directive.trim()) return;

    setSaving(true);
    try {
      await clubsService.addInstruction(selectedClub, {
        clubId: selectedClub,
        title: title.trim(),
        directive: directive.trim(),
        priority,
        issuedBy: profile?.name || 'Wing Leader',
        issuedById: profile?.uid,
        date: new Date().toLocaleDateString('en-GB')
      });

      setTitle('');
      setDirective('');
      setShowForm(false);
      const updated = await clubsService.getInstructions(selectedClub);
      setInstructions(updated);
    } catch (err: any) {
      window.alert(err?.message || 'Could not save. Please try again.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto p-4 sm:p-6 space-y-6">
      <ClubTabs clubs={clubs} value={selectedClub} onChange={setSelectedClub} loading={clubsLoading} />
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-xl font-black text-tac-blue-dark dark:text-white uppercase tracking-tight">
            Leader Directives & Instructions
          </h2>
          <p className="text-xs text-[var(--Sub)]">
            Issue official operational notices, dress codes, rehearsal calls, and schedules
          </p>
        </div>

        <Button
          variant="primary"
          onClick={() => setShowForm(!showForm)}
          icon={<Plus size={16} />}
        >
          {showForm ? 'Cancel' : 'Issue Directive'}
        </Button>
      </div>

      {showForm && (
        <Card className="border-tac-red animate-fadeIn">
          <h3 className="text-sm font-black uppercase tracking-wider text-tac-blue-dark dark:text-white mb-4">
            Create Official Directive
          </h3>

          <form onSubmit={handleSend} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
                  Directive Subject
                </label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g. Mandatory Choir Rehearsal for Easter Sunday"
                  className="w-full px-4 py-2.5 bg-gray-50 dark:bg-slate-800 border border-[var(--Bdr)] rounded-2xl text-sm font-bold outline-none"
                />
              </div>

              <div>
                <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
                  Urgency Level
                </label>
                <select
                  value={priority}
                  onChange={(e) => setPriority(e.target.value as any)}
                  className="w-full px-4 py-2.5 bg-gray-50 dark:bg-slate-800 border border-[var(--Bdr)] rounded-2xl text-sm font-bold outline-none"
                >
                  <option value="normal">Normal Notice</option>
                  <option value="high">High Priority</option>
                  <option value="urgent">Urgent Action Required</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
                Instruction Details
              </label>
              <textarea
                required
                rows={4}
                value={directive}
                onChange={(e) => setDirective(e.target.value)}
                placeholder="Specify precise instructions, time, location, materials required, and attendance expectations..."
                className="w-full px-4 py-3 bg-gray-50 dark:bg-slate-800 border border-[var(--Bdr)] rounded-2xl text-sm outline-none"
              />
            </div>

            <div className="flex justify-end gap-3 pt-2">
              <Button type="button" variant="ghost" onClick={() => setShowForm(false)}>
                Cancel
              </Button>
              <Button type="submit" variant="primary" loading={saving} icon={<Send size={16} />}>
                Broadcast to Wing
              </Button>
            </div>
          </form>
        </Card>
      )}

      <div className="space-y-4">
        {instructions.length === 0 ? (
          <Card>
            <p className="py-8 text-center text-xs text-[var(--Sub)]">
              No directives issued yet.
            </p>
          </Card>
        ) : (
          instructions.map((ins) => (
            <Card key={ins.id} className={ins.priority === 'urgent' ? 'border-l-4 border-l-tac-red' : ''}>
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-2">
                <div className="flex items-center gap-2">
                  <Badge variant={ins.priority === 'urgent' ? 'red' : ins.priority === 'high' ? 'amber' : 'blue'}>
                    {ins.priority.toUpperCase()}
                  </Badge>
                  <h4 className="font-black text-sm uppercase text-tac-blue-dark dark:text-white">
                    {ins.title}
                  </h4>
                </div>
                <span className="text-[10px] text-gray-400">{ins.date}</span>
              </div>
              <p className="text-xs text-[var(--Text)] dark:text-gray-300 mt-2 leading-relaxed">
                {ins.directive}
              </p>
              <p className="text-[10px] text-[var(--Sub)] mt-3">
                Issued By: <span className="font-bold">{ins.issuedBy}</span>
              </p>
            </Card>
          ))
        )}
      </div>
    </div>
  );
};
export default Instructions;
