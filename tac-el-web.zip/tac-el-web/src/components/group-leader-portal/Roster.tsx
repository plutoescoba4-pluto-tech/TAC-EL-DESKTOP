import React, { useState, useEffect } from 'react';
import { useOfficerClubs, ClubTabs } from './useOfficerClubs';
import { clubsService, ClubMember } from '../../services/clubsService';
import { Users, Search, Phone, Mail, CheckCircle2, Shield, UserCheck } from 'lucide-react';
import { Card, Button, Badge } from '../ui';

export const Roster: React.FC = () => {
  const [members, setMembers] = useState<ClubMember[]>([]);
  const [search, setSearch] = useState('');
  const { clubs, selected: selectedClub, setSelected: setSelectedClub, loading: clubsLoading } = useOfficerClubs();
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    clubsService.getRoster(selectedClub).then((res) => {
      setMembers(res);
      setLoading(false);
    });
  }, [selectedClub]);

  const filtered = members.filter(m => 
    m.name.toLowerCase().includes(search.toLowerCase()) ||
    m.email?.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="max-w-4xl mx-auto p-4 sm:p-6 space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-xl font-black text-tac-blue-dark dark:text-white uppercase tracking-tight">
            Ministry Wing Roster & Members
          </h2>
          <p className="text-xs text-[var(--Sub)]">
            Manage enrolled brethren, officers, and contact information
          </p>
        </div>

        <ClubTabs clubs={clubs} value={selectedClub} onChange={setSelectedClub} loading={clubsLoading} />
      </div>

      <div className="flex items-center gap-3 bg-white dark:bg-slate-900 border border-[var(--Bdr)] rounded-2xl px-4 py-3">
        <Search size={18} className="text-gray-400" />
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search roster by name or contact..."
          className="bg-transparent border-none outline-none text-sm text-[var(--Text)] dark:text-white font-medium w-full"
        />
      </div>

      <Card>
        <div className="flex items-center justify-between mb-4">
          <span className="text-xs font-black uppercase tracking-wider text-gray-500">
            Total Active Members: {members.length}
          </span>
          <Badge variant="blue">{(clubs.find((c) => c.id === selectedClub)?.name || 'CLUB').toUpperCase()}</Badge>
        </div>

        <div className="divide-y divide-[var(--Bdr)]">
          {filtered.length === 0 ? (
            <p className="py-8 text-center text-xs text-[var(--Sub)]">
              No members found in this wing roster.
            </p>
          ) : (
            filtered.map((m) => (
              <div key={m.uid} className="py-3 flex items-center justify-between gap-3 text-xs">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-2xl bg-tac-blue/10 text-tac-blue font-black flex items-center justify-center text-sm">
                    {m.name[0]}
                  </div>
                  <div>
                    <h4 className="font-bold text-tac-blue-dark dark:text-white">{m.name}</h4>
                    <p className="text-[10px] text-gray-400">{m.email || m.phone || 'No phone'}</p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <Badge variant={m.role === 'leader' ? 'amber' : 'green'}>
                    {m.role}
                  </Badge>
                  {m.phone && (
                    <a
                      href={`tel:${m.phone}`}
                      className="p-2 bg-gray-100 dark:bg-white/5 rounded-xl hover:text-tac-blue transition-colors"
                    >
                      <Phone size={14} />
                    </a>
                  )}
                </div>
              </div>
            ))
          )}
        </div>
      </Card>
    </div>
  );
};
export default Roster;
