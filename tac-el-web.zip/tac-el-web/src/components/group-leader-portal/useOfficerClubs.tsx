import React, { useEffect, useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { clubsService } from '../../services/clubsService';
import { Team } from '../../types';

/** The real clubs this person is an officer of (an admin: every club), for the leader screens' tabs. */
export function useOfficerClubs() {
  const { profile } = useAuth();
  const [clubs, setClubs] = useState<Team[]>([]);
  const [selected, setSelected] = useState<string>('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!profile?.uid) return;
    let alive = true;
    setLoading(true);
    clubsService.getMyOfficerClubs(profile.uid, profile.role === 'admin').then((list) => {
      if (!alive) return;
      setClubs(list);
      setSelected((cur) => (cur && list.some((c) => c.id === cur) ? cur : list[0]?.id ?? ''));
      setLoading(false);
    });
    return () => { alive = false; };
  }, [profile?.uid, profile?.role]);

  return { clubs, selected, setSelected, loading };
}

export const ClubTabs: React.FC<{ clubs: Team[]; value: string; onChange: (id: string) => void; loading?: boolean }> = ({ clubs, value, onChange, loading }) => {
  if (loading) return <span className="text-xs text-[var(--Sub)]">Loading your clubs…</span>;
  if (clubs.length === 0) return <span className="text-xs text-[var(--Sub)]">You are not an officer of any club yet. An admin gives club roles (Church List &gt; member &gt; Club Role).</span>;
  return (
    <div className="flex gap-2 overflow-x-auto pb-1 max-w-full">
      {clubs.map((c) => (
        <button
          key={c.id}
          onClick={() => onChange(c.id)}
          className={`px-3 py-1.5 rounded-xl text-xs font-black uppercase whitespace-nowrap transition-all ${
            value === c.id ? 'bg-tac-blue text-white shadow-md' : 'bg-gray-100 dark:bg-white/5 text-[var(--Sub)] hover:text-tac-blue'
          }`}
        >
          {c.name}
        </button>
      ))}
    </div>
  );
};
