import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useOfficerClubs, ClubTabs } from './useOfficerClubs';
import { clubsService, ClubMeetingNote } from '../../services/clubsService';
import { FileText, Plus, Save, Calendar, CheckCircle2 } from 'lucide-react';
import { Card, Button, Badge } from '../ui';

export const MeetingNotes: React.FC = () => {
  const { profile } = useAuth();
  const { clubs, selected: selectedClub, setSelected: setSelectedClub, loading: clubsLoading } = useOfficerClubs();
  const [notes, setNotes] = useState<ClubMeetingNote[]>([]);
  const [showEditor, setShowEditor] = useState(false);
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    clubsService.getMeetingNotes(selectedClub).then(setNotes);
  }, [selectedClub]);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !content.trim()) return;

    setSaving(true);
    try {
      await clubsService.addMeetingNote(selectedClub, {
        clubId: selectedClub,
        title: title.trim(),
        content: content.trim(),
        date,
        authorName: profile?.name || 'Group Leader',
        authorId: profile?.uid || 'leader'
      });

      setTitle('');
      setContent('');
      setShowEditor(false);
      const updated = await clubsService.getMeetingNotes(selectedClub);
      setNotes(updated);
    } catch (err: any) {
      window.alert(err?.message || 'Could not save. Please try again.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto p-4 sm:p-6 space-y-6">
      <ClubTabs clubs={clubs} value={selectedClub} onChange={setSelectedClub} loading={clubsLoading} />
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-xl font-black text-tac-blue-dark dark:text-white uppercase tracking-tight">
            Meeting Minutes & Notes
          </h2>
          <p className="text-xs text-[var(--Sub)]">
            Document discussions, deliberations, and executive committee resolutions
          </p>
        </div>

        <Button
          variant="primary"
          onClick={() => setShowEditor(!showEditor)}
          icon={<Plus size={16} />}
        >
          {showEditor ? 'Cancel' : 'New Meeting Note'}
        </Button>
      </div>

      {showEditor && (
        <Card className="border-tac-blue animate-fadeIn">
          <h3 className="text-sm font-black uppercase tracking-wider text-tac-blue-dark dark:text-white mb-4">
            Record Meeting Resolution
          </h3>

          <form onSubmit={handleSave} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
                  Title / Subject
                </label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g. Planning for National Youth Camp 2026"
                  className="w-full px-4 py-2.5 bg-gray-50 dark:bg-slate-800 border border-[var(--Bdr)] rounded-2xl text-sm font-bold outline-none"
                />
              </div>

              <div>
                <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
                  Date of Meeting
                </label>
                <input
                  type="date"
                  required
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="w-full px-4 py-2.5 bg-gray-50 dark:bg-slate-800 border border-[var(--Bdr)] rounded-2xl text-sm font-bold outline-none min-w-0 max-w-full box-border"
                />
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
                Meeting Deliberations & Key Decisions
              </label>
              <textarea
                required
                rows={5}
                value={content}
                onChange={(e) => setContent(e.target.value)}
                placeholder="Key points, resolutions, assigned tasks, and next steps..."
                className="w-full px-4 py-3 bg-gray-50 dark:bg-slate-800 border border-[var(--Bdr)] rounded-2xl text-sm outline-none"
              />
            </div>

            <div className="flex justify-end gap-3 pt-2">
              <Button type="button" variant="ghost" onClick={() => setShowEditor(false)}>
                Cancel
              </Button>
              <Button type="submit" variant="primary" loading={saving} icon={<Save size={16} />}>
                Save Minutes
              </Button>
            </div>
          </form>
        </Card>
      )}

      <div className="space-y-4">
        {notes.length === 0 ? (
          <Card>
            <p className="py-8 text-center text-xs text-[var(--Sub)]">
              No meeting notes published yet. Click "New Meeting Note" to create one.
            </p>
          </Card>
        ) : (
          notes.map((note) => (
            <Card key={note.id}>
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-3">
                <h4 className="font-black text-sm uppercase text-tac-blue-dark dark:text-white">
                  {note.title}
                </h4>
                <div className="flex items-center gap-2">
                  <Badge variant="blue">{note.date}</Badge>
                  <span className="text-[10px] text-gray-400">By {note.authorName}</span>
                </div>
              </div>
              <p className="text-xs text-[var(--Text)] dark:text-gray-300 whitespace-pre-wrap leading-relaxed">
                {note.content}
              </p>
            </Card>
          ))
        )}
      </div>
    </div>
  );
};
export default MeetingNotes;
