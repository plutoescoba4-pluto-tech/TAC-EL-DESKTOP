import { useEffect } from 'react';
import { supabase } from '../../supabase';
import { deviceLinkService } from '../../lib/deviceLink';

/**
 * Runs on a computer that was linked by QR. Every minute (and when the window comes back into view)
 * it checks that the phone has not signed it out; if it has, this computer signs itself out.
 * It does nothing on a normal sign-in.
 */
export const LinkedDeviceWatcher = () => {
  useEffect(() => {
    let stopped = false;
    const check = async () => {
      if (stopped) return;
      if (!(await deviceLinkService.stillLinked())) {
        deviceLinkService.clearLinkedFlag();
        await supabase.auth.signOut();
      }
    };
    check();
    const timer = window.setInterval(check, 60000);
    const onVisible = () => { if (!document.hidden) check(); };
    document.addEventListener('visibilitychange', onVisible);
    return () => { stopped = true; window.clearInterval(timer); document.removeEventListener('visibilitychange', onVisible); };
  }, []);
  return null;
};

export default LinkedDeviceWatcher;
