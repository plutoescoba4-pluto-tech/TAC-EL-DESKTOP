import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Bell, Download, Share, PlusSquare, X } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { enableNotifications, getPushState, isIOS, isStandalone, syncPushSubscription, PushState } from '../../lib/push';

/**
 * One small card at the bottom of the screen, shown at the right moment:
 *   - iPhone in Safari  -> how to add the app to the Home Screen (needed for notifications)
 *   - notifications not asked yet -> "Turn on notifications" (a tap, never automatic)
 *   - Android / computer -> "Install the app"
 * "Not now" hides it for a week.
 */
const SNOOZE_KEY = 'tac_pwa_prompt_snooze_until';
const snoozed = () => Number(localStorage.getItem(SNOOZE_KEY) || 0) > Date.now();
const snooze = () => localStorage.setItem(SNOOZE_KEY, String(Date.now() + 7 * 86400000));

export const PwaPrompts: React.FC = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [state, setState] = useState<PushState>(() => getPushState());
  const [installEvent, setInstallEvent] = useState<any>(null);
  const [hidden, setHidden] = useState(() => snoozed());
  const [message, setMessage] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [showSteps, setShowSteps] = useState(false);

  useEffect(() => {
    const onPrompt = (e: Event) => { e.preventDefault(); setInstallEvent(e); };
    const onInstalled = () => { setInstallEvent(null); setState(getPushState()); };
    window.addEventListener('beforeinstallprompt', onPrompt);
    window.addEventListener('appinstalled', onInstalled);
    return () => { window.removeEventListener('beforeinstallprompt', onPrompt); window.removeEventListener('appinstalled', onInstalled); };
  }, []);

  // Keep this device's push address fresh each time the app opens (when notifications are already allowed).
  useEffect(() => {
    if (user?.id && state === 'granted') syncPushSubscription(user.id);
  }, [user?.id, state]);
  useEffect(() => {
    const onMsg = (e: MessageEvent) => { if (e.data?.type === 'push-subscription-changed' && user?.id) syncPushSubscription(user.id); };
    navigator.serviceWorker?.addEventListener('message', onMsg);
    return () => navigator.serviceWorker?.removeEventListener('message', onMsg);
  }, [user?.id]);

  if (!user || hidden) return null;

  const dismiss = () => { snooze(); setHidden(true); };
  const wrap = 'fixed z-40 left-3 right-3 bottom-24 lg:bottom-6 lg:left-auto lg:right-6 lg:w-96 bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-gray-100 dark:border-white/10 p-4';

  // 1) iPhone in Safari: must be added to the Home Screen first
  if (state === 'needs-install') {
    return (
      <div className={wrap} role="dialog" aria-label="Add TAC-EL to your Home Screen">
        <button type="button" onClick={dismiss} className="absolute top-3 right-3 p-1 text-gray-400" aria-label="Not now"><X size={16} /></button>
        <div className="flex items-start gap-3">
          <div className="w-10 h-10 rounded-2xl bg-tac-blue/10 text-tac-blue flex items-center justify-center shrink-0"><PlusSquare size={20} /></div>
          <div className="min-w-0">
            <p className="font-black text-sm text-tac-blue-dark dark:text-white">Add TAC-EL to your Home Screen</p>
            <p className="text-xs text-gray-500 dark:text-gray-400 mt-0.5">On iPhone, notifications only work once the app is on your Home Screen.</p>
            {showSteps ? (
              <ol className="text-xs text-gray-600 dark:text-gray-300 mt-2 space-y-1 list-decimal ml-4">
                <li>Tap the Share button <Share size={12} className="inline -mt-0.5" /> in Safari.</li>
                <li>Choose <b>Add to Home Screen</b>, then <b>Add</b>.</li>
                <li>Open TAC-EL from your Home Screen and allow notifications.</li>
              </ol>
            ) : (
              <button type="button" onClick={() => setShowSteps(true)} className="mt-2 text-xs font-black uppercase tracking-widest text-tac-blue">Show me how</button>
            )}
          </div>
        </div>
      </div>
    );
  }

  // 2) ask for notifications (never automatically: only when they tap)
  if (state === 'default') {
    const turnOn = async () => {
      setBusy(true);
      const r = await enableNotifications(user.id);
      setBusy(false);
      setState(getPushState());
      setMessage(r.message);
      if (r.ok) setTimeout(() => setHidden(true), 2500);
    };
    return (
      <div className={wrap} role="dialog" aria-label="Turn on notifications">
        <button type="button" onClick={dismiss} className="absolute top-3 right-3 p-1 text-gray-400" aria-label="Not now"><X size={16} /></button>
        <div className="flex items-start gap-3">
          <div className="w-10 h-10 rounded-2xl bg-tac-blue/10 text-tac-blue flex items-center justify-center shrink-0"><Bell size={20} /></div>
          <div className="min-w-0">
            <p className="font-black text-sm text-tac-blue-dark dark:text-white">Stay in the loop</p>
            <p className="text-xs text-gray-500 dark:text-gray-400 mt-0.5">Get a notification for messages, notices, events and live prayer. You choose which ones.</p>
            {message && <p className="text-xs text-tac-blue mt-2 font-semibold">{message}</p>}
            <div className="flex items-center gap-3 mt-3">
              <button type="button" onClick={turnOn} disabled={busy} className="px-4 py-2 rounded-xl bg-tac-blue text-white text-xs font-black uppercase tracking-widest disabled:opacity-60">{busy ? 'Asking…' : 'Turn on'}</button>
              <button type="button" onClick={() => navigate('/dashboard/notification-settings')} className="text-xs font-black uppercase tracking-widest text-gray-400">Choose which</button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // 3) Android / computer: install the app
  if (installEvent && !isStandalone() && !isIOS()) {
    const install = async () => {
      installEvent.prompt();
      await installEvent.userChoice;
      setInstallEvent(null);
    };
    return (
      <div className={wrap} role="dialog" aria-label="Install TAC-EL">
        <button type="button" onClick={dismiss} className="absolute top-3 right-3 p-1 text-gray-400" aria-label="Not now"><X size={16} /></button>
        <div className="flex items-start gap-3">
          <div className="w-10 h-10 rounded-2xl bg-tac-blue/10 text-tac-blue flex items-center justify-center shrink-0"><Download size={20} /></div>
          <div className="min-w-0">
            <p className="font-black text-sm text-tac-blue-dark dark:text-white">Install TAC-EL</p>
            <p className="text-xs text-gray-500 dark:text-gray-400 mt-0.5">Open it like any other app, straight from your home screen.</p>
            <button type="button" onClick={install} className="mt-3 px-4 py-2 rounded-xl bg-tac-blue text-white text-xs font-black uppercase tracking-widest">Install</button>
          </div>
        </div>
      </div>
    );
  }

  return null;
};

export default PwaPrompts;
