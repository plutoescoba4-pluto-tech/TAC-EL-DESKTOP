import React, { useCallback, useEffect, useRef, useState } from 'react';
import { ArrowLeft, Smartphone, RefreshCw } from 'lucide-react';
import QRCode from 'qrcode';
import { deviceLinkService, LINK_QR_PREFIX } from '../../lib/deviceLink';

/**
 * "Sign in with your phone": shown on a computer that is not signed in.
 * It displays a QR code. On the phone: Linked Devices > Link a device, scan, confirm.
 * The computer then signs itself in. (Up to 2 linked devices; the oldest is signed out when a third is added.)
 */
type Phase = 'starting' | 'waiting' | 'signing-in' | 'expired' | 'denied' | 'error';

export const LinkWithPhone: React.FC<{ onBack?: () => void; embedded?: boolean }> = ({ onBack, embedded = false }) => {
  const [phase, setPhase] = useState<Phase>('starting');
  const [qr, setQr] = useState<string>('');
  const [code, setCode] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [detail, setDetail] = useState<string>('');
  const [secondsLeft, setSecondsLeft] = useState(0);
  const timer = useRef<number | null>(null);
  const alive = useRef(true);
  const regenerations = useRef(0);

  const stop = () => { if (timer.current) { window.clearInterval(timer.current); timer.current = null; } };

  const start: () => Promise<void> = useCallback(async () => {
    stop();
    setPhase('starting'); setError(null); setDetail('');
    try {
      const req = await deviceLinkService.createRequest();
      if (!alive.current) return;
      setCode(req.code);
      try {
        setQr(await QRCode.toDataURL(LINK_QR_PREFIX + req.code, { width: 260, margin: 1, errorCorrectionLevel: 'M' }));
      } catch {
        setQr('');   // the picture could not be drawn: the typed code below still works
      }
      const expiresAt = new Date(req.expiresAt).getTime();
      setPhase('waiting');

      timer.current = window.setInterval(async () => {
        const left = Math.max(0, Math.round((expiresAt - Date.now()) / 1000));
        setSecondsLeft(left);
        try {
          const r = await deviceLinkService.poll(req.requestId, req.pollSecret);
          if (!alive.current) return;
          if (r.status === 'approved' && r.tokenHash) {
            stop(); setPhase('signing-in');
            try { await deviceLinkService.completeSignIn(r.tokenHash); }   // the app then moves on by itself
            catch (e: any) { if (alive.current) { setError(e.message); setPhase('error'); } }
          } else if (r.status === 'denied') { stop(); setPhase('denied'); }
          else if (r.status === 'expired' || left === 0) {
            stop();
            if (regenerations.current < 3) { regenerations.current += 1; start(); } else setPhase('expired');   // a fresh code, up to 3 times
          }
        } catch { /* a missed check is fine; the next one tries again */ }
      }, 2000);
    } catch (e: any) {
      if (alive.current) { setError(e.message); setDetail(e.detail || ''); setPhase('error'); }
    }
  }, []);

  useEffect(() => { alive.current = true; start(); return () => { alive.current = false; stop(); }; }, [start]);

  const pretty = code ? `${code.slice(0, 4)} ${code.slice(4)}` : '';

  return (
    <div className={embedded ? 'w-full' : 'w-full max-w-md mx-auto p-6'}>
      <div className={embedded ? 'text-center' : 'bg-white dark:bg-slate-900 rounded-3xl p-6 shadow-xl border border-gray-100 dark:border-white/10 text-center'}>
        {!embedded && onBack && (
          <button type="button" onClick={onBack} className="flex items-center gap-1.5 text-xs font-black uppercase tracking-widest text-gray-400 mb-4">
            <ArrowLeft size={14} /> Back to sign in
          </button>
        )}

        {!embedded && <h2 className="text-xl font-black text-tac-blue-dark dark:text-white">Sign in with your phone</h2>}

        {(phase === 'starting' || phase === 'waiting') && (
          <>
            <div className="mx-auto mt-4 w-[260px] h-[260px] rounded-2xl bg-white border border-gray-100 flex items-center justify-center overflow-hidden">
              {qr ? <img src={qr} alt="QR code to scan with your phone" width={260} height={260} /> : phase === 'starting' ? <RefreshCw className="animate-spin text-gray-300" /> : <p className="text-xs text-gray-500 px-6">The picture could not be shown. On your phone, choose to type the code, and enter the letters below.</p>}
            </div>
            {pretty && <p className="mt-3 font-mono text-lg tracking-widest text-tac-blue-dark dark:text-white">{pretty}</p>}
            {phase === 'waiting' && secondsLeft > 0 && <p className="text-[11px] text-gray-400 mt-1">This code changes in {secondsLeft}s</p>}
            {!embedded && <ol className="text-left text-sm text-gray-600 dark:text-gray-300 mt-5 space-y-2 list-decimal ml-5">
              <li>Open TAC-EL on your phone.</li>
              <li>Go to <b>Linked Devices</b> and tap <b>Link a device</b>.</li>
              <li>Scan this code (or type the letters above) and confirm.</li>
            </ol>}
          </>
        )}

        {phase === 'signing-in' && (
          <div className="py-10">
            <Smartphone className="mx-auto text-tac-blue mb-3" size={32} />
            <p className="font-bold">Approved. Signing you in…</p>
          </div>
        )}

        {(phase === 'expired' || phase === 'denied' || phase === 'error') && (
          <div className="py-8 space-y-3">
            <p className="text-sm text-gray-600 dark:text-gray-300">
              {phase === 'denied' ? 'The request was cancelled on your phone.' : phase === 'expired' ? 'That code expired.' : error || 'Something went wrong.'}
            </p>
            {phase === 'error' && detail && <p className="text-[11px] font-mono text-gray-400 break-words">Details: {detail}</p>}
            <button type="button" onClick={() => { regenerations.current = 0; start(); }} className="px-5 py-2.5 rounded-xl bg-tac-blue text-white text-xs font-black uppercase tracking-widest">Show a new code</button>
          </div>
        )}

        {!embedded && <p className="text-[11px] text-gray-400 mt-5">Only link a computer you are using right now. Anyone who can see this code could ask you to approve it.</p>}
      </div>
    </div>
  );
};

export default LinkWithPhone;
