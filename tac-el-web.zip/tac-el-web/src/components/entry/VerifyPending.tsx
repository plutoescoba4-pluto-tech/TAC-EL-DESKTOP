import React, { useState } from 'react';
import { ArrowLeft, Search, CheckCircle2, XCircle, ShieldCheck, User } from 'lucide-react';
import { verificationService, VerificationResult } from '../../services/verificationService';
import { CHURCH_LOGO } from '../../constants';

interface VerifyPendingProps {
  onBack: () => void;
  onLoginClick: () => void;
}

export const VerifyPending: React.FC<VerifyPendingProps> = ({ onBack, onLoginClick }) => {
  const [kinId, setKinId] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<VerificationResult | null>(null);

  const handleVerify = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!kinId.trim()) return;

    setLoading(true);
    try {
      const res = await verificationService.autoVerifyTacId(kinId);
      setResult(res);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="w-full max-w-md mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <button
          onClick={onBack}
          className="p-2 -ml-2 text-[var(--Sub)] hover:text-tac-blue flex items-center gap-1.5 text-xs font-black uppercase tracking-wider"
        >
          <ArrowLeft size={16} />
          Back
        </button>
        <span className="text-[10px] font-black uppercase tracking-widest text-tac-blue bg-tac-blue/10 px-3 py-1 rounded-full">
          TAC ID Verification
        </span>
      </div>

      <div className="text-center space-y-2">
        <div className="w-16 h-16 bg-white rounded-2xl mx-auto flex items-center justify-center p-2.5 shadow-xl ring-4 ring-tac-blue/5">
          <img src={CHURCH_LOGO} alt="Church Logo" className="w-full h-full object-contain" />
        </div>
        <h2 className="text-xl font-black text-tac-blue-dark dark:text-white uppercase tracking-tight">
          Verify TAC Membership ID
        </h2>
        <p className="text-xs text-[var(--Sub)]">
          Check verification standing in the Assembly Church Registry
        </p>
      </div>

      <form onSubmit={handleVerify} className="space-y-4">
        <div>
          <label className="block text-[11px] font-black uppercase tracking-wider text-tac-blue-dark dark:text-white mb-2">
            Enter TAC ID (Format: TAC-EL-XXXX)
          </label>
          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
            <input
              type="text"
              required
              value={kinId}
              onChange={(e) => {
                setKinId(e.target.value.toUpperCase());
                setResult(null);
              }}
              placeholder="e.g. TAC-EL-1048"
              className="w-full pl-12 pr-4 py-3.5 bg-white dark:bg-slate-900 border border-[var(--Bdr)] rounded-2xl text-sm font-bold tracking-wider uppercase focus:border-tac-blue focus:ring-2 focus:ring-tac-blue/10 outline-none text-[var(--Text)] dark:text-white"
            />
          </div>
        </div>

        <button
          type="submit"
          disabled={loading || !kinId.trim()}
          className="w-full py-3.5 bg-tac-blue hover:bg-blue-600 text-white rounded-2xl font-black text-xs uppercase tracking-wider shadow-lg shadow-tac-blue/20 flex items-center justify-center gap-2 transition-all active:scale-95 disabled:opacity-50"
        >
          {loading ? (
            <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
          ) : (
            <>
              <ShieldCheck size={18} />
              Check TAC Standing
            </>
          )}
        </button>
      </form>

      {result && (
        <div className={`p-5 rounded-3xl border ${result.valid ? 'bg-emerald-50 dark:bg-emerald-950/30 border-emerald-200 dark:border-emerald-800' : 'bg-red-50 dark:bg-red-950/30 border-red-200 dark:border-red-800'} space-y-3`}>
          <div className="flex items-center gap-3">
            {result.valid ? (
              <CheckCircle2 size={24} className="text-emerald-500 shrink-0" />
            ) : (
              <XCircle size={24} className="text-red-500 shrink-0" />
            )}
            <div>
              <h4 className={`text-sm font-black uppercase tracking-wide ${result.valid ? 'text-emerald-700 dark:text-emerald-400' : 'text-red-700 dark:text-red-400'}`}>
                {result.valid ? 'Official Member Verified' : 'Verification Unsuccessful'}
              </h4>
              <p className="text-xs text-[var(--Sub)] mt-0.5">
                {result.message}
              </p>
            </div>
          </div>

          {result.profile && (
            <div className="mt-3 pt-3 border-t border-emerald-200/50 dark:border-emerald-800/50 text-xs space-y-1">
              <div className="flex justify-between">
                <span className="text-[var(--Sub)]">Member Name:</span>
                <span className="font-bold text-[var(--Text)] dark:text-white">{result.profile.name}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[var(--Sub)]">Clearance Role:</span>
                <span className="font-bold uppercase text-tac-blue">{result.profile.role}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[var(--Sub)]">Assembly ID:</span>
                <span className="font-bold text-emerald-600">{result.profile.userId}</span>
              </div>
            </div>
          )}

          {result.valid && (
            <button
              onClick={onLoginClick}
              className="w-full mt-3 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-black text-xs uppercase tracking-wider transition-all"
            >
              Sign In With This TAC ID
            </button>
          )}
        </div>
      )}
    </div>
  );
};
export default VerifyPending;
