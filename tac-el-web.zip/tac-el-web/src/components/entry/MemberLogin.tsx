import React, { useState } from 'react';
import { ForgotPassword } from './ForgotPassword';
import { LinkWithPhone } from './LinkWithPhone';
import { isMobileDevice } from '../../lib/device';
import { useNavigate } from 'react-router-dom';
import { Mail, Lock, LogIn, ArrowLeft, AlertCircle } from 'lucide-react';
import { authService } from '../../services/authService';
import { useAuth } from '../../context/AuthContext';
import { CHURCH_LOGO } from '../../constants';
import { GoogleIcon } from '../icons/GoogleIcon';

interface MemberLoginProps {
  onBack: () => void;
  onJoinClick: () => void;
}

export const MemberLogin: React.FC<MemberLoginProps> = ({ onBack, onJoinClick }) => {
  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [googleLoading, setGoogleLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [showForgot, setShowForgot] = useState(false);
  const [showQr, setShowQr] = useState(false);
  const { refreshProfile } = useAuth();
  const navigate = useNavigate();

  const handleGoogleLogin = async () => {
    setGoogleLoading(true);
    setError(null);
    try {
      // Redirects to Google and back — code after this line won't run in
      // this page load. AuthContext picks up the session on return.
      await authService.signInWithGoogle('member');
    } catch (err: any) {
      setError(err.message || 'Google sign-in failed. Please try again.');
      setGoogleLoading(false);
    }
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!identifier || !password) {
      setError('Please provide your Email/TAC ID and password.');
      return;
    }

    setLoading(true);
    setError(null);

    try {
      let email = identifier.trim();
      // If user typed a TAC ID (e.g. TAC-EL-1234), look up email
      if (email.toUpperCase().startsWith('TAC-EL-')) {
        const foundEmail = await authService.emailForTacId(email);
        if (foundEmail) {
          email = foundEmail;
        } else {
          setError('TAC ID not found. Please log in with your email address.');
          setLoading(false);
          return;
        }
      }

      await authService.login(email, password);
      await refreshProfile();
      navigate('/dashboard');
    } catch (err: any) {
      setError(err.message || 'Login failed. Please check your credentials.');
    } finally {
      setLoading(false);
    }
  };

  if (showForgot) return <ForgotPassword onBack={() => setShowForgot(false)} />;
  if (showQr) return <LinkWithPhone onBack={() => setShowQr(false)} />;

  return (
    <div className="w-full max-w-md mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <button
          onClick={onBack}
          className="p-2 -ml-2 text-[var(--Sub)] hover:text-tac-blue flex items-center gap-1.5 text-xs font-black uppercase tracking-wider"
        >
          <ArrowLeft size={16} />
          Back
        </button>
        <span className="text-[10px] font-black uppercase tracking-widest text-tac-blue bg-tac-blue/10 px-3 py-1 rounded-full">
          Member Entrance
        </span>
      </div>

      <div className="text-center space-y-2">
        <div className="w-16 h-16 bg-white rounded-2xl mx-auto flex items-center justify-center p-2.5 shadow-xl ring-4 ring-tac-blue/5">
          <img src={CHURCH_LOGO} alt="Church Logo" className="w-full h-full object-contain" />
        </div>
        <h2 className="text-xl font-black text-tac-blue-dark dark:text-white uppercase tracking-tight">
          Member Sign In
        </h2>
        <p className="text-xs text-[var(--Sub)]">
          Welcome back to the Assembly fellowship
        </p>
      </div>

      {error && (
        <div className="p-4 bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-800 rounded-2xl flex items-center gap-3 text-red-600 dark:text-red-400 text-xs font-bold">
          <AlertCircle size={16} className="shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {/* Primary Real Google Sign-in */}
      <button
        type="button"
        disabled={googleLoading || loading}
        onClick={handleGoogleLogin}
        className="w-full py-4 bg-white dark:bg-slate-800 hover:bg-gray-50 dark:hover:bg-slate-700/80 border-2 border-gray-200 dark:border-white/10 text-slate-800 dark:text-white rounded-2xl font-black text-xs uppercase tracking-wider shadow-md hover:shadow-lg flex items-center justify-center gap-3 transition-all active:scale-[0.98] disabled:opacity-50"
      >
        {googleLoading ? (
          <div className="w-5 h-5 border-2 border-tac-blue border-t-transparent rounded-full animate-spin" />
        ) : (
          <>
            <GoogleIcon size={20} />
            <span>Continue with Google</span>
          </>
        )}
      </button>

      <div className="relative my-4">
        <div className="absolute inset-0 flex items-center">
          <div className="w-full border-t border-[var(--Bdr)]"></div>
        </div>
        <div className="relative flex justify-center text-[10px] uppercase font-bold tracking-widest text-[var(--Sub)] bg-white dark:bg-slate-900 px-3">
          Or continue with TAC ID / Email
        </div>
      </div>

      <form onSubmit={handleLogin} className="space-y-4">
        <div>
          <label className="block text-[11px] font-black uppercase tracking-wider text-tac-blue-dark dark:text-white mb-2">
            Email or TAC Member ID
          </label>
          <div className="relative">
            <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
            <input
              type="text"
              value={identifier}
              onChange={(e) => setIdentifier(e.target.value)}
              placeholder="e.g. member@tac-el.org or TAC-EL-1024"
              className="w-full pl-12 pr-4 py-3.5 bg-white dark:bg-slate-900 border border-[var(--Bdr)] rounded-2xl text-sm focus:border-tac-blue focus:ring-2 focus:ring-tac-blue/10 outline-none text-[var(--Text)] dark:text-white"
            />
          </div>
        </div>

        <div>
          <label className="block text-[11px] font-black uppercase tracking-wider text-tac-blue-dark dark:text-white mb-2">
            Password
          </label>
          <div className="relative">
            <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              className="w-full pl-12 pr-4 py-3.5 bg-white dark:bg-slate-900 border border-[var(--Bdr)] rounded-2xl text-sm focus:border-tac-blue focus:ring-2 focus:ring-tac-blue/10 outline-none text-[var(--Text)] dark:text-white"
            />
          </div>
        </div>

        <button
          type="submit"
          disabled={loading || googleLoading}
          className="w-full py-4 bg-tac-blue hover:bg-blue-600 text-white rounded-2xl font-black text-xs uppercase tracking-wider shadow-lg shadow-tac-blue/20 flex items-center justify-center gap-2 transition-all active:scale-95 disabled:opacity-50"
        >
          {loading ? (
            <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
          ) : (
            <>
              <LogIn size={18} />
              Enter Fellowship
            </>
          )}
        </button>
        <div className="text-center -mt-1">
          <button type="button" onClick={() => setShowForgot(true)} className="text-xs font-black uppercase tracking-widest text-tac-blue-light hover:underline">
            Forgot password?
          </button>
        </div>
        {!isMobileDevice() && <div className="text-center mt-1">
          <button type="button" onClick={() => setShowQr(true)} className="text-xs font-black uppercase tracking-widest text-gray-400 hover:text-tac-blue-light hover:underline">
            Sign in with your phone (QR)
          </button>
        </div>}
      </form>

      <div className="flex items-center justify-center pt-2">
        <button
          type="button"
          onClick={onJoinClick}
          className="text-[11px] font-bold text-[var(--Sub)] hover:text-tac-blue"
        >
          New to the assembly? <span className="font-black text-tac-blue">Register & Get TAC ID</span>
        </button>
      </div>
    </div>
  );
};

export default MemberLogin;
