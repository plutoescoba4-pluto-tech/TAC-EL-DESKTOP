import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, UserPlus, Mail, Lock, Phone, User, CheckCircle2, AlertCircle, KeyRound } from 'lucide-react';
import { authService } from '../../services/authService';
import { useAuth } from '../../context/AuthContext';
import { CHURCH_LOGO, ASSEMBLY } from '../../constants';
import { GoogleIcon } from '../icons/GoogleIcon';

interface JoinChurchProps {
  onBack: () => void;
  onLoginClick: () => void;
}

export const JoinChurch: React.FC<JoinChurchProps> = ({ onBack, onLoginClick }) => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    password: '',
    confirmPassword: '',
    wing: 'Youth Ministry (Witness)',
    occupation: ''
  });
  const [loading, setLoading] = useState(false);
  const [googleLoading, setGoogleLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [registeredKinId, setRegisteredKinId] = useState<string | null>(null);
  const { refreshProfile } = useAuth();
  // after the form: the 6-digit code that was emailed
  const [pendingEmail, setPendingEmail] = useState<string | null>(null);
  const [code, setCode] = useState('');
  const [verifying, setVerifying] = useState(false);
  const [wait, setWait] = useState(0);
  const [note, setNote] = useState<string | null>(null);
  useEffect(() => {
    if (wait <= 0) return;
    const t = setTimeout(() => setWait((w) => w - 1), 1000);
    return () => clearTimeout(t);
  }, [wait]);

  const handleVerify = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!pendingEmail || code.trim().length < 6) { setError('Type the 6-digit code from your email.'); return; }
    setVerifying(true); setError(null); setNote(null);
    try {
      const uid = await authService.verifySignupCode(pendingEmail, code);
      // the account is signed in now; wait a moment for the profile (and the TAC ID) to be made
      let p = null as Awaited<ReturnType<typeof authService.getCurrentUserProfile>>;
      for (let i = 0; i < 12 && !p; i++) {
        p = await authService.getCurrentUserProfile(uid);
        if (!p) await new Promise((r) => setTimeout(r, 500));
      }
      setRegisteredKinId(p?.userId || 'TAC-EL-NEW');
      await refreshProfile();
    } catch (err: any) {
      setError(err.message || 'That code did not work.');
      setVerifying(false);
    }
  };

  const handleResend = async () => {
    if (!pendingEmail || wait > 0) return;
    setError(null); setNote(null);
    try { await authService.resendSignupCode(pendingEmail); setNote('A new code is on its way.'); setWait(60); }
    catch (err: any) { setError(err.message || 'Could not send a new code.'); }
  };
  const navigate = useNavigate();

  const handleGoogleSignUp = async () => {
    setGoogleLoading(true);
    setError(null);
    try {
      // Redirects to Google and back — this page unmounts. AuthContext
      // creates the profile on return and sets `newTacId`; the "here's
      // your TAC ID" reveal happens in App.tsx after landing on /dashboard,
      // not here (Firebase's popup flow could show it inline; Supabase's
      // redirect flow can't).
      await authService.signInWithGoogle('member');
    } catch (err: any) {
      setError(err.message || 'Google registration failed. Please try again.');
      setGoogleLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.email || !formData.password) {
      setError('Please fill in all mandatory fields.');
      return;
    }
    if (formData.password.length < 6) {
      setError('Password must be at least 6 characters long.');
      return;
    }
    if (formData.password !== formData.confirmPassword) {
      setError('Passwords do not match.');
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const profile = await authService.register(
        formData.email.trim(),
        formData.password,
        formData.name.trim(),
        'member',
        {
          phone: formData.phone.trim(),
          occupation: formData.occupation.trim()
        }
      );

      setRegisteredKinId(profile.userId || 'TAC-EL-NEW');
      await refreshProfile();
    } catch (err: any) {
      if (err.message === 'CONFIRM_EMAIL_SENT') {
        setPendingEmail(formData.email.trim());
        setNote('We sent a 6-digit code to your email.');
        setWait(60);
      } else {
        setError(err.message || 'Failed to complete registration.');
      }
      setLoading(false);
    }
  };

  if (pendingEmail && !registeredKinId) {
    return (
      <div className="w-full max-w-md mx-auto space-y-6">
        <button onClick={() => { setPendingEmail(null); setCode(''); setError(null); setNote(null); }}
          className="p-2 -ml-2 text-[var(--Sub)] hover:text-tac-blue flex items-center gap-1.5 text-xs font-black uppercase tracking-wider">
          <ArrowLeft size={16} /> Back
        </button>
        <div className="text-center space-y-2">
          <div className="w-14 h-14 bg-tac-blue/10 text-tac-blue rounded-2xl mx-auto flex items-center justify-center"><KeyRound size={26} /></div>
          <h2 className="text-xl font-black text-tac-blue-dark dark:text-white uppercase tracking-tight">Check your email</h2>
          <p className="text-xs text-[var(--Sub)]">Type the 6-digit code we sent to <b>{pendingEmail}</b>. Look in Spam or Promotions if you do not see it.</p>
        </div>
        {error && (
          <div className="p-4 bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-800 rounded-2xl flex items-center gap-3 text-red-600 dark:text-red-400 text-xs font-bold">
            <AlertCircle size={16} className="shrink-0" /><span>{error}</span>
          </div>
        )}
        {note && !error && <p className="text-center text-xs font-bold text-emerald-600">{note}</p>}
        <form onSubmit={handleVerify} className="space-y-4">
          <input value={code} onChange={(e) => setCode(e.target.value.replace(/\D/g, '').slice(0, 8))}
            inputMode="numeric" autoComplete="one-time-code" autoFocus placeholder="000000"
            className="w-full text-center tracking-[0.5em] text-2xl font-black py-4 bg-white dark:bg-slate-900 border border-[var(--Bdr)] rounded-2xl outline-none focus:border-tac-blue focus:ring-2 focus:ring-tac-blue/10 text-[var(--Text)] dark:text-white" />
          <button type="submit" disabled={verifying || code.length < 6}
            className="w-full py-4 bg-tac-blue text-white rounded-2xl font-black text-xs uppercase tracking-wider shadow-lg shadow-tac-blue/20 disabled:opacity-50 active:scale-95 transition-all">
            {verifying ? 'Checking...' : 'Confirm and get my TAC ID'}
          </button>
        </form>
        <button onClick={handleResend} disabled={wait > 0}
          className="w-full text-center text-xs font-black uppercase tracking-wider text-tac-blue disabled:text-gray-400">
          {wait > 0 ? `Send a new code in ${wait}s` : 'Send a new code'}
        </button>
      </div>
    );
  }

  if (registeredKinId) {
    return (
      <div className="w-full max-w-md mx-auto text-center space-y-6">
        <div className="w-20 h-20 bg-emerald-500/10 text-emerald-500 rounded-3xl mx-auto flex items-center justify-center p-4 ring-8 ring-emerald-500/10 animate-bounce">
          <CheckCircle2 size={40} />
        </div>
        <div>
          <h2 className="text-2xl font-black text-tac-blue-dark dark:text-white uppercase tracking-tight">
            Welcome to Fellowship!
          </h2>
          <p className="text-xs text-[var(--Sub)] mt-1">
            Your official Assembly TAC ID has been generated:
          </p>
          <div className="my-4 py-3 px-6 bg-tac-blue/10 dark:bg-tac-blue/20 border-2 border-tac-blue rounded-2xl inline-block">
            <span className="text-xl font-black text-tac-blue dark:text-tac-blue-light tracking-widest">
              {registeredKinId}
            </span>
          </div>
          <p className="text-xs text-[var(--Sub)]">
            Keep this TAC ID safe for quick login, church roster lookup, and giving reconciliation.
          </p>
        </div>

        <button
          onClick={() => navigate('/dashboard')}
          className="w-full py-4 bg-tac-blue hover:bg-blue-600 text-white rounded-2xl font-black text-xs uppercase tracking-wider shadow-lg shadow-tac-blue/20 transition-all active:scale-95"
        >
          Enter Assembly Dashboard
        </button>
      </div>
    );
  }

  return (
    <div className="w-full max-w-md mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <button
          onClick={onBack}
          className="p-2 -ml-2 text-[var(--Sub)] hover:text-tac-blue flex items-center gap-1.5 text-xs font-black uppercase tracking-wider"
        >
          <ArrowLeft size={16} />
          Back
        </button>
        <span className="text-[10px] font-black uppercase tracking-widest text-emerald-600 bg-emerald-500/10 px-3 py-1 rounded-full">
          New Membership
        </span>
      </div>

      <div className="text-center space-y-2">
        <div className="w-14 h-14 bg-white rounded-2xl mx-auto flex items-center justify-center p-2 shadow-xl ring-4 ring-tac-blue/5">
          <img src={CHURCH_LOGO} alt="Church Logo" className="w-full h-full object-contain" />
        </div>
        <h2 className="text-xl font-black text-tac-blue-dark dark:text-white uppercase tracking-tight">
          Join {ASSEMBLY}
        </h2>
        <p className="text-xs text-[var(--Sub)]">
          Become an active member of The Apostolic Church Ghana family
        </p>
      </div>

      {error && (
        <div className="p-4 bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-800 rounded-2xl flex items-center gap-3 text-red-600 dark:text-red-400 text-xs font-bold">
          <AlertCircle size={16} className="shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {/* Quick Google Account Creation */}
      <button
        type="button"
        disabled={googleLoading || loading}
        onClick={handleGoogleSignUp}
        className="w-full py-4 bg-white dark:bg-slate-800 hover:bg-gray-50 dark:hover:bg-slate-700/80 border-2 border-emerald-500/30 hover:border-emerald-500 text-slate-800 dark:text-white rounded-2xl font-black text-xs uppercase tracking-wider shadow-md hover:shadow-lg flex items-center justify-center gap-3 transition-all active:scale-[0.98] disabled:opacity-50"
      >
        {googleLoading ? (
          <div className="w-5 h-5 border-2 border-emerald-500 border-t-transparent rounded-full animate-spin" />
        ) : (
          <>
            <GoogleIcon size={20} />
            <span>Create Account with Google</span>
          </>
        )}
      </button>

      <div className="relative my-2">
        <div className="absolute inset-0 flex items-center">
          <div className="w-full border-t border-[var(--Bdr)]"></div>
        </div>
        <div className="relative flex justify-center text-[10px] uppercase font-bold tracking-widest text-[var(--Sub)] bg-white dark:bg-slate-900 px-3">
          Or register with email form
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-3.5">
        <div>
          <label className="block text-[11px] font-black uppercase tracking-wider text-tac-blue-dark dark:text-white mb-1.5">
            Full Name (First & Surname)
          </label>
          <div className="relative">
            <User className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
            <input
              type="text"
              required
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              placeholder="e.g. John Kwame Mensah"
              className="w-full pl-12 pr-4 py-3 bg-white dark:bg-slate-900 border border-[var(--Bdr)] rounded-2xl text-sm focus:border-tac-blue focus:ring-2 focus:ring-tac-blue/10 outline-none text-[var(--Text)] dark:text-white"
            />
          </div>
        </div>

        <div>
          <label className="block text-[11px] font-black uppercase tracking-wider text-tac-blue-dark dark:text-white mb-1.5">
            Email Address
          </label>
          <div className="relative">
            <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
            <input
              type="email"
              required
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              placeholder="e.g. j.mensah@gmail.com"
              className="w-full pl-12 pr-4 py-3 bg-white dark:bg-slate-900 border border-[var(--Bdr)] rounded-2xl text-sm focus:border-tac-blue focus:ring-2 focus:ring-tac-blue/10 outline-none text-[var(--Text)] dark:text-white"
            />
          </div>
        </div>

        <div>
          <label className="block text-[11px] font-black uppercase tracking-wider text-tac-blue-dark dark:text-white mb-1.5">
            Phone / WhatsApp Number
          </label>
          <div className="relative">
            <Phone className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
            <input
              type="tel"
              value={formData.phone}
              onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
              placeholder="e.g. +233 24 000 0000"
              className="w-full pl-12 pr-4 py-3 bg-white dark:bg-slate-900 border border-[var(--Bdr)] rounded-2xl text-sm focus:border-tac-blue focus:ring-2 focus:ring-tac-blue/10 outline-none text-[var(--Text)] dark:text-white"
            />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-[11px] font-black uppercase tracking-wider text-tac-blue-dark dark:text-white mb-1.5">
              Password
            </label>
            <div className="relative">
              <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
              <input
                type="password"
                required
                value={formData.password}
                onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                placeholder="••••••"
                className="w-full pl-11 pr-3 py-3 bg-white dark:bg-slate-900 border border-[var(--Bdr)] rounded-2xl text-sm focus:border-tac-blue focus:ring-2 focus:ring-tac-blue/10 outline-none text-[var(--Text)] dark:text-white"
              />
            </div>
          </div>
          <div>
            <label className="block text-[11px] font-black uppercase tracking-wider text-tac-blue-dark dark:text-white mb-1.5">
              Confirm Password
            </label>
            <div className="relative">
              <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
              <input
                type="password"
                required
                value={formData.confirmPassword}
                onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
                placeholder="••••••"
                className="w-full pl-11 pr-3 py-3 bg-white dark:bg-slate-900 border border-[var(--Bdr)] rounded-2xl text-sm focus:border-tac-blue focus:ring-2 focus:ring-tac-blue/10 outline-none text-[var(--Text)] dark:text-white"
              />
            </div>
          </div>
        </div>

        <div>
          <label className="block text-[11px] font-black uppercase tracking-wider text-tac-blue-dark dark:text-white mb-1.5">
            Ministry Wing / Movement
          </label>
          <select
            value={formData.wing}
            onChange={(e) => setFormData({ ...formData, wing: e.target.value })}
            className="w-full px-4 py-3 bg-white dark:bg-slate-900 border border-[var(--Bdr)] rounded-2xl text-sm focus:border-tac-blue focus:ring-2 focus:ring-tac-blue/10 outline-none text-[var(--Text)] dark:text-white"
          >
            <option value="Youth Ministry (Witness)">Youth Ministry (Witness Movement)</option>
            <option value="Women's Movement">Women's Movement</option>
            <option value="Men's Movement">Men's Movement</option>
            <option value="Sanctuary Choir & Praise">Sanctuary Choir & Praise</option>
            <option value="Children's Ministry">Children's Ministry</option>
          </select>
        </div>

        <button
          type="submit"
          disabled={loading}
          className="w-full py-4 bg-emerald-600 hover:bg-emerald-700 text-white rounded-2xl font-black text-xs uppercase tracking-wider shadow-lg shadow-emerald-600/20 flex items-center justify-center gap-2 transition-all active:scale-95 disabled:opacity-50 mt-4"
        >
          {loading ? (
            <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
          ) : (
            <>
              <UserPlus size={18} />
              Complete Registration & Get TAC ID
            </>
          )}
        </button>
      </form>

      <div className="text-center pt-2">
        <button
          type="button"
          onClick={onLoginClick}
          className="text-xs text-[var(--Sub)] hover:text-tac-blue"
        >
          Already have an account? <span className="font-black text-tac-blue">Log In</span>
        </button>
      </div>
    </div>
  );
};
export default JoinChurch;
