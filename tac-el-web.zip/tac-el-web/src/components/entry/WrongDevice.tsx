import React, { useEffect, useState } from 'react';
import { Monitor, Smartphone } from 'lucide-react';
import { supabase } from '../../supabase';
import { continueAnyway } from '../../lib/device';

/**
 * Shown when the phone app is opened on a computer, or the computer app on a phone.
 * Points people to the right place (addresses are saved by the admin in Admin > Website > Contact & links > App links).
 */
const env = (k: string) => (((import.meta as any).env?.[k] as string) || '').trim();

export const WrongDevice: React.FC<{ kind: 'wrong-computer' | 'wrong-phone' }> = ({ kind }) => {
  const [links, setLinks] = useState<{ app_url?: string; web_url?: string }>({});

  useEffect(() => {
    supabase.from('site_settings').select('value').eq('key', 'app_links').maybeSingle().then(({ data }) => setLinks(data?.value || {}));
  }, []);

  const onComputer = kind === 'wrong-computer';
  const target = onComputer ? (links.web_url || links.app_url || env('VITE_WEB_APP_URL')) : (links.app_url || env('VITE_MOBILE_APP_URL'));

  return (
    <div className="min-h-dvh flex items-center justify-center bg-tac-blue-dark text-white p-6">
      <div className="max-w-md w-full text-center">
        <div className="w-16 h-16 mx-auto rounded-3xl bg-white/10 flex items-center justify-center mb-6">
          {onComputer ? <Monitor size={30} /> : <Smartphone size={30} />}
        </div>
        <h1 className="text-2xl font-black font-serif">{onComputer ? 'On a computer? Use TAC-EL Web' : 'On your phone? Use the TAC-EL app'}</h1>
        <p className="text-white/70 mt-3 text-sm">
          {onComputer
            ? 'This is the phone version of TAC-EL. On a computer, TAC-EL Web gives you the same chats and church life on a bigger screen, signed in by scanning a code with your phone.'
            : 'This is TAC-EL Web, made for computers. On your phone, the TAC-EL app is the best way to use the church app.'}
        </p>
        {target && (
          <a href={target} className="inline-block mt-8 px-7 py-3.5 rounded-2xl bg-white text-tac-blue-dark font-black text-sm uppercase tracking-widest">
            {onComputer ? 'Open TAC-EL Web' : 'Open the TAC-EL app'}
          </a>
        )}
        <button type="button" onClick={continueAnyway} className="block mx-auto mt-6 text-xs font-bold text-white/60 hover:text-white underline">
          Continue here anyway
        </button>
      </div>
    </div>
  );
};

export default WrongDevice;
