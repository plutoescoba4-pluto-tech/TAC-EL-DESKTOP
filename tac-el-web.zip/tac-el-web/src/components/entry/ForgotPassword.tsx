import React, { useEffect, useState } from 'react';
import { ArrowLeft, KeyRound, MailCheck } from 'lucide-react';
import { authService } from '../../services/authService';

/**
 * "Forgot password?" for every login screen.
 *   1. Enter your email (or TAC ID)  ->  a 6-digit code is emailed
 *   2. Enter the code and a new password  ->  you are signed in
 */
export const ForgotPassword: React.FC<{ onBack: () => void; initialIdentifier?: string }> = ({ onBack, initialIdentifier = '' }) => {
  const [step, setStep] = useState<'ask' | 'code'>('ask');
  const [identifier, setIdentifier] = useState(initialIdentifier);
  const [email, setEmail] = useState('');
  const [masked, setMasked] = useState('');
  const [code, setCode] = useState('');
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [cooldown, setCooldown] = useState(0);

  useEffect(() => {
    if (cooldown <= 0) return;
    const t = setTimeout(() => setCooldown(cooldown - 1), 1000);
    return () => clearTimeout(t);
  }, [cooldown]);

  const send = async (e?: React.FormEvent) => {
    e?.preventDefault();
    setBusy(true); setError(null);
    try {
      const r = await authService.requestResetCode(step === 'code' ? email : identifier);
      setEmail(r.email); setMasked(r.masked); setStep('code'); setCooldown(60);
    } catch (err: any) { setError(err.message); }
    setBusy(false);
  };

  const finish = async (e: React.FormEvent) => {
    e.preventDefault();
    if (password !== confirm) { setError('The two passwords do not match.'); return; }
    setBusy(true); setError(null);
    try {
      await authService.resetPasswordWithCode(email, code, password);
      // The person is now signed in; the app moves on by itself.
    } catch (err: any) { setError(err.message); setBusy(false); }
  };

  const input = 'w-full rounded-2xl border border-gray-200 dark:border-white/10 bg-white dark:bg-slate-800 px-4 py-3.5 text-base outline-none focus:border-tac-blue dark:text-white';

  return (
    <div className="w-full max-w-md mx-auto p-6">
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 shadow-xl border border-gray-100 dark:border-white/10">
        <button type="button" onClick={onBack} className="flex items-center gap-1.5 text-xs font-black uppercase tracking-widest text-gray-400 mb-4">
          <ArrowLeft size={14} /> Back to sign in
        </button>

        {step === 'ask' ? (
          <form onSubmit={send} className="space-y-4">
            <div className="w-12 h-12 rounded-full bg-tac-blue/10 text-tac-blue flex items-center justify-center"><KeyRound size={22} /></div>
            <div>
              <h2 className="text-xl font-black text-tac-blue-dark dark:text-white">Forgot your password?</h2>
              <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">Enter your email or TAC ID. We will email you a 6-digit code.</p>
            </div>
            <input className={input} value={identifier} onChange={(e) => setIdentifier(e.target.value)} placeholder="Email or TAC ID" autoComplete="username" autoFocus />
            {error && <p className="text-sm text-tac-red">{error}</p>}
            <button type="submit" disabled={busy || !identifier.trim()} className="w-full py-3.5 rounded-2xl bg-tac-blue text-white font-black text-sm uppercase tracking-widest disabled:opacity-60">
              {busy ? 'Sending…' : 'Send me a code'}
            </button>
          </form>
        ) : (
          <form onSubmit={finish} className="space-y-4">
            <div className="w-12 h-12 rounded-full bg-emerald-50 dark:bg-emerald-500/10 text-emerald-600 flex items-center justify-center"><MailCheck size={22} /></div>
            <div>
              <h2 className="text-xl font-black text-tac-blue-dark dark:text-white">Check your email</h2>
              <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">We sent a 6-digit code to <b>{masked}</b>. It can take a minute to arrive; look in your spam folder too.</p>
            </div>
            <input className={`${input} text-center tracking-[0.5em] font-mono text-xl`} value={code} onChange={(e) => setCode(e.target.value.replace(/\D/g, '').slice(0, 8))}
              inputMode="numeric" autoComplete="one-time-code" placeholder="••••••" autoFocus />
            <input className={input} type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="New password (6 or more characters)" autoComplete="new-password" />
            <input className={input} type="password" value={confirm} onChange={(e) => setConfirm(e.target.value)} placeholder="Type the new password again" autoComplete="new-password" />
            {error && <p className="text-sm text-tac-red">{error}</p>}
            <button type="submit" disabled={busy || code.length < 6 || !password} className="w-full py-3.5 rounded-2xl bg-tac-blue text-white font-black text-sm uppercase tracking-widest disabled:opacity-60">
              {busy ? 'Saving…' : 'Set new password'}
            </button>
            <button type="button" onClick={() => send()} disabled={busy || cooldown > 0} className="w-full text-xs font-black uppercase tracking-widest text-tac-blue disabled:text-gray-400">
              {cooldown > 0 ? `Send a new code in ${cooldown}s` : 'Send a new code'}
            </button>
          </form>
        )}
      </div>
    </div>
  );
};

export default ForgotPassword;
