import React, { useState } from 'react';
import { ForgotPassword } from './ForgotPassword';
import { LinkWithPhone } from './LinkWithPhone';
import { isMobileDevice } from '../../lib/device';
import { useNavigate } from 'react-router-dom';
import { Mail, Lock, Shield, ArrowLeft, AlertCircle, KeyRound } from 'lucide-react';
import { authService } from '../../services/authService';
import { useAuth } from '../../context/AuthContext';
import { CHURCH_LOGO } from '../../constants';
import { GoogleIcon } from '../icons/GoogleIcon';

interface AdminLoginProps {
  onBack: () => void;
}

export const AdminLogin: React.FC<AdminLoginProps> = ({ onBack }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [adminKey, setAdminKey] = useState('');
  const [loading, setLoading] = useState(false);
  const [googleLoading, setGoogleLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [showForgot, setShowForgot] = useState(false);
  const [showQr, setShowQr] = useState(false);
  const { refreshProfile } = useAuth();
  const navigate = useNavigate();

  const handleGoogleLogin = async () => {
    setGoogleLoading(true);
    setError(null);
    try {
      await authService.signInWithGoogle('admin', adminKey);
      // Redirects to Google and back — code after this line won't run
      // in this page load. AuthContext picks up the session on return.
    } catch (err: any) {
      setError(err.message || 'Google authentication failed. Please try again.');
      setGoogleLoading(false);
    }
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) {
      setError('Please provide your admin email and password.');
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const user = await authService.login(email.trim(), password);
      const userProfile = await authService.getCurrentUserProfile(user.id);

      if (userProfile && userProfile.role !== 'admin') {
        if (!adminKey.trim()) {
          setError('Enter the Admin Security Key to continue.');
          setLoading(false);
          return;
        }
        try {
          // Checked on the server (claim-role Edge Function), not in the browser.
          await authService.claimRole('admin', adminKey);
        } catch (claimErr: any) {
          setError(claimErr.message || 'Invalid Admin Security Key. Clearance denied.');
          setLoading(false);
          return;
        }
      }

      await refreshProfile();
      navigate('/dashboard');
    } catch (err: any) {
      setError(err.message || 'Admin authentication failed.');
    } finally {
      setLoading(false);
    }
  };

  if (showForgot) return <ForgotPassword onBack={() => setShowForgot(false)} />;
  if (showQr) return <LinkWithPhone onBack={() => setShowQr(false)} />;

  return (
    <div className="w-full max-w-md mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <button
          onClick={onBack}
          className="p-2 -ml-2 text-[var(--Sub)] hover:text-tac-red flex items-center gap-1.5 text-xs font-black uppercase tracking-wider"
        >
          <ArrowLeft size={16} />
          Back
        </button>
        <span className="text-[10px] font-black uppercase tracking-widest text-tac-red bg-tac-red/10 px-3 py-1 rounded-full">
          Secretariat Clearance
        </span>
      </div>

      <div className="text-center space-y-2">
        <div className="w-16 h-16 bg-white rounded-2xl mx-auto flex items-center justify-center p-2.5 shadow-xl ring-4 ring-tac-red/10">
          <img src={CHURCH_LOGO} alt="Church Logo" className="w-full h-full object-contain" />
        </div>
        <h2 className="text-xl font-black text-tac-blue-dark dark:text-white uppercase tracking-tight">
          Secretariat & Admin
        </h2>
        <p className="text-xs text-[var(--Sub)]">
          Full Assembly management, offices, CRM, and system controls
        </p>
      </div>

      {error && (
        <div className="p-4 bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-800 rounded-2xl flex items-center gap-3 text-red-600 dark:text-red-400 text-xs font-bold">
          <AlertCircle size={16} className="shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {/* Primary Real Google Sign-in */}
      <button
        type="button"
        disabled={googleLoading || loading}
        onClick={handleGoogleLogin}
        className="w-full py-4 bg-white dark:bg-slate-800 hover:bg-gray-50 dark:hover:bg-slate-700/80 border-2 border-tac-red/30 hover:border-tac-red text-slate-800 dark:text-white rounded-2xl font-black text-xs uppercase tracking-wider shadow-md hover:shadow-lg flex items-center justify-center gap-3 transition-all active:scale-[0.98] disabled:opacity-50"
      >
        {googleLoading ? (
          <div className="w-5 h-5 border-2 border-tac-red border-t-transparent rounded-full animate-spin" />
        ) : (
          <>
            <GoogleIcon size={20} />
            <span>Sign In with Google as Admin</span>
          </>
        )}
      </button>

      <div className="relative my-4">
        <div className="absolute inset-0 flex items-center">
          <div className="w-full border-t border-[var(--Bdr)]"></div>
        </div>
        <div className="relative flex justify-center text-[10px] uppercase font-bold tracking-widest text-[var(--Sub)] bg-white dark:bg-slate-900 px-3">
          Or admin email & key
        </div>
      </div>

      <form onSubmit={handleLogin} className="space-y-4">
        <div>
          <label className="block text-[11px] font-black uppercase tracking-wider text-tac-blue-dark dark:text-white mb-2">
            Administrator Email
          </label>
          <div className="relative">
            <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="admin@tac-el.org"
              className="w-full pl-12 pr-4 py-3.5 bg-white dark:bg-slate-900 border border-[var(--Bdr)] rounded-2xl text-sm focus:border-tac-red focus:ring-2 focus:ring-tac-red/10 outline-none text-[var(--Text)] dark:text-white"
            />
          </div>
        </div>

        <div>
          <label className="block text-[11px] font-black uppercase tracking-wider text-tac-blue-dark dark:text-white mb-2">
            Password
          </label>
          <div className="relative">
            <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              className="w-full pl-12 pr-4 py-3.5 bg-white dark:bg-slate-900 border border-[var(--Bdr)] rounded-2xl text-sm focus:border-tac-red focus:ring-2 focus:ring-tac-red/10 outline-none text-[var(--Text)] dark:text-white"
            />
          </div>
        </div>

        <div>
          <label className="block text-[11px] font-black uppercase tracking-wider text-tac-blue-dark dark:text-white mb-2">
            Admin Master Key
          </label>
          <div className="relative">
            <KeyRound className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
            <input
              type="password"
              value={adminKey}
              onChange={(e) => setAdminKey(e.target.value)}
              placeholder="Enter master admin key"
              className="w-full pl-12 pr-4 py-3.5 bg-white dark:bg-slate-900 border border-[var(--Bdr)] rounded-2xl text-sm focus:border-tac-red focus:ring-2 focus:ring-tac-red/10 outline-none text-[var(--Text)] dark:text-white"
            />
          </div>
        </div>

        <button
          type="submit"
          disabled={loading || googleLoading}
          className="w-full py-4 bg-tac-red hover:bg-red-600 text-white rounded-2xl font-black text-xs uppercase tracking-wider shadow-lg shadow-tac-red/20 flex items-center justify-center gap-2 transition-all active:scale-95 disabled:opacity-50"
        >
          {loading ? (
            <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
          ) : (
            <>
              <Shield size={18} />
              Open Admin Console
            </>
          )}
        </button>
        <div className="text-center -mt-1">
          <button type="button" onClick={() => setShowForgot(true)} className="text-xs font-black uppercase tracking-widest text-tac-blue-light hover:underline">
            Forgot password?
          </button>
        </div>
        {!isMobileDevice() && <div className="text-center mt-1">
          <button type="button" onClick={() => setShowQr(true)} className="text-xs font-black uppercase tracking-widest text-gray-400 hover:text-tac-blue-light hover:underline">
            Sign in with your phone (QR)
          </button>
        </div>}
      </form>
    </div>
  );
};

export default AdminLogin;
