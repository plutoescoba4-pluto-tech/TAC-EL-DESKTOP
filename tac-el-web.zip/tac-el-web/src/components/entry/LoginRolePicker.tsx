import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Users, Shield, UserCheck, ChevronRight, UserPlus, Search, AlertCircle } from 'lucide-react';
import { CHURCH_LOGO, CHURCH_SHORT_NAME, ASSEMBLY } from '../../constants';
import { GoogleIcon } from '../icons/GoogleIcon';
import { authService } from '../../services/authService';
import { useAuth } from '../../context/AuthContext';

interface LoginRolePickerProps {
  onSelectRole: (role: 'member' | 'presbytery' | 'admin' | 'join' | 'verify') => void;
}

export const LoginRolePicker: React.FC<LoginRolePickerProps> = ({ onSelectRole }) => {
  const [googleLoading, setGoogleLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { refreshProfile } = useAuth();
  const navigate = useNavigate();

  const handleQuickGoogleSignIn = async () => {
    setGoogleLoading(true);
    setError(null);
    try {
      // Redirects to Google and back — code after this line won't run in
      // this page load. AuthContext picks up the session on return.
      await authService.signInWithGoogle('member');
    } catch (err: any) {
      setError(err.message || 'Google authentication failed.');
      setGoogleLoading(false);
    }
  };

  return (
    <div className="w-full max-w-md mx-auto space-y-6">
      <div className="text-center space-y-3">
        <div className="w-20 h-20 bg-white rounded-3xl mx-auto flex items-center justify-center p-3 shadow-2xl ring-8 ring-white/10 dark:ring-white/5">
          <img src={CHURCH_LOGO} alt="TAC Ghana Logo" className="w-full h-full object-contain" />
        </div>
        <div>
          <h2 className="text-2xl font-black text-tac-blue-dark dark:text-white uppercase tracking-tight">
            {CHURCH_SHORT_NAME}
          </h2>
          <p className="text-xs font-bold uppercase tracking-widest text-tac-red mt-1">
            {ASSEMBLY} · Sanctuary Portal
          </p>
          <p className="text-xs text-[var(--Sub)] mt-2">
            Sign in with Google or select your entrance
          </p>
        </div>
      </div>

      {error && (
        <div className="p-4 bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-800 rounded-2xl flex items-center gap-3 text-red-600 dark:text-red-400 text-xs font-bold">
          <AlertCircle size={16} className="shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {/* Primary Google One-Click Entrance */}
      <button
        type="button"
        disabled={googleLoading}
        onClick={handleQuickGoogleSignIn}
        className="w-full py-4 px-5 bg-white dark:bg-slate-800 hover:bg-gray-50 dark:hover:bg-slate-700/80 border-2 border-gray-200 dark:border-white/10 text-slate-800 dark:text-white rounded-3xl font-black text-xs uppercase tracking-wider shadow-md hover:shadow-xl flex items-center justify-center gap-3 transition-all active:scale-[0.98] disabled:opacity-50"
      >
        {googleLoading ? (
          <div className="w-5 h-5 border-2 border-tac-blue border-t-transparent rounded-full animate-spin" />
        ) : (
          <>
            <GoogleIcon size={20} />
            <span>Continue with Google</span>
          </>
        )}
      </button>

      <div className="relative my-2">
        <div className="absolute inset-0 flex items-center">
          <div className="w-full border-t border-[var(--Bdr)]"></div>
        </div>
        <div className="relative flex justify-center text-[10px] uppercase font-bold tracking-widest text-[var(--Sub)] bg-white dark:bg-slate-900 px-3">
          Or select role entrance
        </div>
      </div>

      <div className="space-y-3">
        <button
          onClick={() => onSelectRole('member')}
          className="w-full p-4.5 bg-white dark:bg-slate-900 border-2 border-gray-100 dark:border-white/10 hover:border-tac-blue rounded-3xl flex items-center gap-4 transition-all shadow-sm hover:shadow-xl group text-left active:scale-[0.98]"
        >
          <div className="w-13 h-13 rounded-2xl bg-tac-blue/10 dark:bg-tac-blue/20 text-tac-blue flex items-center justify-center shrink-0 group-hover:bg-tac-blue group-hover:text-white transition-colors">
            <Users size={24} />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2">
              <h4 className="font-black text-sm text-tac-blue-dark dark:text-white uppercase tracking-wide">
                Church Member
              </h4>
              <span className="text-[9px] bg-tac-blue/10 text-tac-blue px-2 py-0.5 rounded-full font-black">
                PORTAL
              </span>
            </div>
            <p className="text-[11px] text-[var(--Sub)] mt-0.5 truncate">
              Fellowship, Giving, Hymns, Live Audio Sanctuary
            </p>
          </div>
          <ChevronRight size={18} className="text-gray-300 group-hover:text-tac-blue transition-transform group-hover:translate-x-1 shrink-0" />
        </button>

        <button
          onClick={() => onSelectRole('presbytery')}
          className="w-full p-4.5 bg-white dark:bg-slate-900 border-2 border-gray-100 dark:border-white/10 hover:border-amber-500 rounded-3xl flex items-center gap-4 transition-all shadow-sm hover:shadow-xl group text-left active:scale-[0.98]"
        >
          <div className="w-13 h-13 rounded-2xl bg-amber-500/10 dark:bg-amber-500/20 text-amber-600 dark:text-amber-400 flex items-center justify-center shrink-0 group-hover:bg-amber-500 group-hover:text-white transition-colors">
            <UserCheck size={24} />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2">
              <h4 className="font-black text-sm text-tac-blue-dark dark:text-white uppercase tracking-wide">
                Presbytery & Elders
              </h4>
              <span className="text-[9px] bg-amber-500/10 text-amber-600 dark:text-amber-400 px-2 py-0.5 rounded-full font-black">
                LEADERSHIP
              </span>
            </div>
            <p className="text-[11px] text-[var(--Sub)] mt-0.5 truncate">
              Oversight, Pastoral Directives, Approvals & Directives
            </p>
          </div>
          <ChevronRight size={18} className="text-gray-300 group-hover:text-amber-500 transition-transform group-hover:translate-x-1 shrink-0" />
        </button>

        <button
          onClick={() => onSelectRole('admin')}
          className="w-full p-4.5 bg-white dark:bg-slate-900 border-2 border-gray-100 dark:border-white/10 hover:border-tac-red rounded-3xl flex items-center gap-4 transition-all shadow-sm hover:shadow-xl group text-left active:scale-[0.98]"
        >
          <div className="w-13 h-13 rounded-2xl bg-tac-red/10 dark:bg-tac-red/20 text-tac-red flex items-center justify-center shrink-0 group-hover:bg-tac-red group-hover:text-white transition-colors">
            <Shield size={24} />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2">
              <h4 className="font-black text-sm text-tac-blue-dark dark:text-white uppercase tracking-wide">
                Secretariat & Admin
              </h4>
              <span className="text-[9px] bg-tac-red/10 text-tac-red px-2 py-0.5 rounded-full font-black">
                OFFICES
              </span>
            </div>
            <p className="text-[11px] text-[var(--Sub)] mt-0.5 truncate">
              Finance, Member CRM, Operations & Content
            </p>
          </div>
          <ChevronRight size={18} className="text-gray-300 group-hover:text-tac-red transition-transform group-hover:translate-x-1 shrink-0" />
        </button>
      </div>

      <div className="pt-2 grid grid-cols-2 gap-3">
        <button
          onClick={() => onSelectRole('join')}
          className="p-3.5 bg-tac-blue text-white rounded-2xl font-black text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-md shadow-tac-blue/20 hover:bg-blue-600 transition-all active:scale-95"
        >
          <UserPlus size={16} />
          Join Church
        </button>
        <button
          onClick={() => onSelectRole('verify')}
          className="p-3.5 bg-gray-100 dark:bg-white/5 border border-gray-200 dark:border-white/10 text-tac-blue-dark dark:text-white rounded-2xl font-black text-xs uppercase tracking-wider flex items-center justify-center gap-2 hover:bg-gray-200 dark:hover:bg-white/10 transition-all active:scale-95"
        >
          <Search size={16} />
          Verify TAC ID
        </button>
      </div>
    </div>
  );
};

export default LoginRolePicker;
