import React, { useState, useEffect } from 'react';
import { membersService, MembershipApplication } from '../../services/membersService';
import { UserCheck, CheckCircle2, XCircle, Clock, ShieldCheck } from 'lucide-react';
import { Card, Button, Badge } from '../ui';

export const MembershipApplications: React.FC = () => {
  const [apps, setApps] = useState<MembershipApplication[]>([]);
  const [loading, setLoading] = useState(true);

  const loadApps = async () => {
    setLoading(true);
    const list = await membersService.getMembershipApplications();
    setApps(list);
    setLoading(false);
  };

  useEffect(() => {
    loadApps();
  }, []);

  const handleApprove = async (id: string, uid: string) => {
    await membersService.approveApplication(id, uid);
    await loadApps();
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-xl font-black text-tac-blue-dark dark:text-white uppercase tracking-tight">
            Official Church Membership Applications
          </h2>
          <p className="text-xs text-[var(--Sub)]">
            Verify water baptism, right hand of fellowship, and transfer letters from other assemblies
          </p>
        </div>
      </div>

      <Card>
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-xs font-black uppercase tracking-wider text-tac-blue-dark dark:text-white">
            Applications ({apps.length} Brethren)
          </h3>
          <Badge variant="blue">Baptismal Verification</Badge>
        </div>

        {!loading && apps.length === 0 && <p className="text-xs text-[var(--Sub)] py-6 text-center">No applications waiting.</p>}
        <div className="divide-y divide-[var(--Bdr)]">
          {apps.map((a) => (
            <div key={a.id} className="py-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <h4 className="font-bold text-sm text-tac-blue-dark dark:text-white uppercase">{a.applicantName || 'Unnamed'}</h4>
                  <Badge variant={a.status === 'approved' ? 'green' : 'amber'}>{a.status.replace('_', ' ')}</Badge>
                </div>
                <p className="text-[var(--Sub)]">TAC ID submitted: {a.tacIdSubmitted || 'none'}</p>
                <div className="flex gap-3 text-[10px] text-gray-400 pt-1">
                  <span>Applied: <strong>{a.appliedDate ? new Date(a.appliedDate).toLocaleDateString('en-GB') : ''}</strong></span>
                </div>
              </div>

              {a.status !== 'approved' && (
                <div className="flex items-center gap-2">
                  <Button
                    size="sm"
                    variant="primary"
                    onClick={() => handleApprove(a.id, a.userId)}
                    icon={<CheckCircle2 size={14} />}
                  >
                    Admit to Full Fellowship
                  </Button>
                </div>
              )}
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
};
export default MembershipApplications;
