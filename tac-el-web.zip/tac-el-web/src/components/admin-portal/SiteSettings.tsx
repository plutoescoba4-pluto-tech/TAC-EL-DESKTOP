import React from 'react';
import SiteSettingsView from '../sections/SiteSettings';

export const SiteSettings: React.FC = () => {
  return <SiteSettingsView />;
};
export default SiteSettings;
