import React, { useState, useEffect } from 'react';
import { membersService } from '../../services/membersService';
import { authService } from '../../services/authService';
import { UserProfile, UserRole } from '../../types';
import { Users, Search, Shield, Key, Edit3, Trash2 } from 'lucide-react';
import { Card, Button, Badge } from '../ui';
import { ProfileEditor } from './member-crm/ProfileEditor';

export const UserManagement: React.FC = () => {
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [search, setSearch] = useState('');
  const [selectedUser, setSelectedUser] = useState<UserProfile | null>(null);
  const [showEditor, setShowEditor] = useState(false);

  const loadUsers = async () => {
    const list = await membersService.getAllMembers();
    setUsers(list);
  };

  useEffect(() => {
    loadUsers();
  }, []);

  const filtered = users.filter(u =>
    u.name.toLowerCase().includes(search.toLowerCase()) ||
    u.email?.toLowerCase().includes(search.toLowerCase()) ||
    u.userId?.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-xl font-black text-tac-blue-dark dark:text-white uppercase tracking-tight">
            User Accounts & Security Permissions
          </h2>
          <p className="text-xs text-[var(--Sub)]">
            Manage user roles, portal clearance, TAC ID credentials, and account statuses
          </p>
        </div>

        <Badge variant="blue">{users.length} Active System Accounts</Badge>
      </div>

      <div className="flex items-center gap-3 bg-white dark:bg-slate-900 border border-[var(--Bdr)] rounded-2xl px-4 py-3">
        <Search size={18} className="text-gray-400" />
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search user accounts by name, email, or TAC ID..."
          className="bg-transparent border-none outline-none text-sm text-[var(--Text)] dark:text-white font-medium w-full"
        />
      </div>

      <Card>
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-gray-50 dark:bg-white/5 text-gray-500 font-black uppercase tracking-wider">
              <tr>
                <th className="p-3">User</th>
                <th className="p-3">TAC ID</th>
                <th className="p-3">Clearance Role</th>
                <th className="p-3">Office Designation</th>
                <th className="p-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[var(--Bdr)]">
              {filtered.map((u) => (
                <tr key={u.uid} className="hover:bg-gray-50/50 dark:hover:bg-white/5">
                  <td className="p-3">
                    <p className="font-bold text-tac-blue-dark dark:text-white">{u.name}</p>
                    <p className="text-[10px] text-gray-400">{u.email}</p>
                  </td>
                  <td className="p-3 font-mono font-bold text-tac-blue">{u.userId || 'TAC-EL-PENDING'}</td>
                  <td className="p-3">
                    <Badge variant={u.role === 'admin' ? 'red' : u.role === 'presbytery' ? 'amber' : 'green'}>
                      {u.role.toUpperCase()}
                    </Badge>
                  </td>
                  <td className="p-3 text-[var(--Sub)] font-semibold">{u.occupation || 'Member'}</td>
                  <td className="p-3 text-right">
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => {
                        setSelectedUser(u);
                        setShowEditor(true);
                      }}
                      icon={<Edit3 size={14} />}
                    >
                      Edit Access
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>

      <ProfileEditor
        member={selectedUser}
        isOpen={showEditor}
        onClose={() => setShowEditor(false)}
        onUpdated={loadUsers}
      />
    </div>
  );
};
export default UserManagement;
