import React, { useCallback, useEffect, useState } from 'react';
import { Trash2, Upload, Eye, EyeOff } from 'lucide-react';
import { supabase } from '../../supabase';
import { Card } from '../ui';
import { addLibraryWallpaper, removeLibraryWallpaper, type LibraryWallpaper } from '../../lib/chatTheme';

/**
 * Admin > Chat Wallpapers
 * The church's own set of chat backgrounds. Everyone sees them in their chat settings (Chat look > Wallpaper).
 * Needs 12-chat-themes.sql.
 */
const ChatWallpaperLibrary: React.FC = () => {
  const [items, setItems] = useState<LibraryWallpaper[]>([]);
  const [name, setName] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    const { data, error: e } = await supabase.from('chat_wallpapers').select('*').order('sort_order').order('created_at');
    if (e) { setError(/does not exist|schema cache/i.test(e.message) ? 'Run 12-chat-themes.sql in Supabase first, then reopen this page.' : e.message); return; }
    setItems((data ?? []) as LibraryWallpaper[]);
  }, []);
  useEffect(() => { load(); }, [load]);

  const onFiles = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files: File[] = Array.from((e.target.files ?? []) as ArrayLike<File>);
    e.target.value = '';
    if (!files.length) return;
    setBusy(true); setError(null);
    try {
      for (const f of files) await addLibraryWallpaper(f, name || f.name.replace(/\.[^.]+$/, ''));
      setName('');
      await load();
    } catch (err: any) { setError(err?.message || 'Could not upload.'); }
    finally { setBusy(false); }
  };

  const toggle = async (w: LibraryWallpaper) => {
    const { error: e } = await supabase.from('chat_wallpapers').update({ active: !w.active }).eq('id', w.id);
    if (e) setError(e.message); else load();
  };
  const remove = async (w: LibraryWallpaper) => {
    if (!window.confirm('Remove this wallpaper for everyone?')) return;
    try { await removeLibraryWallpaper(w); load(); } catch (err: any) { setError(err?.message || 'Could not remove it.'); }
  };

  return (
    <div className="p-4 lg:p-8 max-w-4xl mx-auto space-y-6">
      <div>
        <h2 className="text-2xl font-black text-tac-blue-dark dark:text-white">Chat Wallpapers</h2>
        <p className="text-sm text-gray-500 mt-1">Pictures everyone can choose as their chat background. Members can still use their own photo.</p>
      </div>
      <Card className="p-5 space-y-3">
        <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Name (optional), e.g. Sunrise"
          className="w-full rounded-xl border border-[var(--Bdr)] bg-transparent px-3 py-2.5 text-sm text-[var(--Text)] outline-none focus:border-tac-blue" />
        <label className={`flex items-center justify-center gap-2 py-3 rounded-xl border-2 border-dashed border-tac-blue/40 text-tac-blue font-black text-xs uppercase tracking-widest cursor-pointer ${busy ? 'opacity-60' : ''}`}>
          <Upload size={16} />{busy ? 'Uploading…' : 'Add pictures'}
          <input type="file" accept="image/*" multiple className="hidden" onChange={onFiles} disabled={busy} />
        </label>
        {error && <p className="text-[12px] font-bold text-tac-red">{error}</p>}
      </Card>
      {items.length === 0 ? (
        <p className="text-sm text-gray-400 text-center py-8">No church wallpapers yet. Members only see the colours and their own photos.</p>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
          {items.map((w) => (
            <div key={w.id} className={`rounded-2xl overflow-hidden border border-black/5 bg-white dark:bg-slate-800 ${w.active ? '' : 'opacity-50'}`}>
              <img src={w.url} alt={w.name} className="w-full aspect-[3/4] object-cover" loading="lazy" />
              <div className="p-2 flex items-center justify-between gap-1">
                <span className="text-[11px] font-bold truncate dark:text-white">{w.name || 'Wallpaper'}</span>
                <span className="flex shrink-0">
                  <button type="button" onClick={() => toggle(w)} title={w.active ? 'Hide from members' : 'Show to members'} className="p-1.5 text-gray-400 hover:text-tac-blue">{w.active ? <Eye size={15} /> : <EyeOff size={15} />}</button>
                  <button type="button" onClick={() => remove(w)} title="Remove" className="p-1.5 text-gray-400 hover:text-tac-red"><Trash2 size={15} /></button>
                </span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export { ChatWallpaperLibrary };
export default ChatWallpaperLibrary;
