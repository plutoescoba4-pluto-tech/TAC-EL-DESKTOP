import React, { useState, useEffect } from 'react';
import { membersService, Visitor } from '../../../services/membersService';
import { Plus, ChevronRight, UserPlus, Trash2 } from 'lucide-react';
import { Card, Button, Badge } from '../../ui';

export const VisitorPipeline: React.FC = () => {
  const [visitors, setVisitors] = useState<Visitor[]>([]);
  const [showAdd, setShowAdd] = useState(false);
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [invitedBy, setInvitedBy] = useState('');
  const [saving, setSaving] = useState(false);
  const [email, setEmail] = useState('');
  const [gender, setGender] = useState('');
  const [dob, setDob] = useState('');
  const [address, setAddress] = useState('');
  const [ethnicity, setEthnicity] = useState('');
  const [language, setLanguage] = useState('');
  const [busyId, setBusyId] = useState<string | null>(null);
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const field = 'w-full px-4 py-2.5 bg-gray-50 dark:bg-slate-800 border border-[var(--Bdr)] rounded-2xl text-sm outline-none';

  const makeMember = async (v: Visitor) => {
    if (!window.confirm(`Add ${v.name} to the register as a new member? They get a new TAC ID and leave this visitor list.`)) return;
    setBusyId(v.id); setMsg(null);
    try {
      const r = await membersService.makeVisitorMember(v.id);
      setMsg({ ok: true, text: `${r.name} is now in the register with ID ${r.member_id}. Open Members to add their photo and card.` });
      await loadVisitors();
    } catch (e: any) {
      setMsg({ ok: false, text: e?.message || 'Could not add them. Run 22-visitors-to-members.sql first.' });
    } finally { setBusyId(null); }
  };

  const removeVisitor = async (v: Visitor) => {
    if (!window.confirm(`Delete ${v.name} from the visitor list? This cannot be undone.`)) return;
    setBusyId(v.id); setMsg(null);
    try { await membersService.deleteVisitor(v.id); await loadVisitors(); }
    catch (e: any) { setMsg({ ok: false, text: e?.message || 'Could not delete.' }); }
    finally { setBusyId(null); }
  };

  const loadVisitors = async () => {
    const list = await membersService.getVisitorPipeline();
    setVisitors(list);
  };

  useEffect(() => {
    loadVisitors();
  }, []);

  const handleAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !phone.trim()) return;

    setSaving(true);
    try {
      await membersService.addVisitor({
        name: name.trim(),
        phone: phone.trim(),
        visitDate: new Date().toLocaleDateString('en-GB'),
        invitedBy: invitedBy.trim() || 'Church Outreach',
        status: 'first_timer',
        ...(email.trim() && { email: email.trim() }),
        ...(gender && { gender }),
        ...(dob && { date_of_birth: dob }),
        ...(address.trim() && { address: address.trim() }),
        ...(ethnicity.trim() && { ethnicity: ethnicity.trim() }),
        ...(language.trim() && { language: language.trim() }),
      });
      setEmail(''); setGender(''); setDob(''); setAddress(''); setEthnicity(''); setLanguage('');

      setName('');
      setPhone('');
      setInvitedBy('');
      setShowAdd(false);
      await loadVisitors();
    } finally {
      setSaving(false);
    }
  };

  const updateStatus = async (id: string, nextStatus: Visitor['status']) => {
    await membersService.updateVisitorStatus(id, nextStatus);
    await loadVisitors();
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-xl font-black text-tac-blue-dark dark:text-white uppercase tracking-tight">
            First-Timer & Visitor Assimilation Pipeline
          </h2>
          <p className="text-xs text-[var(--Sub)]">
            Pastoral follow-up, evangelism retention, and membership transition funnel
          </p>
        </div>

        <Button
          variant="primary"
          onClick={() => setShowAdd(!showAdd)}
          icon={<Plus size={16} />}
        >
          {showAdd ? 'Cancel' : 'Register New Visitor'}
        </Button>
      </div>

      {showAdd && (
        <Card className="animate-fadeIn border-tac-blue">
          <h3 className="text-sm font-black uppercase tracking-wider text-tac-blue-dark dark:text-white mb-4">
            Register First-Timer
          </h3>

          <form onSubmit={handleAdd} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
                  Visitor Name
                </label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Priscilla Owusu"
                  className="w-full px-4 py-2.5 bg-gray-50 dark:bg-slate-800 border border-[var(--Bdr)] rounded-2xl text-sm font-bold outline-none"
                />
              </div>

              <div>
                <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
                  Phone Number
                </label>
                <input
                  type="tel"
                  required
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="024 XXX XXXX"
                  className="w-full px-4 py-2.5 bg-gray-50 dark:bg-slate-800 border border-[var(--Bdr)] rounded-2xl text-sm outline-none"
                />
              </div>

              <div>
                <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
                  Invited By
                </label>
                <input
                  type="text"
                  value={invitedBy}
                  onChange={(e) => setInvitedBy(e.target.value)}
                  placeholder="Member or Wing name"
                  className="w-full px-4 py-2.5 bg-gray-50 dark:bg-slate-800 border border-[var(--Bdr)] rounded-2xl text-sm outline-none"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Email (optional)" className={field} />
              <select value={gender} onChange={(e) => setGender(e.target.value)} className={field}>
                <option value="">Gender</option><option>Male</option><option>Female</option>
              </select>
              <input type="date" value={dob} onChange={(e) => setDob(e.target.value)} className={field} aria-label="Date of birth" />
              <input type="text" value={address} onChange={(e) => setAddress(e.target.value)} placeholder="Address" className={field} />
              <input type="text" value={ethnicity} onChange={(e) => setEthnicity(e.target.value)} placeholder="Ethnicity" className={field} />
              <input type="text" value={language} onChange={(e) => setLanguage(e.target.value)} placeholder="Language" className={field} />
            </div>

            <div className="flex justify-end gap-3 pt-2">
              <Button type="button" variant="ghost" onClick={() => setShowAdd(false)}>
                Cancel
              </Button>
              <Button type="submit" variant="primary" loading={saving}>
                Add to Pipeline
              </Button>
            </div>
          </form>
        </Card>
      )}

      {msg && <p className={`text-xs font-bold rounded-2xl px-4 py-3 ${msg.ok ? 'bg-emerald-50 text-emerald-700' : 'bg-red-50 text-red-700'}`}>{msg.text}</p>}

      {/* Funnel Stages */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
        {(['first_timer', 'followed_up', 'joined_class', 'member'] as const).map((stage) => {
          const stageVisitors = visitors.filter(v => v.status === stage);
          const stageLabels: Record<string, string> = {
            first_timer: '1st Timers',
            followed_up: 'Contacted / Visited',
            joined_class: 'Membership Class',
            member: 'Baptized Member'
          };

          return (
            <Card key={stage} className="p-4 space-y-3">
              <div className="flex items-center justify-between pb-2 border-b border-[var(--Bdr)]">
                <span className="text-[11px] font-black uppercase tracking-wider text-tac-blue-dark dark:text-white">
                  {stageLabels[stage]}
                </span>
                <Badge variant={stage === 'member' ? 'green' : 'blue'}>{stageVisitors.length}</Badge>
              </div>

              <div className="space-y-2 min-h-48">
                {stageVisitors.map((v) => (
                  <div key={v.id} className="p-3 bg-gray-50 dark:bg-white/5 rounded-2xl border border-[var(--Bdr)] text-xs space-y-2">
                    <p className="font-bold text-tac-blue-dark dark:text-white">{v.name}</p>
                    <p className="text-[10px] text-gray-400">{v.phone}</p>
                    <div className="flex justify-between items-center gap-2 pt-1">
                      <button disabled={busyId === v.id} onClick={() => makeMember(v)} className="text-[10px] font-black text-emerald-600 hover:underline flex items-center gap-1 disabled:opacity-50"><UserPlus size={11} /> Make member</button>
                      <button disabled={busyId === v.id} onClick={() => removeVisitor(v)} aria-label={`Delete ${v.name}`} className="text-gray-400 hover:text-tac-red disabled:opacity-50"><Trash2 size={13} /></button>
                    </div>
                    <div className="flex justify-between items-center pt-1 border-t border-gray-100 dark:border-white/5">
                      <span className="text-[9px] text-[var(--Sub)]">Inv: {v.invitedBy}</span>
                      {stage !== 'member' && (
                        <button
                          onClick={() => {
                            const nextMap: Record<string, Visitor['status']> = {
                              first_timer: 'followed_up',
                              followed_up: 'joined_class',
                              joined_class: 'member'
                            };
                            updateStatus(v.id, nextMap[stage]);
                          }}
                          className="text-[10px] font-black text-tac-blue hover:underline flex items-center gap-0.5"
                        >
                          Next <ChevronRight size={10} />
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          );
        })}
      </div>
    </div>
  );
};
export default VisitorPipeline;
