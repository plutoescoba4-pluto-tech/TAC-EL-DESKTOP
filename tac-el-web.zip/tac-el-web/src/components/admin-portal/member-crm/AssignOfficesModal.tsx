import React, { useEffect, useState } from 'react';
import { UserProfile } from '../../../types';
import { Modal, Button } from '../../ui';
import { OfficeInfo, PERM_LABELS, fetchOffices, setOffices } from '../../../lib/offices';

interface Props {
  member: UserProfile | null;
  onClose: () => void;
  onSaved: (uid: string, offices: string[]) => void;
}

/** Tick the offices a person holds. Only the root administrator can save. */
export const AssignOfficesModal: React.FC<Props> = ({ member, onClose, onSaved }) => {
  const [catalog, setCatalog] = useState<OfficeInfo[]>([]);
  const [picked, setPicked] = useState<string[]>([]);
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState('');

  useEffect(() => { fetchOffices().then(setCatalog); }, []);
  useEffect(() => { setPicked(member?.offices ?? []); setErr(''); }, [member]);

  const toggle = (o: string) => setPicked((p) => (p.includes(o) ? p.filter((x) => x !== o) : [...p, o]));
  const save = async () => {
    if (!member) return;
    setSaving(true); setErr('');
    try { const saved = await setOffices(member.uid, picked); onSaved(member.uid, saved); onClose(); }
    catch (e: any) { setErr(e?.message || 'Could not save.'); }
    finally { setSaving(false); }
  };

  return (
    <Modal isOpen={!!member} onClose={onClose} title={member ? `Offices: ${member.name}` : ''} description="Tick every office this person holds." maxWidth="lg">
      <div className="space-y-2 max-h-[55vh] overflow-y-auto pr-1">
        {catalog.map((o) => (
          <label key={o.office} className={`flex items-start gap-3 p-3 rounded-2xl border cursor-pointer ${picked.includes(o.office) ? 'border-tac-blue bg-tac-blue/5' : 'border-[var(--Bdr)]'}`}>
            <input type="checkbox" className="mt-1" checked={picked.includes(o.office)} onChange={() => toggle(o.office)} />
            <span>
              <span className="block text-sm font-black text-tac-blue-dark dark:text-white">{o.label}</span>
              <span className="block text-[11px] text-[var(--Sub)]">{o.description}</span>
              {o.perms.length > 0 && <span className="block text-[10px] text-gray-400 mt-1">{o.perms.map((p) => PERM_LABELS[p] || p).join(' · ')}</span>}
            </span>
          </label>
        ))}
        {catalog.length === 0 && <p className="text-xs text-gray-500">The offices are not set up yet. Run 25-offices.sql in Supabase.</p>}
      </div>
      {err && <p className="text-xs font-bold text-tac-red mt-3">{err}</p>}
      <div className="flex justify-end gap-3 pt-4">
        <Button type="button" variant="ghost" onClick={onClose}>Cancel</Button>
        <Button type="button" variant="primary" loading={saving} onClick={save}>Save offices</Button>
      </div>
    </Modal>
  );
};
export default AssignOfficesModal;
