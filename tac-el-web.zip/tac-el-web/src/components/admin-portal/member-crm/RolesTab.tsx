import React, { useEffect, useMemo, useState } from 'react';
import { membersService } from '../../../services/membersService';
import { UserProfile } from '../../../types';
import { Card, Button } from '../../ui';
import { OfficeInfo, PERM_LABELS, fetchAmRoot, fetchOffices, setOffices } from '../../../lib/offices';
import { X } from 'lucide-react';

/** Every office, who holds it, and a clear way to add or remove people. Only the root administrator can change anything. */
export const RolesTab: React.FC = () => {
  const [catalog, setCatalog] = useState<OfficeInfo[]>([]);
  const [people, setPeople] = useState<UserProfile[]>([]);
  const [root, setRoot] = useState(false);
  const [loading, setLoading] = useState(true);
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const [adding, setAdding] = useState<string | null>(null);
  const [q, setQ] = useState('');
  const [pick, setPick] = useState('');
  const [busy, setBusy] = useState(false);

  const load = async () => {
    const [c, p, r] = await Promise.all([fetchOffices(), membersService.getAllMembers(), fetchAmRoot()]);
    setCatalog(c); setPeople(p); setRoot(r); setLoading(false);
  };
  useEffect(() => { load(); }, []);

  const holders = (o: string) => people.filter((p) => (p.offices ?? []).includes(o));
  const change = async (m: UserProfile, next: string[]) => {
    setBusy(true); setMsg(null);
    try {
      const saved = await setOffices(m.uid, next);
      setPeople((all) => all.map((x) => (x.uid === m.uid ? { ...x, offices: saved } : x)));
      setMsg({ ok: true, text: `Saved. ${m.name} now holds ${saved.length || 'no'} office${saved.length === 1 ? '' : 's'}.` });
      setAdding(null); setPick(''); setQ('');
    } catch (e: any) { setMsg({ ok: false, text: e?.message || 'Could not save.' }); }
    finally { setBusy(false); }
  };

  const candidates = useMemo(() => {
    if (!adding) return [];
    const t = q.trim().toLowerCase();
    return people
      .filter((p) => !(p.offices ?? []).includes(adding))
      .filter((p) => !t || p.name.toLowerCase().includes(t) || (p.email || '').toLowerCase().includes(t) || (p.userId || '').toLowerCase().includes(t))
      .slice(0, 50);
  }, [people, adding, q]);

  if (loading) return <p className="text-sm text-gray-400 py-6">Loading offices…</p>;
  if (catalog.length === 0) return <p className="text-sm text-gray-500 py-6">The offices are not set up yet. Run 25-offices.sql in Supabase, then refresh.</p>;

  return (
    <div className="space-y-4">
      <div>
        <h2 className="text-xl font-black text-tac-blue-dark dark:text-white uppercase tracking-tight">Church offices</h2>
        <p className="text-xs text-[var(--Sub)]">
          {root ? 'You are the root administrator: you can add or remove office holders. One person can hold several offices.' : 'Only the root administrator can change who holds an office. You can see who holds each one.'}
        </p>
      </div>
      {msg && <p className={`text-xs font-bold rounded-2xl px-4 py-3 ${msg.ok ? 'bg-emerald-50 text-emerald-700' : 'bg-red-50 text-red-700'}`}>{msg.text}</p>}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">
        {catalog.map((o) => {
          const hs = holders(o.office);
          return (
            <Card key={o.office} className="p-4 space-y-3">
              <div>
                <p className="text-sm font-black text-tac-blue-dark dark:text-white">{o.label}</p>
                <p className="text-[11px] text-[var(--Sub)]">{o.description}</p>
                {o.perms.length > 0 && <p className="text-[10px] text-gray-400 mt-1">Can: {o.perms.map((p) => PERM_LABELS[p] || p).join(' · ')}</p>}
              </div>
              <div className="flex flex-wrap gap-2">
                {hs.map((h) => (
                  <span key={h.uid} className="inline-flex items-center gap-1 bg-tac-blue/10 text-tac-blue-dark dark:text-white text-xs font-bold rounded-full pl-3 pr-1 py-1">
                    {h.name}
                    {root && (
                      <button type="button" disabled={busy} aria-label={`Remove ${h.name}`} onClick={() => { if (window.confirm(`Remove ${h.name} from ${o.label}?`)) change(h, (h.offices ?? []).filter((x) => x !== o.office)); }}
                        className="w-5 h-5 rounded-full bg-tac-blue/20 flex items-center justify-center"><X size={11} /></button>
                    )}
                  </span>
                ))}
                {hs.length === 0 && <span className="text-[11px] text-gray-400">Nobody holds this office yet.</span>}
              </div>
              {root && adding !== o.office && (
                <Button size="sm" variant="ghost" onClick={() => { setAdding(o.office); setQ(''); setPick(''); }}>Add a person</Button>
              )}
              {root && adding === o.office && (
                <div className="space-y-2">
                  <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search name, email or TAC ID" autoFocus
                    className="w-full px-4 py-2.5 bg-gray-50 dark:bg-slate-800 border border-[var(--Bdr)] rounded-2xl text-sm outline-none" />
                  <div className="max-h-48 overflow-y-auto rounded-2xl border border-[var(--Bdr)] divide-y divide-[var(--Bdr)]">
                    {candidates.map((p) => (
                      <button key={p.uid} type="button" onClick={() => setPick(p.uid)}
                        className={`w-full text-left px-3 py-2 text-xs ${pick === p.uid ? 'bg-tac-blue/10 font-black' : ''}`}>
                        {p.name} <span className="text-gray-400">{p.userId || p.email}</span>
                      </button>
                    ))}
                    {candidates.length === 0 && <p className="px-3 py-2 text-xs text-gray-400">No one found.</p>}
                  </div>
                  <div className="flex gap-2 justify-end">
                    <Button size="sm" variant="ghost" onClick={() => setAdding(null)}>Cancel</Button>
                    <Button size="sm" variant="primary" loading={busy} disabled={!pick}
                      onClick={() => { const m = people.find((x) => x.uid === pick); if (m) change(m, [...(m.offices ?? []), o.office]); }}>Assign</Button>
                  </div>
                </div>
              )}
            </Card>
          );
        })}
      </div>
    </div>
  );
};
export default RolesTab;
