import React, { useState, useEffect } from 'react';
import { membersService } from '../../../services/membersService';
import { UserProfile, UserRole } from '../../../types';
import { Search, UserCheck, Shield, Phone, Mail, Edit3, Filter } from 'lucide-react';
import { Card, Button, Badge } from '../../ui';
import { OfficeInfo, fetchOffices } from '../../../lib/offices';

interface DirectoryProps {
  onEditMember?: (member: UserProfile) => void;
  /** when given, every row shows its offices and an Assign button */
  onAssign?: (member: UserProfile) => void;
  /** bump to re-read the people after offices change */
  refreshKey?: number;
}

export const Directory: React.FC<DirectoryProps> = ({ onEditMember, onAssign, refreshKey = 0 }) => {
  const [catalog, setCatalog] = useState<OfficeInfo[]>([]);
  useEffect(() => { fetchOffices().then(setCatalog); }, []);
  const offLabel = (id: string) => catalog.find((c) => c.office === id)?.label || id;
  const officeBadges = (m: UserProfile) => (m.offices ?? []).length > 0 ? (
    <div className="flex flex-wrap gap-1 mt-1">{(m.offices ?? []).map((o) => <span key={o} className="text-[9px] font-black uppercase tracking-wider bg-tac-blue/10 text-tac-blue rounded-full px-2 py-0.5">{offLabel(o)}</span>)}</div>
  ) : null;
  const [members, setMembers] = useState<UserProfile[]>([]);
  const [search, setSearch] = useState('');
  const [roleFilter, setRoleFilter] = useState<string>('all');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    membersService.getAllMembers().then((res) => {
      setMembers(res);
      setLoading(false);
    });
  }, [refreshKey]);

  const filtered = members.filter((m) => {
    const matchesSearch = 
      m.name.toLowerCase().includes(search.toLowerCase()) ||
      m.email?.toLowerCase().includes(search.toLowerCase()) ||
      m.userId?.toLowerCase().includes(search.toLowerCase());
    const matchesRole = roleFilter === 'all' || m.role === roleFilter;
    return matchesSearch && matchesRole;
  });

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-xl font-black text-tac-blue-dark dark:text-white uppercase tracking-tight">
            Assembly Member Directory & CRM
          </h2>
          <p className="text-xs text-[var(--Sub)]">
            Manage church membership records, TAC IDs, and spiritual statuses
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Badge variant="blue">{filtered.length} Registered Brethren</Badge>
        </div>
      </div>

      <div className="flex flex-col sm:flex-row gap-3">
        <div className="flex-1 flex items-center gap-3 bg-white dark:bg-slate-900 border border-[var(--Bdr)] rounded-2xl px-4 py-3">
          <Search size={18} className="text-gray-400" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by name, email, or TAC ID..."
            className="bg-transparent border-none outline-none text-sm text-[var(--Text)] dark:text-white font-medium w-full"
          />
        </div>

        <select
          value={roleFilter}
          onChange={(e) => setRoleFilter(e.target.value)}
          className="px-4 py-3 bg-white dark:bg-slate-900 border border-[var(--Bdr)] rounded-2xl text-xs font-bold uppercase outline-none"
        >
          <option value="all">All Roles</option>
          <option value="member">Members</option>
          <option value="presbytery">Presbytery / Elders</option>
          <option value="admin">Secretariat / Admin</option>
        </select>
      </div>

      {filtered.length === 0 ? (
        <Card>
          <p className="p-6 text-center text-gray-400 text-xs">No members match the search query.</p>
        </Card>
      ) : (
        <>
          {/* Mobile: stacked cards — a 6-column table has no honest way to
              fit a phone screen, so below md this renders as cards instead
              of forcing a cramped horizontal-scroll table. */}
          <div className="grid grid-cols-1 gap-3 md:hidden">
            {filtered.map((m) => (
              <Card key={m.uid} className="!p-4">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3 min-w-0">
                    <div className={`w-10 h-10 shrink-0 rounded-xl overflow-hidden ${m.color || 'bg-tac-blue'} text-white font-bold flex items-center justify-center text-sm`}>
                      {m.picUrl ? <img src={m.picUrl} alt="" className="w-full h-full object-cover" /> : m.name[0]}
                    </div>
                    <div className="min-w-0">
                      <p className="font-bold text-tac-blue-dark dark:text-white truncate">{m.name}</p>
                      <p className="text-[10px] text-gray-400 truncate">{m.email}</p>
                    </div>
                  </div>
                  <Badge variant={m.role === 'admin' ? 'red' : m.role === 'presbytery' ? 'amber' : 'green'}>
                    {m.role}
                  </Badge>
                </div>
                <div className="grid grid-cols-2 gap-2 mt-3 text-[11px]">
                  <div>
                    <p className="text-gray-400 uppercase font-black text-[9px] tracking-widest">TAC ID</p>
                    <p className="font-mono font-bold text-tac-blue">{m.userId || 'TAC-EL-PENDING'}</p>
                  </div>
                  <div>
                    <p className="text-gray-400 uppercase font-black text-[9px] tracking-widest">Phone</p>
                    <p className="text-[var(--Sub)]">{m.phone || 'N/A'}</p>
                  </div>
                  <div className="col-span-2">
                    <p className="text-gray-400 uppercase font-black text-[9px] tracking-widest">Joined</p>
                    <p className="text-gray-400">{m.joinedDate ? new Date(m.joinedDate).toLocaleDateString() : 'Active'}</p>
                  </div>
                </div>
                {officeBadges(m)}
                <div className="flex gap-2 mt-3">
                  <Button size="sm" variant="ghost" onClick={() => onEditMember?.(m)} icon={<Edit3 size={14} />} className="flex-1 justify-center">Edit</Button>
                  {onAssign && <Button size="sm" variant="primary" onClick={() => onAssign(m)} icon={<Shield size={14} />} className="flex-1 justify-center">Offices</Button>}
                </div>
              </Card>
            ))}
          </div>

          {/* Desktop/tablet: full table */}
          <Card className="hidden md:block">
            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead className="bg-gray-50 dark:bg-white/5 text-gray-500 font-black uppercase tracking-wider">
                  <tr>
                    <th className="p-3">Member Name</th>
                    <th className="p-3">TAC ID</th>
                    <th className="p-3">Role</th>
                    <th className="p-3">Phone</th>
                    <th className="p-3">Joined Date</th>
                    <th className="p-3 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[var(--Bdr)]">
                  {filtered.map((m) => (
                    <tr key={m.uid} className="hover:bg-gray-50/50 dark:hover:bg-white/5">
                      <td className="p-3">
                        <div className="flex items-center gap-3">
                          <div className={`w-8 h-8 rounded-xl overflow-hidden ${m.color || 'bg-tac-blue'} text-white font-bold flex items-center justify-center text-xs`}>
                            {m.picUrl ? <img src={m.picUrl} alt="" className="w-full h-full object-cover" /> : m.name[0]}
                          </div>
                          <div>
                            <p className="font-bold text-tac-blue-dark dark:text-white">{m.name}</p>
                            <p className="text-[10px] text-gray-400">{m.email}</p>
                            {officeBadges(m)}
                          </div>
                        </div>
                      </td>
                      <td className="p-3 font-mono font-bold text-tac-blue">{m.userId || 'TAC-EL-PENDING'}</td>
                      <td className="p-3">
                        <Badge variant={m.role === 'admin' ? 'red' : m.role === 'presbytery' ? 'amber' : 'green'}>
                          {m.role}
                        </Badge>
                      </td>
                      <td className="p-3 text-[var(--Sub)]">{m.phone || 'N/A'}</td>
                      <td className="p-3 text-gray-400">
                        {m.joinedDate ? new Date(m.joinedDate).toLocaleDateString() : 'Active'}
                      </td>
                      <td className="p-3 text-right whitespace-nowrap">
                        {onAssign && <Button size="sm" variant="primary" onClick={() => onAssign(m)} icon={<Shield size={14} />} className="mr-2">Offices</Button>}
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => onEditMember?.(m)}
                          icon={<Edit3 size={14} />}
                        >
                          Edit
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>
        </>
      )}
    </div>
  );
};
export default Directory;
