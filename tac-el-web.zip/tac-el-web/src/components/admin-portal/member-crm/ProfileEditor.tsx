import React, { useEffect, useState } from 'react';
import { supabase } from '../../../supabase';
import { UserProfile, UserRole } from '../../../types';
import { authService } from '../../../services/authService';
import { User, Shield, Check, X, Phone, Mail } from 'lucide-react';
import { membersService } from '../../../services/membersService';
import { useAuth } from '../../../context/AuthContext';
import { Modal, Button } from '../../ui';

interface ProfileEditorProps {
  member: UserProfile | null;
  isOpen: boolean;
  onClose: () => void;
  onUpdated: () => void;
}

export const ProfileEditor: React.FC<ProfileEditorProps> = (props) => {
  if (!props.member) return null;
  return <ProfileEditorInner key={props.member.uid} {...props} member={props.member} />;
};

const ProfileEditorInner: React.FC<ProfileEditorProps & { member: UserProfile }> = ({ member, isOpen, onClose, onUpdated }) => {
  const { user: me } = useAuth();
  const [confirmDel, setConfirmDel] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [delError, setDelError] = useState<string | null>(null);
  const canDelete = member.uid !== me?.id && member.role !== 'admin';
  const handleDelete = async () => {
    setDeleting(true); setDelError(null);
    try {
      await membersService.deleteMember(member.uid);
      onUpdated(); onClose();
    } catch (e: any) {
      setDelError(e?.message || 'Could not delete this account.');
    } finally { setDeleting(false); }
  };

  // what the register knows about this person (department, card, attendance)
  const [reg, setReg] = useState<any>(null);
  const [regErr, setRegErr] = useState('');
  useEffect(() => {
    let live = true;
    supabase.rpc('member_register_info', { p_profile: member.uid }).then(({ data, error }) => {
      if (!live) return;
      if (error) setRegErr('Register details are not available yet (run 21-connect-register.sql).');
      else setReg(data);
    });
    return () => { live = false; };
  }, [member.uid]);

  const [name, setName] = useState(member.name);
  const [role, setRole] = useState<UserRole>(member.role);
  const [userId, setUserId] = useState(member.userId || '');
  const [phone, setPhone] = useState(member.phone || '');
  const [occupation, setOccupation] = useState(member.occupation || '');
  const [saving, setSaving] = useState(false);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      await authService.updateProfile(member.uid, {
        name,
        role: member.uid === me?.id ? member.role : role,
        userId: userId.trim().toUpperCase(),
        phone,
        occupation
      });
      onUpdated();
      onClose();
    } finally {
      setSaving(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Edit Member Profile"
      description={`Update administrative records and clearance for ${member.name}.`}
    >
      <form onSubmit={handleSave} className="space-y-4">
        <div>
          <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
            Full Name
          </label>
          <input
            type="text"
            required
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="w-full px-4 py-2.5 bg-gray-50 dark:bg-slate-800 border border-[var(--Bdr)] rounded-2xl text-sm font-bold outline-none"
          />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
              TAC ID / Member ID
            </label>
            <input
              type="text"
              required
              value={userId}
              onChange={(e) => setUserId(e.target.value)}
              className="w-full px-4 py-2.5 bg-gray-50 dark:bg-slate-800 border border-[var(--Bdr)] rounded-2xl text-sm font-mono font-bold text-tac-blue outline-none uppercase"
            />
          </div>

          <div>
            <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
              Assigned Role
            </label>
            <select
              value={role}
              disabled={member.uid === me?.id}
              title={member.uid === me?.id ? 'You cannot change your own role here' : undefined}
              onChange={(e) => setRole(e.target.value as UserRole)}
              className="w-full px-4 py-2.5 bg-gray-50 dark:bg-slate-800 border border-[var(--Bdr)] rounded-2xl text-sm font-bold outline-none"
            >
              <option value="member">Member</option>
              <option value="presbytery">Presbytery / Elder</option>
              <option value="admin">Secretariat / Admin</option>
            </select>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
              Phone Number
            </label>
            <input
              type="tel"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              className="w-full px-4 py-2.5 bg-gray-50 dark:bg-slate-800 border border-[var(--Bdr)] rounded-2xl text-sm outline-none"
            />
          </div>

          <div>
            <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
              Profession / Occupation
            </label>
            <input
              type="text"
              value={occupation}
              onChange={(e) => setOccupation(e.target.value)}
              className="w-full px-4 py-2.5 bg-gray-50 dark:bg-slate-800 border border-[var(--Bdr)] rounded-2xl text-sm outline-none"
            />
          </div>
        </div>

        <div className="pt-4 flex justify-end gap-3">
          <Button type="button" variant="ghost" onClick={onClose}>
            Cancel
          </Button>
          <Button type="submit" variant="primary" loading={saving}>
            Save Changes
          </Button>
        </div>
      </form>

      <div className="mt-5 pt-4 border-t border-[var(--Bdr)]">
        <p className="text-[10px] font-black uppercase tracking-widest text-gray-400 mb-2">Register and attendance</p>
        {regErr && <p className="text-xs text-gray-500">{regErr}</p>}
        {!regErr && reg && !reg.in_register && <p className="text-xs text-gray-500">Not in the register yet. They link automatically when the register has the same TAC ID.</p>}
        {!regErr && reg?.in_register && (
          <div className="grid grid-cols-2 gap-2 text-xs">
            {[
              ['Department', reg.department || 'None'],
              ['Position', reg.position || 'None'],
              ['Register status', reg.status],
              ['Card', reg.card],
              ['Last attended', reg.last_attended || 'Never'],
              ['Last 30 days', `${reg.attended_30d} of ${reg.services_30d} services`],
              ['Total services', String(reg.attended_total)],
            ].map(([k, v]) => (
              <div key={k as string} className="bg-gray-50 dark:bg-white/5 rounded-xl px-3 py-2">
                <p className="text-[9px] font-black uppercase tracking-wider text-gray-400">{k}</p>
                <p className="font-bold text-tac-blue-dark dark:text-white">{v}</p>
              </div>
            ))}
          </div>
        )}
      </div>

      {canDelete && (
        <div className="mt-5 pt-4 border-t border-red-200">
          {!confirmDel ? (
            <button type="button" onClick={() => setConfirmDel(true)} className="text-xs font-black text-tac-red">
              Delete this member's account…
            </button>
          ) : (
            <div className="space-y-2">
              <p className="text-xs text-gray-600">Permanently delete {member.name}'s account and data? This cannot be undone. Their gifts stay in the church's accounts as guest gifts; pledges, messages and club records are removed.</p>
              {delError && <p className="text-[11px] font-bold text-tac-red">{delError}</p>}
              <div className="flex gap-2 justify-end">
                <Button type="button" variant="ghost" onClick={() => { setConfirmDel(false); setDelError(null); }}>Keep</Button>
                <Button type="button" variant="primary" loading={deleting} onClick={handleDelete}>Yes, delete</Button>
              </div>
            </div>
          )}
        </div>
      )}
    </Modal>
  );
};
export default ProfileEditor;
