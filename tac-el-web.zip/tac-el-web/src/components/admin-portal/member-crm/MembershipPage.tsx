import React, { useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { UserProfile } from '../../../types';
import { Directory } from './Directory';
import { ProfileEditor } from './ProfileEditor';
import { VisitorPipeline } from './VisitorPipeline';
import { RolesTab } from './RolesTab';
import { AssignOfficesModal } from './AssignOfficesModal';
import { MembershipApplications } from '../MembershipApplications';
import { TacIdSettings } from '../TacIdSettings';
import { AppFrame } from '../attendance/AppFrame';

type Tab = 'register' | 'members' | 'roles' | 'applications' | 'visitors' | 'ids';

interface Props {
  isAdmin: boolean;
  /** what the signed-in person may do (from their offices); administrators can do everything */
  perms: string[];
}

/** One place for everything about people. Each person sees only the tabs their office allows. */
export const MembershipPage: React.FC<Props> = ({ isAdmin, perms }) => {
  const can = (p: string) => isAdmin || perms.includes(p);
  const all: { id: Tab; label: string; show: boolean }[] = [
    { id: 'register', label: 'Members', show: can('register.view') },
    { id: 'roles', label: 'Roles', show: isAdmin },
    { id: 'members', label: 'Accounts', show: isAdmin },
    { id: 'applications', label: 'Applications', show: isAdmin },
    { id: 'visitors', label: 'Visitors', show: can('visitors.manage') },
    { id: 'ids', label: 'IDs', show: isAdmin },
  ];
  const tabs = all.filter((t) => t.show);
  const [params] = useSearchParams();
  const first = tabs[0]?.id;
  const [tab, setTab] = useState<Tab | undefined>(() => {
    const want = params.get('tab') as Tab | null;
    if (want && tabs.some((t) => t.id === want)) return want;
    try { const s = sessionStorage.getItem('tac_mem_tab3') as Tab | null; if (s && tabs.some((t) => t.id === s)) return s; } catch { /* fine */ }
    return first;
  });
  const pick = (t: Tab) => { setTab(t); try { sessionStorage.setItem('tac_mem_tab3', t); } catch { /* fine */ } };
  const [editing, setEditing] = useState<UserProfile | null>(null);
  const [assigning, setAssigning] = useState<UserProfile | null>(null);
  const [refresh, setRefresh] = useState(0);

  if (tabs.length === 0) return <p className="text-sm text-gray-500 py-10">Your office does not include any membership tools.</p>;
  const cur = tab && tabs.some((t) => t.id === tab) ? tab : first;

  return (
    <div className="pb-10">
      <h1 className="text-2xl font-black font-serif text-tac-blue-dark dark:text-white">Membership</h1>
      <div className="sticky top-0 z-10 -mx-4 px-4 py-3 bg-[var(--Bg,#f8fafc)]/95 dark:bg-slate-950/95 backdrop-blur flex gap-2 overflow-x-auto">
        {tabs.map((t) => (
          <button key={t.id} onClick={() => pick(t.id)}
            className={`shrink-0 px-4 py-2 rounded-full text-xs font-black uppercase tracking-wider border transition-all ${cur === t.id ? 'bg-tac-blue text-white border-tac-blue shadow' : 'bg-white dark:bg-slate-900 text-[var(--Sub)] border-[var(--Bdr)]'}`}>
            {t.label}
          </button>
        ))}
      </div>
      {cur === 'register' && <AppFrame title="Members" src="/apps/register/index.html" />}
      {cur === 'roles' && <RolesTab />}
      {cur === 'members' && (
        <>
          <Directory refreshKey={refresh} onEditMember={(m: UserProfile) => setEditing(m)} onAssign={(m: UserProfile) => setAssigning(m)} />
          <ProfileEditor member={editing} isOpen={!!editing} onClose={() => setEditing(null)} onUpdated={() => setRefresh((k) => k + 1)} />
          <AssignOfficesModal member={assigning} onClose={() => setAssigning(null)} onSaved={() => setRefresh((k) => k + 1)} />
        </>
      )}
      {cur === 'applications' && <MembershipApplications />}
      {cur === 'visitors' && <VisitorPipeline />}
      {cur === 'ids' && <TacIdSettings />}
    </div>
  );
};
export default MembershipPage;
