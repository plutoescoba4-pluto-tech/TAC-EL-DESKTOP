import React, { useState } from 'react';
import { Smartphone, Send, CheckCircle2, MessageSquare, AlertCircle } from 'lucide-react';
import { Card, Button, Badge } from '../../ui';

export const SmsPush: React.FC = () => {
  const [recipient, setRecipient] = useState('all');
  const [message, setMessage] = useState('');
  const [senderId, setSenderId] = useState('TAC-EASTLEG');
  const [sending, setSending] = useState(false);
  const [sentSuccess, setSentSuccess] = useState(false);

  const charCount = message.length;
  const pageCount = Math.ceil(charCount / 160) || 1;

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim()) return;

    setSending(true);
    setTimeout(() => {
      setSending(false);
      setSentSuccess(true);
      setMessage('');
      setTimeout(() => setSentSuccess(false), 4000);
    }, 800);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-xl font-black text-tac-blue-dark dark:text-white uppercase tracking-tight">
            SMS & Push Notification Gateway
          </h2>
          <p className="text-xs text-[var(--Sub)]">
            Instant SMS alerts for service reminders, all-night vigils, and emergency communications
          </p>
        </div>

        <div className="bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800 px-4 py-2 rounded-2xl">
          <span className="text-[10px] font-black uppercase text-emerald-600 block">SMS Balance</span>
          <span className="text-lg font-black text-emerald-700 dark:text-emerald-400">4,850 Units</span>
        </div>
      </div>

      {sentSuccess && (
        <div className="p-4 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 rounded-2xl flex items-center gap-2 text-emerald-600 dark:text-emerald-400 text-xs font-bold animate-fadeIn">
          <CheckCircle2 size={16} />
          SMS blast delivered to all active mobile network numbers!
        </div>
      )}

      <Card>
        <form onSubmit={handleSend} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
                Sender ID (Alpha Header)
              </label>
              <input
                type="text"
                value={senderId}
                onChange={(e) => setSenderId(e.target.value)}
                maxLength={11}
                className="w-full px-4 py-2.5 bg-gray-50 dark:bg-slate-800 border border-[var(--Bdr)] rounded-2xl text-sm font-bold uppercase font-mono outline-none"
              />
            </div>

            <div>
              <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
                Recipient Segment
              </label>
              <select
                value={recipient}
                onChange={(e) => setRecipient(e.target.value)}
                className="w-full px-4 py-2.5 bg-gray-50 dark:bg-slate-800 border border-[var(--Bdr)] rounded-2xl text-sm font-bold outline-none"
              >
                <option value="all">All Members (420 Contacts)</option>
                <option value="elders">Elders Council Only</option>
                <option value="choir">Choir Members</option>
                <option value="youth">Youth Fellowship</option>
              </select>
            </div>
          </div>

          <div>
            <div className="flex justify-between items-center mb-1">
              <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500">
                SMS Text
              </label>
              <span className="text-[10px] font-mono text-gray-400">
                {charCount} chars · {pageCount} page(s)
              </span>
            </div>
            <textarea
              required
              rows={4}
              maxLength={480}
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="e.g. Calvary greetings! Reminder: Friday Miracle & Prayer Service starts at 6:30 PM tonight. Come and experience God's power. TAC-East Legon"
              className="w-full px-4 py-3 bg-gray-50 dark:bg-slate-800 border border-[var(--Bdr)] rounded-2xl text-sm outline-none"
            />
          </div>

          <div className="flex justify-end pt-2">
            <Button type="submit" variant="primary" loading={sending} icon={<Send size={16} />}>
              Send SMS Blast
            </Button>
          </div>
        </form>
      </Card>
    </div>
  );
};
export default SmsPush;
