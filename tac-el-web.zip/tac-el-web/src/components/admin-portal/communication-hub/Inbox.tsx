import React from 'react';
import AdminInbox from '../../sections/AdminInbox';

export const Inbox: React.FC = () => {
  return <AdminInbox />;
};
export default Inbox;
