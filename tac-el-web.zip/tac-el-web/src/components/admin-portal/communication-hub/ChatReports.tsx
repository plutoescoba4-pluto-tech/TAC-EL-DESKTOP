import React, { useCallback, useEffect, useState } from 'react';
import { Card, Button } from '../../ui';
import { ShieldAlert } from 'lucide-react';
import { chatSafetyService, BlockReport, Suspension, BLOCK_REASONS } from '../../../services/chatSafetyService';

/**
 * Admin > Chat Reports
 * When someone blocks a person they must give a reason; it arrives here with the last 5 messages
 * between the two. The admin decides: unblock, or keep the block for a set time; and may also
 * suspend the reported person from chat and send them a warning.
 */

type Tab = 'open' | 'reviewed' | 'suspended';
const inputCls = 'w-full rounded-xl border border-[var(--Bdr)] bg-transparent px-3 py-2.5 text-sm text-[var(--Text)] outline-none focus:border-tac-blue';
const labelCls = 'block text-[10px] font-black uppercase tracking-widest text-gray-400 mb-1 px-1';
const reasonLabel = (id: string) => BLOCK_REASONS.find((r) => r.id === id)?.label || id;
const when = (iso: string) => new Date(iso).toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' });

const ReviewForm: React.FC<{ report: BlockReport; onDone: () => void }> = ({ report, onDone }) => {
  const [action, setAction] = useState<'unblock' | 'keep'>('keep');
  const [keepDays, setKeepDays] = useState<string>('30');   // '' = until an admin changes it
  const [suspend, setSuspend] = useState(false);
  const [suspendDays, setSuspendDays] = useState('7');
  const [warning, setWarning] = useState('');
  const [note, setNote] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const submit = async () => {
    setBusy(true); setError(null);
    try {
      await chatSafetyService.reviewReport({
        reportId: report.id,
        blockAction: action,
        keepDays: action === 'keep' && keepDays.trim() ? Math.max(1, parseInt(keepDays, 10) || 1) : null,
        suspendDays: suspend ? Math.max(1, parseInt(suspendDays, 10) || 1) : null,
        warning,
        adminNote: note,
      });
      onDone();
    } catch (e: any) { setError(e.message); setBusy(false); }
  };

  return (
    <div className="mt-4 pt-4 border-t border-[var(--Bdr)] space-y-4">
      <div>
        <span className={labelCls}>Decision about the block</span>
        <label className="flex items-center gap-2 text-sm font-semibold mb-1.5"><input type="radio" className="accent-[#1d4ed8]" checked={action === 'keep'} onChange={() => setAction('keep')} /> Keep the block</label>
        {action === 'keep' && (
          <div className="ml-6 mb-2">
            <label className={labelCls}>For how many days? (leave empty = until I change it)</label>
            <input type="number" min={1} className={inputCls} value={keepDays} onChange={(e) => setKeepDays(e.target.value)} placeholder="e.g. 30" />
            <p className="text-[11px] text-gray-500 mt-1">While the block is kept, {report.reporterName} cannot unblock early. It lifts by itself at the end.</p>
          </div>
        )}
        <label className="flex items-center gap-2 text-sm font-semibold"><input type="radio" className="accent-[#1d4ed8]" checked={action === 'unblock'} onChange={() => setAction('unblock')} /> Unblock {report.reportedName}</label>
      </div>

      <div>
        <label className="flex items-center gap-2 text-sm font-semibold"><input type="checkbox" className="w-4 h-4" checked={suspend} onChange={(e) => setSuspend(e.target.checked)} /> Also suspend {report.reportedName} from chat</label>
        {suspend && (
          <div className="ml-6 mt-2">
            <label className={labelCls}>For how many days?</label>
            <input type="number" min={1} className={inputCls} value={suspendDays} onChange={(e) => setSuspendDays(e.target.value)} />
            <p className="text-[11px] text-gray-500 mt-1">They can still read, but cannot send messages or reactions (group chat and direct messages).</p>
          </div>
        )}
      </div>

      <div>
        <label className={labelCls}>Send {report.reportedName} a warning (optional)</label>
        <textarea rows={2} className={inputCls} value={warning} onChange={(e) => setWarning(e.target.value)} placeholder="This appears in their notifications." />
      </div>
      <div>
        <label className={labelCls}>Your note (kept for the record)</label>
        <textarea rows={2} className={inputCls} value={note} onChange={(e) => setNote(e.target.value)} />
      </div>
      {error && <p className="text-xs text-tac-red">{error}</p>}
      <Button onClick={submit} loading={busy}>Save decision</Button>
    </div>
  );
};

const decisionText = (r: BlockReport) => {
  const d = r.decision || {};
  const parts: string[] = [];
  parts.push(d.block_action === 'unblock' ? 'Block lifted' : d.keep_days ? `Block kept for ${d.keep_days} days` : 'Block kept');
  if (d.suspend_days) parts.push(`suspended ${d.suspend_days} days`);
  if (d.warning_sent) parts.push('warning sent');
  return parts.join(' · ');
};

export const ChatReports: React.FC = () => {
  const [tab, setTab] = useState<Tab>('open');
  const [reports, setReports] = useState<BlockReport[]>([]);
  const [suspensions, setSuspensions] = useState<Suspension[]>([]);
  const [openId, setOpenId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [counts, setCounts] = useState<{ open: number }>({ open: 0 });

  const load = useCallback(async () => {
    setLoading(true); setError(null);
    try {
      if (tab === 'suspended') setSuspensions(await chatSafetyService.listSuspensions());
      else setReports(await chatSafetyService.listReports(tab));
      const open = await chatSafetyService.listReports('open');
      setCounts({ open: open.length });
    } catch (e: any) { setError(e.message); }
    setLoading(false);
  }, [tab]);
  useEffect(() => { load(); }, [load]);

  const lift = async (s: Suspension) => {
    if (!window.confirm(`Restore chat access for ${s.userName}?`)) return;
    try { await chatSafetyService.liftSuspension(s.userId); load(); } catch (e: any) { setError(e.message); }
  };

  return (
    <div className="space-y-4 max-w-3xl mx-auto">
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-2xl bg-red-50 dark:bg-red-500/10 text-tac-red flex items-center justify-center"><ShieldAlert size={20} /></div>
        <div>
          <h2 className="text-lg font-black leading-tight">Chat Reports</h2>
          <p className="text-xs text-gray-500 dark:text-gray-400">Review why members blocked someone, and decide what happens next.</p>
        </div>
      </div>

      <div className="flex gap-2">
        {([['open', `To review${counts.open ? ` (${counts.open})` : ''}`], ['reviewed', 'Reviewed'], ['suspended', 'Suspended']] as [Tab, string][]).map(([id, label]) => (
          <button key={id} type="button" onClick={() => { setTab(id); setOpenId(null); }}
            className={`px-4 py-2 rounded-full text-[11px] font-black uppercase tracking-wider border ${tab === id ? 'bg-tac-blue text-white border-tac-blue' : 'border-[var(--Bdr)] text-gray-500'}`}>{label}</button>
        ))}
      </div>

      {error && <p className="text-sm text-tac-red">{error}</p>}
      {loading && <p className="text-xs text-gray-400">Loading…</p>}

      {tab === 'suspended' && !loading && (suspensions.length === 0
        ? <Card><p className="text-sm text-gray-500">Nobody is suspended from chat right now.</p></Card>
        : suspensions.map((s) => (
          <Card key={s.id}>
            <div className="flex items-center justify-between gap-3">
              <div><p className="font-bold text-sm">{s.userName}</p><p className="text-xs text-gray-500">Paused until {when(s.until)}{s.reason ? ` · ${s.reason}` : ''}</p></div>
              <Button variant="outline" onClick={() => lift(s)}>Restore access</Button>
            </div>
          </Card>
        )))}

      {tab !== 'suspended' && !loading && (reports.length === 0
        ? <Card><p className="text-sm text-gray-500">{tab === 'open' ? 'No reports waiting for review.' : 'Nothing reviewed yet.'}</p></Card>
        : reports.map((r) => (
          <Card key={r.id}>
            <div className="flex items-start justify-between gap-3">
              <div className="min-w-0">
                <p className="text-sm"><span className="font-black">{r.reporterName}</span> blocked <span className="font-black">{r.reportedName}</span></p>
                <p className="text-xs text-gray-500">{when(r.createdAt)}</p>
              </div>
              <span className="shrink-0 text-[10px] font-black uppercase tracking-wider px-2 py-1 rounded-full bg-red-50 dark:bg-red-500/10 text-tac-red">{reasonLabel(r.reason)}</span>
            </div>
            {r.note && <p className="mt-3 text-sm whitespace-pre-wrap break-words bg-gray-50 dark:bg-white/5 rounded-xl p-3">{r.note}</p>}

            <p className={`${labelCls} mt-4`}>Last messages between them</p>
            {r.evidence.length === 0
              ? <p className="text-xs text-gray-400">No messages were exchanged.</p>
              : <div className="space-y-1.5">
                  {r.evidence.map((m, i) => (
                    <div key={i} className="text-xs rounded-xl bg-gray-50 dark:bg-white/5 p-2.5">
                      <span className="font-black">{m.from === r.reporterId ? r.reporterName : r.reportedName}</span>
                      <span className="text-gray-400"> · {when(m.at)}</span>
                      <p className="mt-0.5 whitespace-pre-wrap break-words">{m.text}</p>
                    </div>
                  ))}
                </div>}

            {tab === 'reviewed' && (
              <div className="mt-4 pt-3 border-t border-[var(--Bdr)] text-xs text-gray-600 dark:text-gray-300">
                <p className="font-bold">{decisionText(r)}</p>
                {r.adminNote && <p className="mt-1">Note: {r.adminNote}</p>}
                {r.decidedAt && <p className="text-gray-400 mt-0.5">Reviewed {when(r.decidedAt)}</p>}
              </div>
            )}

            {tab === 'open' && (openId === r.id
              ? <ReviewForm report={r} onDone={() => { setOpenId(null); load(); }} />
              : <div className="mt-4"><Button onClick={() => setOpenId(r.id)}>Review this report</Button></div>)}
          </Card>
        )))}
    </div>
  );
};

export default ChatReports;
