import React, { useState, useEffect } from 'react';
import { clubsService } from '../../../services/clubsService';
import { membersService } from '../../../services/membersService';
import { Team, UserProfile } from '../../../types';
import { Users, Edit3, Shield, CheckCircle2, Plus, X } from 'lucide-react';
import { Card, Button, Badge } from '../../ui';

export const ManageClubs: React.FC = () => {
  const [clubs, setClubs] = useState<Team[]>([]);
  const [members, setMembers] = useState<UserProfile[]>([]);
  const [loading, setLoading] = useState(true);
  const [assigningClubId, setAssigningClubId] = useState<string | null>(null);
  const [selectedMember, setSelectedMember] = useState<string>('');
  const [saving, setSaving] = useState(false);
  const [successClubId, setSuccessClubId] = useState<string | null>(null);
  const [leaders, setLeaders] = useState<Record<string, { uid: string; name: string }[]>>({});
  const [error, setError] = useState<string | null>(null);
  const [showNewClub, setShowNewClub] = useState(false);
  const [newClubName, setNewClubName] = useState('');
  const [newClubDesc, setNewClubDesc] = useState('');

  const load = async () => {
    const [c, m, l] = await Promise.all([clubsService.getClubs(), membersService.getAllMembers(), clubsService.getAllLeaders()]);
    setClubs(c);
    setMembers(m);
    setLeaders(l);
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const handleRemoveLeader = async (clubId: string, uid: string, name: string) => {
    if (!window.confirm(`Remove ${name} as leader? They stay in the club as a regular member.`)) return;
    try {
      await clubsService.removeLeader(clubId, uid);
      await load();
    } catch (e: any) {
      setError(e?.message || 'Could not remove leader.');
    }
  };

  const handleCreateClub = async () => {
    if (!newClubName.trim()) return;
    try {
      await clubsService.addClub({ name: newClubName.trim(), description: newClubDesc.trim() });
      setNewClubName(''); setNewClubDesc(''); setShowNewClub(false);
      await load();
    } catch (e: any) {
      setError(e?.message || 'Could not create club.');
    }
  };

  const handleAssignLeader = async (clubId: string) => {
    if (!selectedMember) return;
    const member = members.find(m => m.uid === selectedMember);
    if (!member) return;

    setSaving(true);
    try {
      await clubsService.assignLeader(clubId, member.uid, member.name);
      setSuccessClubId(clubId);
      setAssigningClubId(null);
      setSelectedMember('');
      setTimeout(() => setSuccessClubId(null), 3000);
      await load();
    } catch (e: any) {
      setError(e?.message || 'Could not assign leader.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-xl font-black text-tac-blue-dark dark:text-white uppercase tracking-tight">
            Ministry Wings & Club Management
          </h2>
          <p className="text-xs text-[var(--Sub)]">
            Assign a group leader to unlock their Group Leader Portal — this does not require the member to apply.
          </p>
        </div>
        <Button size="sm" icon={<Plus size={14} />} onClick={() => setShowNewClub((v) => !v)}>New Club</Button>
      </div>

      {error && (
        <div className="p-3 rounded-xl bg-red-50 dark:bg-red-950/30 text-tac-red text-xs flex justify-between gap-3">
          <span>{error}</span>
          <button onClick={() => setError(null)} className="font-black uppercase text-[10px] shrink-0">Dismiss</button>
        </div>
      )}

      {showNewClub && (
        <Card>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 min-w-0">
            <input value={newClubName} onChange={(e) => setNewClubName(e.target.value)} placeholder="Club name"
              className="w-full min-w-0 px-3 py-2.5 bg-gray-50 dark:bg-slate-800 border border-[var(--Bdr)] rounded-xl text-sm outline-none" />
            <input value={newClubDesc} onChange={(e) => setNewClubDesc(e.target.value)} placeholder="Short description"
              className="w-full min-w-0 px-3 py-2.5 bg-gray-50 dark:bg-slate-800 border border-[var(--Bdr)] rounded-xl text-sm outline-none" />
          </div>
          <Button size="sm" className="mt-3" onClick={handleCreateClub}>Create Club</Button>
        </Card>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {clubs.map((club) => (
          <Card key={club.id}>
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className={`w-12 h-12 rounded-2xl ${club.color || 'bg-tac-blue'} text-white font-black text-lg flex items-center justify-center`}>
                  {club.name[0]}
                </div>
                <div>
                  <h4 className="font-bold text-sm text-tac-blue-dark dark:text-white uppercase">{club.name}</h4>
                  <p className="text-[11px] text-[var(--Sub)] line-clamp-1">{club.desc}</p>
                </div>
              </div>
              <Badge variant="blue">{club.members ?? 0} Members</Badge>
            </div>

            <div className="mt-3 flex flex-wrap gap-2">
              {(leaders[club.id] ?? []).length === 0 ? (
                <span className="text-[10px] uppercase font-bold text-gray-400">No leader assigned yet</span>
              ) : (
                (leaders[club.id] ?? []).map((l) => (
                  <span key={l.uid} className="inline-flex items-center gap-1.5 pl-3 pr-1.5 py-1 rounded-full bg-tac-blue/10 text-tac-blue text-[11px] font-bold">
                    <Shield size={11} /> {l.name}
                    <button onClick={() => handleRemoveLeader(club.id, l.uid, l.name)} className="p-0.5 rounded-full hover:bg-tac-red hover:text-white transition-colors" title="Remove leader">
                      <X size={11} />
                    </button>
                  </span>
                ))
              )}
            </div>

            {successClubId === club.id && (
              <div className="mt-3 p-2.5 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 rounded-xl flex items-center gap-2 text-emerald-600 dark:text-emerald-400 text-xs font-bold">
                <CheckCircle2 size={14} />
                Leader assigned — they now see the Group Leader Portal on next login.
              </div>
            )}

            {assigningClubId === club.id ? (
              <div className="mt-4 pt-3 border-t border-[var(--Bdr)] space-y-2">
                <select
                  value={selectedMember}
                  onChange={(e) => setSelectedMember(e.target.value)}
                  className="w-full px-3 py-2 bg-gray-50 dark:bg-slate-800 border border-[var(--Bdr)] rounded-xl text-xs font-bold outline-none"
                >
                  <option value="">-- Choose Member --</option>
                  {members.map(m => (
                    <option key={m.uid} value={m.uid}>{m.name} ({m.userId || 'No ID'})</option>
                  ))}
                </select>
                <div className="flex gap-2">
                  <Button size="sm" variant="primary" loading={saving} onClick={() => handleAssignLeader(club.id)} className="flex-1">
                    Confirm
                  </Button>
                  <Button size="sm" variant="outline" onClick={() => { setAssigningClubId(null); setSelectedMember(''); }}>
                    Cancel
                  </Button>
                </div>
              </div>
            ) : (
              <div className="mt-4 pt-3 border-t border-[var(--Bdr)] flex items-center justify-between text-xs">
                <span className="text-[10px] uppercase font-bold text-gray-400">Status: Active Ministry</span>
                <Button size="sm" variant="outline" icon={<Shield size={14} />} onClick={() => setAssigningClubId(club.id)}>
                  Assign Leader
                </Button>
              </div>
            )}
          </Card>
        ))}
      </div>
    </div>
  );
};
export default ManageClubs;
