import React, { useState } from 'react';
import { Sparkles, Save, CheckCircle2, Shield, Bot, Key } from 'lucide-react';
import { Card, Button, Badge } from '../ui';

export const KinAiSettings: React.FC = () => {
  const [model, setModel] = useState('gemini-2.5-flash');
  const [systemPrompt, setSystemPrompt] = useState(
    `You are Kin AI, the spiritual companion and apostolic pastoral guide of The Apostolic Church Ghana, East Legon Assembly.
Your answers are biblical, comforting, grounded in Apostolic tenets (Tenets of The Apostolic Church Ghana), and supportive of Christian discipleship. Always refer to Holy Scripture with chapter and verse.`
  );
  const [temperature, setTemperature] = useState('0.7');
  const [safetyFilter, setSafetyFilter] = useState('strict');
  const [saving, setSaving] = useState(false);
  const [savedSuccess, setSavedSuccess] = useState(false);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setTimeout(() => {
      setSaving(false);
      setSavedSuccess(true);
      setTimeout(() => setSavedSuccess(false), 3000);
    }, 600);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-xl font-black text-tac-blue-dark dark:text-white uppercase tracking-tight">
            Kin AI Pastoral & Theological Configuration
          </h2>
          <p className="text-xs text-[var(--Sub)]">
            Govern AI responses, scripture grounding parameters, and doctrinal boundaries
          </p>
        </div>

        <Badge variant="blue">Autonomous Pastoral Assistant</Badge>
      </div>

      {savedSuccess && (
        <div className="p-4 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 rounded-2xl flex items-center gap-2 text-emerald-600 dark:text-emerald-400 text-xs font-bold animate-fadeIn">
          <CheckCircle2 size={16} />
          Kin AI behavioral parameters and system prompt successfully updated!
        </div>
      )}

      <Card>
        <form onSubmit={handleSave} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
                Language Model Engine
              </label>
              <select
                value={model}
                onChange={(e) => setModel(e.target.value)}
                className="w-full px-4 py-2.5 bg-gray-50 dark:bg-slate-800 border border-[var(--Bdr)] rounded-2xl text-sm font-bold outline-none"
              >
                <option value="gemini-2.5-flash">Gemini 2.5 Flash (Ultra Fast & Grounded)</option>
                <option value="gemini-2.5-pro">Gemini 2.5 Pro (Deep Theological Exegesis)</option>
                <option value="groq-llama-3.3-70b">Groq Llama-3.3 70B Versatile</option>
              </select>
            </div>

            <div>
              <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
                Doctrinal Safety Filter
              </label>
              <select
                value={safetyFilter}
                onChange={(e) => setSafetyFilter(e.target.value)}
                className="w-full px-4 py-2.5 bg-gray-50 dark:bg-slate-800 border border-[var(--Bdr)] rounded-2xl text-sm font-bold outline-none"
              >
                <option value="strict">Strict (Apostolic Church Tenets Enforced)</option>
                <option value="balanced">Balanced (Broad Evangelical Christian)</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
              System Instruction & Pastoral Persona
            </label>
            <textarea
              required
              rows={6}
              value={systemPrompt}
              onChange={(e) => setSystemPrompt(e.target.value)}
              className="w-full px-4 py-3 bg-gray-50 dark:bg-slate-800 border border-[var(--Bdr)] rounded-2xl text-xs font-mono outline-none leading-relaxed"
            />
          </div>

          <div className="pt-2 flex justify-end">
            <Button type="submit" variant="primary" loading={saving} icon={<Save size={16} />}>
              Save Kin AI Parameters
            </Button>
          </div>
        </form>
      </Card>
    </div>
  );
};
export default KinAiSettings;
