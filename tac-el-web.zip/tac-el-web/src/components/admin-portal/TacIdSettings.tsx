import React, { useCallback, useEffect, useState } from 'react';
import { supabase } from '../../supabase';
import { Card, Button } from '../ui';
import { IdCard } from 'lucide-react';

/**
 * Admin > Member IDs
 * Choose how every member's TAC ID looks (prefix, separator, minimum digits, next number),
 * e.g. TACEL100, TACEL101 ... New members follow the saved format. The admin can also re-issue
 * everyone's ID in the new format (every member is notified). The rules live in the database
 * (06c-ids-and-hymns.sql); members can still always sign in with their email.
 */

interface Settings { prefix: string; separator: string; min_digits: number; next_number: number; last_reissued_at: string | null }

const inputCls = 'w-full rounded-xl border border-[var(--Bdr)] bg-transparent px-3 py-2.5 text-sm text-[var(--Text)] outline-none focus:border-tac-blue';
const labelCls = 'block text-[10px] font-black uppercase tracking-widest text-gray-400 mb-1 px-1';
const SEPARATORS: { value: string; label: string }[] = [
  { value: '', label: 'None  (TACEL100)' },
  { value: '-', label: 'Dash  (TACEL-100)' },
  { value: '_', label: 'Underscore  (TACEL_100)' },
  { value: '.', label: 'Dot  (TACEL.100)' },
  { value: '/', label: 'Slash  (TACEL/100)' },
];

const preview = (prefix: string, sep: string, digits: number, next: number) =>
  `${prefix.trim().toUpperCase()}${sep}${String(Math.max(0, next || 0)).padStart(Math.max(1, digits || 1), '0')}`;

export const TacIdSettings: React.FC = () => {
  const [loaded, setLoaded] = useState<Settings | null>(null);
  const [prefix, setPrefix] = useState('TACEL');
  const [sep, setSep] = useState('');
  const [digits, setDigits] = useState('3');
  const [next, setNext] = useState('100');
  const [notice, setNotice] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);
  const [busy, setBusy] = useState(false);
  const [members, setMembers] = useState<number | null>(null);
  const [confirmText, setConfirmText] = useState('');
  const [reissuing, setReissuing] = useState(false);

  const load = useCallback(async () => {
    const { data, error } = await supabase.from('tac_id_settings').select('*').maybeSingle();
    if (error || !data) {
      setNotice({ type: 'err', text: 'Could not load the ID settings. Make sure 06c-ids-and-hymns.sql has been run, and that you are signed in as admin.' });
      return;
    }
    setLoaded(data as Settings);
    setPrefix(data.prefix); setSep(data.separator); setDigits(String(data.min_digits)); setNext(String(data.next_number));
    const { count } = await supabase.from('profiles').select('id', { count: 'exact', head: true });
    setMembers(count ?? null);
  }, []);
  useEffect(() => { load(); }, [load]);

  const save = async () => {
    setBusy(true); setNotice(null);
    const { data, error } = await supabase.rpc('admin_set_tac_id_format', {
      p_prefix: prefix, p_separator: sep, p_min_digits: parseInt(digits, 10), p_next_number: parseInt(next, 10),
    });
    setBusy(false);
    if (error) return setNotice({ type: 'err', text: error.message });
    setNotice({ type: 'ok', text: `Saved. The next new member will get ${data}.` });
    load();
  };

  const reissue = async () => {
    setReissuing(true); setNotice(null);
    const { data, error } = await supabase.rpc('admin_reissue_all_tac_ids', { p_confirm: confirmText });
    setReissuing(false);
    if (error) return setNotice({ type: 'err', text: error.message });
    setConfirmText('');
    setNotice({ type: 'ok', text: `Done. ${data} members now have a new ID, and each one has been notified.` });
    load();
  };

  const dirty = !!loaded && (prefix.trim().toUpperCase() !== loaded.prefix || sep !== loaded.separator || parseInt(digits, 10) !== loaded.min_digits || parseInt(next, 10) !== loaded.next_number);

  return (
    <div className="space-y-4 max-w-2xl mx-auto">
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-2xl bg-tac-blue/10 text-tac-blue flex items-center justify-center"><IdCard size={20} /></div>
        <div>
          <h2 className="text-lg font-black leading-tight">Member IDs</h2>
          <p className="text-xs text-gray-500 dark:text-gray-400">Decide how every member's TAC ID looks.</p>
        </div>
      </div>

      {notice && (
        <div role="status" className={`rounded-xl px-4 py-3 text-sm font-semibold ${notice.type === 'ok' ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-300' : 'bg-red-50 text-red-700 dark:bg-red-500/10 dark:text-red-300'}`}>{notice.text}</div>
      )}

      <Card>
        <h3 className="font-black text-sm mb-3">ID format</h3>
        <div className="grid grid-cols-2 gap-3 mb-3">
          <div><label className={labelCls}>Starts with</label><input className={inputCls} value={prefix} maxLength={12} onChange={(e) => setPrefix(e.target.value.replace(/[^A-Za-z0-9]/g, ''))} /></div>
          <div><label className={labelCls}>Between</label>
            <select className={inputCls} value={sep} onChange={(e) => setSep(e.target.value)}>
              {SEPARATORS.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
            </select>
          </div>
          <div><label className={labelCls}>Minimum digits</label><input type="number" min={1} max={8} className={inputCls} value={digits} onChange={(e) => setDigits(e.target.value)} /></div>
          <div><label className={labelCls}>Next number</label><input type="number" min={0} className={inputCls} value={next} onChange={(e) => setNext(e.target.value)} /></div>
        </div>
        <div className="rounded-2xl bg-gray-50 dark:bg-white/5 p-4 text-center mb-3">
          <p className="text-[10px] font-black uppercase tracking-widest text-gray-400">The next member will get</p>
          <p className="text-2xl font-black font-mono text-tac-blue">{preview(prefix, sep, parseInt(digits, 10), parseInt(next, 10))}</p>
        </div>
        <p className="text-xs text-gray-500 mb-3">Saving only changes the IDs of <b>new</b> members. Existing members keep their current ID until you re-issue them below.</p>
        <Button onClick={save} loading={busy} disabled={!dirty}>Save format</Button>
      </Card>

      <Card>
        <h3 className="font-black text-sm mb-1 text-tac-red">Re-issue everyone's ID</h3>
        <p className="text-xs text-gray-500 mb-3">
          Gives {members ?? 'every'} member{members === 1 ? '' : 's'} a new ID in the format above, oldest account first, starting at the next number.
          Every member gets a notification with their new ID. Members can still sign in with their email. Do this once, then tell the church the new IDs.
          {loaded?.last_reissued_at ? ` Last re-issued ${new Date(loaded.last_reissued_at).toLocaleString()}.` : ''}
        </p>
        {dirty && <p className="text-xs text-amber-700 dark:text-amber-300 mb-3">Save the format above first, so the new IDs use it.</p>}
        <label className={labelCls}>Type REISSUE to confirm</label>
        <input className={`${inputCls} mb-3`} value={confirmText} onChange={(e) => setConfirmText(e.target.value)} placeholder="REISSUE" />
        <Button variant="outline" onClick={reissue} loading={reissuing} disabled={confirmText !== 'REISSUE' || dirty}>Re-issue all IDs now</Button>
      </Card>
    </div>
  );
};

export default TacIdSettings;
