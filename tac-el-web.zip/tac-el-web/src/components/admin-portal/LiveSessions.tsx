import React from 'react';
import VoiceConference from '../sections/VoiceConference';

export const LiveSessions: React.FC = () => {
  return <VoiceConference />;
};
export default LiveSessions;
