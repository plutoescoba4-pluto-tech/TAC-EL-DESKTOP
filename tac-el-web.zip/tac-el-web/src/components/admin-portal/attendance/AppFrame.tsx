import React, { useState } from 'react';

/** Shows one of the original membership / attendance apps inside the admin, unchanged.
 *  They live on this same site (/apps/...), so the administrator is already signed in. */
export const AppFrame: React.FC<{ src: string; title: string }> = ({ src, title }) => {
  const [loaded, setLoaded] = useState(false);
  return (
    <div className="-mx-4 -mt-2 relative" style={{ height: 'calc(100dvh - 9.5rem)', minHeight: 420 }}>
      {!loaded && <p className="absolute inset-0 flex items-center justify-center text-sm text-[var(--Sub)]">Opening {title}…</p>}
      <iframe
        title={title}
        src={src}
        onLoad={() => setLoaded(true)}
        allow="clipboard-write; camera; fullscreen"
        className="w-full h-full border-0 bg-white"
      />
    </div>
  );
};
export default AppFrame;
