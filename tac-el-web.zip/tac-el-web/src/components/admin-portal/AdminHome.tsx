import React from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Users, UserCheck, IdCard, Briefcase, Bell, Calendar, BookOpen, Image as ImageIcon, Music4, Zap, Landmark, HandCoins,
  ClipboardList, Shield, HeartHandshake, Inbox, Smartphone, ShieldAlert, Palette, Radio,
  Package, Globe, Presentation, Settings, UserCog, User, UserPlus, Building2,
} from 'lucide-react';

type Card = { label: string; hint: string; to: string; icon: React.ReactNode; perm?: string[]; officeOnly?: boolean };
type Section = { title: string; cards: Card[] };

const s = 22;
const SECTIONS: Section[] = [
  { title: 'People', cards: [
    { label: 'Membership', hint: 'Members, register, IDs, visitors', to: '/dashboard/admin/membership', icon: <Users size={s} />, perm: ['register.view', 'visitors.manage'] },
    { label: 'Attendance', hint: 'Scan, live count, services', to: '/dashboard/admin/attendance', icon: <UserCheck size={s} />, perm: ['attendance.view'] },
    { label: 'Offices', hint: 'Who holds which office', to: '/dashboard/admin/membership?tab=roles', icon: <Briefcase size={s} /> },
    { label: 'Users', hint: 'Accounts and roles', to: '/dashboard/admin/users', icon: <UserCog size={s} /> },
  ]},
  { title: 'Content', cards: [
    { label: 'Notices', hint: 'Announcements', to: '/dashboard/admin/notices', icon: <Bell size={s} /> },
    { label: 'Events', hint: 'Programmes', to: '/dashboard/admin/events', icon: <Calendar size={s} /> },
    { label: 'Sermons', hint: 'Messages', to: '/dashboard/admin/sermons', icon: <BookOpen size={s} />, perm: ['media.manage'] },
    { label: 'Gallery', hint: 'Photos', to: '/dashboard/admin/gallery', icon: <ImageIcon size={s} />, perm: ['media.manage'] },
    { label: 'Hymns', hint: 'Verses and choruses', to: '/dashboard/admin/hymns', icon: <Music4 size={s} /> },
    { label: 'Updates', hint: 'Profile changes to approve', to: '/dashboard/updates', icon: <Zap size={s} /> },
  ]},
  { title: 'Money', cards: [
    { label: 'Treasury', hint: 'Giving and reports', to: '/dashboard/office/treasurer', icon: <Landmark size={s} /> },
    { label: 'Pledges', hint: 'Manage pledges', to: '/dashboard/admin/pledges', icon: <HandCoins size={s} /> },
    { label: 'Batch entry', hint: 'Record offerings', to: '/dashboard/admin/batches', icon: <ClipboardList size={s} /> },
    { label: 'Money reports', hint: 'Giving and reports, view only', to: '/dashboard/office/reports', icon: <Landmark size={s} />, perm: ['money.view'], officeOnly: true },
    { label: 'Assets', hint: 'Church property register', to: '/dashboard/admin/assets', icon: <Package size={s} />, perm: ['assets.view'] },
  ]},
  { title: 'Clubs', cards: [
    { label: 'Clubs', hint: 'Create and manage', to: '/dashboard/admin/clubs', icon: <HeartHandshake size={s} /> },
    { label: 'Presbytery', hint: 'Council portal', to: '/dashboard/presbytery', icon: <Shield size={s} /> },
  ]},
  { title: 'Messages', cards: [
    { label: 'Inbox', hint: 'Requests to the admin', to: '/dashboard/admin/inbox', icon: <Inbox size={s} /> },
    { label: 'Chat reports', hint: 'Blocks and complaints', to: '/dashboard/admin/chat-reports', icon: <ShieldAlert size={s} /> },
    { label: 'SMS and push', hint: 'Send alerts', to: '/dashboard/admin/sms', icon: <Smartphone size={s} /> },
    { label: 'Wallpapers', hint: 'Chat backgrounds', to: '/dashboard/admin/chat-wallpapers', icon: <Palette size={s} /> },
    { label: 'Voice recordings', hint: 'Saved meetings', to: '/dashboard/admin/voice-recordings', icon: <Radio size={s} /> },
  ]},
  { title: 'Website', cards: [
    { label: 'Website', hint: 'Wording and photos', to: '/dashboard/admin/website', icon: <Globe size={s} />, perm: ['media.manage'] },
    { label: 'Slideshow', hint: 'Home page pictures', to: '/dashboard/admin/hero', icon: <Presentation size={s} />, perm: ['media.manage'] },
    { label: 'Site settings', hint: 'Church details', to: '/dashboard/admin/settings', icon: <Settings size={s} /> },
    { label: 'My account', hint: 'Profile, sign out', to: '/dashboard/profile', icon: <User size={s} /> },
  ]},
];

const KEY = 'tac_admin_home_tab';
const readTab = () => { try { return sessionStorage.getItem(KEY) || SECTIONS[0].title; } catch { return SECTIONS[0].title; } };

interface HomeProps { isAdmin?: boolean; perms?: string[] }

export const AdminHome: React.FC<HomeProps> = ({ isAdmin = true, perms = [] }) => {
  const navigate = useNavigate();
  const visible = (c: Card) => (isAdmin ? !c.officeOnly : (!!c.perm && c.perm.some((p) => perms.includes(p))));
  const SECS = SECTIONS.map((x) => ({ ...x, cards: x.cards.filter(visible) })).filter((x) => x.cards.length > 0);
  const [tab, setTab] = React.useState<string>(() => {
    const t = readTab();
    return SECS.some((x) => x.title === t) ? t : (SECS[0] || SECTIONS[0]).title;
  });
  const pick = (t: string) => { setTab(t); try { sessionStorage.setItem(KEY, t); } catch { /* fine */ } };
  const sec = SECS.find((x) => x.title === tab) || (SECS[0] || SECTIONS[0]);
  return (
    <div className="pb-10">
      <h1 className="text-2xl font-black font-serif text-tac-blue-dark dark:text-white">{isAdmin ? 'Admin' : 'My office'}</h1>
      {/* one group at a time: nothing long to scroll, and coming back lands on the same group */}
      <div className="sticky top-0 z-10 -mx-4 px-4 py-3 mt-2 bg-[var(--Bg,#f8fafc)]/95 dark:bg-slate-950/95 backdrop-blur flex gap-2 overflow-x-auto">
        {SECS.map((x) => (
          <button
            key={x.title}
            onClick={() => pick(x.title)}
            className={`shrink-0 px-4 py-2 rounded-full text-xs font-black uppercase tracking-wider border transition-all ${
              x.title === tab
                ? 'bg-tac-blue text-white border-tac-blue shadow'
                : 'bg-white dark:bg-slate-900 text-[var(--Sub)] border-[var(--Bdr)]'
            }`}
          >
            {x.title}
          </button>
        ))}
      </div>
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3 mt-2">
        {sec.cards.map((c) => (
          <button
            key={c.to}
            onClick={() => navigate(c.to)}
            className="text-left bg-white dark:bg-slate-900 border border-[var(--Bdr)] rounded-2xl p-4 shadow-sm active:scale-95 transition-all"
          >
            <div className="w-11 h-11 rounded-2xl bg-tac-blue/10 text-tac-blue flex items-center justify-center">{c.icon}</div>
            <p className="mt-3 text-sm font-black text-tac-blue-dark dark:text-white leading-tight">{c.label}</p>
            <p className="text-[11px] text-[var(--Sub)] mt-0.5 leading-snug">{c.hint}</p>
          </button>
        ))}
      </div>
    </div>
  );
};
export default AdminHome;
