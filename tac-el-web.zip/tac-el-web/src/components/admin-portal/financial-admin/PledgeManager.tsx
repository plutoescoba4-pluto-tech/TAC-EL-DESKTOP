import React, { useState, useEffect } from 'react';
import { givingService, Pledge } from '../../../services/givingService';
import { Target, Plus, CheckCircle2, TrendingUp, Search } from 'lucide-react';
import { Card, Button, Badge } from '../../ui';

export const PledgeManager: React.FC = () => {
  const [pledges, setPledges] = useState<Pledge[]>([]);
  const [showAdd, setShowAdd] = useState(false);
  const [userName, setUserName] = useState('');
  const [userEmail, setUserEmail] = useState('');
  const [projectTitle, setProjectTitle] = useState('East Legon Sanctuary Completion Project');
  const [targetAmount, setTargetAmount] = useState('');
  const [dueDate, setDueDate] = useState('');
  const [saving, setSaving] = useState(false);

  const loadPledges = async () => {
    const list = await givingService.getPledges();
    setPledges(list);
  };

  useEffect(() => {
    loadPledges();
  }, []);

  const handleAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    const target = parseFloat(targetAmount);
    if (!userName.trim() || !target) return;

    setSaving(true);
    try {
      await givingService.createPledge({
        userId: 'manual',
        userName: userName.trim(),
        userEmail: userEmail.trim(),
        projectTitle,
        targetAmount: target,
        amountPaid: 0,
        dueDate: dueDate || '2026-12-31',
        status: 'active'
      });

      setUserName('');
      setUserEmail('');
      setTargetAmount('');
      setShowAdd(false);
      await loadPledges();
    } finally {
      setSaving(false);
    }
  };

  const totalPledged = pledges.reduce((a, b) => a + (b.targetAmount || 0), 0);
  const totalPaid = pledges.reduce((a, b) => a + (b.amountPaid || 0), 0);
  const fulfillmentPct = totalPledged > 0 ? Math.round((totalPaid / totalPledged) * 100) : 0;

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-xl font-black text-tac-blue-dark dark:text-white uppercase tracking-tight">
            Church Building & Project Pledges
          </h2>
          <p className="text-xs text-[var(--Sub)]">
            Manage long-term capital campaigns, member commitments, and redemption progress
          </p>
        </div>

        <Button
          variant="primary"
          onClick={() => setShowAdd(!showAdd)}
          icon={<Plus size={16} />}
        >
          {showAdd ? 'Cancel' : 'New Pledge Commitment'}
        </Button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Card className="text-center p-4">
          <span className="text-[10px] font-black uppercase text-gray-400">Total Capital Pledged</span>
          <p className="text-2xl font-black text-tac-blue mt-1">GH₵ {totalPledged.toLocaleString()}</p>
        </Card>
        <Card className="text-center p-4">
          <span className="text-[10px] font-black uppercase text-gray-400">Redeemed to Date</span>
          <p className="text-2xl font-black text-emerald-600 mt-1">GH₵ {totalPaid.toLocaleString()}</p>
        </Card>
        <Card className="text-center p-4">
          <span className="text-[10px] font-black uppercase text-gray-400">Campaign Fulfillment</span>
          <p className="text-2xl font-black text-tac-blue-dark dark:text-white mt-1">{fulfillmentPct}%</p>
        </Card>
      </div>

      {showAdd && (
        <Card className="animate-fadeIn border-tac-blue">
          <h3 className="text-sm font-black uppercase tracking-wider text-tac-blue-dark dark:text-white mb-4">
            Record Member Pledge
          </h3>

          <form onSubmit={handleAdd} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
                  Member / Donor Name
                </label>
                <input
                  type="text"
                  required
                  value={userName}
                  onChange={(e) => setUserName(e.target.value)}
                  placeholder="e.g. Deacon Emmanuel Darko"
                  className="w-full px-4 py-2.5 bg-gray-50 dark:bg-slate-800 border border-[var(--Bdr)] rounded-2xl text-sm font-bold outline-none"
                />
              </div>

              <div>
                <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
                  Email / Contact
                </label>
                <input
                  type="email"
                  value={userEmail}
                  onChange={(e) => setUserEmail(e.target.value)}
                  placeholder="e.g. e.darko@gmail.com"
                  className="w-full px-4 py-2.5 bg-gray-50 dark:bg-slate-800 border border-[var(--Bdr)] rounded-2xl text-sm outline-none"
                />
              </div>

              <div>
                <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
                  Target Pledge Amount (GH₵)
                </label>
                <input
                  type="number"
                  required
                  value={targetAmount}
                  onChange={(e) => setTargetAmount(e.target.value)}
                  placeholder="e.g. 5000"
                  className="w-full px-4 py-2.5 bg-gray-50 dark:bg-slate-800 border border-[var(--Bdr)] rounded-2xl text-sm font-bold outline-none"
                />
              </div>

              <div>
                <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
                  Target Redemption Date
                </label>
                <input
                  type="date"
                  value={dueDate}
                  onChange={(e) => setDueDate(e.target.value)}
                  className="w-full px-4 py-2.5 bg-gray-50 dark:bg-slate-800 border border-[var(--Bdr)] rounded-2xl text-sm outline-none min-w-0 max-w-full box-border"
                />
              </div>
            </div>

            <div className="flex justify-end gap-3 pt-2">
              <Button type="button" variant="ghost" onClick={() => setShowAdd(false)}>
                Cancel
              </Button>
              <Button type="submit" variant="primary" loading={saving}>
                Save Pledge Record
              </Button>
            </div>
          </form>
        </Card>
      )}

      <Card>
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-xs font-black uppercase tracking-wider text-tac-blue-dark dark:text-white">
            Pledge Commitments ({pledges.length} Donors)
          </h3>
          <Badge variant="blue">Building Fund</Badge>
        </div>

        <div className="divide-y divide-[var(--Bdr)]">
          {pledges.length === 0 ? (
            <p className="py-8 text-center text-xs text-[var(--Sub)]">
              No pledge commitments on record.
            </p>
          ) : (
            pledges.map((p) => {
              const progress = Math.min(100, Math.round(((p.amountPaid || 0) / p.targetAmount) * 100));
              return (
                <div key={p.id} className="py-4 space-y-2">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-bold text-xs text-tac-blue-dark dark:text-white uppercase">{p.userName}</h4>
                      <p className="text-[10px] text-gray-400">Due: {p.dueDate}</p>
                    </div>
                    <div className="text-right">
                      <span className="font-mono font-black text-xs text-tac-blue">
                        GH₵ {(p.amountPaid || 0).toLocaleString()} / {p.targetAmount.toLocaleString()}
                      </span>
                      <span className="block text-[10px] text-emerald-600 font-bold">{progress}% Paid</span>
                    </div>
                  </div>
                  <div className="w-full h-2 bg-gray-100 dark:bg-white/10 rounded-full overflow-hidden">
                    <div className="h-full bg-emerald-500 rounded-full" style={{ width: `${progress}%` }} />
                  </div>
                </div>
              );
            })
          )}
        </div>
      </Card>
    </div>
  );
};
export default PledgeManager;
