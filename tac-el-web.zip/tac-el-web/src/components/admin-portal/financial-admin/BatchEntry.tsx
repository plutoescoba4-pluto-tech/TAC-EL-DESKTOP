import React, { useState } from 'react';
import { givingService } from '../../../services/givingService';
import { Plus, Trash2, Save, CheckCircle2, DollarSign } from 'lucide-react';
import { Card, Button, Badge } from '../../ui';

interface BatchRow {
  id: string;
  name: string;
  kinId: string;
  amount: string;
  type: 'tithe' | 'offering' | 'welfare' | 'pledge';
}

export const BatchEntry: React.FC = () => {
  const [rows, setRows] = useState<BatchRow[]>([
    { id: '1', name: '', kinId: '', amount: '', type: 'tithe' }
  ]);
  const [saving, setSaving] = useState(false);
  const [success, setSuccess] = useState(false);

  const addRow = () => {
    setRows([...rows, { id: String(Date.now()), name: '', kinId: '', amount: '', type: 'tithe' }]);
  };

  const removeRow = (id: string) => {
    if (rows.length > 1) {
      setRows(rows.filter(r => r.id !== id));
    }
  };

  const updateRow = (id: string, field: keyof BatchRow, val: string) => {
    setRows(rows.map(r => r.id === id ? { ...r, [field]: val } : r));
  };

  const handleSaveBatch = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      for (const row of rows) {
        const num = parseFloat(row.amount);
        if (num > 0) {
          await givingService.recordDonation({
            userId: row.kinId || 'cash-collection',
            userName: row.name || 'Anonymous Cash Offering',
            amount: num,
            type: row.type as any,
            date: new Date().toLocaleDateString('en-GB')
          });
        }
      }
      setSuccess(true);
      setRows([{ id: '1', name: '', kinId: '', amount: '', type: 'tithe' }]);
      setTimeout(() => setSuccess(false), 3000);
    } finally {
      setSaving(false);
    }
  };

  const totalBatch = rows.reduce((acc, r) => acc + (parseFloat(r.amount) || 0), 0);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-xl font-black text-tac-blue-dark dark:text-white uppercase tracking-tight">
            Batch Tithe & Offering Counter
          </h2>
          <p className="text-xs text-[var(--Sub)]">
            High-speed batch entry for Sunday envelope collections and cash counts
          </p>
        </div>

        <div className="bg-tac-blue/10 px-4 py-2 rounded-2xl">
          <span className="text-[10px] font-black uppercase text-tac-blue block">Batch Total</span>
          <span className="text-xl font-black text-tac-blue-dark dark:text-white">GH₵ {totalBatch.toFixed(2)}</span>
        </div>
      </div>

      {success && (
        <div className="p-4 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 rounded-2xl flex items-center gap-2 text-emerald-600 dark:text-emerald-400 text-xs font-bold animate-fadeIn">
          <CheckCircle2 size={16} />
          Batch intake successfully processed and added to treasury ledger!
        </div>
      )}

      <Card>
        <form onSubmit={handleSaveBatch} className="space-y-4">
          <div className="space-y-3">
            {rows.map((row, idx) => (
              <div key={row.id} className="flex flex-wrap sm:flex-nowrap items-center gap-3 p-3 bg-gray-50 dark:bg-white/5 rounded-2xl border border-[var(--Bdr)]">
                <span className="text-xs font-mono font-bold text-gray-400 w-6">#{idx + 1}</span>

                <input
                  type="text"
                  placeholder="Member Name (or Cash)"
                  value={row.name}
                  onChange={(e) => updateRow(row.id, 'name', e.target.value)}
                  className="flex-1 min-w-[140px] px-3 py-2 bg-white dark:bg-slate-900 border border-[var(--Bdr)] rounded-xl text-xs font-bold outline-none"
                />

                <input
                  type="text"
                  placeholder="TAC ID (Optional)"
                  value={row.kinId}
                  onChange={(e) => updateRow(row.id, 'kinId', e.target.value.toUpperCase())}
                  className="w-32 px-3 py-2 bg-white dark:bg-slate-900 border border-[var(--Bdr)] rounded-xl text-xs font-mono uppercase outline-none"
                />

                <select
                  value={row.type}
                  onChange={(e) => updateRow(row.id, 'type', e.target.value)}
                  className="w-28 px-3 py-2 bg-white dark:bg-slate-900 border border-[var(--Bdr)] rounded-xl text-xs font-bold outline-none uppercase"
                >
                  <option value="tithe">Tithe</option>
                  <option value="offering">Offering</option>
                  <option value="welfare">Welfare</option>
                  <option value="pledge">Pledge</option>
                </select>

                <input
                  type="number"
                  step="any"
                  required
                  placeholder="GH₵ 0.00"
                  value={row.amount}
                  onChange={(e) => updateRow(row.id, 'amount', e.target.value)}
                  className="w-28 px-3 py-2 bg-white dark:bg-slate-900 border border-[var(--Bdr)] rounded-xl text-xs font-mono font-bold outline-none"
                />

                <button
                  type="button"
                  onClick={() => removeRow(row.id)}
                  className="p-2 text-gray-400 hover:text-red-500 rounded-lg"
                >
                  <Trash2 size={16} />
                </button>
              </div>
            ))}
          </div>

          <div className="flex justify-between items-center pt-2">
            <Button type="button" variant="outline" size="sm" onClick={addRow} icon={<Plus size={14} />}>
              Add Another Line
            </Button>

            <Button type="submit" variant="primary" loading={saving} icon={<Save size={16} />}>
              Save Batch Collection
            </Button>
          </div>
        </form>
      </Card>
    </div>
  );
};
export default BatchEntry;
