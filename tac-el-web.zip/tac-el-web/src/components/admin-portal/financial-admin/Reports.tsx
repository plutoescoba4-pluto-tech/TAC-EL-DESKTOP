import React from 'react';
import FinanceReports from '../../office-portal/treasurer/FinanceReports';

export const Reports: React.FC = () => {
  return <FinanceReports />;
};
export default Reports;
