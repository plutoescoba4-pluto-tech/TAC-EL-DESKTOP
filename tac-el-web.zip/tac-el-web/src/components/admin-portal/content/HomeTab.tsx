import React, { useRef, useState } from 'react';
import { ArrowUp, ArrowDown, Plus } from 'lucide-react';
import {
  Card, DeleteBtn, GhostBtn, ImageField, Notify, PrimaryBtn, Switch, TextField, errText, hintCls, inputCls, isHttps, labelCls, uploadImage, useSetting, MAX_BYTES,
} from './websiteShared';

/**
 * Admin > Website > Home page
 *   Slideshow (website_background + hero_settings), Welcome picture (welcome),
 *   Pastor's welcome (pastor_welcome), Watch online (watch_online).
 * Everything here is optional: a section hides itself on the website until it is filled in.
 */

/* ------------------------------------------------------------------ slideshow */
interface HeroSlide { id: string; imageUrl: string; mobileImageUrl?: string; caption?: string; linkUrl?: string; linkLabel?: string; active: boolean }
interface HeroSettings { interval_seconds: number; effect: 'fade' | 'slide' | 'zoom'; overlay: number; show_dots: boolean; show_arrows: boolean }
const DEFAULT_HERO: HeroSettings = { interval_seconds: 5, effect: 'fade', overlay: 0, show_dots: true, show_arrows: true };
const newId = () => (crypto as any).randomUUID?.() ?? `s-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;

const Slideshow: React.FC<{ notify: Notify }> = ({ notify }) => {
  const slides = useSetting<HeroSlide[]>('website_background', []);
  const settings = useSetting<HeroSettings>('hero_settings', DEFAULT_HERO);
  const [adding, setAdding] = useState<string | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  const list = slides.value;
  const set = (next: HeroSlide[]) => slides.update(next);
  const patch = (i: number, p: Partial<HeroSlide>) => set(list.map((s, k) => (k === i ? { ...s, ...p } : s)));
  const move = (i: number, d: number) => {
    const j = i + d; if (j < 0 || j >= list.length) return;
    const next = [...list]; [next[i], next[j]] = [next[j], next[i]]; set(next);
  };

  const addFiles = async (files: FileList | null) => {
    if (!files?.length) return;
    const added: HeroSlide[] = [];
    try {
      const arr = Array.from(files);
      for (let i = 0; i < arr.length; i++) {
        const f = arr[i];
        if (!f.type.startsWith('image/')) { notify({ type: 'err', text: `"${f.name}" is not a picture, so it was skipped.` }); continue; }
        if (f.size > MAX_BYTES) { notify({ type: 'err', text: `"${f.name}" is bigger than 25 MB, so it was skipped.` }); continue; }
        setAdding(`Uploading ${i + 1} of ${arr.length}…`);
        added.push({ id: newId(), imageUrl: await uploadImage(f, 'hero', { maxW: 1600, maxH: 1200 }), active: true });
      }
      if (added.length) set([...list, ...added]);
    } catch (e: any) { notify({ type: 'err', text: errText(e) }); }
    setAdding(null);
    if (fileRef.current) fileRef.current.value = '';
  };

  const saveSlides = () => {
    const bad = list.find((s) => !s.imageUrl || !isHttps(s.linkUrl || '') || !isHttps(s.mobileImageUrl || ''));
    if (bad) return notify({ type: 'err', text: 'Every slide needs a picture, and links must start with https://' });
    // empty optional fields are left out so the website treats them as "not set"
    const clean = list.map((s) => {
      const o: any = { id: s.id, imageUrl: s.imageUrl, active: s.active !== false };
      if (s.mobileImageUrl) o.mobileImageUrl = s.mobileImageUrl;
      if (s.caption?.trim()) o.caption = s.caption.trim();
      if (s.linkUrl?.trim()) { o.linkUrl = s.linkUrl.trim(); if (s.linkLabel?.trim()) o.linkLabel = s.linkLabel.trim(); }
      return o as HeroSlide;
    });
    slides.save(notify, 'The slideshow', clean);
  };

  const hs = settings.value;
  const upd = (p: Partial<HeroSettings>) => settings.update({ ...hs, ...p });

  return (
    <div className="space-y-4">
      <Card title="Slideshow pictures" hint="These roll on the website's home page. The order below is the order on the website. Wide pictures work best (the website shows them in an arch, about 4:3). Pictures are shrunk automatically before they are uploaded.">
        <input ref={fileRef} type="file" accept="image/*" multiple hidden onChange={(e) => addFiles(e.target.files)} />
        <div className="flex flex-wrap items-center gap-3 mb-4">
          <button type="button" onClick={() => fileRef.current?.click()} disabled={!!adding}
            className="px-4 py-2.5 rounded-xl border-2 border-dashed border-[var(--Bdr)] text-xs font-black uppercase tracking-widest text-tac-blue inline-flex items-center gap-2 disabled:opacity-50">
            <Plus size={14} /> {adding || 'Add pictures'}
          </button>
          {slides.dirty && <span className="text-[11px] font-black uppercase tracking-widest text-amber-600">Unsaved changes</span>}
        </div>

        {slides.loading ? <p className="text-xs text-gray-400">Loading…</p> : list.length === 0 ? (
          <p className="text-xs text-gray-400">No slides yet. The website shows its default pictures, then the logo.</p>
        ) : list.map((s, i) => (
          <div key={s.id} className="rounded-2xl border border-[var(--Bdr)] p-4 mb-3">
            <div className="flex items-center justify-between gap-2 mb-3">
              <p className="text-[11px] font-black uppercase tracking-widest text-gray-400">Slide {i + 1}</p>
              <div className="flex items-center gap-1">
                <button type="button" className="p-2 rounded-lg border border-[var(--Bdr)]" onClick={() => move(i, -1)} title="Move earlier"><ArrowUp size={14} /></button>
                <button type="button" className="p-2 rounded-lg border border-[var(--Bdr)]" onClick={() => move(i, 1)} title="Move later"><ArrowDown size={14} /></button>
                <Switch on={s.active !== false} onChange={(on) => patch(i, { active: on })} label="Showing" />
                <DeleteBtn onClick={() => { if (window.confirm('Remove this slide?')) set(list.filter((_, k) => k !== i)); }} />
              </div>
            </div>
            <div className="grid sm:grid-cols-2 gap-x-4">
              <ImageField label="Computer picture (required)" value={s.imageUrl} folder="hero" notify={notify} maxW={1600} maxH={1200} onChange={(url) => patch(i, { imageUrl: url })} hint="Best around 1600 × 1200." />
              <ImageField label="Phone picture (optional, tall)" value={s.mobileImageUrl || ''} folder="hero" notify={notify} maxW={900} maxH={1100} onChange={(url) => patch(i, { mobileImageUrl: url })} hint="Used on phones. Best around 900 × 1100." />
            </div>
            <TextField label="Caption (optional)" value={s.caption || ''} onChange={(v) => patch(i, { caption: v })} placeholder="Sunday Worship, all are welcome" />
            <div className="grid sm:grid-cols-2 gap-x-4">
              <TextField label="Button link (optional)" value={s.linkUrl || ''} onChange={(v) => patch(i, { linkUrl: v })} placeholder="https://..." />
              <TextField label="Button words" value={s.linkLabel || ''} onChange={(v) => patch(i, { linkLabel: v })} placeholder="Plan a visit" />
            </div>
          </div>
        ))}
        {list.length > 0 && <PrimaryBtn onClick={saveSlides} busy={slides.saving}>Save slideshow</PrimaryBtn>}
      </Card>

      <Card title="Slideshow style" hint="How the pictures change.">
        <div className="grid sm:grid-cols-2 gap-x-4">
          <div className="mb-3">
            <label className={labelCls}>Seconds per picture (2 to 20)</label>
            <input type="number" min={2} max={20} className={inputCls} value={hs.interval_seconds} onChange={(e) => upd({ interval_seconds: Math.min(20, Math.max(2, parseInt(e.target.value, 10) || 5)) })} />
          </div>
          <div className="mb-3">
            <label className={labelCls}>Effect</label>
            <select className={inputCls} value={hs.effect} onChange={(e) => upd({ effect: e.target.value as HeroSettings['effect'] })}>
              <option value="fade">Fade</option><option value="slide">Slide</option><option value="zoom">Slow zoom</option>
            </select>
          </div>
        </div>
        <div className="mb-3">
          <label className={labelCls}>Darkness over the pictures: {hs.overlay}%</label>
          <input type="range" min={0} max={70} step={5} className="w-full accent-[#1B3F8B]" value={hs.overlay} onChange={(e) => upd({ overlay: parseInt(e.target.value, 10) })} />
          <p className={hintCls}>0 = none. A little darkness makes white captions easier to read.</p>
        </div>
        <div className="flex gap-6 mb-4">
          <Switch on={hs.show_dots} onChange={(v) => upd({ show_dots: v })} label="Dots" />
          <Switch on={hs.show_arrows} onChange={(v) => upd({ show_arrows: v })} label="Arrows" />
        </div>
        <PrimaryBtn onClick={() => settings.save(notify, 'The slideshow style')} busy={settings.saving}>Save style</PrimaryBtn>
      </Card>
    </div>
  );
};

/* ------------------------------------------------------------------- welcome picture */
const WelcomePicture: React.FC<{ notify: Notify }> = ({ notify }) => {
  const w = useSetting<{ image_url: string }>('welcome', { image_url: '' });
  return (
    <Card title="Welcome picture" hint={'The photo inside the arch in the "New to TAC East Legon?" section of the home page.'}>
      <ImageField label="Picture" value={w.value.image_url} folder="hero" notify={notify} maxW={1200} maxH={1500} onChange={(url) => w.update({ image_url: url })} hint="A warm photo of people at church works best." />
      <PrimaryBtn onClick={() => w.save(notify, 'The welcome picture')} busy={w.saving} disabled={!w.dirty}>Save</PrimaryBtn>
    </Card>
  );
};

/* --------------------------------------------------------------- pastor's welcome */
const PastorWelcome: React.FC<{ notify: Notify }> = ({ notify }) => {
  const p = useSetting<{ name: string; title: string; photo_url: string; message: string }>('pastor_welcome', { name: '', title: '', photo_url: '', message: '' });
  const v = p.value;
  const set = (patch: Partial<typeof v>) => p.update({ ...v, ...patch });
  return (
    <Card title="A word of welcome" hint="Shown on the home page. This section stays hidden until you write a message.">
      <ImageField label="Photo" value={v.photo_url} folder="leaders" notify={notify} round maxW={900} maxH={1100} onChange={(url) => set({ photo_url: url })} />
      <div className="grid sm:grid-cols-2 gap-x-4">
        <TextField label="Name" value={v.name} onChange={(x) => set({ name: x })} />
        <TextField label="Title" value={v.title} onChange={(x) => set({ title: x })} placeholder="Resident Pastor" />
      </div>
      <TextField label="Message" value={v.message} onChange={(x) => set({ message: x })} multiline rows={8} hint="Leave an empty line to start a new paragraph." />
      <PrimaryBtn onClick={() => p.save(notify, "The pastor's welcome")} busy={p.saving} disabled={!p.dirty}>Save</PrimaryBtn>
    </Card>
  );
};

/* ------------------------------------------------------------------- watch online */
const WatchOnline: React.FC<{ notify: Notify }> = ({ notify }) => {
  const w = useSetting<{ video_url: string; youtube_url: string; facebook_url: string }>('watch_online', { video_url: '', youtube_url: '', facebook_url: '' });
  const v = w.value;
  const set = (patch: Partial<typeof v>) => w.update({ ...v, ...patch });
  const save = () => {
    const idOk = (x: string) => !x.trim() || /^[\w-]{11}$/.test(x.trim()) || isHttps(x);
    if (!idOk(v.video_url) || !isHttps(v.youtube_url) || !isHttps(v.facebook_url)) return notify({ type: 'err', text: 'Links must start with https:// (the video can also be just the YouTube video code).' });
    w.save(notify, 'Watch online');
  };
  return (
    <Card title="Worship with us from anywhere" hint="Shown on the home page. This section stays hidden until a video is set.">
      <TextField label="Video (YouTube link or video code)" value={v.video_url} onChange={(x) => set({ video_url: x })} placeholder="https://www.youtube.com/watch?v=..." hint="The video that plays on the home page." />
      <TextField label="Our YouTube channel (optional)" value={v.youtube_url} onChange={(x) => set({ youtube_url: x })} placeholder="https://www.youtube.com/@..." />
      <TextField label="Our Facebook page (optional)" value={v.facebook_url} onChange={(x) => set({ facebook_url: x })} placeholder="https://www.facebook.com/..." />
      <PrimaryBtn onClick={save} busy={w.saving} disabled={!w.dirty}>Save</PrimaryBtn>
    </Card>
  );
};

/* ----------------------------------------------------------------------- the tab */
type Part = 'slideshow' | 'welcome' | 'pastor' | 'watch';
const PARTS: { id: Part; label: string }[] = [
  { id: 'slideshow', label: 'Slideshow' }, { id: 'welcome', label: 'Welcome picture' }, { id: 'pastor', label: "Pastor's welcome" }, { id: 'watch', label: 'Watch online' },
];

export const HomeTab: React.FC<{ notify: Notify }> = ({ notify }) => {
  const [part, setPart] = useState<Part>('slideshow');
  return (
    <div className="space-y-4">
      <div className="flex gap-2 overflow-x-auto pb-1">
        {PARTS.map((p) => (
          <button key={p.id} type="button" onClick={() => setPart(p.id)}
            className={`shrink-0 px-3 py-1.5 rounded-full text-[10px] font-black uppercase tracking-wider border ${part === p.id ? 'bg-tac-blue/10 text-tac-blue border-tac-blue/40' : 'border-[var(--Bdr)] text-gray-400'}`}>{p.label}</button>
        ))}
      </div>
      {part === 'slideshow' && <Slideshow notify={notify} />}
      {part === 'welcome' && <WelcomePicture notify={notify} />}
      {part === 'pastor' && <PastorWelcome notify={notify} />}
      {part === 'watch' && <WatchOnline notify={notify} />}
    </div>
  );
};

export default HomeTab;
