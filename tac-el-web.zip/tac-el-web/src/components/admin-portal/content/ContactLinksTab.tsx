import React, { useState } from 'react';
import { Card, ImageField, Notify, PrimaryBtn, TextField, extractMapSrc, hintCls, isHttps, useSetting } from './websiteShared';

/**
 * Admin > Website > Contact & links
 *   contact_info (address, phone, email, WhatsApp, map), service_times, social_links, about_content,
 *   branding (logo), app_links (Get buttons).
 */

/* ----------------------------------------------------------------------------- contact */
interface ContactInfo { location: string; phone: string; email: string; whatsapp: string; map_embed_url: string; map_link: string }
const EMPTY_CONTACT: ContactInfo = { location: '', phone: '', email: '', whatsapp: '', map_embed_url: '', map_link: '' };

const ContactCard: React.FC<{ notify: Notify }> = ({ notify }) => {
  const c = useSetting<ContactInfo>('contact_info', EMPTY_CONTACT);
  const v = c.value;
  const [mapText, setMapText] = useState<string | null>(null);        // what the admin pasted (may be the whole <iframe> code)
  const set = (p: Partial<ContactInfo>) => c.update({ ...v, ...p });

  const pasteMap = (text: string) => {
    setMapText(text);
    const src = extractMapSrc(text);
    if (src !== null) set({ map_embed_url: src });
  };
  const mapProblem = mapText !== null && mapText.trim() !== '' && extractMapSrc(mapText) === null;

  const save = () => {
    if (mapProblem) return notify({ type: 'err', text: 'The map must be a Google Maps embed (in Google Maps: Share, Embed a map, copy the code).' });
    if (!isHttps(v.map_link)) return notify({ type: 'err', text: 'The "open in Maps" link must start with https://' });
    const wa = v.whatsapp.replace(/[^\d]/g, '');
    c.save(notify, 'Contact details', { ...v, whatsapp: wa });
  };

  return (
    <Card title="Contact details" hint="Shown on the Contact page and in the footer. Empty items are hidden.">
      <TextField label="Address" value={v.location} onChange={(x) => set({ location: x })} multiline rows={2} />
      <div className="grid sm:grid-cols-3 gap-x-4">
        <TextField label="Phone" value={v.phone} onChange={(x) => set({ phone: x })} />
        <TextField label="Email" value={v.email} onChange={(x) => set({ email: x })} />
        <TextField label="WhatsApp number" value={v.whatsapp} onChange={(x) => set({ whatsapp: x })} placeholder="233240000000" hint="Digits only, with the country code (233 for Ghana), no plus sign or zero." />
      </div>
      <TextField label="Map: paste the Google Maps embed code" value={mapText ?? (v.map_embed_url ? `(saved) ${v.map_embed_url}` : '')} onChange={pasteMap} multiline rows={3}
        hint="In Google Maps: Share, then Embed a map, then Copy HTML. Paste it here." />
      {mapProblem && <p className="text-xs text-red-600 -mt-2 mb-3">That is not a Google Maps embed.</p>}
      {v.map_embed_url && !mapProblem && <iframe title="Map preview" src={v.map_embed_url} className="w-full h-44 rounded-2xl border border-[var(--Bdr)] mb-3" loading="lazy" />}
      <TextField label="Map link (the 'Get directions' button)" value={v.map_link} onChange={(x) => set({ map_link: x })} placeholder="https://maps.app.goo.gl/..." />
      <PrimaryBtn onClick={save} busy={c.saving} disabled={!c.dirty}>Save contact details</PrimaryBtn>
    </Card>
  );
};

/* ------------------------------------------------------------------------ service times */
interface TimeRow { day: string; label: string; time: string }
const TimesCard: React.FC<{ notify: Notify }> = ({ notify }) => {
  const t = useSetting<TimeRow[]>('service_times', []);
  const [text, setText] = useState<string | null>(null);
  const shown = text ?? t.value.map((r) => [r.day, r.label, r.time].join(' | ')).join('\n');
  const save = () => {
    const rows = shown.split('\n').map((l) => l.trim()).filter(Boolean).map((line) => {
      const [day, label, time] = line.split('|').map((s) => s.trim());
      return { day: day || '', label: label || '', time: time || '' };
    });
    t.save(notify, 'Service times', rows);
  };
  return (
    <Card title="Service times" hint="One per line, written as: Day | Service name | Time.   Example: Sunday | First Service | 8:00 AM">
      <textarea rows={5} className="w-full rounded-xl border border-[var(--Bdr)] bg-transparent px-3 py-2.5 text-sm mb-3" value={shown} onChange={(e) => { setText(e.target.value); t.update(t.value); }} />
      <PrimaryBtn onClick={save} busy={t.saving}>Save service times</PrimaryBtn>
    </Card>
  );
};

/* ----------------------------------------------------------------------------- social */
interface Social { facebook: string; instagram: string; tiktok: string; youtube: string; x: string; whatsapp: string }
const EMPTY_SOCIAL: Social = { facebook: '', instagram: '', tiktok: '', youtube: '', x: '', whatsapp: '' };
const SocialCard: React.FC<{ notify: Notify }> = ({ notify }) => {
  const s = useSetting<Social>('social_links', EMPTY_SOCIAL);
  const v = s.value;
  const set = (p: Partial<Social>) => s.update({ ...v, ...p });
  const save = () => {
    if (!(Object.values(v) as string[]).every(isHttps)) return notify({ type: 'err', text: 'Links must start with https://' });
    const clean = Object.fromEntries((Object.entries(v) as [string, string][]).map(([k, x]) => [k, x.trim()]).filter(([, x]) => x));
    s.save(notify, 'Social links', clean as unknown as Social);
  };
  return (
    <Card title="Social media" hint="Icons appear in the footer only for the links you fill in.">
      <div className="grid sm:grid-cols-2 gap-x-4">
        <TextField label="Facebook" value={v.facebook} onChange={(x) => set({ facebook: x })} placeholder="https://www.facebook.com/..." />
        <TextField label="Instagram" value={v.instagram} onChange={(x) => set({ instagram: x })} placeholder="https://www.instagram.com/..." />
        <TextField label="TikTok" value={v.tiktok} onChange={(x) => set({ tiktok: x })} placeholder="https://www.tiktok.com/@..." />
        <TextField label="YouTube" value={v.youtube} onChange={(x) => set({ youtube: x })} placeholder="https://www.youtube.com/@..." />
        <TextField label="X (Twitter)" value={v.x} onChange={(x) => set({ x })} placeholder="https://x.com/..." />
        <TextField label="WhatsApp channel or chat link" value={v.whatsapp} onChange={(x) => set({ whatsapp: x })} placeholder="https://wa.me/233..." />
      </div>
      <PrimaryBtn onClick={save} busy={s.saving} disabled={!s.dirty}>Save social links</PrimaryBtn>
    </Card>
  );
};

/* ------------------------------------------------------------------------------ about */
const AboutCard: React.FC<{ notify: Notify }> = ({ notify }) => {
  const a = useSetting<{ mission: string; vision: string; story: string }>('about_content', { mission: '', vision: '', story: '' });
  const v = a.value;
  const set = (p: Partial<typeof v>) => a.update({ ...v, ...p });
  return (
    <Card title="About page">
      <TextField label="Mission" value={v.mission} onChange={(x) => set({ mission: x })} multiline rows={3} />
      <TextField label="Vision" value={v.vision} onChange={(x) => set({ vision: x })} multiline rows={3} />
      <TextField label="Our story" value={v.story} onChange={(x) => set({ story: x })} multiline rows={6} hint="Leave an empty line to start a new paragraph." />
      <PrimaryBtn onClick={() => a.save(notify, 'The About page')} busy={a.saving} disabled={!a.dirty}>Save about page</PrimaryBtn>
    </Card>
  );
};

/* ------------------------------------------------------------------------------ logo */
const LogoCard: React.FC<{ notify: Notify }> = ({ notify }) => {
  const b = useSetting<{ logo_url: string }>('branding', { logo_url: '' });
  return (
    <Card title="Church logo" hint="Shown in the menu and footer. Until you add one, the website uses its own logo. A square picture with a clear background works best.">
      <ImageField label="Logo" value={b.value.logo_url} folder="branding" notify={notify} maxW={600} maxH={600} png onChange={(url) => b.update({ logo_url: url })} />
      <PrimaryBtn onClick={() => b.save(notify, 'The logo')} busy={b.saving} disabled={!b.dirty}>Save logo</PrimaryBtn>
    </Card>
  );
};

/* ------------------------------------------------------------------------- app links */
interface AppLinks { app_url: string; web_url: string; android_url: string; apk_url: string; apk_version: string; desktop_url: string; website_url: string }
const EMPTY_LINKS: AppLinks = { app_url: '', web_url: '', android_url: '', apk_url: '', apk_version: '', desktop_url: '', website_url: '' };
const AppLinksCard: React.FC<{ notify: Notify }> = ({ notify }) => {
  const l = useSetting<AppLinks>('app_links', EMPTY_LINKS);
  const v = l.value;
  const set = (p: Partial<AppLinks>) => l.update({ ...v, ...p });
  const save = () => {
    if (![v.app_url, v.web_url, v.android_url, v.apk_url, v.desktop_url, v.website_url].every(isHttps)) return notify({ type: 'err', text: 'Links must start with https://' });
    const clean = Object.fromEntries((Object.entries(v) as [string, string][]).map(([k, x]) => [k, x.trim()]));
    l.save(notify, 'App links', clean as unknown as AppLinks);
  };
  return (
    <Card title="App links (the Get buttons on the website)" hint="Each button on the Android, iPhone and Computer pages switches on by itself when you save its link here. Links must start with https://">
      <TextField label="TAC-EL phone app address (opened by the iPhone Get button)" value={v.app_url} onChange={(x) => set({ app_url: x })} placeholder="https://tac-el-app.netlify.app" />
      <TextField label="TAC-EL Web address (opened by the computer 'use it in your browser' button)" value={v.web_url} onChange={(x) => set({ web_url: x })} placeholder="https://tac-el-web.netlify.app" />
      <TextField label="Google Play link (leave empty until it is published)" value={v.android_url} onChange={(x) => set({ android_url: x })} placeholder="https://play.google.com/store/apps/details?id=..." />
      <TextField label="Direct download link for the Android app file (APK)" value={v.apk_url} onChange={(x) => set({ apk_url: x })} placeholder="https://.../tac-el.apk" />
      <TextField label="APK version note (optional)" value={v.apk_version} onChange={(x) => set({ apk_version: x })} placeholder="Version 1.0 · 24 MB" />
      <TextField label="Desktop app download link" value={v.desktop_url} onChange={(x) => set({ desktop_url: x })} placeholder="https://.../TAC-EL-Setup.exe" />
      <TextField label="The website's own address (for the 'Open the website' shortcuts here)" value={v.website_url} onChange={(x) => set({ website_url: x })} placeholder="https://tac-el-site.netlify.app" />
      <PrimaryBtn onClick={save} busy={l.saving} disabled={!l.dirty}>Save app links</PrimaryBtn>
      {v.website_url && (
        <p className={`${hintCls} mt-3`}>
          <a className="text-tac-blue font-bold" href={v.website_url} target="_blank" rel="noreferrer">Open the website</a>
          {' · '}
          <a className="text-tac-blue font-bold" href={`${v.website_url.replace(/\/+$/, '')}/?demo=1`} target="_blank" rel="noreferrer">See it with sample content</a>
        </p>
      )}
    </Card>
  );
};

export const ContactLinksTab: React.FC<{ notify: Notify }> = ({ notify }) => (
  <div className="space-y-4">
    <ContactCard notify={notify} />
    <TimesCard notify={notify} />
    <SocialCard notify={notify} />
    <AboutCard notify={notify} />
    <LogoCard notify={notify} />
    <AppLinksCard notify={notify} />
  </div>
);

export default ContactLinksTab;
