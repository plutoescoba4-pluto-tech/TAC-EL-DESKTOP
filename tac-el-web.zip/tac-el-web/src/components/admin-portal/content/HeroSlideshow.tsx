import React from 'react';
import SiteSettings from '../../sections/SiteSettings';

/**
 * Admin > Hero used to be a demo page with stock photos that were never saved.
 * The real homepage slideshow is managed in Site Settings (upload a picture, remove a picture),
 * so this page now opens that screen.
 */
export const HeroSlideshow: React.FC = () => <SiteSettings />;
export default HeroSlideshow;
