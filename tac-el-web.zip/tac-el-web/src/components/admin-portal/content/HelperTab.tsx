import React from 'react';
import { ArrowUp, ArrowDown, Plus } from 'lucide-react';
import { Card, DeleteBtn, GhostBtn, Notify, PrimaryBtn, TextField, useSetting } from './websiteShared';

/**
 * Admin > Website > Helper
 * The answers the website's little help bubble gives to visitors. A visitor's question is matched against the
 * keywords. Leave it empty to keep the website's built-in answers.
 */
interface Faq { keywords: string[]; question: string; answer: string }
const MAX_FAQ = 60;

export const HelperTab: React.FC<{ notify: Notify }> = ({ notify }) => {
  const f = useSetting<Faq[]>('kin_faq', []);
  const list = f.value;
  const patch = (i: number, p: Partial<Faq>) => f.update(list.map((x, k) => (k === i ? { ...x, ...p } : x)));
  const move = (i: number, d: number) => {
    const j = i + d; if (j < 0 || j >= list.length) return;
    const next = [...list]; [next[i], next[j]] = [next[j], next[i]]; f.update(next);
  };
  const save = () => {
    const clean = list
      .map((x) => ({ keywords: x.keywords.map((k) => k.trim().toLowerCase()).filter(Boolean), question: x.question.trim(), answer: x.answer.trim() }))
      .filter((x) => x.answer);
    if (clean.some((x) => !x.keywords.length)) return notify({ type: 'err', text: 'Every answer needs at least one keyword.' });
    f.save(notify, 'The helper answers', clean);
  };

  return (
    <div className="space-y-4">
      <Card title="Helper answers" hint="When a visitor asks the helper something, it looks for these keywords in their words and replies with the matching answer. Example: keywords 'service, time, when' and the answer 'We worship on Sundays at...'.">
        {f.loading ? <p className="text-xs text-gray-400">Loading…</p> : list.length === 0 ? <p className="text-xs text-gray-400 mb-3">None yet, so the website uses its built-in answers.</p> : list.map((x, i) => (
          <div key={i} className="rounded-2xl border border-[var(--Bdr)] p-3 mb-3">
            <div className="flex items-center justify-between mb-2">
              <span className="text-[11px] font-black uppercase tracking-widest text-gray-400">Answer {i + 1}</span>
              <div className="flex items-center gap-1">
                <button type="button" className="p-1.5 rounded-lg border border-[var(--Bdr)]" onClick={() => move(i, -1)}><ArrowUp size={13} /></button>
                <button type="button" className="p-1.5 rounded-lg border border-[var(--Bdr)]" onClick={() => move(i, 1)}><ArrowDown size={13} /></button>
                <DeleteBtn onClick={() => f.update(list.filter((_, k) => k !== i))} />
              </div>
            </div>
            <TextField label="Keywords (separate with commas)" value={x.keywords.join(', ')} onChange={(v) => patch(i, { keywords: v.split(',') })} placeholder="service, time, when" />
            <TextField label="The question (for your own reference)" value={x.question} onChange={(v) => patch(i, { question: v })} />
            <TextField label="Answer" value={x.answer} onChange={(v) => patch(i, { answer: v })} multiline rows={3} />
          </div>
        ))}
        <div className="flex flex-wrap items-center gap-3">
          <GhostBtn onClick={() => { if (list.length >= MAX_FAQ) return notify({ type: 'err', text: `At most ${MAX_FAQ} answers.` }); f.update([...list, { keywords: [], question: '', answer: '' }]); }}>
            <Plus size={12} className="inline -mt-0.5" /> Add an answer
          </GhostBtn>
          <PrimaryBtn onClick={save} busy={f.saving}>Save helper answers</PrimaryBtn>
          {f.dirty && <span className="text-[11px] font-black uppercase tracking-widest text-amber-600">Unsaved changes</span>}
        </div>
      </Card>
    </div>
  );
};

export default HelperTab;
