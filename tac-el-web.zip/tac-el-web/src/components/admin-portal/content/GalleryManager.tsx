import React from 'react';
import GalleryView from '../../sections/GalleryView';

/**
 * Admin > Gallery used to be a demo page with made-up photos that never touched the database.
 * It now opens the real church gallery (the same photos members see). Admins get the
 * upload button and a delete button on every photo there.
 */
export const GalleryManager: React.FC = () => <GalleryView />;
export default GalleryManager;
