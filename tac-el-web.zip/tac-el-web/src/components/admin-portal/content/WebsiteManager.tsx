import React, { useCallback, useEffect, useRef, useState } from 'react';
import { supabase } from '../../../supabase';
import { Card, Button } from '../../ui';
import { Globe, Trash2, Upload, X, ArrowUp, ArrowDown, RefreshCw } from 'lucide-react';
import { SITE_TEXT_REGISTRY } from './websiteTextRegistry';
import { HomeTab } from './HomeTab';
import { NewHereTab } from './NewHereTab';
import { GivingTab } from './GivingTab';
import { HelperTab } from './HelperTab';
import { ContactLinksTab } from './ContactLinksTab';
import { inputCls, labelCls, hintCls, errText, uploadImage, getSetting, setSetting, Switch, ImagePicker, Row, DeleteBtn, Notice, Notify, Picked } from './websiteShared';

/**
 * Admin > Website
 *
 * Controls what the PUBLIC website shows. The church app and the website share one
 * database; nothing from the app appears on the website by itself. Each club, event,
 * sermon and photo has an "On website" switch, and the rest of the website (leaders,
 * rolling background, wording, contact details) is edited here.
 *
 * The admin is already signed in, so every save goes through the normal admin rules in
 * the database (no separate login, no open access).
 */

type Tab = 'clubs' | 'events' | 'sermons' | 'gallery' | 'leadership' | 'home' | 'newhere' | 'giving' | 'contact' | 'helper' | 'text' | 'messages';
const TABS: { id: Tab; label: string }[] = [
  { id: 'home', label: 'Home page' },
  { id: 'newhere', label: "I'm New" },
  { id: 'giving', label: 'Giving' },
  { id: 'contact', label: 'Contact & links' },
  { id: 'clubs', label: 'Clubs' },
  { id: 'events', label: 'Events' },
  { id: 'sermons', label: 'Sermons' },
  { id: 'gallery', label: 'Gallery' },
  { id: 'leadership', label: 'Leadership' },
  { id: 'helper', label: 'Helper' },
  { id: 'text', label: 'Wording' },
  { id: 'messages', label: 'Messages' },
];

// Which column means "shown on the website" for each table.
const SHOW_COLUMN: Record<string, string> = {
  clubs: 'is_public',
  events: 'show_on_website',
  sermons: 'show_on_website',
  gallery_photos: 'show_on_website',
  leadership: 'is_active',
};

function useRows<T = any>(table: string, query: (q: any) => any, deps: any[] = []) {
  const [rows, setRows] = useState<T[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const reload = useCallback(async () => {
    setLoading(true);
    const { data, error } = await query(supabase.from(table));
    if (error) setError(errText(error)); else { setError(null); setRows((data as T[]) ?? []); }
    setLoading(false);
  }, [table, ...deps]); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => { reload(); }, [reload]);
  return { rows, loading, error, reload };
}

async function setShown(table: string, id: string, shown: boolean) {
  const { error } = await supabase.from(table).update({ [SHOW_COLUMN[table]]: shown }).eq('id', id);
  if (error) throw error;
}
async function deleteRow(table: string, id: string) {
  const { error } = await supabase.from(table).delete().eq('id', id);
  if (error) throw error;
}

/* ------------------------------------------------------------------- tabs */

// ---- Clubs / Events / Sermons: switch on the ones to show, plus add new ones from here
interface FieldDef { name: string; label: string; type?: 'text' | 'textarea' | 'datetime-local' | 'date'; required?: boolean }
interface ContentCfg {
  table: string; title: string; hint: string; fields: FieldDef[]; addLabel: string;
  order: (q: any) => any; makeRow: (v: Record<string, string>, show: boolean) => Record<string, any>;
  row: (r: any) => { title: string; sub: string };
}
const CONTENT: Record<'clubs' | 'events' | 'sermons', ContentCfg> = {
  clubs: {
    table: 'clubs', title: 'All clubs (church app)', addLabel: 'Add a club',
    hint: 'Switch ON to show a club on the website. Clubs created in the app stay hidden until you do.',
    fields: [{ name: 'name', label: 'Club name', required: true }, { name: 'meeting_time', label: 'Meeting time' }, { name: 'description', label: 'Description', type: 'textarea' }],
    order: (q) => q.select('*').order('name'),
    makeRow: (v, show) => ({ name: v.name, meeting_time: v.meeting_time, description: v.description, is_public: show }),
    row: (r) => ({ title: r.name, sub: r.meeting_time || '' }),
  },
  events: {
    table: 'events', title: 'All events (church app)', addLabel: 'Add an event',
    hint: 'Only events switched ON appear on the website.',
    fields: [{ name: 'title', label: 'Event title', required: true }, { name: 'starts_at', label: 'Date and time', type: 'datetime-local' }, { name: 'location', label: 'Location' }, { name: 'description', label: 'Details', type: 'textarea' }],
    order: (q) => q.select('*').order('starts_at', { ascending: false }),
    makeRow: (v, show) => ({ title: v.title, starts_at: v.starts_at ? new Date(v.starts_at).toISOString() : new Date().toISOString(), location: v.location, description: v.description, show_on_website: show }),
    row: (r) => ({ title: r.title, sub: r.starts_at ? new Date(r.starts_at).toLocaleString() : '' }),
  },
  sermons: {
    table: 'sermons', title: 'All sermons (church app)', addLabel: 'Add a sermon',
    hint: 'Only sermons switched ON appear on the website.',
    fields: [{ name: 'title', label: 'Sermon title', required: true }, { name: 'speaker', label: 'Preacher' }, { name: 'audio_url', label: 'Audio link (optional)' }, { name: 'preached_at', label: 'Date', type: 'date' }],
    order: (q) => q.select('*').order('preached_at', { ascending: false }),
    makeRow: (v, show) => ({ title: v.title, speaker: v.speaker, audio_url: v.audio_url, preached_at: v.preached_at || new Date().toISOString(), show_on_website: show }),
    row: (r) => ({ title: r.title, sub: r.speaker || '' }),
  },
};

const ContentTab: React.FC<{ kind: keyof typeof CONTENT; notify: Notify }> = ({ kind, notify }) => {
  const cfg = CONTENT[kind];
  const { rows, loading, error, reload } = useRows<any>(cfg.table, cfg.order, [kind]);
  const [values, setValues] = useState<Record<string, string>>({});
  const [showNow, setShowNow] = useState(true);
  const [busy, setBusy] = useState(false);
  const col = SHOW_COLUMN[cfg.table];

  const add = async () => {
    const missing = cfg.fields.find((f) => f.required && !(values[f.name] || '').trim());
    if (missing) return notify({ type: 'err', text: `Enter the ${missing.label.toLowerCase()}.` });
    setBusy(true);
    const { error } = await supabase.from(cfg.table).insert(cfg.makeRow(values, showNow));
    setBusy(false);
    if (error) return notify({ type: 'err', text: errText(error) });
    setValues({}); notify({ type: 'ok', text: 'Added.' }); reload();
  };
  const toggle = async (r: any, on: boolean) => {
    try { await setShown(cfg.table, r.id, on); reload(); } catch (e) { notify({ type: 'err', text: errText(e) }); }
  };
  const del = async (r: any) => {
    if (!window.confirm('DELETE this for good?\n\nThis removes it from the church app AND the website. To only hide it from the website, use the switch instead.')) return;
    try { await deleteRow(cfg.table, r.id); reload(); } catch (e) { notify({ type: 'err', text: errText(e) }); }
  };

  return (
    <div className="space-y-4">
      <Card>
        <h3 className="font-black text-sm mb-3">{cfg.addLabel}</h3>
        {cfg.fields.map((f) => (
          <div key={f.name} className="mb-3">
            <label className={labelCls}>{f.label}</label>
            {f.type === 'textarea'
              ? <textarea rows={3} className={inputCls} value={values[f.name] || ''} onChange={(e) => setValues({ ...values, [f.name]: e.target.value })} />
              : <input type={f.type || 'text'} className={inputCls} value={values[f.name] || ''} onChange={(e) => setValues({ ...values, [f.name]: e.target.value })} />}
          </div>
        ))}
        <label className="flex items-center gap-2 text-sm font-semibold mb-3"><input type="checkbox" className="w-4 h-4" checked={showNow} onChange={(e) => setShowNow(e.target.checked)} /> Show on the website now</label>
        <Button onClick={add} loading={busy}>{cfg.addLabel}</Button>
      </Card>
      <Card>
        <h3 className="font-black text-sm mb-1">{cfg.title}</h3>
        <p className={hintCls}>{cfg.hint}</p>
        {error && <p className="text-xs text-red-600 mb-2">Could not load: {error}</p>}
        {loading && !rows.length ? <p className="text-xs text-gray-400">Loading…</p> : rows.length === 0 ? <p className="text-xs text-gray-400">None yet.</p> : rows.map((r) => {
          const { title, sub } = cfg.row(r);
          return (
            <Row key={r.id}>
              <div className="min-w-0"><p className="font-bold text-sm truncate">{title}</p>{sub && <p className="text-xs text-gray-500 truncate">{sub}</p>}</div>
              <div className="flex items-center gap-2 shrink-0"><Switch on={!!r[col]} onChange={(v) => toggle(r, v)} /><DeleteBtn onClick={() => del(r)} /></div>
            </Row>
          );
        })}
      </Card>
    </div>
  );
};

// ---- Gallery
const GalleryTab: React.FC<{ notify: Notify }> = ({ notify }) => {
  const { rows, loading, error, reload } = useRows<any>('gallery_photos', (q) => q.select('id, caption, image_url, show_on_website').order('created_at', { ascending: false }).limit(60));
  const [picked, setPicked] = useState<Picked[]>([]);
  const [caption, setCaption] = useState('');
  const [showNow, setShowNow] = useState(true);
  const [progress, setProgress] = useState<string | null>(null);

  const add = async () => {
    if (!picked.length) return notify({ type: 'err', text: 'Choose at least one photo first.' });
    try {
      const urls: string[] = [];
      for (let i = 0; i < picked.length; i++) {
        setProgress(`Uploading ${i + 1} of ${picked.length}…`);
        urls.push(await uploadImage(picked[i].file, 'gallery'));
      }
      const { error } = await supabase.from('gallery_photos').insert(urls.map((u) => ({ image_url: u, caption, show_on_website: showNow })));
      if (error) throw error;
      picked.forEach((p) => URL.revokeObjectURL(p.url));
      setPicked([]); setCaption(''); notify({ type: 'ok', text: urls.length > 1 ? 'Photos added.' : 'Photo added.' }); reload();
    } catch (e) { notify({ type: 'err', text: errText(e) }); } finally { setProgress(null); }
  };

  return (
    <div className="space-y-4">
      <Card>
        <h3 className="font-black text-sm mb-3">Add photos</h3>
        <ImagePicker picked={picked} onChange={setPicked} multiple label="Photos (choose one or many)" notify={notify} />
        <div className="mb-3"><label className={labelCls}>Caption (optional)</label><input className={inputCls} value={caption} onChange={(e) => setCaption(e.target.value)} /></div>
        <label className="flex items-center gap-2 text-sm font-semibold mb-3"><input type="checkbox" className="w-4 h-4" checked={showNow} onChange={(e) => setShowNow(e.target.checked)} /> Show on the website now</label>
        <Button onClick={add} loading={!!progress}>{progress || 'Add photos'}</Button>
      </Card>
      <Card>
        <h3 className="font-black text-sm mb-1">All photos (church app)</h3>
        <p className={hintCls}>Only photos switched ON appear on the website. Shows the 60 newest.</p>
        {error && <p className="text-xs text-red-600 mb-2">Could not load: {error}</p>}
        {loading && !rows.length ? <p className="text-xs text-gray-400">Loading…</p> : rows.length === 0 ? <p className="text-xs text-gray-400">None yet.</p> : rows.map((r) => (
          <Row key={r.id}>
            <div className="flex items-center gap-3 min-w-0">
              <img src={r.image_url} alt="" className="w-14 h-14 rounded-lg object-cover border border-[var(--Bdr)] shrink-0 bg-gray-100" />
              <p className="text-sm truncate">{r.caption || '(no caption)'}</p>
            </div>
            <div className="flex items-center gap-2 shrink-0">
              <Switch on={!!r.show_on_website} onChange={async (v) => { try { await setShown('gallery_photos', r.id, v); reload(); } catch (e) { notify({ type: 'err', text: errText(e) }); } }} />
              <DeleteBtn onClick={async () => { if (!window.confirm('DELETE this photo from the church app AND the website?')) return; try { await deleteRow('gallery_photos', r.id); reload(); } catch (e) { notify({ type: 'err', text: errText(e) }); } }} />
            </div>
          </Row>
        ))}
      </Card>
    </div>
  );
};

// ---- Leadership (website only)
const LeadershipTab: React.FC<{ notify: Notify }> = ({ notify }) => {
  const { rows, loading, error, reload } = useRows<any>('leadership', (q) => q.select('*').order('sort_order').order('full_name'));
  const [picked, setPicked] = useState<Picked[]>([]);
  const [v, setV] = useState({ name: '', title: '', bio: '' });
  const [progress, setProgress] = useState<string | null>(null);

  const add = async () => {
    if (!v.name.trim()) return notify({ type: 'err', text: "Enter the leader's name." });
    try {
      let photo = '';
      if (picked.length) { setProgress('Uploading photo…'); photo = await uploadImage(picked[0].file, 'leaders'); }
      const { error } = await supabase.from('leadership').insert({ full_name: v.name.trim(), title: v.title.trim(), photo_url: photo, bio: v.bio.trim(), is_active: true });
      if (error) throw error;
      picked.forEach((p) => URL.revokeObjectURL(p.url));
      setPicked([]); setV({ name: '', title: '', bio: '' }); notify({ type: 'ok', text: 'Leader added.' }); reload();
    } catch (e) { notify({ type: 'err', text: errText(e) }); } finally { setProgress(null); }
  };

  return (
    <div className="space-y-4">
      <Card>
        <h3 className="font-black text-sm mb-3">Add a leader</h3>
        <ImagePicker picked={picked} onChange={setPicked} round label="Photo" notify={notify} />
        <div className="mb-3"><label className={labelCls}>Full name</label><input className={inputCls} value={v.name} onChange={(e) => setV({ ...v, name: e.target.value })} /></div>
        <div className="mb-3"><label className={labelCls}>Title (e.g. Resident Pastor)</label><input className={inputCls} value={v.title} onChange={(e) => setV({ ...v, title: e.target.value })} /></div>
        <div className="mb-3"><label className={labelCls}>Short bio</label><textarea rows={3} className={inputCls} value={v.bio} onChange={(e) => setV({ ...v, bio: e.target.value })} /></div>
        <Button onClick={add} loading={!!progress}>{progress || 'Add leader'}</Button>
      </Card>
      <Card>
        <h3 className="font-black text-sm mb-1">Leadership on the website</h3>
        <p className={hintCls}>Switch OFF to hide a leader without deleting.</p>
        {error && <p className="text-xs text-red-600 mb-2">Could not load: {error}</p>}
        {loading && !rows.length ? <p className="text-xs text-gray-400">Loading…</p> : rows.length === 0 ? <p className="text-xs text-gray-400">No leaders yet. The website shows a "coming soon" message.</p> : rows.map((r) => (
          <Row key={r.id}>
            <div className="flex items-center gap-3 min-w-0">
              {r.photo_url ? <img src={r.photo_url} alt="" className="w-12 h-12 rounded-full object-cover border border-[var(--Bdr)] shrink-0" /> : <div className="w-12 h-12 rounded-full bg-gray-100 dark:bg-white/5 shrink-0" />}
              <div className="min-w-0"><p className="font-bold text-sm truncate">{r.title}</p><p className="text-xs text-gray-500 truncate">{r.full_name}</p></div>
            </div>
            <div className="flex items-center gap-2 shrink-0">
              <Switch on={r.is_active !== false} onChange={async (on) => { try { await setShown('leadership', r.id, on); reload(); } catch (e) { notify({ type: 'err', text: errText(e) }); } }} />
              <DeleteBtn onClick={async () => { if (!window.confirm('Delete this leader for good?')) return; try { await deleteRow('leadership', r.id); reload(); } catch (e) { notify({ type: 'err', text: errText(e) }); } }} />
            </div>
          </Row>
        ))}
      </Card>
    </div>
  );
};

// ---- Wording: every fixed text on the website (site_settings 'site_text': { key: text })
const TextTab: React.FC<{ notify: Notify }> = ({ notify }) => {
  const [saved, setSaved] = useState<Record<string, string>>({});
  const [draft, setDraft] = useState<Record<string, string>>({});
  const [pageId, setPageId] = useState(SITE_TEXT_REGISTRY[0].id);
  const [busy, setBusy] = useState(false);
  const page = SITE_TEXT_REGISTRY.find((p) => p.id === pageId) || SITE_TEXT_REGISTRY[0];

  useEffect(() => { getSetting<Record<string, string>>('site_text').then((v) => setSaved(v && typeof v === 'object' ? v : {})); }, []);

  const persist = async (next: Record<string, string>) => {
    setBusy(true);
    try { await setSetting('site_text', next); setSaved(next); return true; }
    catch (e) { notify({ type: 'err', text: errText(e) }); return false; }
    finally { setBusy(false); }
  };
  const save = async () => {
    const next = { ...saved };
    for (const p of SITE_TEXT_REGISTRY) for (const i of p.items) {
      if (!(i.key in draft)) continue;
      const val = draft[i.key].trim();
      if (!val || val === i.def) delete next[i.key]; else next[i.key] = val;
    }
    if (await persist(next)) { setDraft({}); notify({ type: 'ok', text: 'Saved. The website will show the new wording.' }); }
  };
  const reset = async () => {
    if (!window.confirm(`Put every text on "${page.label}" back to its original wording?`)) return;
    const next = { ...saved };
    const d = { ...draft };
    page.items.forEach((i) => { delete next[i.key]; delete d[i.key]; });
    if (await persist(next)) { setDraft(d); notify({ type: 'ok', text: 'Original wording restored.' }); }
  };

  return (
    <Card>
      <h3 className="font-black text-sm mb-1">Edit any text on the website</h3>
      <p className={hintCls}>Pick a page, change any wording, then press Save. Text only (no formatting). A field you leave unchanged keeps its original wording. Service times, contact details and the About-page story are in the "Contact & times" tab.</p>
      <div className="mb-4">
        <label className={labelCls}>Page</label>
        <select className={inputCls} value={pageId} onChange={(e) => setPageId(e.target.value)}>
          {SITE_TEXT_REGISTRY.map((p) => <option key={p.id} value={p.id}>{p.label}</option>)}
        </select>
      </div>
      {page.items.map((i) => {
        const cur = draft[i.key] ?? saved[i.key] ?? i.def;
        const long = i.def.length > 70 || cur.length > 70;
        return (
          <div key={i.key} className="mb-3">
            <label className={labelCls}>{i.label}</label>
            {long
              ? <textarea rows={Math.min(6, Math.ceil(cur.length / 45) + 1)} className={inputCls} value={cur} onChange={(e) => setDraft({ ...draft, [i.key]: e.target.value })} />
              : <input className={inputCls} value={cur} onChange={(e) => setDraft({ ...draft, [i.key]: e.target.value })} />}
          </div>
        );
      })}
      <div className="flex gap-2 flex-wrap mt-2">
        <Button onClick={save} loading={busy}>Save this page's wording</Button>
        <Button variant="outline" onClick={reset} disabled={busy}>Put back the original wording</Button>
      </div>
    </Card>
  );
};

// ---- Messages from the website's contact form
const VISITOR_TAG = "[I'm New - visitor card]";
const MessagesTab: React.FC<{ notify: Notify }> = ({ notify }) => {
  const { rows, loading, error, reload } = useRows<any>('contact_messages', (q) => q.select('*').order('created_at', { ascending: false }).limit(200));
  const [filter, setFilter] = useState<'all' | 'visitor' | 'contact' | 'new'>('all');
  const mark = async (id: string, status: string) => {
    const { error } = await supabase.from('contact_messages').update({ status }).eq('id', id);
    if (error) notify({ type: 'err', text: errText(error) }); else reload();
  };
  const isVisitor = (m: any) => String(m.message || '').startsWith(VISITOR_TAG);
  const shown = rows.filter((m) => filter === 'all' ? true : filter === 'visitor' ? isVisitor(m) : filter === 'contact' ? !isVisitor(m) : (m.status || 'new') === 'new');
  const unread = rows.filter((m) => (m.status || 'new') === 'new').length;
  const chips: [typeof filter, string][] = [['all', 'All'], ['new', `New${unread ? ` (${unread})` : ''}`], ['visitor', "I'm New cards"], ['contact', 'Contact form']];
  return (
    <Card>
      <div className="flex items-center justify-between mb-2">
        <h3 className="font-black text-sm">Messages from website visitors</h3>
        <button type="button" onClick={reload} className="p-2 rounded-lg border border-[var(--Bdr)]" title="Refresh"><RefreshCw size={14} /></button>
      </div>
      <div className="flex gap-2 overflow-x-auto pb-2 mb-2">
        {chips.map(([id, label]) => (
          <button key={id} type="button" onClick={() => setFilter(id)}
            className={`shrink-0 px-3 py-1.5 rounded-full text-[10px] font-black uppercase tracking-wider border ${filter === id ? 'bg-tac-blue/10 text-tac-blue border-tac-blue/40' : 'border-[var(--Bdr)] text-gray-400'}`}>{label}</button>
        ))}
      </div>
      {error && <p className="text-xs text-red-600 mb-2">Could not load: {error}</p>}
      {loading && !rows.length ? <p className="text-xs text-gray-400">Loading…</p> : shown.length === 0 ? <p className="text-xs text-gray-400">Nothing here.</p> : shown.map((m) => (
        <Row key={m.id}>
          <div className="min-w-0">
            <p className="text-sm">
              {isVisitor(m) && <span className="mr-2 text-[10px] font-black uppercase tracking-wider text-tac-blue">I'm New</span>}
              <span className="font-bold">{m.name}</span> <span className="text-gray-500">({m.contact})</span>
            </p>
            <p className="text-xs text-gray-600 dark:text-gray-300 whitespace-pre-wrap break-words">{String(m.message || '').replace(VISITOR_TAG, '').trim()}</p>
            <p className="text-[10px] text-gray-400 mt-0.5">{m.created_at ? new Date(m.created_at).toLocaleString() : ''}</p>
          </div>
          <select className="rounded-lg border border-[var(--Bdr)] bg-transparent text-xs px-2 py-1.5 shrink-0" value={m.status || 'new'} onChange={(e) => mark(m.id, e.target.value)}>
            <option value="new">New</option><option value="read">Read</option><option value="replied">Replied</option>
          </select>
        </Row>
      ))}
    </Card>
  );
};

/* --------------------------------------------------------------- the screen */

export const WebsiteManager: React.FC = () => {
  const [tab, setTab] = useState<Tab>('home');
  const [notice, setNotice] = useState<Notice | null>(null);
  useEffect(() => { if (notice?.type === 'ok') { const t = setTimeout(() => setNotice(null), 4000); return () => clearTimeout(t); } }, [notice]);

  return (
    <div className="space-y-4 max-w-3xl mx-auto">
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-2xl bg-tac-blue/10 text-tac-blue flex items-center justify-center"><Globe size={20} /></div>
        <div>
          <h2 className="text-lg font-black leading-tight">Website</h2>
          <p className="text-xs text-gray-500 dark:text-gray-400">Control exactly what the public church website shows.</p>
        </div>
      </div>

      <div className="flex gap-2 overflow-x-auto pb-1 -mx-1 px-1">
        {TABS.map((t) => (
          <button key={t.id} type="button" onClick={() => { setTab(t.id); setNotice(null); }}
            className={`shrink-0 px-4 py-2 rounded-full text-[11px] font-black uppercase tracking-wider border transition-colors ${tab === t.id ? 'bg-tac-blue text-white border-tac-blue' : 'border-[var(--Bdr)] text-gray-500'}`}>
            {t.label}
          </button>
        ))}
      </div>

      {notice && (
        <div role="status" className={`rounded-xl px-4 py-3 text-sm font-semibold ${notice.type === 'ok' ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-300' : 'bg-red-50 text-red-700 dark:bg-red-500/10 dark:text-red-300'}`}>
          {notice.text}
        </div>
      )}

      {tab === 'clubs' && <ContentTab kind="clubs" notify={setNotice} />}
      {tab === 'events' && <ContentTab kind="events" notify={setNotice} />}
      {tab === 'sermons' && <ContentTab kind="sermons" notify={setNotice} />}
      {tab === 'gallery' && <GalleryTab notify={setNotice} />}
      {tab === 'leadership' && <LeadershipTab notify={setNotice} />}
      {tab === 'home' && <HomeTab notify={setNotice} />}
      {tab === 'newhere' && <NewHereTab notify={setNotice} />}
      {tab === 'giving' && <GivingTab notify={setNotice} />}
      {tab === 'helper' && <HelperTab notify={setNotice} />}
      {tab === 'text' && <TextTab notify={setNotice} />}
      {tab === 'contact' && <ContactLinksTab notify={setNotice} />}
      {tab === 'messages' && <MessagesTab notify={setNotice} />}
    </div>
  );
};

export default WebsiteManager;
