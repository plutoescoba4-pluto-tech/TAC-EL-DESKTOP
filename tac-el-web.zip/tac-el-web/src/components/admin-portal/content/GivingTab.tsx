import React from 'react';
import { Plus } from 'lucide-react';
import { Card, DeleteBtn, GhostBtn, ImageField, Notify, PrimaryBtn, TextField, isHttps, useSetting } from './websiteShared';

/**
 * Admin > Website > Giving
 * What the website's Give page shows. Each method appears only if it is filled in.
 * The website never takes card numbers or PINs: online giving is a link to a hosted checkout page.
 */
interface Momo { network: string; number: string; name: string }
interface Giving {
  intro: string; payment_link: string; payment_label: string; provider_name: string;
  momo: Momo[]; bank: { bank_name: string; account_name: string; account_number: string; branch: string }; qr_image_url: string;
}
const EMPTY: Giving = {
  intro: '', payment_link: '', payment_label: '', provider_name: '', momo: [],
  bank: { bank_name: '', account_name: '', account_number: '', branch: '' }, qr_image_url: '',
};
const MAX_MOMO = 6;

export const GivingTab: React.FC<{ notify: Notify }> = ({ notify }) => {
  const g = useSetting<Giving>('giving', EMPTY);
  const v: Giving = { ...EMPTY, ...g.value, bank: { ...EMPTY.bank, ...(g.value.bank || {}) }, momo: g.value.momo || [] };
  const set = (p: Partial<Giving>) => g.update({ ...v, ...p });
  const setMomo = (i: number, p: Partial<Momo>) => set({ momo: v.momo.map((m, k) => (k === i ? { ...m, ...p } : m)) });

  const save = () => {
    if (!isHttps(v.payment_link) || !isHttps(v.qr_image_url)) return notify({ type: 'err', text: 'Links must start with https://' });
    const out: any = {};
    if (v.intro.trim()) out.intro = v.intro.trim();
    if (v.payment_link.trim()) { out.payment_link = v.payment_link.trim(); if (v.payment_label.trim()) out.payment_label = v.payment_label.trim(); if (v.provider_name.trim()) out.provider_name = v.provider_name.trim(); }
    const momo = v.momo.map((m) => ({ network: m.network.trim(), number: m.number.trim(), name: m.name.trim() })).filter((m) => m.number);
    if (momo.length) out.momo = momo;
    const bank = Object.fromEntries(Object.entries(v.bank).map(([k, x]) => [k, String(x || '').trim()]).filter(([, x]) => x));
    if (Object.keys(bank).length) out.bank = bank;
    if (v.qr_image_url) out.qr_image_url = v.qr_image_url;
    g.save(notify, 'The giving page', out as Giving);
  };

  return (
    <div className="space-y-4">
      <Card title="Giving page" hint="Only what you fill in appears on the Give page. Never put card numbers or PINs anywhere.">
        <TextField label="Short message at the top" value={v.intro} onChange={(x) => set({ intro: x })} multiline rows={3} placeholder="Your giving supports the work of the church..." />
      </Card>

      <Card title="Give online (a payment page link)" hint="Paste the link to your hosted checkout page (for example a Paystack payment page). Visitors tap it to give securely. If you do not add a QR picture below, the website makes a QR code from this link.">
        <TextField label="Payment page link" value={v.payment_link} onChange={(x) => set({ payment_link: x })} placeholder="https://checkout.paystack.com/..." />
        <div className="grid sm:grid-cols-2 gap-x-4">
          <TextField label="Button words" value={v.payment_label} onChange={(x) => set({ payment_label: x })} placeholder="Give securely online" />
          <TextField label="Provider name" value={v.provider_name} onChange={(x) => set({ provider_name: x })} placeholder="Paystack" />
        </div>
        <ImageField label="QR code picture (optional)" value={v.qr_image_url} folder="giving" notify={notify} maxW={800} maxH={800} onChange={(url) => set({ qr_image_url: url })} />
      </Card>

      <Card title="Mobile Money" hint="One row for each number people can send to.">
        {v.momo.map((m, i) => (
          <div key={i} className="rounded-2xl bg-gray-50 dark:bg-white/5 p-3 mb-2">
            <div className="flex items-center justify-between mb-2"><span className="text-[11px] font-black text-gray-400">Number {i + 1}</span><DeleteBtn onClick={() => set({ momo: v.momo.filter((_, k) => k !== i) })} /></div>
            <div className="grid sm:grid-cols-3 gap-x-3">
              <TextField label="Network" value={m.network} onChange={(x) => setMomo(i, { network: x })} placeholder="MTN MoMo" />
              <TextField label="Number" value={m.number} onChange={(x) => setMomo(i, { number: x })} placeholder="024 000 0000" />
              <TextField label="Account name" value={m.name} onChange={(x) => setMomo(i, { name: x })} />
            </div>
          </div>
        ))}
        <GhostBtn onClick={() => { if (v.momo.length >= MAX_MOMO) return notify({ type: 'err', text: `At most ${MAX_MOMO} numbers.` }); set({ momo: [...v.momo, { network: '', number: '', name: '' }] }); }}>
          <Plus size={12} className="inline -mt-0.5" /> Add a number
        </GhostBtn>
      </Card>

      <Card title="Bank transfer">
        <div className="grid sm:grid-cols-2 gap-x-4">
          <TextField label="Bank" value={v.bank.bank_name} onChange={(x) => set({ bank: { ...v.bank, bank_name: x } })} />
          <TextField label="Branch" value={v.bank.branch} onChange={(x) => set({ bank: { ...v.bank, branch: x } })} />
          <TextField label="Account name" value={v.bank.account_name} onChange={(x) => set({ bank: { ...v.bank, account_name: x } })} />
          <TextField label="Account number" value={v.bank.account_number} onChange={(x) => set({ bank: { ...v.bank, account_number: x } })} />
        </div>
      </Card>

      <div className="flex items-center gap-3">
        <PrimaryBtn onClick={save} busy={g.saving}>Save giving page</PrimaryBtn>
        {g.dirty && <span className="text-[11px] font-black uppercase tracking-widest text-amber-600">Unsaved changes</span>}
      </div>
    </div>
  );
};

export default GivingTab;
