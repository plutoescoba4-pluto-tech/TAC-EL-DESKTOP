import React, { useState, useEffect } from 'react';
import { eventsService } from '../../../services/eventsService';
import { EventItem } from '../../../types';
import { Calendar, Plus, Trash2, MapPin, Clock, Edit3 } from 'lucide-react';
import { Card, Button, Badge } from '../../ui';

export const EventsManager: React.FC = () => {
  const [events, setEvents] = useState<EventItem[]>([]);
  const [showAdd, setShowAdd] = useState(false);
  const [title, setTitle] = useState('');
  const [date, setDate] = useState('');
  const [time, setTime] = useState('');
  const [location, setLocation] = useState('Sanctuary Main Hall');
  const [description, setDescription] = useState('');
  const [saving, setSaving] = useState(false);

  const loadEvents = async () => {
    const list = await eventsService.getEvents();
    setEvents(list);
  };

  useEffect(() => {
    loadEvents();
  }, []);

  const handleAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !date.trim()) return;

    setSaving(true);
    try {
      await eventsService.addEvent({
        title: title.trim(),
        startDate: date,
        type: 'service',
        summary: description.trim() || title.trim(),
        location: location.trim()
      });

      setTitle('');
      setDate('');
      setTime('');
      setDescription('');
      setShowAdd(false);
      await loadEvents();
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (confirm('Delete this church calendar event?')) {
      await eventsService.deleteEvent(id);
      await loadEvents();
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-xl font-black text-tac-blue-dark dark:text-white uppercase tracking-tight">
            Church Calendar & Events Manager
          </h2>
          <p className="text-xs text-[var(--Sub)]">
            Schedule conventions, retreats, revivals, and weekly services
          </p>
        </div>

        <Button
          variant="primary"
          onClick={() => setShowAdd(!showAdd)}
          icon={<Plus size={16} />}
        >
          {showAdd ? 'Cancel' : 'Add Church Event'}
        </Button>
      </div>

      {showAdd && (
        <Card className="animate-fadeIn border-tac-blue">
          <h3 className="text-sm font-black uppercase tracking-wider text-tac-blue-dark dark:text-white mb-4">
            Schedule Church Event
          </h3>

          <form onSubmit={handleAdd} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
                  Event Title
                </label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g. Annual Easter Convention 2026"
                  className="w-full px-4 py-2.5 bg-gray-50 dark:bg-slate-800 border border-[var(--Bdr)] rounded-2xl text-sm font-bold outline-none"
                />
              </div>

              <div>
                <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
                  Venue / Location
                </label>
                <input
                  type="text"
                  required
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  placeholder="Sanctuary Main Hall"
                  className="w-full px-4 py-2.5 bg-gray-50 dark:bg-slate-800 border border-[var(--Bdr)] rounded-2xl text-sm outline-none"
                />
              </div>

              <div>
                <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
                  Date
                </label>
                <input
                  type="date"
                  required
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="w-full px-4 py-2.5 bg-gray-50 dark:bg-slate-800 border border-[var(--Bdr)] rounded-2xl text-sm outline-none min-w-0 max-w-full box-border"
                />
              </div>

              <div>
                <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
                  Time Slot
                </label>
                <input
                  type="text"
                  value={time}
                  onChange={(e) => setTime(e.target.value)}
                  placeholder="e.g. 9:00 AM - 1:00 PM"
                  className="w-full px-4 py-2.5 bg-gray-50 dark:bg-slate-800 border border-[var(--Bdr)] rounded-2xl text-sm outline-none"
                />
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
                Event Description & Ministry Coordinators
              </label>
              <textarea
                rows={3}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Program outline, guest speakers, dress code..."
                className="w-full px-4 py-3 bg-gray-50 dark:bg-slate-800 border border-[var(--Bdr)] rounded-2xl text-sm outline-none"
              />
            </div>

            <div className="flex justify-end gap-3 pt-2">
              <Button type="button" variant="ghost" onClick={() => setShowAdd(false)}>
                Cancel
              </Button>
              <Button type="submit" variant="primary" loading={saving}>
                Publish to Calendar
              </Button>
            </div>
          </form>
        </Card>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {events.map((e) => (
          <Card key={e.id}>
            <div className="flex items-start justify-between gap-3">
              <div>
                <h4 className="font-bold text-sm text-tac-blue-dark dark:text-white uppercase">{e.title}</h4>
                <div className="flex flex-wrap items-center gap-3 text-xs text-[var(--Sub)] mt-1.5">
                  <span className="flex items-center gap-1 font-semibold text-tac-blue">
                    <Calendar size={13} />
                    {e.startDate}
                  </span>
                  {e.location && (
                    <span className="flex items-center gap-1">
                      <MapPin size={13} />
                      {e.location}
                    </span>
                  )}
                </div>
              </div>

              <button
                onClick={() => handleDelete(e.id)}
                className="p-2 text-gray-400 hover:text-red-500"
              >
                <Trash2 size={16} />
              </button>
            </div>
            {e.summary && (
              <p className="text-xs text-[var(--Sub)] mt-3 pt-3 border-t border-[var(--Bdr)] line-clamp-2">
                {e.summary}
              </p>
            )}
          </Card>
        ))}
      </div>
    </div>
  );
};
export default EventsManager;
