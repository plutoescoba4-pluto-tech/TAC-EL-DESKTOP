import React, { useRef, useState } from 'react';
import { supabase } from '../../../supabase';
import { Upload, X, Trash2 } from 'lucide-react';

/**
 * Pieces shared by every Admin > Website tab: looks, saving a website setting, uploading pictures
 * (which are resized in the browser first), and the small building blocks.
 */
// Phone photos are big; they are resized in the browser BEFORE upload, so the original may be large.
export const MAX_BYTES = 25 * 1024 * 1024;
export const inputCls = 'w-full rounded-xl border border-[var(--Bdr)] bg-transparent px-3 py-2.5 text-sm text-[var(--Text)] outline-none focus:border-tac-blue';
export const labelCls = 'block text-[10px] font-black uppercase tracking-widest text-gray-400 mb-1 px-1';
export const hintCls = 'text-xs text-gray-500 dark:text-gray-400 mb-3';

/* ------------------------------------------------------------------ helpers */

export interface Notice { type: 'ok' | 'err'; text: string }
export type Notify = (n: Notice | null) => void;

export const errText = (e: any) => {
  const m: string = e?.message || String(e);
  return /row-level security|policy/i.test(m) ? m + ' — you need to be signed in as an admin.' : m;
};

/** Shrinks a photo in the browser (the website works best with pictures under about 300 KB). GIFs are left alone. */
export async function resizeImage(file: File, maxW: number, maxH: number, quality = 0.82, png = false): Promise<File> {
  if (!file.type.startsWith('image/') || file.type === 'image/gif') return file;
  try {
    const bmp = await createImageBitmap(file, { imageOrientation: 'from-image' } as any);
    const scale = Math.min(1, maxW / bmp.width, maxH / bmp.height);
    const w = Math.max(1, Math.round(bmp.width * scale));
    const h = Math.max(1, Math.round(bmp.height * scale));
    const canvas = document.createElement('canvas');
    canvas.width = w; canvas.height = h;
    canvas.getContext('2d')!.drawImage(bmp, 0, 0, w, h);
    const type = png ? 'image/png' : canvas.toDataURL('image/webp').startsWith('data:image/webp') ? 'image/webp' : 'image/jpeg';
    const blob: Blob | null = await new Promise((res) => canvas.toBlob(res, type, quality));
    if (!blob || (scale === 1 && blob.size >= file.size)) return file;   // already small enough
    return new File([blob], file.name.replace(/\.[^.]+$/, '') + (type === 'image/webp' ? '.webp' : type === 'image/png' ? '.png' : '.jpg'), { type });
  } catch {
    return file;                                                          // could not read it: upload as it is
  }
}

export interface ResizeOpts { maxW?: number; maxH?: number; png?: boolean }

/** Resizes, uploads to the public "website-media" bucket and returns the public link. */
export async function uploadImage(file: File, folder: string, opts: ResizeOpts = {}): Promise<string> {
  const small = await resizeImage(file, opts.maxW ?? 1600, opts.maxH ?? 1600, 0.82, !!opts.png);
  const ext = (small.name.split('.').pop() || 'jpg').toLowerCase().replace(/[^a-z0-9]/g, '') || 'jpg';
  const path = `${folder}/${Date.now()}_${Math.random().toString(36).slice(2, 8)}.${ext}`;
  const { error } = await supabase.storage.from('website-media').upload(path, small, { contentType: small.type, upsert: false });
  if (error) throw new Error(`Could not upload "${file.name}": ${errText(error)}`);
  return supabase.storage.from('website-media').getPublicUrl(path).data.publicUrl;
}

export async function getSetting<T = any>(key: string): Promise<T | null> {
  const { data } = await supabase.from('site_settings').select('value').eq('key', key).maybeSingle();
  return (data?.value as T) ?? null;
}
export async function setSetting(key: string, value: any): Promise<void> {
  const { error } = await supabase.from('site_settings').upsert({ key, value, updated_at: new Date().toISOString() });
  if (error) throw error;
}

/* ---------------------------------------------------------- small components */

export const Switch: React.FC<{ on: boolean; onChange: (v: boolean) => void; label?: string }> = ({ on, onChange, label = 'On website' }) => (
  <label className={`inline-flex items-center gap-2 text-[11px] font-black cursor-pointer whitespace-nowrap ${on ? 'text-emerald-600' : 'text-gray-400'}`}>
    <input type="checkbox" checked={on} onChange={(e) => onChange(e.target.checked)} className="w-4 h-4 accent-[#1d4ed8]" />
    {label}
  </label>
);

export interface Picked { file: File; url: string }

/** Photo chooser that shows PREVIEWS (not file names) before anything is uploaded. */
export const ImagePicker: React.FC<{
  picked: Picked[]; onChange: (p: Picked[]) => void; multiple?: boolean; round?: boolean; label: string; notify: Notify;
}> = ({ picked, onChange, multiple, round, label, notify }) => {
  const ref = useRef<HTMLInputElement>(null);
  const pick = (files: FileList | null) => {
    if (!files) return;
    const next: Picked[] = multiple ? [...picked] : [];
    if (!multiple) picked.forEach((p) => URL.revokeObjectURL(p.url));
    for (const f of Array.from(files)) {
      if (!f.type.startsWith('image/')) { notify({ type: 'err', text: `"${f.name}" is not a picture, so it was skipped.` }); continue; }
      if (f.size > MAX_BYTES) { notify({ type: 'err', text: `"${f.name}" is bigger than 25 MB, so it was skipped.` }); continue; }
      next.push({ file: f, url: URL.createObjectURL(f) });
    }
    onChange(next);
    if (ref.current) ref.current.value = '';
  };
  const remove = (i: number) => {
    URL.revokeObjectURL(picked[i].url);
    onChange(picked.filter((_, k) => k !== i));
  };
  const size = round ? 'w-28 h-28 rounded-full' : 'w-24 h-24 rounded-xl';
  return (
    <div className="mb-3">
      <span className={labelCls}>{label}</span>
      <button type="button" onClick={() => ref.current?.click()}
        className="w-full flex items-center justify-center gap-2 rounded-xl border-2 border-dashed border-[var(--Bdr)] py-4 text-xs font-black uppercase tracking-wider text-tac-blue active:opacity-70">
        <Upload size={16} /> {multiple ? 'Choose photos' : 'Choose a photo'}
      </button>
      <input ref={ref} type="file" accept="image/*" multiple={!!multiple} hidden onChange={(e) => pick(e.target.files)} />
      {picked.length > 0 && (
        <div className="flex flex-wrap gap-3 mt-3">
          {picked.map((p, i) => (
            <div key={p.url} className={`relative ${size}`}>
              <img src={p.url} alt="" className={`${size} object-cover border border-[var(--Bdr)]`} />
              <button type="button" title="Remove" onClick={() => remove(i)}
                className="absolute -top-2 -right-2 w-6 h-6 rounded-full bg-red-600 text-white flex items-center justify-center"><X size={13} /></button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export const Row: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <div className="flex items-center justify-between gap-3 py-3 border-b border-[var(--Bdr)] last:border-0">{children}</div>
);

export const DeleteBtn: React.FC<{ onClick: () => void }> = ({ onClick }) => (
  <button type="button" onClick={onClick} title="Delete" className="p-2 rounded-lg text-red-600 hover:bg-red-50 dark:hover:bg-red-500/10"><Trash2 size={16} /></button>
);


/* ----------------------------------------------------------------- more shared pieces */

/** The website only accepts https links for pictures and buttons. Empty is fine. */
export const isHttps = (u: string) => !u.trim() || /^https:\/\//i.test(u.trim());

/** For the map: accepts the whole <iframe ...> code Google gives, or just the link; returns the src, or null if it is not a Google Maps embed. */
export function extractMapSrc(text: string): string | null {
  const t = text.trim();
  if (!t) return '';
  const m = /src\s*=\s*["']([^"']+)["']/i.exec(t);
  const url = (m ? m[1] : t).trim();
  return /^https:\/\/(www\.)?google\.[a-z.]+\/maps\/embed/i.test(url) || /^https:\/\/maps\.google\.[a-z.]+\/maps\/embed/i.test(url) ? url : null;
}

export const Card: React.FC<{ title?: string; hint?: React.ReactNode; children: React.ReactNode }> = ({ title, hint, children }) => (
  <div className="rounded-3xl bg-white dark:bg-slate-900 border border-[var(--Bdr)] p-5">
    {title && <h3 className="font-black text-sm mb-1">{title}</h3>}
    {hint && <p className={hintCls}>{hint}</p>}
    {children}
  </div>
);

export const PrimaryBtn: React.FC<{ onClick: () => void; busy?: boolean; children: React.ReactNode; disabled?: boolean }> = ({ onClick, busy, children, disabled }) => (
  <button type="button" onClick={onClick} disabled={busy || disabled}
    className="px-5 py-2.5 rounded-xl bg-tac-blue text-white text-xs font-black uppercase tracking-widest disabled:opacity-50">
    {busy ? 'Saving…' : children}
  </button>
);

export const GhostBtn: React.FC<{ onClick: () => void; children: React.ReactNode; danger?: boolean }> = ({ onClick, children, danger }) => (
  <button type="button" onClick={onClick}
    className={`px-3 py-2 rounded-xl border text-[11px] font-black uppercase tracking-widest ${danger ? 'border-red-200 text-red-600' : 'border-[var(--Bdr)] text-gray-500'}`}>
    {children}
  </button>
);

export const TextField: React.FC<{
  label: string; value: string; onChange: (v: string) => void; placeholder?: string; multiline?: boolean; rows?: number; hint?: string; type?: string;
}> = ({ label, value, onChange, placeholder, multiline, rows = 3, hint, type = 'text' }) => (
  <div className="mb-3">
    <label className={labelCls}>{label}</label>
    {multiline
      ? <textarea rows={rows} className={inputCls} value={value} placeholder={placeholder} onChange={(e) => onChange(e.target.value)} />
      : <input type={type} className={inputCls} value={value} placeholder={placeholder} onChange={(e) => onChange(e.target.value)} />}
    {hint && <p className="text-[11px] text-gray-400 mt-1 px-1">{hint}</p>}
  </div>
);

/** One picture: shows it, uploads a new one as soon as it is chosen (resized first), and can remove it. */
export const ImageField: React.FC<{
  label: string; value: string; onChange: (url: string) => void; folder: string; notify: Notify;
  maxW?: number; maxH?: number; round?: boolean; hint?: string; png?: boolean;
}> = ({ label, value, onChange, folder, notify, maxW, maxH, round, hint, png }) => {
  const ref = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState(false);
  const size = round ? 'w-24 h-24 rounded-full' : 'w-28 h-20 rounded-xl';

  const choose = async (files: FileList | null) => {
    const f = files?.[0];
    if (ref.current) ref.current.value = '';
    if (!f) return;
    if (!f.type.startsWith('image/')) return notify({ type: 'err', text: `"${f.name}" is not a picture.` });
    if (f.size > MAX_BYTES) return notify({ type: 'err', text: `"${f.name}" is bigger than 25 MB.` });
    setBusy(true);
    try { onChange(await uploadImage(f, folder, { maxW, maxH, png })); }
    catch (e: any) { notify({ type: 'err', text: e.message }); }
    setBusy(false);
  };

  return (
    <div className="mb-3">
      <span className={labelCls}>{label}</span>
      <div className="flex items-center gap-3">
        {value
          ? <img src={value} alt="" className={`${size} object-cover border border-[var(--Bdr)] bg-gray-100 shrink-0`} />
          : <div className={`${size} border-2 border-dashed border-[var(--Bdr)] shrink-0 flex items-center justify-center text-gray-300`}><Upload size={18} /></div>}
        <div className="flex flex-col gap-2">
          <button type="button" onClick={() => ref.current?.click()} disabled={busy}
            className="px-3 py-2 rounded-xl border border-[var(--Bdr)] text-[11px] font-black uppercase tracking-widest text-tac-blue disabled:opacity-50">
            {busy ? 'Uploading…' : value ? 'Change picture' : 'Choose picture'}
          </button>
          {value && !busy && (
            <button type="button" onClick={() => onChange('')} className="text-[11px] font-black uppercase tracking-widest text-red-500 text-left inline-flex items-center gap-1"><X size={12} /> Remove</button>
          )}
        </div>
        <input ref={ref} type="file" accept="image/*" hidden onChange={(e) => choose(e.target.files)} />
      </div>
      {hint && <p className="text-[11px] text-gray-400 mt-1.5 px-1">{hint}</p>}
    </div>
  );
};

/** Loads one website setting and saves it back (only an admin can). */
export function useSetting<T>(key: string, fallback: T) {
  const [value, setValue] = useState<T>(fallback);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [dirty, setDirty] = useState(false);

  React.useEffect(() => {
    let alive = true;
    getSetting<any>(key).then((v) => {
      if (!alive) return;
      if (Array.isArray(fallback)) setValue((Array.isArray(v) ? v : fallback) as T);
      else setValue((v && typeof v === 'object' && !Array.isArray(v) ? { ...(fallback as any), ...v } : fallback) as T);
      setLoading(false);
    });
    return () => { alive = false; };
  }, [key]); // eslint-disable-line react-hooks/exhaustive-deps

  const update = (next: T) => { setValue(next); setDirty(true); };
  const save = async (notify: Notify, label: string, override?: T): Promise<boolean> => {
    setSaving(true);
    try {
      await setSetting(key, override ?? value);
      setDirty(false);
      notify({ type: 'ok', text: `${label} saved. It is live on the website now.` });
      return true;
    } catch (e: any) { notify({ type: 'err', text: errText(e) }); return false; }
    finally { setSaving(false); }
  };
  return { value, update, loading, saving, dirty, save };
}
