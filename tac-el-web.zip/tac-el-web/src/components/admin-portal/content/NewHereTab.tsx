import React, { useState } from 'react';
import { ArrowUp, ArrowDown, ChevronDown, ChevronRight, Plus, Trash2 } from 'lucide-react';
import { Card, GhostBtn, ImageField, Notify, PrimaryBtn, TextField, hintCls, inputCls, isHttps, labelCls, useSetting } from './websiteShared';

/**
 * Admin > Website > I'm New
 * Builds the website's "I'm New" page from blocks (add, edit, delete, reorder). Array order = page order.
 * Block types: steps (numbered), cards, text (with an optional photo), faq (questions and answers),
 * connect (the visitor card form). Limits: 30 blocks, 24 items per block.
 */

type BlockType = 'steps' | 'cards' | 'text' | 'faq' | 'connect';
interface Item { title?: string; time?: string; text?: string; q?: string; a?: string }
interface Block { type: BlockType; title?: string; body?: string; items?: Item[]; image_url?: string; image_side?: 'left' | 'right'; options?: string[] }
interface NewHere { intro: string; blocks: Block[] }

const MAX_BLOCKS = 30;
const MAX_ITEMS = 24;

const TYPE_INFO: Record<BlockType, { label: string; help: string }> = {
  steps: { label: 'Numbered steps', help: 'For example "What to expect on Sunday".' },
  cards: { label: 'Cards', help: 'Three-column cards: children and youth, parking, dress...' },
  text: { label: 'Text with a photo', help: 'A heading, some paragraphs and an optional picture.' },
  faq: { label: 'Questions and answers', help: 'Questions first-time visitors ask. They open when tapped.' },
  connect: { label: 'Visitor card', help: 'The form where visitors tell you they are coming. Messages arrive in Messages.' },
};

const BlockEditor: React.FC<{ block: Block; onChange: (b: Block) => void; notify: Notify }> = ({ block, onChange, notify }) => {
  const set = (p: Partial<Block>) => onChange({ ...block, ...p });
  const items = block.items ?? [];
  const setItem = (i: number, p: Partial<Item>) => set({ items: items.map((it, k) => (k === i ? { ...it, ...p } : it)) });
  const addItem = () => { if (items.length >= MAX_ITEMS) return notify({ type: 'err', text: `At most ${MAX_ITEMS} items in one block.` }); set({ items: [...items, {}] }); };
  const delItem = (i: number) => set({ items: items.filter((_, k) => k !== i) });
  const moveItem = (i: number, d: number) => {
    const j = i + d; if (j < 0 || j >= items.length) return;
    const next = [...items]; [next[i], next[j]] = [next[j], next[i]]; set({ items: next });
  };

  const ItemTools = ({ i }: { i: number }) => (
    <div className="flex items-center gap-1">
      <button type="button" className="p-1.5 rounded-lg border border-[var(--Bdr)]" onClick={() => moveItem(i, -1)}><ArrowUp size={12} /></button>
      <button type="button" className="p-1.5 rounded-lg border border-[var(--Bdr)]" onClick={() => moveItem(i, 1)}><ArrowDown size={12} /></button>
      <button type="button" className="p-1.5 rounded-lg text-red-600" onClick={() => delItem(i)}><Trash2 size={13} /></button>
    </div>
  );

  return (
    <div>
      <TextField label="Heading" value={block.title || ''} onChange={(v) => set({ title: v })} />
      {block.type !== 'faq' && block.type !== 'cards' && (
        <TextField label={block.type === 'text' ? 'Paragraphs' : 'Short introduction (optional)'} value={block.body || ''} onChange={(v) => set({ body: v })} multiline rows={block.type === 'text' ? 6 : 2}
          hint={block.type === 'text' ? 'Leave an empty line to start a new paragraph.' : undefined} />
      )}

      {block.type === 'text' && (
        <>
          <ImageField label="Picture (optional)" value={block.image_url || ''} folder="gallery" notify={notify} maxW={1200} maxH={1200} onChange={(url) => set({ image_url: url })} />
          <div className="mb-3">
            <label className={labelCls}>Picture on the</label>
            <select className={inputCls} value={block.image_side || 'right'} onChange={(e) => set({ image_side: e.target.value as 'left' | 'right' })}>
              <option value="right">Right</option><option value="left">Left</option>
            </select>
          </div>
        </>
      )}

      {(block.type === 'steps' || block.type === 'cards' || block.type === 'faq') && (
        <div>
          <p className={labelCls}>{block.type === 'faq' ? 'Questions' : block.type === 'steps' ? 'Steps (in order)' : 'Cards'}</p>
          {items.map((it, i) => (
            <div key={i} className="rounded-2xl bg-gray-50 dark:bg-white/5 p-3 mb-2">
              <div className="flex items-center justify-between mb-2">
                <span className="text-[11px] font-black text-gray-400">{block.type === 'steps' ? `Step ${i + 1}` : `Item ${i + 1}`}</span>
                <ItemTools i={i} />
              </div>
              {block.type === 'faq' ? (
                <>
                  <TextField label="Question" value={it.q || ''} onChange={(v) => setItem(i, { q: v })} />
                  <TextField label="Answer" value={it.a || ''} onChange={(v) => setItem(i, { a: v })} multiline rows={3} />
                </>
              ) : (
                <>
                  <TextField label="Title" value={it.title || ''} onChange={(v) => setItem(i, { title: v })} />
                  {block.type === 'steps' && <TextField label="When (optional)" value={it.time || ''} onChange={(v) => setItem(i, { time: v })} placeholder="15 min before" />}
                  <TextField label="Text" value={it.text || ''} onChange={(v) => setItem(i, { text: v })} multiline rows={2} />
                </>
              )}
            </div>
          ))}
          <GhostBtn onClick={addItem}><Plus size={12} className="inline -mt-0.5" /> Add {block.type === 'faq' ? 'a question' : block.type === 'steps' ? 'a step' : 'a card'}</GhostBtn>
        </div>
      )}

      {block.type === 'connect' && (
        <TextField label={'"How did you hear about us?" choices'} value={(block.options || []).join('\n')} onChange={(v) => set({ options: v.split('\n') })}
          multiline rows={4} hint="One choice per line." />
      )}
    </div>
  );
};

export const NewHereTab: React.FC<{ notify: Notify }> = ({ notify }) => {
  const nh = useSetting<NewHere>('new_here', { intro: '', blocks: [] });
  const [open, setOpen] = useState<number | null>(null);
  const v = nh.value;
  const blocks = v.blocks ?? [];
  const setBlocks = (b: Block[]) => nh.update({ ...v, blocks: b });

  const add = (type: BlockType) => {
    if (blocks.length >= MAX_BLOCKS) return notify({ type: 'err', text: `At most ${MAX_BLOCKS} blocks.` });
    const start: Block = type === 'connect' ? { type, title: 'Let us know you are coming', options: ['A friend or family member', 'Social media', 'Other'] } : { type, title: '', items: type === 'text' ? undefined : [{}] };
    setBlocks([...blocks, start]); setOpen(blocks.length);
  };
  const move = (i: number, d: number) => {
    const j = i + d; if (j < 0 || j >= blocks.length) return;
    const next = [...blocks]; [next[i], next[j]] = [next[j], next[i]]; setBlocks(next); setOpen(j);
  };

  const save = () => {
    if (blocks.some((b) => b.image_url && !isHttps(b.image_url))) return notify({ type: 'err', text: 'Pictures must be https links (use the picture button).' });
    // leave out empty fields; the website treats missing as "not set"
    const clean: NewHere = {
      intro: (v.intro || '').trim(),
      blocks: blocks.map((b) => {
        const o: any = { type: b.type };
        if (b.title?.trim()) o.title = b.title.trim();
        if (b.body?.trim()) o.body = b.body.trim();
        if (b.type === 'steps' || b.type === 'cards' || b.type === 'faq') {
          o.items = (b.items ?? []).filter((it) => Object.values(it).some((x) => String(x || '').trim())).map((it) => {
            const r: any = {};
            (Object.keys(it) as (keyof Item)[]).forEach((k) => { if (String(it[k] || '').trim()) r[k] = String(it[k]).trim(); });
            return r;
          });
        }
        if (b.type === 'text') { if (b.image_url) { o.image_url = b.image_url; o.image_side = b.image_side || 'right'; } }
        if (b.type === 'connect') o.options = (b.options ?? []).map((x) => x.trim()).filter(Boolean);
        return o as Block;
      }),
    };
    nh.save(notify, "The I'm New page", clean);
  };

  return (
    <div className="space-y-4">
      <Card title="The I'm New page" hint="Build the page for first-time visitors from blocks. The page shows a friendly message until you add at least one block.">
        <TextField label="Welcome line under the heading" value={v.intro || ''} onChange={(x) => nh.update({ ...v, intro: x })} />
        {nh.dirty && <p className="text-[11px] font-black uppercase tracking-widest text-amber-600 mb-3">Unsaved changes</p>}

        {nh.loading ? <p className="text-xs text-gray-400">Loading…</p> : blocks.length === 0 ? <p className="text-xs text-gray-400 mb-3">No blocks yet. Add the first one below.</p> : blocks.map((b, i) => (
          <div key={i} className="rounded-2xl border border-[var(--Bdr)] mb-3 overflow-hidden">
            <div className="flex items-center gap-2 px-4 py-3 bg-gray-50 dark:bg-white/5">
              <button type="button" onClick={() => setOpen(open === i ? null : i)} className="flex items-center gap-2 min-w-0 flex-1 text-left">
                {open === i ? <ChevronDown size={16} /> : <ChevronRight size={16} />}
                <span className="text-[10px] font-black uppercase tracking-widest text-tac-blue shrink-0">{TYPE_INFO[b.type].label}</span>
                <span className="text-sm font-bold truncate">{b.title || '(no heading)'}</span>
              </button>
              <button type="button" className="p-1.5 rounded-lg border border-[var(--Bdr)]" onClick={() => move(i, -1)}><ArrowUp size={13} /></button>
              <button type="button" className="p-1.5 rounded-lg border border-[var(--Bdr)]" onClick={() => move(i, 1)}><ArrowDown size={13} /></button>
              <button type="button" className="p-1.5 rounded-lg text-red-600" onClick={() => { if (window.confirm('Delete this block?')) { setBlocks(blocks.filter((_, k) => k !== i)); setOpen(null); } }}><Trash2 size={14} /></button>
            </div>
            {open === i && <div className="p-4"><BlockEditor block={b} notify={notify} onChange={(nb) => setBlocks(blocks.map((x, k) => (k === i ? nb : x)))} /></div>}
          </div>
        ))}

        <p className={`${hintCls} mt-2`}>Add a block:</p>
        <div className="flex flex-wrap gap-2 mb-5">
          {(Object.keys(TYPE_INFO) as BlockType[]).map((t) => (
            <button key={t} type="button" title={TYPE_INFO[t].help} onClick={() => add(t)}
              className="px-3 py-2 rounded-xl border border-[var(--Bdr)] text-[11px] font-black uppercase tracking-wider text-tac-blue inline-flex items-center gap-1"><Plus size={12} /> {TYPE_INFO[t].label}</button>
          ))}
        </div>
        <PrimaryBtn onClick={save} busy={nh.saving}>Save the I'm New page</PrimaryBtn>
      </Card>
    </div>
  );
};

export default NewHereTab;
