import React, { useState, useEffect } from 'react';
import { noticesService } from '../../../services/contentService';
import { Notice } from '../../../types';
import { Bell, Plus, Trash2, Calendar, Tag } from 'lucide-react';
import { Card, Button, Badge } from '../../ui';

export const NoticesManager: React.FC = () => {
  const [notices, setNotices] = useState<Notice[]>([]);
  const [showAdd, setShowAdd] = useState(false);
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [category, setCategory] = useState<'General' | 'Youth' | 'Women' | 'Men' | 'Choir'>('General');
  const [saving, setSaving] = useState(false);

  const loadNotices = async () => {
    try {
      setNotices(await noticesService.getNotices());
    } catch (e) {
      // fallback
    }
  };

  useEffect(() => {
    loadNotices();
  }, []);

  const handleAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !content.trim()) return;

    setSaving(true);
    try {
      await noticesService.addNotice({ title: title.trim(), body: content.trim() });

      setTitle('');
      setContent('');
      setShowAdd(false);
      await loadNotices();
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (confirm('Delete this notice?')) {
      await noticesService.deleteNotice(id);
      await loadNotices();
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-xl font-black text-tac-blue-dark dark:text-white uppercase tracking-tight">
            Assembly Noticeboard Manager
          </h2>
          <p className="text-xs text-[var(--Sub)]">
            Publish weekly announcements, pastoral letters, and circulars
          </p>
        </div>

        <Button
          variant="primary"
          onClick={() => setShowAdd(!showAdd)}
          icon={<Plus size={16} />}
        >
          {showAdd ? 'Cancel' : 'Post Notice'}
        </Button>
      </div>

      {showAdd && (
        <Card className="animate-fadeIn border-tac-blue">
          <h3 className="text-sm font-black uppercase tracking-wider text-tac-blue-dark dark:text-white mb-4">
            Create Notice
          </h3>

          <form onSubmit={handleAdd} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
                  Notice Heading
                </label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g. Presbytery Council Meeting This Friday"
                  className="w-full px-4 py-2.5 bg-gray-50 dark:bg-slate-800 border border-[var(--Bdr)] rounded-2xl text-sm font-bold outline-none"
                />
              </div>

              <div>
                <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
                  Department / Target
                </label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value as any)}
                  className="w-full px-4 py-2.5 bg-gray-50 dark:bg-slate-800 border border-[var(--Bdr)] rounded-2xl text-sm font-bold outline-none"
                >
                  <option value="General">General Assembly</option>
                  <option value="Youth">Youth & Witness Wing</option>
                  <option value="Women">Women's Movement</option>
                  <option value="Men">Men's Ministry</option>
                  <option value="Choir">Choir & Music Team</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
                Announcement Body
              </label>
              <textarea
                required
                rows={4}
                value={content}
                onChange={(e) => setContent(e.target.value)}
                placeholder="Full notice text..."
                className="w-full px-4 py-3 bg-gray-50 dark:bg-slate-800 border border-[var(--Bdr)] rounded-2xl text-sm outline-none"
              />
            </div>

            <div className="flex justify-end gap-3 pt-2">
              <Button type="button" variant="ghost" onClick={() => setShowAdd(false)}>
                Cancel
              </Button>
              <Button type="submit" variant="primary" loading={saving}>
                Publish Notice
              </Button>
            </div>
          </form>
        </Card>
      )}

      <div className="space-y-4">
        {notices.map((n) => (
          <Card key={n.id}>
            <div className="flex items-start justify-between gap-3">
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <Badge variant="blue">{n.type === "urg" ? "Urgent" : n.type === "pin" ? "Pinned" : "General"}</Badge>
                  <span className="text-[10px] text-gray-400">{n.date}</span>
                </div>
                <h4 className="font-bold text-sm text-tac-blue-dark dark:text-white uppercase">{n.title}</h4>
              </div>

              <button
                onClick={() => handleDelete(n.id)}
                className="p-2 text-gray-400 hover:text-red-500"
              >
                <Trash2 size={16} />
              </button>
            </div>

            <p className="text-xs text-[var(--Sub)] mt-2 whitespace-pre-wrap leading-relaxed">
              {n.body}
            </p>
          </Card>
        ))}
      </div>
    </div>
  );
};
export default NoticesManager;
