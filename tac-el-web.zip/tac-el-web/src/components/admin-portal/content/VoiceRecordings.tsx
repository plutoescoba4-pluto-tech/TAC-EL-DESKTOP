import React, { useState, useEffect } from 'react';
import { Mic, Radio, Library, Trash2, RefreshCw, Clock } from 'lucide-react';
import { voiceRecordingsService, PendingRecording } from '../../../services/voiceRecordingsService';
import { Card, Button, Badge } from '../../ui';

const fmtDuration = (s: number) => `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;

interface Draft { title: string; speaker: string }

/** Admin inbox for Voice Sanctuary sessions. Each recording is previewed,
 *  then either posted as a sermon (members and presbytery see it in the
 *  Sermon Library) or saved to the recordings library, or discarded. */
export const VoiceRecordings: React.FC = () => {
  const [items, setItems] = useState<PendingRecording[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [busyPath, setBusyPath] = useState<string | null>(null);
  const [drafts, setDrafts] = useState<Record<string, Draft>>({});

  const load = async () => {
    setLoading(true);
    setError(null);
    try {
      const list = await voiceRecordingsService.listPending();
      setItems(list);
      setDrafts((prev) => {
        const next = { ...prev };
        for (const r of list) {
          if (!next[r.path]) {
            next[r.path] = {
              title: `Voice Sanctuary — ${new Date(r.recordedAt).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' })}`,
              speaker: r.hostName.replace(/\b\w/g, (ch) => ch.toUpperCase()),
            };
          }
        }
        return next;
      });
    } catch (e: any) {
      setError(
        e?.message?.toLowerCase().includes('bucket')
          ? 'The "voice-sanctuary" storage bucket was not found. Create it in Supabase Storage (see MIGRATION_NOTES.md).'
          : e?.message || 'Could not load recordings.'
      );
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);

  const run = async (rec: PendingRecording, action: () => Promise<void>) => {
    setBusyPath(rec.path);
    setError(null);
    try {
      await action();
      setItems((prev) => prev.filter((r) => r.path !== rec.path));
    } catch (e: any) {
      setError(e?.message || 'That did not work. Please try again.');
    } finally {
      setBusyPath(null);
    }
  };

  const setDraft = (path: string, patch: Partial<Draft>) =>
    setDrafts((d) => ({ ...d, [path]: { ...d[path], ...patch } }));

  return (
    <div className="p-4 lg:p-8 max-w-4xl mx-auto space-y-6">
      <div className="flex items-start justify-between gap-3">
        <div>
          <h2 className="text-2xl font-black font-serif text-tac-blue-dark dark:text-white tracking-tight flex items-center gap-2">
            <Mic size={22} className="text-tac-red" /> Voice Sanctuary Recordings
          </h2>
          <p className="text-xs text-[var(--Sub)] mt-1">
            Every prayer session is recorded automatically. Review it, then post it as a sermon or keep it in the library.
          </p>
        </div>
        <Button size="sm" variant="ghost" icon={<RefreshCw size={14} />} onClick={load}>Refresh</Button>
      </div>

      {error && (
        <div className="p-3 rounded-xl bg-red-50 dark:bg-red-950/30 text-tac-red text-xs font-medium flex justify-between gap-3">
          <span>{error}</span>
          <button onClick={() => setError(null)} className="font-black uppercase text-[10px] shrink-0">Dismiss</button>
        </div>
      )}

      {loading ? (
        <p className="text-center text-xs text-gray-400 py-10">Loading recordings…</p>
      ) : items.length === 0 ? (
        <Card><p className="text-center text-xs text-gray-400 py-8">No recordings waiting for review.</p></Card>
      ) : (
        <div className="space-y-4">
          {items.map((rec) => {
            const d = drafts[rec.path] || { title: '', speaker: '' };
            const busy = busyPath === rec.path;
            return (
              <Card key={rec.path} className="space-y-4 min-w-0">
                <div className="flex flex-wrap items-center gap-2">
                  <Badge variant="amber">Awaiting review</Badge>
                  <span className="text-[11px] text-gray-400">{new Date(rec.recordedAt).toLocaleString()}</span>
                  <span className="text-[11px] text-gray-400 flex items-center gap-1"><Clock size={11} /> {fmtDuration(rec.durationSec)}</span>
                  <span className="text-[11px] text-gray-400">Host: {rec.hostName}</span>
                </div>

                <audio controls preload="none" src={rec.url} className="w-full" />

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 min-w-0">
                  <div className="min-w-0">
                    <label className="text-[10px] font-black uppercase tracking-widest text-gray-400 mb-1 block">Title</label>
                    <input value={d.title} onChange={(e) => setDraft(rec.path, { title: e.target.value })}
                      className="w-full min-w-0 box-border px-3 py-2.5 bg-gray-50 dark:bg-slate-800 border border-[var(--Bdr)] rounded-xl text-sm outline-none focus:border-tac-blue" />
                  </div>
                  <div className="min-w-0">
                    <label className="text-[10px] font-black uppercase tracking-widest text-gray-400 mb-1 block">Speaker / Host</label>
                    <input value={d.speaker} onChange={(e) => setDraft(rec.path, { speaker: e.target.value })}
                      className="w-full min-w-0 box-border px-3 py-2.5 bg-gray-50 dark:bg-slate-800 border border-[var(--Bdr)] rounded-xl text-sm outline-none focus:border-tac-blue" />
                  </div>
                </div>

                <div className="flex flex-wrap gap-2">
                  <Button size="sm" loading={busy} icon={<Radio size={14} />} disabled={!d.title.trim()}
                    onClick={() => run(rec, () => voiceRecordingsService.postAsSermon(rec, d.title.trim(), d.speaker.trim() || rec.hostName))}>
                    Post as Sermon
                  </Button>
                  <Button size="sm" variant="secondary" loading={busy} icon={<Library size={14} />} disabled={!d.title.trim()}
                    onClick={() => run(rec, () => voiceRecordingsService.saveToLibrary(rec, d.title.trim()))}>
                    Save to Library
                  </Button>
                  <Button size="sm" variant="ghost" disabled={busy} icon={<Trash2 size={14} />}
                    onClick={() => { if (window.confirm('Discard this recording permanently?')) run(rec, () => voiceRecordingsService.discard(rec)); }}>
                    Discard
                  </Button>
                </div>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
};

export default VoiceRecordings;
