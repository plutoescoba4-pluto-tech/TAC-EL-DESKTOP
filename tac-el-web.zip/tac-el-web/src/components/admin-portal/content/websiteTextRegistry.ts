// Every piece of fixed text on the public website that the admin can change.
// GENERATED from the website's pages (each element carries a data-text="key" attribute).
// If new text is added to a website page, regenerate this list so it shows up in the editor.
export interface SiteTextItem { key: string; label: string; def: string }
export interface SiteTextPage { id: string; label: string; items: SiteTextItem[] }

export const SITE_TEXT_REGISTRY: SiteTextPage[] = [
  {
    "id": "home",
    "label": "Home",
    "items": [
      {
        "key": "home.1",
        "label": "Browser tab title",
        "def": "TAC East Legon Assembly — The Apostolic Church, Ghana"
      },
      {
        "key": "home.2",
        "label": "Heading",
        "def": "A house of prayer for every generation of East Legon"
      },
      {
        "key": "home.3",
        "label": "Paragraph",
        "def": "Madina District · East Legon Assembly"
      },
      {
        "key": "home.4",
        "label": "Paragraph",
        "def": "The Apostolic Church, Ghana gathers for worship, teaching and fellowship. Wherever you are in your walk, there's a seat for you here."
      },
      {
        "key": "home.5",
        "label": "Link / button",
        "def": "Get the TAC-EL App"
      },
      {
        "key": "home.6",
        "label": "Link / button",
        "def": "Plan a Visit"
      },
      {
        "key": "home.8",
        "label": "Heading",
        "def": "This week at TAC East Legon"
      },
      {
        "key": "home.9",
        "label": "Link / button",
        "def": "See all events"
      },
      {
        "key": "home.11",
        "label": "Heading",
        "def": "Find your people"
      },
      {
        "key": "home.12",
        "label": "Paragraph",
        "def": "There's a place to belong here. Browse what's active, then get the app to join."
      },
      {
        "key": "home.13",
        "label": "Link / button",
        "def": "Browse Clubs"
      },
      {
        "key": "home.15",
        "label": "Heading",
        "def": "Give online, safely and simply"
      },
      {
        "key": "home.16",
        "label": "Paragraph",
        "def": "Support the work of the church via Mobile Money or card — MTN MoMo, Vodafone Cash, AirtelTigo and more."
      },
      {
        "key": "home.17",
        "label": "Link / button",
        "def": "Give Now"
      },
      {
        "key": "home.18",
        "label": "Heading",
        "def": "New to TAC East Legon?"
      },
      {
        "key": "home.19",
        "label": "Paragraph",
        "def": "Come as you are. Whether church has been part of your life for years or you are just curious about Jesus, there is a seat for you here."
      },
      {
        "key": "home.20",
        "label": "Paragraph",
        "def": "Expect heartfelt worship, prayer and clear teaching from the Bible, and people who are glad you came."
      },
      {
        "key": "home.21",
        "label": "Link / button",
        "def": "Plan a Visit"
      },
      {
        "key": "home.22",
        "label": "Link / button",
        "def": "Our story"
      },
      {
        "key": "home.23",
        "label": "Heading",
        "def": "Worship with us from anywhere"
      },
      {
        "key": "home.24",
        "label": "Paragraph",
        "def": "Can't make it in person? Join our services online, or catch up on recent sermons."
      },
      {
        "key": "home.25",
        "label": "Link / button",
        "def": "Sermons and audio"
      },
      {
        "key": "home.28",
        "label": "Text",
        "def": "From our pastor"
      },
      {
        "key": "home.29",
        "label": "Heading",
        "def": "A word of welcome"
      },
      {
        "key": "home.30",
        "label": "Text",
        "def": "Visit us"
      },
      {
        "key": "home.31",
        "label": "Heading",
        "def": "We would love to see you"
      },
      {
        "key": "home.32",
        "label": "Link / button",
        "def": "Get directions"
      },
      {
        "key": "home.33",
        "label": "Link / button",
        "def": "Chat on WhatsApp"
      }
    ]
  },
  {
    "id": "about",
    "label": "About",
    "items": [
      {
        "key": "about.1",
        "label": "Browser tab title",
        "def": "About Us — TAC East Legon Assembly"
      },
      {
        "key": "about.2",
        "label": "Paragraph",
        "def": "Who we are"
      },
      {
        "key": "about.3",
        "label": "Heading",
        "def": "About TAC East Legon Assembly"
      },
      {
        "key": "about.4",
        "label": "Paragraph",
        "def": "Part of The Apostolic Church, Ghana — Madina District."
      },
      {
        "key": "about.5",
        "label": "Heading",
        "def": "Our Mission"
      },
      {
        "key": "about.6",
        "label": "Heading",
        "def": "Our Vision"
      },
      {
        "key": "about.7",
        "label": "Heading",
        "def": "Our Story"
      },
      {
        "key": "about.9",
        "label": "Link / button",
        "def": "Meet Our Leadership"
      },
      {
        "key": "about.10",
        "label": "Heading",
        "def": "What We Believe"
      },
      {
        "key": "about.11",
        "label": "Paragraph",
        "def": "Core convictions we hold as part of The Apostolic Church, Ghana."
      },
      {
        "key": "about.12",
        "label": "Paragraph",
        "def": "The Bible"
      },
      {
        "key": "about.13",
        "label": "Paragraph",
        "def": "We believe the Bible is God's inspired Word and our final authority for faith and life."
      },
      {
        "key": "about.14",
        "label": "Paragraph",
        "def": "Salvation"
      },
      {
        "key": "about.15",
        "label": "Paragraph",
        "def": "Salvation is by grace through faith in Jesus Christ — His death and resurrection."
      },
      {
        "key": "about.16",
        "label": "Paragraph",
        "def": "The Holy Spirit"
      },
      {
        "key": "about.17",
        "label": "Paragraph",
        "def": "We believe in the present-day work and baptism of the Holy Spirit, empowering believers for life and service."
      },
      {
        "key": "about.18",
        "label": "Paragraph",
        "def": "Water Baptism"
      },
      {
        "key": "about.19",
        "label": "Paragraph",
        "def": "We practice believer's baptism by immersion as a public declaration of faith."
      },
      {
        "key": "about.20",
        "label": "Paragraph",
        "def": "The Church"
      },
      {
        "key": "about.21",
        "label": "Paragraph",
        "def": "The Church is the body of Christ — we grow, worship, and serve together as family."
      },
      {
        "key": "about.22",
        "label": "Paragraph",
        "def": "Christ's Return"
      },
      {
        "key": "about.23",
        "label": "Paragraph",
        "def": "We believe in the promised return of Jesus Christ and hold to a life of readiness and hope."
      },
      {
        "key": "about.24",
        "label": "Heading",
        "def": "Join us this Sunday"
      },
      {
        "key": "about.25",
        "label": "Link / button",
        "def": "Get Directions & Contact"
      }
    ]
  },
  {
    "id": "sermons",
    "label": "Sermons",
    "items": [
      {
        "key": "sermons.1",
        "label": "Browser tab title",
        "def": "Sermons — TAC East Legon Assembly"
      },
      {
        "key": "sermons.2",
        "label": "Paragraph",
        "def": "Word for you"
      },
      {
        "key": "sermons.3",
        "label": "Heading",
        "def": "Sermons"
      },
      {
        "key": "sermons.4",
        "label": "Paragraph",
        "def": "Recent messages from TAC East Legon Assembly."
      },
      {
        "key": "sermons.5",
        "label": "Paragraph",
        "def": "No sermons posted yet — check back soon."
      }
    ]
  },
  {
    "id": "events",
    "label": "Events",
    "items": [
      {
        "key": "events.1",
        "label": "Browser tab title",
        "def": "Events — TAC East Legon Assembly"
      },
      {
        "key": "events.2",
        "label": "Paragraph",
        "def": "What's happening"
      },
      {
        "key": "events.3",
        "label": "Heading",
        "def": "Events"
      },
      {
        "key": "events.4",
        "label": "Paragraph",
        "def": "Everything on the calendar — services, programs and club meetings."
      },
      {
        "key": "events.5",
        "label": "Paragraph",
        "def": "No upcoming events right now — please check back soon."
      }
    ]
  },
  {
    "id": "clubs",
    "label": "Ministries",
    "items": [
      {
        "key": "clubs.1",
        "label": "Browser tab title",
        "def": "Clubs — TAC East Legon Assembly"
      },
      {
        "key": "clubs.2",
        "label": "Paragraph",
        "def": "Find your people"
      },
      {
        "key": "clubs.3",
        "label": "Heading",
        "def": "Clubs & Ministries"
      },
      {
        "key": "clubs.4",
        "label": "Paragraph",
        "def": "A glimpse of what's active at TAC East Legon. Get the app to see full details and join."
      },
      {
        "key": "clubs.5",
        "label": "Paragraph",
        "def": "Our ministries and clubs will be listed here soon."
      },
      {
        "key": "clubs.6",
        "label": "Heading",
        "def": "Ready to join one?"
      },
      {
        "key": "clubs.7",
        "label": "Paragraph",
        "def": "Get the TAC-EL app to see full details and apply."
      },
      {
        "key": "clubs.8",
        "label": "Link / button",
        "def": "Get the TAC-EL App"
      }
    ]
  },
  {
    "id": "leadership",
    "label": "Leadership",
    "items": [
      {
        "key": "leadership.1",
        "label": "Browser tab title",
        "def": "Leadership — TAC East Legon Assembly"
      },
      {
        "key": "leadership.2",
        "label": "Paragraph",
        "def": "Our leaders"
      },
      {
        "key": "leadership.3",
        "label": "Heading",
        "def": "Leadership"
      },
      {
        "key": "leadership.4",
        "label": "Paragraph",
        "def": "The pastors and elders serving TAC East Legon Assembly."
      },
      {
        "key": "leadership.5",
        "label": "Paragraph",
        "def": "Our pastors and elders will be introduced here soon. Please check back."
      }
    ]
  },
  {
    "id": "gallery",
    "label": "Gallery",
    "items": [
      {
        "key": "gallery.1",
        "label": "Browser tab title",
        "def": "Gallery — TAC East Legon Assembly"
      },
      {
        "key": "gallery.2",
        "label": "Paragraph",
        "def": "Moments"
      },
      {
        "key": "gallery.3",
        "label": "Heading",
        "def": "Gallery"
      },
      {
        "key": "gallery.4",
        "label": "Paragraph",
        "def": "Snapshots from services, events, and church life."
      },
      {
        "key": "gallery.5",
        "label": "Paragraph",
        "def": "No photos yet — check back soon."
      }
    ]
  },
  {
    "id": "give",
    "label": "Give",
    "items": [
      {
        "key": "give.1",
        "label": "Browser tab title",
        "def": "Give — TAC East Legon Assembly"
      },
      {
        "key": "give.2",
        "label": "Paragraph",
        "def": "Give"
      },
      {
        "key": "give.3",
        "label": "Heading",
        "def": "Support the Work of the Church"
      },
      {
        "key": "give.4",
        "label": "Paragraph",
        "def": "Give safely by Mobile Money, bank transfer or secure online checkout."
      },
      {
        "key": "give.18",
        "label": "Paragraph",
        "def": "Transfer directly using the details below, and use your name as the payment reference."
      },
      {
        "key": "give.28",
        "label": "Paragraph",
        "def": "Scan with your phone camera or Mobile Money app to give."
      },
      {
        "key": "give.30",
        "label": "Heading",
        "def": "Why give?"
      },
      {
        "key": "give.31",
        "label": "Paragraph",
        "def": "Your giving keeps the ministries, outreach, and daily work of TAC East Legon Assembly running — from Sunday service to community support."
      },
      {
        "key": "give.32",
        "label": "Heading",
        "def": "Safe & Trusted"
      },
      {
        "key": "give.33",
        "label": "Paragraph",
        "def": "Online giving details will be available here soon. For now you can give at any of our services, or contact us and we will gladly help."
      },
      {
        "key": "give.34",
        "label": "Link / button",
        "def": "Contact us"
      },
      {
        "key": "give.35",
        "label": "Paragraph",
        "def": "You will be taken to a secure checkout page to complete your gift by card or Mobile Money."
      },
      {
        "key": "give.36",
        "label": "Paragraph",
        "def": "Send your gift to one of the numbers below, and keep your confirmation message as your receipt."
      },
      {
        "key": "give.37",
        "label": "Text",
        "def": "This website never asks for your card number or Mobile Money PIN."
      },
      {
        "key": "give.38",
        "label": "Text",
        "def": "Questions about giving? Please contact the church office."
      }
    ]
  },
  {
    "id": "contact",
    "label": "Contact",
    "items": [
      {
        "key": "contact.1",
        "label": "Browser tab title",
        "def": "Contact Us — TAC East Legon Assembly"
      },
      {
        "key": "contact.2",
        "label": "Paragraph",
        "def": "Get in touch"
      },
      {
        "key": "contact.3",
        "label": "Heading",
        "def": "Contact Us"
      },
      {
        "key": "contact.4",
        "label": "Paragraph",
        "def": "Assembly location and contact information — reach out any time."
      },
      {
        "key": "contact.5",
        "label": "Heading",
        "def": "Assembly Details"
      },
      {
        "key": "contact.6",
        "label": "Paragraph",
        "def": "Location"
      },
      {
        "key": "contact.7",
        "label": "Paragraph",
        "def": "Phone"
      },
      {
        "key": "contact.8",
        "label": "Paragraph",
        "def": "Email"
      },
      {
        "key": "contact.9",
        "label": "Heading",
        "def": "Service Times"
      },
      {
        "key": "contact.11",
        "label": "Heading",
        "def": "Send a Message"
      },
      {
        "key": "contact.12",
        "label": "Form label",
        "def": "Full name"
      },
      {
        "key": "contact.13",
        "label": "Form label",
        "def": "Email or phone"
      },
      {
        "key": "contact.14",
        "label": "Form label",
        "def": "Message"
      },
      {
        "key": "contact.15",
        "label": "Button",
        "def": "Send Message"
      },
      {
        "key": "contact.16",
        "label": "Paragraph",
        "def": "Our address and phone details will appear here soon. In the meantime, please send us a message."
      },
      {
        "key": "contact.17",
        "label": "Link / button",
        "def": "Get directions"
      },
      {
        "key": "contact.18",
        "label": "Link / button",
        "def": "WhatsApp us"
      },
      {
        "key": "contact.19",
        "label": "Paragraph",
        "def": "Your message goes straight to the church office, who will get back to you."
      }
    ]
  },
  {
    "id": "newhere",
    "label": "I'm New",
    "items": [
      {
        "key": "newhere.1",
        "label": "Browser tab title",
        "def": "I'm New — Plan Your Visit | TAC East Legon Assembly"
      },
      {
        "key": "newhere.2",
        "label": "Paragraph",
        "def": "New here?"
      },
      {
        "key": "newhere.3",
        "label": "Heading",
        "def": "We are glad you are here"
      },
      {
        "key": "newhere.4",
        "label": "Paragraph",
        "def": "Everything you need to know before your first visit to TAC East Legon Assembly."
      },
      {
        "key": "newhere.5",
        "label": "Paragraph",
        "def": "Our guide for first-time visitors is on its way. In the meantime, you are warmly welcome at any of our services, and you can reach us any time."
      },
      {
        "key": "newhere.6",
        "label": "Link / button",
        "def": "Contact us"
      },
      {
        "key": "newhere.7",
        "label": "Heading",
        "def": "Plan your visit"
      },
      {
        "key": "newhere.8",
        "label": "Link / button",
        "def": "Get directions"
      },
      {
        "key": "newhere.9",
        "label": "Link / button",
        "def": "Ask us on WhatsApp"
      }
    ]
  },
  {
    "id": "getapp",
    "label": "Get the App",
    "items": [
      {
        "key": "getapp.1",
        "label": "Browser tab title",
        "def": "Get the TAC-EL App — TAC East Legon Assembly"
      },
      {
        "key": "getapp.2",
        "label": "Paragraph",
        "def": "The TAC-EL App"
      },
      {
        "key": "getapp.3",
        "label": "Heading",
        "def": "Your church, in your pocket."
      },
      {
        "key": "getapp.4",
        "label": "Paragraph",
        "def": "Give, join a ministry, chat with your church family, catch sermons, and stay connected — all from the TAC-EL app. Coming soon to Android and iOS."
      },
      {
        "key": "getapp.5",
        "label": "Text",
        "def": "Get it for"
      },
      {
        "key": "getapp.6",
        "label": "Text",
        "def": "Android"
      },
      {
        "key": "getapp.7",
        "label": "Text",
        "def": "Get it for"
      },
      {
        "key": "getapp.8",
        "label": "Text",
        "def": "iPhone & iPad"
      },
      {
        "key": "getapp.9",
        "label": "Text",
        "def": "Continue on"
      },
      {
        "key": "getapp.10",
        "label": "Text",
        "def": "Desktop"
      },
      {
        "key": "getapp.11",
        "label": "Paragraph",
        "def": "On a computer, the first time you open TAC-EL you see a welcome screen with a code. Scan it with the TAC-EL app on your phone (Linked Devices) and you are in. Use it in your browser or download the desktop app."
      },
      {
        "key": "getapp.12",
        "label": "Paragraph",
        "def": "Android: get it from Google Play or download it directly. iPhone and iPad: follow the short steps on the next page."
      },
      {
        "key": "getapp.13",
        "label": "Paragraph",
        "def": "Give"
      },
      {
        "key": "getapp.14",
        "label": "Paragraph",
        "def": "Give via Mobile Money or card, anytime."
      },
      {
        "key": "getapp.15",
        "label": "Paragraph",
        "def": "Connect"
      },
      {
        "key": "getapp.16",
        "label": "Paragraph",
        "def": "Chat, join a club, and get notified about what matters to you."
      },
      {
        "key": "getapp.17",
        "label": "Paragraph",
        "def": "Grow"
      },
      {
        "key": "getapp.18",
        "label": "Paragraph",
        "def": "Sermons, Bible, hymns, and an AI study companion, always with you."
      }
    ]
  },
  {
    "id": "getandroid",
    "label": "Get on Android (page)",
    "items": [
      {
        "key": "getandroid.1",
        "label": "Browser tab title",
        "def": "Get the TAC-EL App on Android — TAC East Legon Assembly"
      },
      {
        "key": "getandroid.2",
        "label": "Paragraph",
        "def": "Android"
      },
      {
        "key": "getandroid.3",
        "label": "Heading",
        "def": "Get TAC-EL on your Android phone"
      },
      {
        "key": "getandroid.4",
        "label": "Paragraph",
        "def": "Choose the way that suits you. Both give you the same app."
      },
      {
        "key": "getandroid.5",
        "label": "Paragraph",
        "def": "Option 1"
      },
      {
        "key": "getandroid.6",
        "label": "Heading",
        "def": "Google Play"
      },
      {
        "key": "getandroid.7",
        "label": "Paragraph",
        "def": "The easiest way, with automatic updates."
      },
      {
        "key": "getandroid.8",
        "label": "Link / button",
        "def": "Get it on Google Play"
      },
      {
        "key": "getandroid.9",
        "label": "Paragraph",
        "def": "Coming soon to Google Play."
      },
      {
        "key": "getandroid.10",
        "label": "Paragraph",
        "def": "Option 2"
      },
      {
        "key": "getandroid.11",
        "label": "Heading",
        "def": "Download the app directly"
      },
      {
        "key": "getandroid.12",
        "label": "Paragraph",
        "def": "Download the app file (APK) and install it yourself. It takes about a minute."
      },
      {
        "key": "getandroid.13",
        "label": "Link / button",
        "def": "Download the app (APK)"
      },
      {
        "key": "getandroid.14",
        "label": "Paragraph",
        "def": "The direct download will be available here soon."
      },
      {
        "key": "getandroid.15",
        "label": "Heading",
        "def": "Installing the direct download"
      },
      {
        "key": "getandroid.16",
        "label": "Heading",
        "def": "Tap “Download the app”"
      },
      {
        "key": "getandroid.17",
        "label": "Paragraph",
        "def": "If your browser says this type of file can be harmful, tap Download anyway. It is safe when it comes from this page."
      },
      {
        "key": "getandroid.18",
        "label": "Heading",
        "def": "Open the file you downloaded"
      },
      {
        "key": "getandroid.19",
        "label": "Paragraph",
        "def": "Tap the download notification, or open it from your Downloads folder."
      },
      {
        "key": "getandroid.20",
        "label": "Heading",
        "def": "Allow the install"
      },
      {
        "key": "getandroid.21",
        "label": "Paragraph",
        "def": "If Android asks, allow your browser to install apps from this source, go back, and tap Install. If Play Protect shows a warning, tap More details, then Install anyway."
      },
      {
        "key": "getandroid.22",
        "label": "Heading",
        "def": "Open TAC-EL and turn on notifications"
      },
      {
        "key": "getandroid.23",
        "label": "Paragraph",
        "def": "Sign in or create your account, and tap Allow when the app asks to send you notifications."
      },
      {
        "key": "getandroid.24",
        "label": "Paragraph",
        "def": "Please note"
      },
      {
        "key": "getandroid.25",
        "label": "Paragraph",
        "def": "Only download the app from this official TAC East Legon page, never from a link someone forwards to you. When a new version is available, come back here and download it again."
      },
      {
        "key": "getandroid.26",
        "label": "Link / button",
        "def": "← Back to all download options"
      }
    ]
  },
  {
    "id": "getios",
    "label": "Get on iPhone (instructions page)",
    "items": [
      {
        "key": "getios.1",
        "label": "Browser tab title",
        "def": "Get the TAC-EL App on iPhone — TAC East Legon Assembly"
      },
      {
        "key": "getios.2",
        "label": "Paragraph",
        "def": "iPhone & iPad"
      },
      {
        "key": "getios.3",
        "label": "Heading",
        "def": "Add TAC-EL to your iPhone"
      },
      {
        "key": "getios.4",
        "label": "Paragraph",
        "def": "No App Store needed. It takes less than a minute, and the app then sits on your Home Screen like any other app."
      },
      {
        "key": "getios.5",
        "label": "Paragraph",
        "def": "Before you start"
      },
      {
        "key": "getios.6",
        "label": "Paragraph",
        "def": "Use Safari, and make sure your iPhone has iOS 16.4 or newer (Settings, General, About). That is what lets you receive notifications."
      },
      {
        "key": "getios.7",
        "label": "Heading",
        "def": "Tap the Get button below"
      },
      {
        "key": "getios.8",
        "label": "Paragraph",
        "def": "It opens the TAC-EL app in Safari."
      },
      {
        "key": "getios.9",
        "label": "Heading",
        "def": "Tap the Share button"
      },
      {
        "key": "getios.10",
        "label": "Paragraph",
        "def": "It is the square with an arrow pointing up, at the bottom of the screen."
      },
      {
        "key": "getios.11",
        "label": "Heading",
        "def": "Choose “Add to Home Screen”"
      },
      {
        "key": "getios.12",
        "label": "Paragraph",
        "def": "Scroll down the list, tap Add to Home Screen, then tap Add."
      },
      {
        "key": "getios.13",
        "label": "Heading",
        "def": "Open TAC-EL from your Home Screen"
      },
      {
        "key": "getios.14",
        "label": "Paragraph",
        "def": "Use the new TAC-EL icon, not Safari. Sign in or create your account."
      },
      {
        "key": "getios.15",
        "label": "Heading",
        "def": "Turn on notifications"
      },
      {
        "key": "getios.16",
        "label": "Paragraph",
        "def": "When the app asks to send you notifications, tap Allow. If you missed it, go to Settings, Notifications, TAC-EL, and switch on Allow Notifications."
      },
      {
        "key": "getios.17",
        "label": "Link / button",
        "def": "Get the TAC-EL App"
      },
      {
        "key": "getios.18",
        "label": "Paragraph",
        "def": "The app link will appear here soon."
      },
      {
        "key": "getios.19",
        "label": "Link / button",
        "def": "← Back to all download options"
      }
    ]
  },
  {
    "id": "menu",
    "label": "Menu (top of every page)",
    "items": [
      {
        "key": "menu.1",
        "label": "Small text",
        "def": "THE APOSTOLIC CHURCH — GHANA"
      },
      {
        "key": "menu.2",
        "label": "Link / button",
        "def": "Home"
      },
      {
        "key": "menu.3",
        "label": "Link / button",
        "def": "About"
      },
      {
        "key": "menu.4",
        "label": "Link / button",
        "def": "Sermons"
      },
      {
        "key": "menu.5",
        "label": "Link / button",
        "def": "Events"
      },
      {
        "key": "menu.6",
        "label": "Link / button",
        "def": "Ministries"
      },
      {
        "key": "menu.7",
        "label": "Link / button",
        "def": "Leadership"
      },
      {
        "key": "menu.8",
        "label": "Link / button",
        "def": "Gallery"
      },
      {
        "key": "menu.9",
        "label": "Link / button",
        "def": "Give"
      },
      {
        "key": "menu.10",
        "label": "Link / button",
        "def": "Contact"
      },
      {
        "key": "menu.11",
        "label": "Link / button",
        "def": "Get the TAC-EL App"
      },
      {
        "key": "menu.12",
        "label": "Link / button",
        "def": "I'm New"
      },
      {
        "key": "menu.13",
        "label": "Link / button",
        "def": "Skip to content"
      }
    ]
  },
  {
    "id": "footer",
    "label": "Footer (bottom of every page)",
    "items": [
      {
        "key": "footer.1",
        "label": "Text",
        "def": "TAC East Legon Assembly"
      },
      {
        "key": "footer.2",
        "label": "Paragraph",
        "def": "The Apostolic Church, Ghana — East Legon Assembly."
      },
      {
        "key": "footer.3",
        "label": "Heading",
        "def": "Explore"
      },
      {
        "key": "footer.4",
        "label": "Heading",
        "def": "Visit us"
      },
      {
        "key": "footer.5",
        "label": "Heading",
        "def": "Service times"
      },
      {
        "key": "menu.3",
        "label": "Link / button",
        "def": "About"
      },
      {
        "key": "menu.4",
        "label": "Link / button",
        "def": "Sermons"
      },
      {
        "key": "menu.5",
        "label": "Link / button",
        "def": "Events"
      },
      {
        "key": "menu.6",
        "label": "Link / button",
        "def": "Ministries"
      },
      {
        "key": "menu.9",
        "label": "Link / button",
        "def": "Give"
      },
      {
        "key": "menu.10",
        "label": "Link / button",
        "def": "Contact"
      },
      {
        "key": "menu.12",
        "label": "Link / button",
        "def": "I'm New"
      }
    ]
  }
];
