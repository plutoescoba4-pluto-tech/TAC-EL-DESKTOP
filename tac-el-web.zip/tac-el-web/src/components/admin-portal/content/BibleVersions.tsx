import React, { useState } from 'react';
import { BookOpen, Check, ToggleLeft, ToggleRight, Download } from 'lucide-react';
import { Card, Badge, Button } from '../../ui';

interface BibleVersion {
  id: string;
  name: string;
  code: string;
  language: string;
  enabled: boolean;
  offlineReady: boolean;
}

export const BibleVersions: React.FC = () => {
  const [versions, setVersions] = useState<BibleVersion[]>([
    { id: 'kjv', name: 'King James Version', code: 'KJV', language: 'English', enabled: true, offlineReady: true },
    { id: 'niv', name: 'New International Version', code: 'NIV', language: 'English', enabled: true, offlineReady: true },
    { id: 'twi', name: 'Twi Bible (Akuapem / Asante)', code: 'TWI', language: 'Akan (Twi)', enabled: true, offlineReady: true },
    { id: 'fante', name: 'Fante Bible (Baebor)', code: 'FAN', language: 'Fante', enabled: true, offlineReady: false },
    { id: 'ga', name: 'Ga Holy Bible', code: 'GA', language: 'Ga', enabled: false, offlineReady: false },
    { id: 'esv', name: 'English Standard Version', code: 'ESV', language: 'English', enabled: true, offlineReady: true }
  ]);

  const toggleVersion = (id: string) => {
    setVersions(versions.map(v => v.id === id ? { ...v, enabled: !v.enabled } : v));
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-xl font-black text-tac-blue-dark dark:text-white uppercase tracking-tight">
            Bible Translations & Versions
          </h2>
          <p className="text-xs text-[var(--Sub)]">
            Manage enabled scriptures, indigenous Ghanaian translations, and offline caches
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {versions.map((ver) => (
          <Card key={ver.id}>
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-tac-blue/10 text-tac-blue flex items-center justify-center font-black text-sm">
                  {ver.code}
                </div>
                <div>
                  <h4 className="font-bold text-sm text-tac-blue-dark dark:text-white uppercase">{ver.name}</h4>
                  <p className="text-[11px] text-[var(--Sub)]">{ver.language}</p>
                </div>
              </div>

              <button
                onClick={() => toggleVersion(ver.id)}
                className="text-2xl transition-transform"
              >
                {ver.enabled ? (
                  <ToggleRight size={32} className="text-tac-blue" />
                ) : (
                  <ToggleLeft size={32} className="text-gray-400" />
                )}
              </button>
            </div>

            <div className="mt-4 pt-3 border-t border-[var(--Bdr)] flex items-center justify-between text-xs">
              <span className="text-[10px] text-gray-400">
                {ver.offlineReady ? 'Offline Preloaded' : 'Cloud Dynamic'}
              </span>
              <Badge variant={ver.enabled ? 'green' : 'gray'}>
                {ver.enabled ? 'Active Translation' : 'Disabled'}
              </Badge>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
};
export default BibleVersions;
