import React, { useState, useEffect } from 'react';
import { sermonsService } from '../../../services/contentService';
import { Sermon } from '../../../types';
import { Plus, Trash2, Headphones, Video, Image as ImageIcon, Link2, X } from 'lucide-react';
import { Card, Button, Badge } from '../../ui';
import { SermonMedia } from '../../shared/SermonMedia';

const field = 'w-full px-4 py-2.5 bg-gray-50 dark:bg-slate-800 border border-[var(--Bdr)] rounded-2xl text-sm outline-none';
const label = 'block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1';
const MAX_MB = 50;

/** One optional media slot: upload a file OR paste a link. Leave it empty to skip it. */
const MediaSlot: React.FC<{
  title: string; icon: React.ReactNode; accept: string; hint: string; allowLink?: boolean;
  file: File | null; setFile: (f: File | null) => void; link: string; setLink: (v: string) => void;
}> = ({ title, icon, accept, hint, allowLink = true, file, setFile, link, setLink }) => (
  <div className="rounded-2xl border border-dashed border-[var(--Bdr)] p-3 space-y-2">
    <div className="flex items-center gap-2 text-[11px] font-black uppercase tracking-wider text-tac-blue-dark dark:text-white">
      {icon} {title} <span className="text-gray-400 font-bold normal-case tracking-normal">(optional)</span>
    </div>
    {file ? (
      <div className="flex items-center justify-between gap-2 text-xs bg-tac-blue/5 rounded-xl px-3 py-2">
        <span className="truncate font-semibold">{file.name} ({(file.size / (1024 * 1024)).toFixed(1)} MB)</span>
        <button type="button" onClick={() => setFile(null)} className="text-gray-500 hover:text-red-500"><X size={16} /></button>
      </div>
    ) : (
      <input
        type="file" accept={accept}
        onChange={(e) => {
          const f = e.target.files?.[0] || null;
          if (f && f.size > MAX_MB * 1024 * 1024) { alert(`That file is ${(f.size / 1048576).toFixed(0)} MB. The limit is ${MAX_MB} MB. Paste a link instead.`); e.target.value = ''; return; }
          setFile(f);
        }}
        className="block w-full text-xs"
      />
    )}
    {allowLink && !file && (
      <input type="url" value={link} onChange={(e) => setLink(e.target.value)} placeholder="or paste a link  https://..." className={field} />
    )}
    <p className="text-[10px] text-gray-400">{hint}</p>
  </div>
);

export const SermonsManager: React.FC = () => {
  const [sermons, setSermons] = useState<Sermon[]>([]);
  const [showAdd, setShowAdd] = useState(false);
  const [title, setTitle] = useState('');
  const [preacher, setPreacher] = useState('');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [scripture, setScripture] = useState('');
  const [description, setDescription] = useState('');
  const [audioFile, setAudioFile] = useState<File | null>(null);
  const [audioUrl, setAudioUrl] = useState('');
  const [videoFile, setVideoFile] = useState<File | null>(null);
  const [videoUrl, setVideoUrl] = useState('');
  const [coverFile, setCoverFile] = useState<File | null>(null);
  const [linkUrl, setLinkUrl] = useState('');
  const [onWebsite, setOnWebsite] = useState(true);
  const [saving, setSaving] = useState(false);
  const [step, setStep] = useState('');

  const loadSermons = async () => {
    try { setSermons(await sermonsService.getSermons()); } catch { /* keep list as is */ }
  };
  useEffect(() => { loadSermons(); }, []);

  const reset = () => {
    setTitle(''); setPreacher(''); setScripture(''); setDescription(''); setDate(new Date().toISOString().split('T')[0]);
    setAudioFile(null); setAudioUrl(''); setVideoFile(null); setVideoUrl(''); setCoverFile(null); setLinkUrl('');
    setOnWebsite(true); setShowAdd(false);
  };

  const handleAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !preacher.trim()) return;
    setSaving(true);
    try {
      // upload only what was chosen; anything left empty is simply not saved
      let a = audioUrl.trim(); let v = videoUrl.trim(); let c = '';
      if (audioFile) { setStep('Uploading audio...'); a = await sermonsService.uploadMedia(audioFile, 'audio'); }
      if (videoFile) { setStep('Uploading video...'); v = await sermonsService.uploadMedia(videoFile, 'video'); }
      if (coverFile) { setStep('Uploading cover picture...'); c = await sermonsService.uploadMedia(coverFile, 'cover'); }
      setStep('Saving...');
      await sermonsService.addSermon({
        title: title.trim(), speaker: preacher.trim(), date,
        audioUrl: a || undefined, videoUrl: v || undefined, coverUrl: c || undefined,
        linkUrl: linkUrl.trim() || undefined, scripture: scripture.trim() || undefined,
        description: description.trim() || undefined, showOnWebsite: onWebsite,
      });
      reset();
      await loadSermons();
    } catch (err: any) {
      alert(err?.message || 'Failed to save sermon. Please try again.');
    } finally {
      setSaving(false); setStep('');
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Delete this sermon?')) return;
    try { await sermonsService.deleteSermon(id); await loadSermons(); }
    catch (err: any) { alert(err?.message || 'Failed to delete sermon.'); }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
        <div>
          <h2 className="text-lg font-black text-tac-blue-dark dark:text-white uppercase tracking-tight">Sermon & Pulpit Archive</h2>
          <p className="text-xs text-[var(--Sub)]">Add a sermon with audio, video, a cover picture or a link. Everything except the title and preacher is optional.</p>
        </div>
        <Button variant="primary" onClick={() => (showAdd ? reset() : setShowAdd(true))} icon={<Plus size={16} />}>
          {showAdd ? 'Cancel' : 'Upload Sermon'}
        </Button>
      </div>

      {showAdd && (
        <Card className="animate-fadeIn border-tac-blue">
          <h3 className="text-sm font-black uppercase tracking-wider text-tac-blue-dark dark:text-white mb-4">Publish Sermon</h3>
          <form onSubmit={handleAdd} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div><label className={label}>Sermon theme / title</label>
                <input type="text" required value={title} onChange={(e) => setTitle(e.target.value)} placeholder="e.g. Walking in the Power of the Holy Spirit" className={`${field} font-bold`} /></div>
              <div><label className={label}>Preacher / minister</label>
                <input type="text" required value={preacher} onChange={(e) => setPreacher(e.target.value)} placeholder="e.g. Pastor Samuel Darko" className={`${field} font-bold`} /></div>
              <div><label className={label}>Date preached</label>
                <input type="date" value={date} onChange={(e) => setDate(e.target.value)} className={field} /></div>
              <div><label className={label}>Scripture reading</label>
                <input type="text" value={scripture} onChange={(e) => setScripture(e.target.value)} placeholder="e.g. Acts 2:1-4" className={field} /></div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <MediaSlot title="Audio" icon={<Headphones size={14} />} accept="audio/*" hint={`MP3, M4A, WAV. Up to ${MAX_MB} MB, or paste a link.`}
                file={audioFile} setFile={setAudioFile} link={audioUrl} setLink={setAudioUrl} />
              <MediaSlot title="Video" icon={<Video size={14} />} accept="video/mp4,video/webm,video/quicktime" hint={`MP4 up to ${MAX_MB} MB, or paste a YouTube / video link.`}
                file={videoFile} setFile={setVideoFile} link={videoUrl} setLink={setVideoUrl} />
              <MediaSlot title="Cover picture" icon={<ImageIcon size={14} />} accept="image/jpeg,image/png,image/webp" hint="Shown above the audio or video." allowLink={false}
                file={coverFile} setFile={setCoverFile} link="" setLink={() => {}} />
              <div className="rounded-2xl border border-dashed border-[var(--Bdr)] p-3 space-y-2">
                <div className="flex items-center gap-2 text-[11px] font-black uppercase tracking-wider text-tac-blue-dark dark:text-white">
                  <Link2 size={14} /> Social media link <span className="text-gray-400 font-bold normal-case tracking-normal">(optional)</span>
                </div>
                <input type="url" value={linkUrl} onChange={(e) => setLinkUrl(e.target.value)} placeholder="Facebook, YouTube, TikTok, WhatsApp channel..." className={field} />
                <p className="text-[10px] text-gray-400">Good when the message is posted somewhere else.</p>
              </div>
            </div>

            <div><label className={label}>Sermon notes</label>
              <textarea rows={3} value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Key points..." className={`${field} py-3`} /></div>

            <label className="flex items-center gap-2 text-xs font-bold text-tac-blue-dark dark:text-white">
              <input type="checkbox" checked={onWebsite} onChange={(e) => setOnWebsite(e.target.checked)} className="w-4 h-4" />
              Show on the public website
            </label>

            <div className="flex justify-end items-center gap-3 pt-1">
              {step && <span className="text-xs text-[var(--Sub)]">{step}</span>}
              <Button type="button" variant="ghost" onClick={reset}>Cancel</Button>
              <Button type="submit" variant="primary" loading={saving}>Publish</Button>
            </div>
          </form>
        </Card>
      )}

      <div className="space-y-4">
        {sermons.length === 0 ? (
          <Card><p className="py-8 text-center text-xs text-[var(--Sub)]">No sermons yet. Tap "Upload Sermon" to add the first message.</p></Card>
        ) : sermons.map((s) => (
          <Card key={s.id}>
            <div className="flex items-start justify-between gap-2 mb-3">
              <div className="min-w-0">
                <h4 className="font-bold text-sm text-tac-blue-dark dark:text-white uppercase break-words">{s.title}</h4>
                <p className="text-xs text-tac-blue font-semibold">{s.speaker}{s.scripture ? ` · ${s.scripture}` : ''}</p>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                <Badge variant="blue">{s.date}</Badge>
                <button onClick={() => handleDelete(s.id)} className="text-gray-400 hover:text-red-500 p-1" aria-label="Delete"><Trash2 size={16} /></button>
              </div>
            </div>
            <SermonMedia sermon={s} compact />
          </Card>
        ))}
      </div>
    </div>
  );
};
export default SermonsManager;
