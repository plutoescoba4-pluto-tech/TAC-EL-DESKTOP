import React, { useState, useEffect } from 'react';
import { hymnsService } from '../../../services/contentService';
import { Music, Plus, Edit3, Trash2, Search, Save, Check } from 'lucide-react';
import { Card, Button, Badge } from '../../ui';
import { Hymn, HymnSection } from '../../../types';
import { HymnSectionsEditor } from '../../shared/HymnSections';

export const HymnsManager: React.FC = () => {
  const [hymns, setHymns] = useState<Hymn[]>([]);
  const [search, setSearch] = useState('');
  const [showEditor, setShowEditor] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [number, setNumber] = useState('');
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState('Worship');
  const [sections, setSections] = useState<HymnSection[]>([]);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const loadHymns = async () => {
    try {
      setHymns(await hymnsService.getHymns());
    } catch (e) {
      // fallback
    }
  };

  useEffect(() => {
    loadHymns();
  }, []);

  const resetForm = () => {
    setEditingId(null); setNumber(''); setTitle(''); setCategory('Worship'); setSections([]); setError(null);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !number) return;
    const cleaned = sections.map((x) => ({ ...x, text: x.text.trim() })).filter((x) => x.text);
    if (!cleaned.length) { setError('Add at least one verse or chorus (paste the hymn, then split it).'); return; }
    setSaving(true); setError(null);
    try {
      const data = { number: parseInt(number), title: title.trim(), category, sections: cleaned };
      if (editingId) await hymnsService.updateHymn(editingId, data);
      else await hymnsService.addHymn(data as any);
      setShowEditor(false);
      resetForm();
      await loadHymns();
    } catch (err: any) {
      setError(err?.message || 'Could not save the hymn.');
    } finally {
      setSaving(false);
    }
  };

  const handleEdit = (h: Hymn) => {
    setEditingId(h.id);
    setNumber(String(h.number));
    setTitle(h.title);
    setCategory(h.category || 'Worship');
    setSections(h.sections || []);
    setError(null);
    setShowEditor(true);
  };

  const handleDelete = async (id: string) => {
    if (confirm('Delete this hymn?')) {
      await hymnsService.deleteHymn(id);
      await loadHymns();
    }
  };

  const filtered = hymns.filter(h =>
    h.title.toLowerCase().includes(search.toLowerCase()) ||
    String(h.number).includes(search)
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-xl font-black text-tac-blue-dark dark:text-white uppercase tracking-tight">
            Apostolic Hymnal Repository
          </h2>
          <p className="text-xs text-[var(--Sub)]">
            Manage hymn lyrics, stanzas, chorus, and praise categories
          </p>
        </div>

        <Button
          variant="primary"
          onClick={() => {
            resetForm();
            setShowEditor(!showEditor);
          }}
          icon={<Plus size={16} />}
        >
          {showEditor ? 'Cancel' : 'Add New Hymn'}
        </Button>
      </div>

      {showEditor && (
        <Card className="animate-fadeIn border-tac-blue">
          <h3 className="text-sm font-black uppercase tracking-wider text-tac-blue-dark dark:text-white mb-4">
            {editingId ? 'Edit Hymn' : 'Add Hymnal Entry'}
          </h3>

          <form onSubmit={handleSave} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
                  Hymn Number
                </label>
                <input
                  type="number"
                  required
                  value={number}
                  onChange={(e) => setNumber(e.target.value)}
                  placeholder="e.g. 1"
                  className="w-full px-4 py-2.5 bg-gray-50 dark:bg-slate-800 border border-[var(--Bdr)] rounded-2xl text-sm font-bold outline-none"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
                  Hymn Title
                </label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g. The Church's One Foundation"
                  className="w-full px-4 py-2.5 bg-gray-50 dark:bg-slate-800 border border-[var(--Bdr)] rounded-2xl text-sm font-bold outline-none"
                />
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">Category</label>
              <select value={category} onChange={(e) => setCategory(e.target.value)}
                className="w-full sm:w-64 px-4 py-2.5 bg-gray-50 dark:bg-slate-800 border border-[var(--Bdr)] rounded-2xl text-sm font-bold outline-none">
                {['Worship', 'Praise', 'Youth', 'Communion', 'Revival'].map((c) => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>

            <HymnSectionsEditor sections={sections} onChange={setSections} />
            {error && <p className="text-sm text-red-600">{error}</p>}

            <div className="flex justify-end gap-3 pt-2">
              <Button type="button" variant="ghost" onClick={() => { setShowEditor(false); resetForm(); }}>
                Cancel
              </Button>
              <Button type="submit" variant="primary" loading={saving}>
                Save Hymn
              </Button>
            </div>
          </form>
        </Card>
      )}

      <div className="flex items-center gap-3 bg-white dark:bg-slate-900 border border-[var(--Bdr)] rounded-2xl px-4 py-3">
        <Search size={18} className="text-gray-400" />
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search hymnal by title or number..."
          className="bg-transparent border-none outline-none text-sm text-[var(--Text)] dark:text-white font-medium w-full"
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filtered.map((h) => (
          <Card key={h.id}>
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-center gap-3">
                <span className="w-10 h-10 rounded-xl bg-tac-blue/10 text-tac-blue font-black flex items-center justify-center text-sm font-mono">
                  #{h.number}
                </span>
                <div>
                  <h4 className="font-bold text-sm text-tac-blue-dark dark:text-white">{h.title}</h4>
                  <p className="text-[10px] text-gray-400">
                    {h.sections.filter((x) => x.type === 'verse').length} verses
                    {h.sections.some((x) => x.type === 'chorus') ? ' · chorus' : ''} · {h.category}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-1">
                <button onClick={() => handleEdit(h)} className="p-2 text-gray-400 hover:text-tac-blue">
                  <Edit3 size={15} />
                </button>
                <button onClick={() => handleDelete(h.id)} className="p-2 text-gray-400 hover:text-red-500">
                  <Trash2 size={15} />
                </button>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
};
export default HymnsManager;
