import React from 'react';

export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'danger' | 'ghost' | 'outline' | 'emerald';
  size?: 'sm' | 'md' | 'lg';
  loading?: boolean;
  icon?: React.ReactNode;
}

export const Button: React.FC<ButtonProps> = ({
  children,
  variant = 'primary',
  size = 'md',
  loading = false,
  icon,
  className = '',
  disabled,
  ...props
}) => {
  const baseStyles = 'inline-flex items-center justify-center font-black uppercase tracking-wider rounded-2xl transition-all active:scale-95 disabled:opacity-50 disabled:pointer-events-none select-none';
  
  const sizeStyles = {
    sm: 'text-[10px] px-3 py-2 gap-1.5 h-9',
    md: 'text-xs px-5 py-3 gap-2 h-12',
    lg: 'text-sm px-7 py-4 gap-2.5 h-14'
  }[size];

  const variantStyles = {
    primary: 'bg-tac-blue text-white hover:bg-blue-600 shadow-md shadow-tac-blue/20 hover:shadow-lg',
    secondary: 'bg-tac-blue-dark text-white hover:bg-slate-900 border border-white/10',
    danger: 'bg-tac-red text-white hover:bg-red-600 shadow-md shadow-tac-red/20',
    ghost: 'bg-transparent hover:bg-gray-100 dark:hover:bg-white/5 text-[var(--Text)] dark:text-white',
    outline: 'border border-[var(--Bdr)] bg-transparent text-[var(--Text)] dark:text-white hover:bg-gray-50 dark:hover:bg-white/5',
    emerald: 'bg-[#00a884] text-white hover:bg-[#008f6f] shadow-md shadow-emerald-500/20'
  }[variant];

  return (
    <button
      className={`${baseStyles} ${sizeStyles} ${variantStyles} ${className}`}
      disabled={disabled || loading}
      {...props}
    >
      {loading ? (
        <span className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin mr-1" />
      ) : icon ? (
        <span className="shrink-0">{icon}</span>
      ) : null}
      <span>{children}</span>
    </button>
  );
};

export interface CardProps extends React.HTMLAttributes<HTMLDivElement> {
  glass?: boolean;
  padded?: boolean;
}

export const Card: React.FC<CardProps> = ({
  children,
  glass = false,
  padded = true,
  className = '',
  ...props
}) => {
  const base = glass
    ? 'bg-white/80 dark:bg-slate-900/80 backdrop-blur-md border border-white/20 dark:border-white/10 shadow-xl rounded-3xl'
    : 'bg-white dark:bg-slate-900 border border-[var(--Bdr)] shadow-sm hover:shadow-md transition-shadow rounded-3xl';
  const pad = padded ? 'p-5 sm:p-6' : '';

  return (
    <div className={`${base} ${pad} ${className}`} {...props}>
      {children}
    </div>
  );
};

export interface BadgeProps extends React.HTMLAttributes<HTMLSpanElement> {
  variant?: 'blue' | 'red' | 'green' | 'amber' | 'gray';
  size?: 'sm' | 'md';
}

export const Badge: React.FC<BadgeProps> = ({
  children,
  variant = 'blue',
  size = 'md',
  className = '',
  ...props
}) => {
  const styles = {
    blue: 'bg-tac-blue/10 text-tac-blue dark:bg-tac-blue/20 dark:text-tac-blue-light border-tac-blue/20',
    red: 'bg-tac-red/10 text-tac-red dark:bg-tac-red/20 dark:text-red-400 border-tac-red/20',
    green: 'bg-emerald-500/10 text-emerald-600 dark:bg-emerald-500/20 dark:text-emerald-400 border-emerald-500/20',
    amber: 'bg-amber-500/10 text-amber-600 dark:bg-amber-500/20 dark:text-amber-400 border-amber-500/20',
    gray: 'bg-gray-100 text-gray-600 dark:bg-white/10 dark:text-gray-300 border-black/5 dark:border-white/5'
  }[variant];

  const sizeCls = size === 'sm' ? 'px-2 py-0.5 text-[9px]' : 'px-2.5 py-1 text-[10px]';

  return (
    <span
      className={`inline-flex items-center gap-1 font-black uppercase tracking-wider rounded-full border ${sizeCls} ${styles} ${className}`}
      {...props}
    >
      {children}
    </span>
  );
};

export interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  title?: string;
  description?: string;
  children: React.ReactNode;
  maxWidth?: 'sm' | 'md' | 'lg' | 'xl';
}

export const Modal: React.FC<ModalProps> = ({
  isOpen,
  onClose,
  title,
  description,
  children,
  maxWidth = 'md'
}) => {
  if (!isOpen) return null;

  const maxW = {
    sm: 'max-w-sm',
    md: 'max-w-md',
    lg: 'max-w-lg',
    xl: 'max-w-2xl'
  }[maxWidth];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fadeIn">
      <div 
        className="fixed inset-0" 
        onClick={onClose} 
      />
      <div className={`relative w-full ${maxW} bg-white dark:bg-slate-900 border border-[var(--Bdr)] rounded-3xl shadow-2xl overflow-hidden z-10 flex flex-col max-h-[90vh]`}>
        {(title || description) && (
          <div className="p-6 border-b border-[var(--Bdr)] flex items-start justify-between">
            <div>
              {title && <h3 className="text-lg font-black text-tac-blue-dark dark:text-white uppercase tracking-tight">{title}</h3>}
              {description && <p className="text-xs text-[var(--Sub)] mt-1">{description}</p>}
            </div>
            <button
              onClick={onClose}
              className="p-2 -mr-2 -mt-2 text-gray-400 hover:text-gray-600 dark:hover:text-white rounded-full hover:bg-gray-100 dark:hover:bg-white/5 transition-all"
            >
              ✕
            </button>
          </div>
        )}
        <div className="p-6 overflow-y-auto flex-1">
          {children}
        </div>
      </div>
    </div>
  );
};
