import React from 'react';

interface State { error: Error | null }

/**
 * If anything crashes while the app is drawing itself, React removes everything and the page turns
 * white. This catches that and shows what went wrong instead (plain styles on purpose, so it still
 * shows even if the stylesheet failed to load).
 */
export class ErrorBoundary extends React.Component<{ children: React.ReactNode }, State> {
  state: State = { error: null };

  static getDerivedStateFromError(error: Error): State {
    return { error };
  }

  componentDidCatch(error: Error, info: React.ErrorInfo) {
    console.error('The app crashed:', error, info.componentStack);
  }

  render() {
    const { error } = this.state;
    if (!error) return this.props.children;
    return (
      <div style={{ minHeight: '100dvh', background: '#0b1f4d', color: '#fff', fontFamily: 'system-ui, sans-serif', padding: '32px 20px' }}>
        <div style={{ maxWidth: 640, margin: '0 auto' }}>
          <h1 style={{ fontSize: 20, margin: '0 0 8px' }}>Something went wrong</h1>
          <p style={{ opacity: 0.8, fontSize: 14, margin: '0 0 16px' }}>
            The app hit an error and could not continue. Please send this message to the developer.
          </p>
          <pre style={{ background: 'rgba(255,255,255,0.08)', padding: 14, borderRadius: 10, fontSize: 12, whiteSpace: 'pre-wrap', wordBreak: 'break-word', maxHeight: '50vh', overflow: 'auto' }}>
            {String(error?.message || error)}
            {error?.stack ? '\n\n' + error.stack.split('\n').slice(0, 8).join('\n') : ''}
          </pre>
          <button onClick={() => window.location.reload()} style={{ marginTop: 16, padding: '10px 18px', borderRadius: 10, border: 'none', fontWeight: 700, cursor: 'pointer' }}>
            Reload
          </button>
        </div>
      </div>
    );
  }
}

export default ErrorBoundary;
