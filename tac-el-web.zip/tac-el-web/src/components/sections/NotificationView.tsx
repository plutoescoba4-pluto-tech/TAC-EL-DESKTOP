import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Bell, 
  Calendar, 
  BookOpen, 
  Image as ImageIcon, 
  ChevronRight, 
  Clock,
  CheckCircle2,
  Filter,
  Search
} from 'lucide-react';
import { Trash2, X } from 'lucide-react';
import { supabase } from '../../supabase';
import { useAuth } from '../../context/AuthContext';
import { useNavigate } from 'react-router-dom';
import { formatDistanceToNow } from 'date-fns';

// Dismissing an item here hides it from this feed — it must NOT delete the
// underlying notice/sermon/event/photo (that's real church content other
// screens still need). So "delete" is a per-user, per-device dismissal list
// in localStorage, the same pattern used elsewhere for data with no
// per-user table of its own (see MIGRATION_NOTES.md).
const dismissedKey = (uid: string) => `tac_dismissed_notifications_${uid}`;
function loadDismissed(uid: string): Set<string> {
  try {
    const raw = localStorage.getItem(dismissedKey(uid));
    return new Set(raw ? JSON.parse(raw) : []);
  } catch {
    return new Set();
  }
}
function saveDismissed(uid: string, ids: Set<string>) {
  try {
    localStorage.setItem(dismissedKey(uid), JSON.stringify(Array.from(ids)));
  } catch { /* ignore */ }
}

// ... (types)
interface SiteUpdate {
  id: string;
  title: string;
  description: string;
  type: 'notice' | 'sermon' | 'event' | 'gallery';
  createdAt: any;
  link: string;
}

const NotificationView: React.FC = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [updates, setUpdates] = useState<SiteUpdate[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<'all' | 'notice' | 'sermon' | 'event' | 'gallery'>('all');
  const [dismissed, setDismissed] = useState<Set<string>>(new Set());

  const dismiss = (itemKey: string) => {
    if (!user) return;
    setDismissed((prev) => {
      const next = new Set(prev);
      next.add(itemKey);
      saveDismissed(user.id, next);
      return next;
    });
  };

  const clearAll = () => {
    if (!user) return;
    const allKeys = new Set(dismissed);
    updates.forEach((u) => allKeys.add(`${u.type}:${u.id}`));
    setDismissed(allKeys);
    saveDismissed(user.id, allKeys);
  };

  useEffect(() => {
    // We aggregate the last items from multiple tables. Column names differ
    // per table per your schema (notices.body, sermons.speaker,
    // events.starts_at, gallery_photos.image_url), so each entry maps its
    // own row shape into the common SiteUpdate shape below.
    const sources: { table: string; type: SiteUpdate['type']; dateCol: string; toUpdate: (row: any) => Omit<SiteUpdate, 'id' | 'type' | 'createdAt' | 'link'>; link: string }[] = [
      { table: 'notices', type: 'notice', dateCol: 'created_at', link: '/dashboard/notices', toUpdate: (d) => ({ title: d.title, description: d.body }) },
      { table: 'sermons', type: 'sermon', dateCol: 'created_at', link: '/dashboard/sermons', toUpdate: (d) => ({ title: d.title, description: d.speaker || '' }) },
      { table: 'events', type: 'event', dateCol: 'created_at', link: '/dashboard/events', toUpdate: (d) => ({ title: d.title, description: d.starts_at }) },
      { table: 'gallery_photos', type: 'gallery', dateCol: 'created_at', link: '/dashboard/gallery', toUpdate: () => ({ title: 'New Photo', description: 'Added to church gallery' }) },
    ];

    const fetchAll = async () => {
      try {
        const results = await Promise.all(sources.map(async (src) => {
          const { data, error } = await supabase.from(src.table).select('*').order(src.dateCol, { ascending: false }).limit(15);
          if (error) return [] as SiteUpdate[];
          return (data ?? []).map((row: any) => ({
            id: row.id,
            ...src.toUpdate(row),
            type: src.type,
            createdAt: row[src.dateCol],
            link: src.link,
          }));
        }));

        const merged = results.flat().sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
        setUpdates(merged);

        // Opening this inbox is what should clear the bell badge — it was
        // previously only cleared by dismissing the brief popup toast,
        // never by actually visiting this page. The badge counts unseen
        // notices specifically, so mark the newest one seen here too.
        if (user) {
          const latestNotice = merged.find((u) => u.type === 'notice');
          if (latestNotice) {
            try { localStorage.setItem(`lastSeenNotice_${user.id}`, latestNotice.id); } catch { /* ignore */ }
          }
        }
      } catch (e: any) {
        console.warn("Notification feed load failed", e);
      } finally {
        setLoading(false);
      }
    };

    fetchAll();
    if (user) setDismissed(loadDismissed(user.id));
  }, [user?.id]);

  const visible = updates.filter((u) => !dismissed.has(`${u.type}:${u.id}`));
  const filtered = filter === 'all' ? visible : visible.filter(u => u.type === filter);

  return (
    <div className="p-4 lg:p-8 space-y-8 max-w-4xl mx-auto">
      <header className="flex flex-col sm:flex-row sm:items-center justify-between gap-6">
        <div>
          <h2 className="text-3xl font-black font-serif text-tac-blue-dark dark:text-white tracking-tight">Activity Feed</h2>
          <p className="text-[var(--Sub)] font-medium">Stay updated with everything happening in the assembly.</p>
        </div>

        <div className="flex items-center gap-2 overflow-x-auto pb-2 sm:pb-0 no-scrollbar">
           {(['all', 'notice', 'sermon', 'event', 'gallery'] as const).map(f => (
             <button 
              key={f}
              onClick={() => setFilter(f)}
              className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all shrink-0 ${filter === f ? 'bg-tac-blue text-white shadow-lg shadow-tac-blue/20' : 'bg-white dark:bg-slate-800 border border-gray-100 dark:border-white/10 text-gray-400 hover:border-tac-blue/30'}`}
             >
               {f}s
             </button>
           ))}
           {visible.length > 0 && (
             <button
               onClick={clearAll}
               className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all shrink-0 bg-red-50 dark:bg-red-900/20 text-tac-red hover:bg-tac-red hover:text-white"
             >
               <Trash2 size={12} /> Clear All
             </button>
           )}
        </div>
      </header>

      {loading ? (
        <div className="space-y-4">
          {[1, 2, 3, 4].map(i => (
            <div key={i} className="h-24 bg-gray-100 dark:bg-white/5 animate-pulse rounded-3xl" />
          ))}
        </div>
      ) : (
        <div className="space-y-4">
          <AnimatePresence mode="popLayout">
            {filtered.map((item, idx) => (
              <motion.div 
                key={item.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95 }}
                transition={{ delay: idx * 0.05 }}
                onClick={() => navigate(item.link)}
                className="group p-5 bg-white dark:bg-slate-800 rounded-[2rem] border border-[var(--Bdr)] shadow-sm hover:shadow-xl hover:border-tac-blue/20 transition-all cursor-pointer flex items-center gap-4 text-left"
              >
                  <div className={`shrink-0 w-14 h-14 rounded-2xl flex items-center justify-center ${
                    item.type === 'notice' ? 'bg-tac-red/10 text-tac-red' : 
                    item.type === 'sermon' ? 'bg-tac-blue/10 text-tac-blue' :
                    item.type === 'event' ? 'bg-tac-gold/10 text-tac-gold' :
                    'bg-green-100 dark:bg-green-900/20 text-green-600 dark:text-green-400'
                  }`}>
                    {item.type === 'notice' && <Bell size={24} />}
                    {item.type === 'sermon' && <BookOpen size={24} />}
                    {item.type === 'event' && <Calendar size={24} />}
                    {item.type === 'gallery' && <ImageIcon size={24} />}
                  </div>

                  <div className="flex-1 min-w-0">
                     <div className="flex items-center gap-2 mb-1">
                        <span className="text-[9px] font-black uppercase tracking-widest opacity-40 dark:text-white/40">{item.type}</span>
                        <div className="w-1 h-1 bg-gray-200 dark:bg-white/10 rounded-full" />
                        <span className="text-[9px] font-bold text-tac-blue/60 dark:text-tac-blue-light flex items-center gap-1">
                           <Clock size={10} />
                           {item.createdAt ? formatDistanceToNow(new Date(item.createdAt), { addSuffix: true }) : 'Just now'}
                        </span>
                     </div>
                     <h3 className="text-base font-black text-tac-blue-dark dark:text-white truncate group-hover:text-tac-blue transition-colors">{item.title}</h3>
                     <p className="text-xs text-[var(--Sub)] font-medium truncate opacity-80">{item.description}</p>
                  </div>

                  <button
                    onClick={(e) => { e.stopPropagation(); dismiss(`${item.type}:${item.id}`); }}
                    className="p-2 bg-gray-50 dark:bg-white/5 rounded-xl text-gray-300 hover:bg-tac-red hover:text-white transition-all shrink-0"
                    title="Remove from inbox"
                  >
                     <X size={18} />
                  </button>

                  <div className="p-2 bg-gray-50 dark:bg-white/5 rounded-xl text-gray-300 group-hover:bg-tac-blue group-hover:text-white transition-all shrink-0">
                     <ChevronRight size={20} />
                  </div>
              </motion.div>
            ))}
          </AnimatePresence>

          {filtered.length === 0 && (
            <div className="py-20 text-center space-y-4">
               <CheckCircle2 className="mx-auto text-tac-blue/10" size={64} />
               <p className="text-sm font-black uppercase tracking-widest text-gray-300">You're all caught up!</p>
            </div>
          )}
        </div>
      )}

      {!loading && updates.length > 0 && (
        <div className="pt-8 flex justify-center">
           <div className="flex items-center gap-3 text-tac-blue/20 font-black uppercase tracking-[0.3em] text-[10px]">
              <div className="w-12 h-[1px] bg-tac-blue/10" />
              End of Activity
              <div className="w-12 h-[1px] bg-tac-blue/10" />
           </div>
        </div>
      )}
    </div>
  );
};

export default NotificationView;
