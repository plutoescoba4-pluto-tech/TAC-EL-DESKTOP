import React, { useCallback, useEffect, useRef, useState } from 'react';
import { MonitorSmartphone, ScanLine, X, LogOut, Laptop } from 'lucide-react';
import { deviceLinkService, LinkedDevice, MAX_LINKED_DEVICES } from '../../lib/deviceLink';
import { isMobileDevice } from '../../lib/device';

/**
 * Linked Devices (on the phone): see the computers signed in to your account, sign any of them out,
 * and link a new one by scanning the QR code it shows. The phone plus up to 2 linked devices;
 * linking a third signs the oldest one out.
 */

const ago = (iso: string) => {
  const m = Math.round((Date.now() - new Date(iso).getTime()) / 60000);
  if (m < 2) return 'just now';
  if (m < 60) return `${m} minutes ago`;
  if (m < 1440) return `${Math.round(m / 60)} hours ago`;
  return new Date(iso).toLocaleDateString([], { day: 'numeric', month: 'short' });
};

/** Camera that reads a QR code. Uses the browser's built-in reader when there is one, otherwise jsQR. */
const QrScanner: React.FC<{ onCode: (text: string) => void; onError: (m: string) => void }> = ({ onCode, onError }) => {
  const videoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    let stream: MediaStream | null = null;
    let stopped = false;
    let raf = 0;

    (async () => {
      try {
        stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' }, audio: false });
        if (stopped) { stream.getTracks().forEach((t) => t.stop()); return; }
        const video = videoRef.current!;
        video.srcObject = stream;
        await video.play();

        const Detector = (window as any).BarcodeDetector;
        const detector = Detector ? new Detector({ formats: ['qr_code'] }) : null;
        const jsQR = detector ? null : (await import('jsqr')).default;
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d', { willReadFrequently: true });
        let last = 0;

        const tick = async (t: number) => {
          if (stopped) return;
          if (t - last > 250 && video.readyState >= 2) {
            last = t;
            try {
              let text: string | null = null;
              if (detector) {
                const found = await detector.detect(video);
                text = found[0]?.rawValue ?? null;
              } else if (ctx && jsQR) {
                canvas.width = video.videoWidth; canvas.height = video.videoHeight;
                ctx.drawImage(video, 0, 0);
                const img = ctx.getImageData(0, 0, canvas.width, canvas.height);
                text = jsQR(img.data, img.width, img.height)?.data ?? null;
              }
              if (text) { onCode(text); return; }
            } catch { /* keep scanning */ }
          }
          raf = requestAnimationFrame(tick);
        };
        raf = requestAnimationFrame(tick);
      } catch (e: any) {
        onError(e?.name === 'NotAllowedError' ? 'Camera permission was denied. Allow the camera for this app, or type the code instead.' : 'Could not start the camera. You can type the code instead.');
      }
    })();

    return () => { stopped = true; cancelAnimationFrame(raf); stream?.getTracks().forEach((t) => t.stop()); };
  }, [onCode, onError]);

  return (
    <div className="relative rounded-2xl overflow-hidden bg-black aspect-square">
      <video ref={videoRef} playsInline muted className="w-full h-full object-cover" />
      <div className="absolute inset-8 border-2 border-white/70 rounded-2xl pointer-events-none" />
    </div>
  );
};

export const LinkedDevices: React.FC = () => {
  const [devices, setDevices] = useState<LinkedDevice[]>([]);
  const [loading, setLoading] = useState(true);
  const [notice, setNotice] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);

  // linking flow
  const [linking, setLinking] = useState(false);
  const [manual, setManual] = useState('');
  const [scanError, setScanError] = useState<string | null>(null);
  const [pending, setPending] = useState<{ code: string; device_name: string; created_at: string } | null>(null);
  const [busy, setBusy] = useState(false);
  const handled = useRef(false);

  const load = useCallback(async () => {
    try { setDevices(await deviceLinkService.list()); } catch (e: any) { setNotice({ type: 'err', text: e.message }); }
    setLoading(false);
  }, []);
  useEffect(() => { load(); }, [load]);

  const check = useCallback(async (text: string) => {
    if (handled.current) return;
    const code = deviceLinkService.parseCode(text);
    if (!code) { setScanError('That does not look like a TAC-EL link code.'); return; }
    handled.current = true; setBusy(true); setScanError(null);
    try {
      const info = await deviceLinkService.lookup(code);
      setPending({ code, ...info });
    } catch (e: any) { setScanError(e.message); handled.current = false; }
    setBusy(false);
  }, []);
  const onScanError = useCallback((m: string) => setScanError(m), []);

  const close = () => { setLinking(false); setPending(null); setManual(''); setScanError(null); handled.current = false; };

  const approve = async () => {
    if (!pending) return;
    setBusy(true);
    try {
      await deviceLinkService.approve(pending.code);
      const name = pending.device_name;
      close();
      setNotice({ type: 'ok', text: `Linking "${name}"… it will appear here in a moment.` });
      setTimeout(load, 3500); setTimeout(load, 8000);
    } catch (e: any) { setScanError(e.message); }
    setBusy(false);
  };
  const decline = async () => {
    if (pending) deviceLinkService.deny(pending.code).catch(() => {});
    close();
  };

  const unlink = async (d: LinkedDevice) => {
    if (!window.confirm(`Sign out "${d.device_name}"?`)) return;
    try { await deviceLinkService.unlink(d.id); setNotice({ type: 'ok', text: `"${d.device_name}" was signed out.` }); load(); }
    catch (e: any) { setNotice({ type: 'err', text: e.message }); }
  };
  const unlinkAll = async () => {
    if (!window.confirm('Sign out every linked device?')) return;
    try { await deviceLinkService.unlinkAll(); setNotice({ type: 'ok', text: 'All linked devices were signed out.' }); load(); }
    catch (e: any) { setNotice({ type: 'err', text: e.message }); }
  };

  const full = devices.length >= MAX_LINKED_DEVICES;

  return (
    <div className="max-w-2xl mx-auto p-4 lg:p-8 space-y-4">
      <div className="flex items-center gap-3">
        <div className="w-11 h-11 rounded-2xl bg-tac-blue/10 text-tac-blue flex items-center justify-center"><MonitorSmartphone size={22} /></div>
        <div>
          <h2 className="text-2xl font-black font-serif text-tac-blue-dark dark:text-white leading-tight">Linked Devices</h2>
          <p className="text-sm text-[var(--Sub)]">Use TAC-EL on a computer without typing your password.</p>
        </div>
      </div>

      {notice && (
        <div role="status" className={`rounded-xl px-4 py-3 text-sm font-semibold ${notice.type === 'ok' ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-300' : 'bg-red-50 text-red-700 dark:bg-red-500/10 dark:text-red-300'}`}>{notice.text}</div>
      )}

      <div className="rounded-3xl bg-white dark:bg-slate-900 border border-[var(--Bdr)] p-5">
        <p className="text-sm text-[var(--Sub)] mb-4">
          On the computer, open TAC-EL and choose <b>Sign in with your phone</b>. Then scan its code here. You can have your phone plus up to {MAX_LINKED_DEVICES} linked devices.
          {full && ' You have reached the limit: linking another will sign out the oldest one.'}
        </p>
        {isMobileDevice() ? (
          <button type="button" onClick={() => { handled.current = false; setLinking(true); }}
            className="w-full sm:w-auto px-5 py-3 rounded-2xl bg-tac-blue text-white text-xs font-black uppercase tracking-widest inline-flex items-center justify-center gap-2">
            <ScanLine size={16} /> Link a device
          </button>
        ) : (
          <p className="text-xs font-semibold text-tac-blue">To link a new computer, open TAC-EL on your phone, go to Linked Devices and tap Link a device.</p>
        )}
      </div>

      <div className="rounded-3xl bg-white dark:bg-slate-900 border border-[var(--Bdr)] overflow-hidden">
        <div className="flex items-center justify-between px-5 py-3 border-b border-[var(--Bdr)]">
          <p className="text-[11px] font-black uppercase tracking-widest text-gray-400">Signed in on ({devices.length} of {MAX_LINKED_DEVICES})</p>
          {devices.length > 1 && <button type="button" onClick={unlinkAll} className="text-[11px] font-black uppercase tracking-widest text-tac-red">Sign out all</button>}
        </div>
        {loading ? <p className="p-5 text-xs text-gray-400">Loading…</p> : devices.length === 0 ? (
          <p className="p-5 text-sm text-[var(--Sub)]">No linked devices yet.</p>
        ) : devices.map((d) => (
          <div key={d.id} className="flex items-center gap-3 px-5 py-4 border-b border-[var(--Bdr)] last:border-0">
            <div className="w-10 h-10 rounded-xl bg-gray-100 dark:bg-white/5 text-gray-500 flex items-center justify-center shrink-0"><Laptop size={18} /></div>
            <div className="min-w-0 flex-1">
              <p className="font-bold text-sm truncate">{d.device_name}{d.is_current && <span className="ml-2 text-[10px] font-black uppercase text-tac-blue">This device</span>}</p>
              <p className="text-xs text-[var(--Sub)]">Linked {ago(d.created_at)} · last active {ago(d.last_seen_at)}</p>
            </div>
            <button type="button" onClick={() => unlink(d)} className="p-2 rounded-lg text-tac-red hover:bg-red-50 dark:hover:bg-red-500/10" title="Sign out"><LogOut size={16} /></button>
          </div>
        ))}
      </div>

      {linking && (
        <div className="fixed inset-0 z-[170] flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm" onClick={close}>
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-5 shadow-2xl max-w-sm w-full max-h-[92vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-black text-lg text-tac-blue-dark dark:text-white">{pending ? 'Link this device?' : 'Scan the code'}</h3>
              <button type="button" onClick={decline} className="p-2 text-gray-400"><X size={18} /></button>
            </div>

            {pending ? (
              <div className="space-y-4">
                <div className="rounded-2xl bg-gray-50 dark:bg-white/5 p-4 text-center">
                  <Laptop className="mx-auto text-tac-blue mb-2" size={30} />
                  <p className="font-black">{pending.device_name}</p>
                  <p className="text-xs text-gray-500 mt-1">Asked to sign in {ago(pending.created_at)}</p>
                </div>
                <p className="text-xs text-gray-600 dark:text-gray-300">
                  This will sign that device in to your account. <b>Only continue if you are looking at that computer right now</b> and it is yours.
                  {full && ' You already have the maximum, so your oldest linked device will be signed out.'}
                </p>
                {scanError && <p className="text-xs text-tac-red">{scanError}</p>}
                <div className="grid grid-cols-2 gap-3">
                  <button type="button" onClick={decline} className="py-3 rounded-2xl bg-gray-100 dark:bg-white/5 text-gray-500 font-black text-[11px] uppercase tracking-widest">Cancel</button>
                  <button type="button" onClick={approve} disabled={busy} className="py-3 rounded-2xl bg-tac-blue text-white font-black text-[11px] uppercase tracking-widest disabled:opacity-60">{busy ? 'Linking…' : 'Link it'}</button>
                </div>
              </div>
            ) : (
              <div className="space-y-4">
                <QrScanner onCode={check} onError={onScanError} />
                {scanError && <p className="text-xs text-tac-red">{scanError}</p>}
                <div>
                  <p className="text-[11px] font-black uppercase tracking-widest text-gray-400 mb-1.5">Or type the letters shown on the computer</p>
                  <div className="flex gap-2">
                    <input value={manual} onChange={(e) => setManual(e.target.value.toUpperCase())} maxLength={9} placeholder="ABCD EFGH"
                      className="flex-1 rounded-xl border border-gray-200 dark:border-white/10 bg-transparent px-3 py-2.5 text-center font-mono tracking-widest outline-none focus:border-tac-blue dark:text-white" />
                    <button type="button" onClick={() => check(manual)} disabled={busy || manual.replace(/\s/g, '').length < 8}
                      className="px-4 rounded-xl bg-tac-blue text-white text-xs font-black uppercase tracking-widest disabled:opacity-50">Check</button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default LinkedDevices;
