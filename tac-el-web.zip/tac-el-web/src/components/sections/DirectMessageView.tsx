import { pauseOthers } from '../../lib/singleAudio';
import { isAutoCaption } from '../../lib/chatText';
import { createPortal } from 'react-dom';
import React, { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Send, 
  Image as ImageIcon, 
  Smile, 
  Reply, 
  X, 
  Mic, 
  Plus, 
  Camera, 
  File, 
  MapPin,
  Trash2,
  StopCircle,
  Play,
  Video,
  Check,
  CheckCheck,
  ChevronLeft,
  Music,
  Paperclip,
  Navigation,
  RefreshCw
} from 'lucide-react';
import { chatService } from '../../services/chatService';
import { useChatTheme, themeVars, themeAttrs, wallpaperProps } from '../../lib/chatTheme';
import ChatThemePanel from '../chat/ChatThemePanel';
import { membersService } from '../../services/membersService';
import { authService } from '../../services/authService';
import { useAuth } from '../../context/AuthContext';
import { ChatMessage, UserProfile } from '../../types';
import { handleFirestoreError, OperationType } from '../../lib/firestore-errors';
import { 
  MAX_FIRESTORE_PAYLOAD_BYTES, 
  MAX_BINARY_FILE_BYTES, 
  calculatePayloadSizeBytes, 
  processFileForChat 
} from '../../lib/image-utils';
import { useHoldMic } from '../../lib/useHoldMic';
import { WhatsAppAudioRecorder } from '../chat/WhatsAppAudioRecorder';
import { ChatSoundToggle } from '../chat/ChatSoundToggle';
import { ReactionPicker, ReactionChips, useReactions, MuteButton, BlockButton, BlockDialog, BlockedBar, useDmBlock, useMySuspension, SuspendedNotice } from '../chat/ChatExtras';
import type { Reaction } from '../../services/chatService';
import { markConversationRead, dmConv } from '../../lib/chatUnread';
import { lastSeenLabel } from '../../lib/presenceStatus';
import type { RealtimeChannel } from '@supabase/supabase-js';

const DirectMessageView: React.FC = () => {
  const { dmId } = useParams();
  const { user, profile } = useAuth();
  const navigate = useNavigate();
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputText, setInputText] = useState('');
  const [replyingTo, setReplyTo] = useState<ChatMessage | null>(null);
  const [showAttach, setShowAttach] = useState(false);
  const [showEmojis, setShowEmojis] = useState(false);
  const [showAudioRecorder, setShowAudioRecorder] = useState(false);
  const [releaseSignal, setReleaseSignal] = useState<{ kind: 'send' | 'cancel'; n: number } | null>(null);
  const holdMic = useHoldMic({
    onTap: () => setShowAudioRecorder(true),
    onHoldStart: () => { setReleaseSignal(null); setShowAudioRecorder(true); },
    onRelease: (kind) => setReleaseSignal({ kind, n: Date.now() }),
  });
  const [isRecording, setIsRecording] = useState(false);
  const [isVideoRecording, setIsVideoRecording] = useState(false);
  const [recordingTime, setRecordingTime] = useState(0);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  const [cameraStream, setCameraStream] = useState<MediaStream | null>(null);
  // which camera: 'user' = front, 'environment' = back (remembered)
  const [facing, setFacing] = useState<'user' | 'environment'>(() => {
    try { return localStorage.getItem('tac_cam_facing') === 'environment' ? 'environment' : 'user'; } catch { return 'user'; }
  });
  const openCam = async (face: 'user' | 'environment', size: { w: number; h: number }) => {
    try {
      return await navigator.mediaDevices.getUserMedia({ video: { facingMode: { exact: face }, width: { ideal: size.w }, height: { ideal: size.h } } });
    } catch {
      // some phones and tablets do not accept "exact": ask for it softly, then for any camera
      try {
        return await navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: face }, width: { ideal: size.w }, height: { ideal: size.h } } });
      } catch {
        return await navigator.mediaDevices.getUserMedia({ video: true });
      }
    }
  };

  const [recordingStream, setRecordingStream] = useState<MediaStream | null>(null);
  const [audioBlob, setAudioBlob] = useState<Blob | null>(null);
  const [videoBlob, setVideoBlob] = useState<Blob | null>(null);
  const [showAudioPreview, setShowAudioPreview] = useState(false);
  const [showVideoPreview, setShowVideoPreview] = useState(false);
  const [showBgSettings, setShowBgSettings] = useState(false);
  const [recentEmojis, setRecentEmojis] = useState<string[]>([]);
  const [isCapturingPhoto, setIsCapturingPhoto] = useState(false);
  const [isClearingDM, setIsClearingDM] = useState(false);
  const [otherUser, setOtherUser] = useState<UserProfile | null>(null);
  const [otherTyping, setOtherTyping] = useState(false);
  const dmPresenceRef = useRef<RealtimeChannel | null>(null);
  const [sendError, setSendError] = useState<string | null>(null);
  const reactions = useReactions('dm');
  const suspendedUntil = useMySuspension(user?.id);
  const otherId = dmId && user ? dmId.split('_').find((id) => id !== user.id) : undefined;
  const { block: myBlock, refresh: refreshBlock } = useDmBlock(user?.id, otherId);
  const { theme: chatTheme } = useChatTheme(user?.id, otherId ? `dm:${otherId}` : undefined);
  const wallpaper = wallpaperProps(chatTheme.wallpaper);
  const [showBlockDialog, setShowBlockDialog] = useState(false);

  // Auto-dismiss send errors
  useEffect(() => {
    if (sendError) {
      const t = setTimeout(() => setSendError(null), 6000);
      return () => clearTimeout(t);
    }
  }, [sendError]);

  const [clearedAt, setClearedAt] = useState(0);
  useEffect(() => {
    if (!user || !otherId) return;
    let off = false;
    chatService.getThreadClearedAt(user.id, `dm:${otherId}`).then((t) => { if (!off) setClearedAt(t || 0); }).catch(() => {});
    return () => { off = true; };
  }, [user?.id, otherId]);

  const handleClearDMMessages = async () => {
    if (!user || !otherId) return;
    try {
      const t = await chatService.clearThreadForMe(user.id, `dm:${otherId}`);
      setClearedAt(typeof t === 'number' ? t : Date.now());
      setIsClearingDM(false);
    } catch (err) {
      console.error('Failed to clear DM messages:', err);
    }
  };
  const scrollRef = useRef<HTMLDivElement>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const liveVideoRef = useRef<HTMLVideoElement>(null);
  const timerRef = useRef<any>(null);

  const emojis = ['🙏', '🙌', '🔥', '❤️', '⛪', '📖', '✨', '😊', '🤝', '💯', '✝️', '🕊️', '😇', '📢', '😂', '😍', '🤔', '💪', '👍', '🎁', '🎈', '🎉', '🌟', '🌈', '💧', '🌍', '⏰', '📱', '💻', '🛐', '📜', '⚖️', '🗝️'];
  const backgrounds = [
    'bg-[#efeae2]',
    'bg-gray-100',
    'bg-blue-50',
    'bg-stone-200'
  ];

  useEffect(() => {
    if (!dmId || !user) return;

    // Identify other user
    const otherUid = dmId.split('_').find(id => id !== user.id);
    // Refresh the other person's online / last-seen every 30s so the header
    // stays honest while the thread is open.
    let statusTimer: ReturnType<typeof setInterval> | undefined;
    if (otherUid) {
      const loadOther = () => membersService.getMemberById(otherUid).then(p => { if (p) setOtherUser(p); });
      loadOther();
      statusTimer = setInterval(loadOther, 30000);
      markConversationRead(user.id, dmConv(otherUid));
    }

    const unsub = otherUid
      ? chatService.subscribeToDirectChat(user.id, otherUid, (msgs) => {
          setMessages(msgs);
          // This thread is open, so everything in it is being read.
          markConversationRead(user.id, dmConv(otherUid));
          if (msgs.some((m) => m.senderId === otherUid && !m.readBy?.length)) {
            chatService.markDirectRead(otherUid, user.id).catch(() => {});
          }
          setTimeout(() => {
            if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
          }, 100);
        }, 100)
      : () => {};

    return () => {
      unsub();
      if (statusTimer) clearInterval(statusTimer);
      if (recordingStream) recordingStream.getTracks().forEach(t => t.stop());
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [dmId, user, recordingStream]);

  // Typing indicator: ephemeral Presence channel shared by the two people in
  // this thread (nothing stored). Same pattern as the group chat.
  useEffect(() => {
    if (!dmId || !user) return;
    const otherUid = dmId.split('_').find(id => id !== user.id);
    if (!otherUid) return;
    const { channel, unsubscribe } = chatService.subscribeDmPresence(
      dmId,
      { uid: user.id, name: profile?.name || 'Member' },
      (state) => setOtherTyping(!!state[otherUid]?.typing)
    );
    dmPresenceRef.current = channel;
    return () => {
      dmPresenceRef.current = null;
      setOtherTyping(false);
      unsubscribe();
    };
  }, [dmId, user?.id]);

  // Push OUR typing state; auto-clears after 4s without a keystroke.
  useEffect(() => {
    if (!dmPresenceRef.current || !profile) return;
    const typing = inputText.trim().length > 0;
    dmPresenceRef.current.track({ name: profile.name, typing });
    if (!typing) return;
    const t = setTimeout(() => dmPresenceRef.current?.track({ name: profile.name, typing: false }), 4000);
    return () => clearTimeout(t);
  }, [inputText, profile?.name]);

  useEffect(() => {
    const saved = localStorage.getItem('recent_emojis');
    if (saved) setRecentEmojis(JSON.parse(saved));
  }, []);

  const saveEmoji = (emoji: string) => {
    const newRecent = [emoji, ...recentEmojis.filter(e => e !== emoji).slice(0, 7)];
    setRecentEmojis(newRecent);
    localStorage.setItem('recent_emojis', JSON.stringify(newRecent));
    setInputText(prev => prev + emoji);
    setShowEmojis(false);
  };

  const handleSendMessage = async (textOverride?: string, mediaData?: any) => {
    if (!dmId || (!textOverride && !inputText.trim() && !mediaData)) return;
    if (!user || !profile) return;
    const otherUid = dmId.split('_').find(id => id !== user.id);
    if (!otherUid) return;

    const msgData: any = {
      text: textOverride || inputText.trim(),
      ...mediaData
    };

    if (replyingTo) {
      // Store compact text summary only - avoid duplicating large base64 media payloads inside replyTo
      const replySummary = replyingTo.text 
        || (replyingTo.img ? 'Photo' : replyingTo.vid ? 'Video' : replyingTo.voice ? 'Voice message' : 'Attachment');
      msgData.replyTo = {
        sender: replyingTo.senderName,
        text: replySummary
      };
    }

    // Defensive check before sending
    const estimatedSize = calculatePayloadSizeBytes(msgData);
    if (estimatedSize > MAX_FIRESTORE_PAYLOAD_BYTES) {
      setSendError(`Attachment is too large (${Math.round(estimatedSize / 1024)} KB). The maximum database limit is 9 MB. Please attach a shorter clip or smaller file.`);
      return;
    }

    // WhatsApp style: the message shows and the box clears at once; the server catches up quietly
    const tmpId = `tmp-${Date.now()}`;
    const prevInput = inputText; const prevReply = replyingTo;
    setMessages((prev) => [...prev, {
      ...msgData, id: tmpId, senderId: user.id, senderName: profile.name,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }), createdAt: new Date().toISOString(),
      deliveredTo: [], readBy: [],
    } as any]);
    setInputText(''); setReplyTo(null); setShowAttach(false); setShowEmojis(false); setSendError(null);
    setTimeout(() => { if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight; }, 30);
    try {
      await chatService.sendDirectMessage(user.id, otherUid, msgData);
    } catch (err: any) {
      setMessages((prev) => prev.filter((m) => m.id !== tmpId));
      setInputText(prevInput); setReplyTo(prevReply);
      console.error('Send failed details:', err);
      setSendError(err.message || 'Message failed to send. Please try again.');
      handleFirestoreError(err, OperationType.CREATE, `dms/${dmId}/messages`);
    }
  };

  const handleLocation = () => {
    if ("geolocation" in navigator) {
      navigator.geolocation.getCurrentPosition(async (position) => {
        const { latitude, longitude } = position.coords;
        const locationUrl = `https://www.google.com/maps?q=${latitude},${longitude}`;
        handleSendMessage(`Shared Location`, { 
          location: { lat: latitude, lng: longitude, url: locationUrl },
          text: `My location: ${locationUrl}`
        });
        setShowAttach(false);
      }, (err) => {
        setSendError(err.code === 1 ? "Location permission was denied. Allow location access in your browser settings." : "Could not get your location. Make sure GPS is on and try again.");
      }, { enableHighAccuracy: true, timeout: 15000, maximumAge: 30000 });
    } else {
      setSendError("Geolocation is not supported by this browser.");
    }
  };

  const startRecording = async (type: 'audio' | 'video' = 'audio') => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        audio: true, 
        video: type === 'video' ? { facingMode: { ideal: facing }, width: { ideal: 640 }, height: { ideal: 480 } } : false 
      });
      
      setRecordingStream(stream);

      const options: MediaRecorderOptions = {};
      if (type === 'video') {
        if (MediaRecorder.isTypeSupported('video/webm;codecs=vp8,opus')) {
          options.mimeType = 'video/webm;codecs=vp8,opus';
        } else if (MediaRecorder.isTypeSupported('video/webm')) {
          options.mimeType = 'video/webm';
        } else if (MediaRecorder.isTypeSupported('video/mp4')) {
          options.mimeType = 'video/mp4';
        }
        options.videoBitsPerSecond = 250000;
        options.audioBitsPerSecond = 32000;
      } else {
        if (MediaRecorder.isTypeSupported('audio/webm;codecs=opus')) {
          options.mimeType = 'audio/webm;codecs=opus';
        } else if (MediaRecorder.isTypeSupported('audio/webm')) {
          options.mimeType = 'audio/webm';
        } else if (MediaRecorder.isTypeSupported('audio/mp4')) {
          options.mimeType = 'audio/mp4';
        }
        options.audioBitsPerSecond = 32000;
      }

      const recorder = new MediaRecorder(stream, options);
      mediaRecorderRef.current = recorder;
      chunksRef.current = [];

      recorder.ondataavailable = (e) => {
        if (e.data.size > 0) chunksRef.current.push(e.data);
      };

      recorder.onstop = async () => {
        if (chunksRef.current.length === 0) {
          stream.getTracks().forEach(t => t.stop());
          setRecordingStream(null);
          return;
        }

        const mimeType = type === 'video' ? (recorder.mimeType || 'video/webm') : (recorder.mimeType || 'audio/webm');
        const blob = new Blob(chunksRef.current, { type: mimeType });

        if (blob.size > MAX_BINARY_FILE_BYTES) {
          setSendError(`Recording is too large (${Math.round(blob.size / 1024)} KB). Maximum allowed size is ${Math.round(MAX_BINARY_FILE_BYTES / 1024)} KB. Please record a shorter clip (under 15 seconds for video).`);
          stream.getTracks().forEach(t => t.stop());
          setRecordingStream(null);
          return;
        }

        const reader = new FileReader();
        reader.onload = () => {
          const result = reader.result as string;
          if (type === 'video') handleSendMessage('Video Message', { vid: result });
          else handleSendMessage('Voice Message', { voice: result });
        };
        reader.readAsDataURL(blob);

        stream.getTracks().forEach(t => t.stop());
        setRecordingStream(null);
      };

      recorder.start();
      if (type === 'video') setIsVideoRecording(true);
      else setIsRecording(true);
      
      setRecordingTime(0);
      timerRef.current = setInterval(() => {
        setRecordingTime(prev => {
          const next = prev + 1;
          if (type === 'video' && next >= 15) stopRecording(true);
          else if (type === 'audio' && next >= 90) stopRecording(true);
          return next;
        });
      }, 1000);
    } catch (err) {
      console.error('Recording failed:', err);
      setSendError('Media access denied. Please check permissions.');
    }
  };

  const stopRecording = (shouldSave = true) => {
    if (mediaRecorderRef.current && (isRecording || isVideoRecording)) {
      // If we don't want to save, we clear chunks before stopping
      if (!shouldSave) chunksRef.current = [];
      
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      setIsVideoRecording(false);
      clearInterval(timerRef.current);
    }
  };

  const takeSnapshot = async () => {
    try {
      const stream = await openCam(facing, { w: 1280, h: 720 });
      setCameraStream(stream);
      setIsCapturingPhoto(true);
    } catch (err) {
      setSendError('Camera access denied. Please check permissions.');
    }
  };

  /** front <-> back camera while the live camera is open */
  const flipCamera = async () => {
    const next = facing === 'user' ? 'environment' : 'user';
    const curId = cameraStream?.getVideoTracks()[0]?.getSettings().deviceId;
    try {
      cameraStream?.getTracks().forEach((t) => t.stop());
      let stream = await openCam(next, { w: 1280, h: 720 });
      const gotId = stream.getVideoTracks()[0]?.getSettings().deviceId;
      if (curId && gotId === curId) {
        // the browser ignored the front/back hint (common on tablets): step to the next camera by id
        const cams = (await navigator.mediaDevices.enumerateDevices()).filter((d) => d.kind === 'videoinput');
        if (cams.length > 1) {
          stream.getTracks().forEach((t) => t.stop());
          const i = cams.findIndex((d) => d.deviceId === curId);
          const other = cams[(i + 1) % cams.length];
          stream = await navigator.mediaDevices.getUserMedia({ video: { deviceId: { exact: other.deviceId }, width: { ideal: 1280 }, height: { ideal: 720 } } });
        }
      }
      const fm = stream.getVideoTracks()[0]?.getSettings().facingMode;
      const shown: 'user' | 'environment' = fm === 'environment' || fm === 'user' ? fm : next;
      setFacing(shown);
      try { localStorage.setItem('tac_cam_facing', shown); } catch { /* fine */ }
      setCameraStream(stream);
    } catch {
      setSendError('Could not switch the camera. This device may have only one.');
    }
  };

  const capturePhoto = () => {
    if (liveVideoRef.current) {
      const canvas = document.createElement('canvas');
      let w = liveVideoRef.current.videoWidth || 800;
      let h = liveVideoRef.current.videoHeight || 600;
      const maxDim = 900;
      if (w > maxDim || h > maxDim) {
        if (w > h) {
          h = Math.round((h * maxDim) / w);
          w = maxDim;
        } else {
          w = Math.round((w * maxDim) / h);
          h = maxDim;
        }
      }
      canvas.width = w;
      canvas.height = h;
      const ctx = canvas.getContext('2d');
      ctx?.drawImage(liveVideoRef.current, 0, 0, w, h);
      const dataUrl = canvas.toDataURL('image/jpeg', 0.65);
      handleSendMessage('Photo Captured', { img: dataUrl });
      closeCamera();
    }
  };

  const closeCamera = () => {
    if (cameraStream) {
      cameraStream.getTracks().forEach(t => t.stop());
      setCameraStream(null);
    }
    setIsCapturingPhoto(false);
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    e.target.value = '';
    setShowAttach(false);

    if (file.type.startsWith('image/')) {
      try {
        const processed = await processFileForChat(file);
        if (processed.isOverLimit) {
          setSendError(`Image is too large (${Math.round(processed.sizeBytes / 1024)} KB). Please choose a smaller picture.`);
          return;
        }
        handleSendMessage(`Photo: ${file.name}`, { img: processed.dataUrl });
      } catch (err) {
        setSendError('Failed to process image file.');
      }
    } else {
      if (file.size > MAX_BINARY_FILE_BYTES) {
        setSendError(`File '${file.name}' is too large (${(file.size / (1024 * 1024)).toFixed(1)} MB). Storage limit is ${Math.round(MAX_BINARY_FILE_BYTES / 1024)} KB. Please upload a smaller file or share a link.`);
        return;
      }
      const reader = new FileReader();
      reader.onload = (event) => {
        const result = event.target?.result as string;
        if (file.type.startsWith('video/')) handleSendMessage(`Video: ${file.name}`, { vid: result });
        else handleSendMessage(`File: ${file.name}`, { file: result });
      };
      reader.readAsDataURL(file);
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div {...themeAttrs(chatTheme)} style={themeVars(chatTheme)} className="chat-scope flex flex-col h-full flex-1 min-h-0 bg-[#efeae2] dark:bg-[#0b141a] relative overflow-hidden font-sans">
      {/* Clear DM Chat Confirmation Modal */}
      <AnimatePresence>
        {isClearingDM && (
          <div className="fixed inset-0 z-[150] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
             <motion.div 
               initial={{ scale: 0.9, opacity: 0 }}
               animate={{ scale: 1, opacity: 1 }}
               exit={{ scale: 0.9, opacity: 0 }}
               className="bg-white dark:bg-slate-900 rounded-3xl p-6 shadow-2xl max-w-sm w-full border border-gray-100 dark:border-white/10 text-center"
             >
                <div className="w-14 h-14 bg-red-100 dark:bg-red-900/20 text-tac-red rounded-2xl flex items-center justify-center mx-auto mb-4">
                   <Trash2 size={28} />
                </div>
                <h3 className="text-base font-black text-tac-blue-dark dark:text-white mb-2">Clear Direct Conversation?</h3>
                <p className="text-xs text-gray-500 dark:text-gray-400 mb-6">This clears the conversation on your side only. The other person keeps their copy.</p>
                <div className="grid grid-cols-2 gap-3">
                   <button 
                     onClick={() => setIsClearingDM(false)}
                     className="py-3 bg-gray-100 dark:bg-white/5 text-gray-500 rounded-xl font-bold text-xs hover:bg-gray-200 transition-all"
                   >
                     Cancel
                   </button>
                   <button 
                     onClick={handleClearDMMessages}
                     className="py-3 bg-tac-red text-white rounded-xl font-bold text-xs shadow-lg shadow-tac-red/20 hover:scale-105 active:scale-95 transition-all"
                   >
                     Clear All
                   </button>
                </div>
             </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Static Header Bar - Matches Church Chat Style */}
      <div className="flex items-center justify-between p-3 bg-white dark:bg-slate-900 border-b border-[var(--Bdr)] shrink-0 z-30 shadow-sm sticky top-0">
         <div className="flex items-center gap-3">
            <button onClick={() => navigate('/dashboard/network')} className="p-2 hover:bg-gray-100 dark:hover:bg-white/5 rounded-2xl text-tac-blue transition-all" title="Back to Presbytery Network">
               <ChevronLeft size={22} />
            </button>
            <div className={`w-10 h-10 rounded-2xl flex items-center justify-center text-white font-black shadow-lg overflow-hidden shrink-0 ${otherUser?.color || 'bg-tac-blue'}`}>
               {otherUser?.picUrl ? <img src={otherUser.picUrl} className="w-full h-full object-cover" alt={otherUser.name} /> : otherUser?.name?.charAt(0) || '?'}
            </div>
            <div>
               <h3 className="text-sm font-black text-tac-blue-dark dark:text-white leading-tight">{otherUser?.name || 'Direct Connection'}</h3>
               <div className={`text-[10px] font-bold flex items-center gap-1 text-left ${otherTyping ? 'text-tac-blue italic' : otherUser?.online ? 'text-green-600 dark:text-green-400' : 'text-gray-400'}`}>
                 {!otherTyping && <div className={`w-1.5 h-1.5 rounded-full ${otherUser?.online ? 'bg-green-500 animate-pulse' : 'bg-gray-300'}`} />}
                 {otherTyping ? 'typing…' : otherUser?.online ? 'online' : lastSeenLabel(otherUser?.lastSeen)}
               </div>
            </div>
         </div>
         <div className="flex items-center gap-1">
           {otherId && <MuteButton userId={user?.id} target={otherId} />}
           {otherId && (
             <BlockButton
               name={otherUser?.name || 'this person'}
               blocked={!!myBlock}
               onOpen={() => (myBlock ? document.getElementById('dm-blocked-bar')?.scrollIntoView({ behavior: 'smooth' }) : setShowBlockDialog(true))}
             />
           )}
           <ChatSoundToggle />
           <button 
             onClick={() => setIsClearingDM(true)} 
             className="p-2.5 text-gray-400 hover:text-tac-red hover:bg-red-50 dark:hover:bg-white/5 rounded-full transition-all"
             title="Clear DM Chat History"
           >
              <Trash2 size={18} />
           </button>
           <button 
             onClick={() => setShowBgSettings(!showBgSettings)} 
             className="p-2.5 text-tac-blue-dark dark:text-white/60 hover:bg-gray-100 dark:hover:bg-white/5 rounded-full transition-all"
             title="Change Chat Wallpaper"
           >
              <ImageIcon size={20} />
           </button>
         </div>
      </div>

      {/* Background Settings */}
      <AnimatePresence>
        {showBgSettings && (
          <motion.div
            initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }}
            className="absolute top-16 right-3 left-3 sm:left-auto sm:w-96 max-h-[80vh] overflow-y-auto bg-white dark:bg-slate-800 rounded-3xl p-5 shadow-2xl z-[80] border border-gray-100 dark:border-white/10"
          >
            <ChatThemePanel uid={user?.id} scope={otherId ? `dm:${otherId}` : undefined} scopeLabel="this chat" onClose={() => setShowBgSettings(false)} />
          </motion.div>
        )}
      </AnimatePresence>

      {/* Messages Area */}
      <div 
        ref={scrollRef}
        className={`flex-1 min-h-0 overflow-y-auto overscroll-contain p-4 lg:px-12 space-y-2 relative scroll-smooth ${wallpaper.className}`}
        style={wallpaper.style}
      >
        {messages.filter((m) => !clearedAt || Date.parse(String((m as any).createdAt ?? (m as any).timestamp ?? 0)) > clearedAt).map((msg) => (
          <DMMessageBubble 
            key={msg.id} 
            msg={msg} 
            isMe={msg.senderId === user?.id} 
            dmId={dmId!}
            otherOnline={!!otherUser?.online}
            reactions={reactions[msg.id]}
            myId={user?.id}
            onReact={(emoji) => { if (user) chatService.react('dm', msg.id, user.id, emoji).catch((e) => console.warn('Reaction failed:', e)); }}
            onReply={() => { setReplyTo(msg); setShowAttach(false); setShowEmojis(false); }}
          />
        ))}
        {otherTyping && (
          <div className="flex justify-start">
            <div className="bg-white dark:bg-slate-800 rounded-2xl rounded-bl-md px-4 py-3 shadow-sm flex items-center gap-1" aria-label="typing">
              <span className="w-2 h-2 rounded-full bg-gray-400 animate-bounce" style={{ animationDelay: '0ms' }} />
              <span className="w-2 h-2 rounded-full bg-gray-400 animate-bounce" style={{ animationDelay: '150ms' }} />
              <span className="w-2 h-2 rounded-full bg-gray-400 animate-bounce" style={{ animationDelay: '300ms' }} />
            </div>
          </div>
        )}
      </div>

      {showBlockDialog && otherId && (
        <BlockDialog
          name={otherUser?.name || 'this person'}
          otherId={otherId}
          onClose={() => setShowBlockDialog(false)}
          onDone={() => { setShowBlockDialog(false); refreshBlock(); }}
        />
      )}
      <div id="dm-blocked-bar" />
      {myBlock && <BlockedBar name={otherUser?.name || 'this person'} block={myBlock} onUnblocked={refreshBlock} />}
      {suspendedUntil && <SuspendedNotice until={suspendedUntil} />}
      {/* Input Area - Static at Bottom */}
      <div style={myBlock || suspendedUntil ? { display: 'none' } : undefined} className="bg-white dark:bg-slate-900 p-2 sm:p-3 flex flex-col gap-2 relative border-t border-[var(--Bdr)] shrink-0 z-30 sticky bottom-0">
         <input id="dm-file-input" type="file" className="hidden" onChange={handleFileUpload} />
         
         {createPortal(
<AnimatePresence>
            {(isRecording || isVideoRecording || isCapturingPhoto) && (
              <motion.div 
                initial={{ opacity: 0 }} 
                animate={{ opacity: 1 }} 
                exit={{ opacity: 0 }} 
                className="fixed inset-0 h-[100dvh] bg-black/90 z-[200] flex flex-col items-center justify-center px-4 pt-6 pb-[max(1rem,env(safe-area-inset-bottom))] text-white overflow-hidden"
              >
                <div className="absolute top-4 left-4">
                  <h2 className="text-2xl font-black uppercase tracking-widest text-tac-red animate-pulse">
                    {isCapturingPhoto ? 'Camera Active' : `Recording ${isVideoRecording ? 'Video' : 'Audio'}...`}
                  </h2>
                </div>

                <div className="flex-1 flex items-center justify-center w-full">
                  {(isVideoRecording || isCapturingPhoto) ? (
                    <div className="relative w-full max-w-2xl aspect-video bg-black rounded-3xl overflow-hidden border-4 border-white/20 shadow-2xl">
                      <video 
                        ref={(el) => {
                          liveVideoRef.current = el;
                          if (el && (isCapturingPhoto || isVideoRecording)) {
                            el.srcObject = isCapturingPhoto ? cameraStream : recordingStream;
                          }
                        }} 
                        autoPlay playsInline muted className="w-full h-full object-cover" style={isCapturingPhoto && facing === 'user' ? { transform: 'scaleX(-1)' } : undefined}
                      />
                      {!isCapturingPhoto && (
                        <div className="absolute bottom-4 left-1/2 -translate-x-1/2 bg-black/50 backdrop-blur-xl px-4 py-2 rounded-full font-mono text-2xl tracking-tighter">
                          {formatTime(recordingTime)}
                        </div>
                      )}
                    </div>
                  ) : (
                    <div className="flex flex-col items-center gap-8">
                      <div className="w-48 h-48 bg-tac-red rounded-full flex items-center justify-center animate-pulse shadow-[0_0_50px_rgba(239,68,68,0.4)]">
                        <Mic size={80} className="text-white" />
                      </div>
                      <div className="text-6xl font-black tabular-nums font-mono">
                        {formatTime(recordingTime)}
                      </div>
                    </div>
                  )}
                </div>

                <div className="flex items-center gap-8 mb-4 shrink-0">
                  {isCapturingPhoto && (
                    <button onClick={flipCamera} title="Switch camera" aria-label="Switch camera"
                      className="w-14 h-14 bg-white/10 hover:bg-white/20 backdrop-blur-xl text-white rounded-full flex items-center justify-center transition-all border border-white/10 order-last">
                      <RefreshCw size={24} />
                    </button>
                  )}
                  <button 
                    onClick={isCapturingPhoto ? closeCamera : () => stopRecording(false)} 
                    className="w-20 h-20 bg-white/10 hover:bg-white/20 backdrop-blur-xl text-white rounded-full flex items-center justify-center transition-all border border-white/10"
                  >
                    <X size={32} />
                  </button>
                  <button 
                    onClick={isCapturingPhoto ? capturePhoto : () => stopRecording(true)} 
                    className={`w-24 h-24 ${isCapturingPhoto ? 'bg-tac-blue' : 'bg-tac-red'} hover:scale-110 active:scale-95 text-white rounded-full flex items-center justify-center transition-all shadow-2xl`}
                  >
                    {isCapturingPhoto ? <Camera size={48} /> : <StopCircle size={48} />}
                  </button>
                </div>
                <p className="text-sm font-medium text-white/40 uppercase tracking-widest">{isCapturingPhoto ? 'Tap camera to capture' : 'Tap stop to save and send'}</p>
              </motion.div>
            )}
          </AnimatePresence>,
 document.body)}

         {/* Attachments Menu */}
         <AnimatePresence>
           {showAttach && (
             <motion.div 
               initial={{ opacity: 0, y: 20, scale: 0.95 }}
               animate={{ opacity: 1, y: 0, scale: 1 }}
               exit={{ opacity: 0, y: 20, scale: 0.95 }}
               className="absolute bottom-20 left-4 bg-white dark:bg-slate-800 rounded-[2.5rem] p-6 shadow-2xl z-[60] border border-gray-100 dark:border-white/10 grid grid-cols-3 gap-6"
             >
               <AttachmentOption 
                 icon={<Camera className="text-blue-500" />} 
                 label="Camera" 
                 onClick={takeSnapshot} 
               />
               <AttachmentOption 
                 icon={<ImageIcon className="text-purple-500" />} 
                 label="Gallery" 
                 onClick={() => { document.getElementById('dm-file-input')?.click(); }} 
               />
               <AttachmentOption 
                 icon={<File className="text-orange-500" />} 
                 label="Document" 
                 onClick={() => { document.getElementById('dm-file-input')?.click(); }} 
               />
               <AttachmentOption 
                 icon={<Music className="text-pink-500" />} 
                 label="Audio" 
                 onClick={() => { setShowAttach(false); setShowAudioRecorder(true); }} 
               />
               <AttachmentOption 
                 icon={<Navigation className="text-green-500" />} 
                 label="Location" 
                 onClick={handleLocation} 
               />
               <AttachmentOption 
                 icon={<Video className="text-red-500" />} 
                 label="Video Msg" 
                 onClick={() => startRecording('video')} 
               />
             </motion.div>
           )}
         </AnimatePresence>

         {/* Emoji Picker */}
         <AnimatePresence>
           {showEmojis && (
             <motion.div 
               initial={{ opacity: 0, y: 20 }}
               animate={{ opacity: 1, y: 0 }}
               exit={{ opacity: 0, y: 20 }}
               className="absolute bottom-20 left-1/2 -translate-x-1/2 w-[92%] max-w-[340px] bg-white dark:bg-slate-800 rounded-3xl p-4 shadow-2xl z-[60] border border-gray-100 dark:border-white/10"
             >
               {/* Mobile Header with visible Close button */}
               <div className="flex items-center justify-between pb-2 mb-2 border-b border-gray-100 dark:border-white/10">
                 <div className="flex items-center gap-1.5 text-tac-blue font-black uppercase text-xs tracking-wider">
                   <Smile size={18} />
                   <span>Emojis</span>
                 </div>
                 <button 
                   type="button" 
                   onClick={() => setShowEmojis(false)}
                   className="p-1.5 bg-gray-100 dark:bg-white/10 hover:bg-gray-200 text-gray-500 dark:text-gray-300 rounded-full active:scale-90 transition-all flex items-center justify-center"
                   title="Close emojis"
                 >
                   <X size={16} />
                 </button>
               </div>
               {recentEmojis.length > 0 && (
                 <div className="mb-4">
                   <p className="text-[10px] font-black uppercase text-gray-400 tracking-widest mb-2 px-1">Recently Used</p>
                   <div className="flex flex-wrap gap-2">
                      {recentEmojis.map(emoji => (
                        <button key={emoji} onClick={() => saveEmoji(emoji)} className="text-2xl p-2 hover:bg-gray-100 rounded-xl">{emoji}</button>
                      ))}
                   </div>
                 </div>
               )}
               <div className="grid grid-cols-7 gap-2 overflow-y-auto max-h-48 scrollbar-none">
                 {emojis.map(emoji => (
                   <button 
                     key={emoji} 
                     onClick={() => saveEmoji(emoji)}
                     className="text-2xl hover:bg-gray-100 dark:hover:bg-white/5 p-2 rounded-xl transition-all active:scale-90"
                   >
                     {emoji}
                   </button>
                 ))}
               </div>
             </motion.div>
           )}
         </AnimatePresence>

         {/* Real-time Send Error Alert Banner */}
         <AnimatePresence>
           {sendError && (
             <motion.div 
               initial={{ y: 20, opacity: 0 }}
               animate={{ y: 0, opacity: 1 }}
               exit={{ y: 20, opacity: 0 }}
               className="mb-2 p-3 bg-red-50 dark:bg-red-950/70 border border-red-200 dark:border-red-800/70 rounded-2xl flex items-center justify-between text-xs text-red-600 dark:text-red-300 font-semibold shadow-md z-30"
             >
               <div className="flex items-center gap-2">
                 <span className="text-base shrink-0 font-black">!</span>
                 <p className="leading-snug">{sendError}</p>
               </div>
               <button 
                 type="button"
                 onClick={() => setSendError(null)}
                 className="p-1 hover:bg-black/5 dark:hover:bg-white/10 rounded-full shrink-0 ml-2"
                 title="Dismiss"
               >
                 <X size={14} />
               </button>
             </motion.div>
           )}
         </AnimatePresence>

         {/* Reply Preview */}
         <AnimatePresence>
           {replyingTo && (
             <motion.div 
               initial={{ y: 20, opacity: 0 }}
               animate={{ y: 0, opacity: 1 }}
               exit={{ y: 20, opacity: 0 }}
               className="mb-2 px-3 py-2 bg-white/90 dark:bg-slate-800/90 backdrop-blur-sm border border-tac-blue/20 rounded-2xl flex items-center gap-3 shadow-sm"
             >
               <div className="flex-1 bg-gray-50 dark:bg-white/5 border-l-4 border-tac-blue rounded-lg p-2 text-xs text-left">
                 <p className="font-bold text-tac-blue">{replyingTo.senderName}</p>
                 <p className="text-gray-500 dark:text-gray-400 truncate">{replyingTo.text || (replyingTo.img ? 'Photo' : replyingTo.vid ? 'Video' : 'Voice message')}</p>
               </div>
               <button onClick={() => setReplyTo(null)} className="p-1.5 hover:bg-gray-100 dark:hover:bg-white/10 rounded-full">
                 <X size={16} className="text-gray-400" />
               </button>
             </motion.div>
           )}
         </AnimatePresence>

         <div className="flex items-center gap-1.5 sm:gap-2">
           <div className="flex-1 min-w-[60px] bg-gray-50 dark:bg-white/5 rounded-2xl flex items-center px-1 border border-gray-100 dark:border-white/10">
             <button onClick={() => { setShowAttach(!showAttach); setShowEmojis(false); }} className={`p-2.5 transition-colors ${showAttach ? 'text-tac-blue' : 'text-gray-500 hover:text-tac-blue'}`}><Plus size={20} /></button>
             <button onClick={() => { setShowEmojis(!showEmojis); setShowAttach(false); }} className={`p-2.5 transition-colors ${showEmojis ? 'text-tac-blue' : 'text-gray-500 hover:text-tac-blue'}`}><Smile size={20} /></button>
             <input 
               type="text" placeholder="Message" value={inputText} onChange={(e) => setInputText(e.target.value)}
               onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
               className="flex-1 py-3 text-sm outline-none px-1 bg-transparent dark:text-white"
             />
             <button 
               onClick={takeSnapshot}
               className="p-2.5 text-gray-400 hover:text-tac-blue transition-all"
             >
               <Camera size={20} />
             </button>
             {!inputText.trim() && (
               <button 
                 type="button" 
                 onClick={() => startRecording('video')}
                 className="p-2.5 text-gray-400 hover:text-tac-red transition-all"
               >
                 <Video size={20} />
               </button>
             )}
           </div>
           <button 
             type="button"
             onClick={inputText.trim() ? () => handleSendMessage() : undefined}
            {...(inputText.trim() ? {} : holdMic)}
            style={{ touchAction: 'none', WebkitTouchCallout: 'none', userSelect: 'none' }}
             className={`w-10 h-10 sm:w-12 sm:h-12 rounded-2xl flex items-center justify-center shadow-lg shrink-0 ${inputText.trim() ? 'bg-tac-blue' : 'bg-[#005c4b]'} text-white transition-all hover:scale-105 active:scale-95`}
             title={inputText.trim() ? 'Send message' : 'Record voice note (WhatsApp style)'}
           >
             {inputText.trim() ? <Send size={18} className="sm:w-5 sm:h-5" /> : <Mic size={18} className="sm:w-5 sm:h-5" />}
           </button>
         </div>
      </div>

      {/* WhatsApp Voice Recording Dedicated Page/Screen */}
      <WhatsAppAudioRecorder
        isOpen={showAudioRecorder}
        releaseSignal={releaseSignal}
        onClose={() => setShowAudioRecorder(false)}
        onSend={(_blob, dataUrl) => {
          handleSendMessage("Voice message", { voice: dataUrl });
          setShowAudioRecorder(false);
        }}
        onError={(err) => setSendError(err)}
      />
    </div>
  );
};

const AttachmentOption: React.FC<{ icon: React.ReactNode; label: string; onClick: () => void }> = ({ icon, label, onClick }) => (
  <button 
    onClick={onClick}
    className="flex flex-col items-center gap-2 group"
  >
    <div className="w-14 h-14 bg-gray-50 dark:bg-white/5 rounded-2xl flex items-center justify-center group-hover:scale-110 transition-all shadow-sm border border-gray-100 dark:border-white/5">
      {React.cloneElement(icon as React.ReactElement, { size: 24 })}
    </div>
    <span className="text-[10px] font-black uppercase tracking-widest text-gray-400 group-hover:text-tac-blue transition-colors">{label}</span>
  </button>
);

const DMMessageBubble: React.FC<{ msg: ChatMessage; isMe: boolean; dmId: string; otherOnline: boolean; reactions?: Reaction[]; myId?: string; onReact: (emoji: string | null) => void; onReply: () => void }> = ({ msg, isMe, dmId, otherOnline, reactions, myId, onReact, onReply }) => {
  const { profile } = useAuth();
  const [showOptions, setShowOptions] = useState(false);

  const handleDelete = async () => {
    // participants are allowed to delete in DMs
    if (confirm('Delete this message?')) {
      try {
        await chatService.deleteDirectMessage(msg.id);
      } catch (err) {
        handleFirestoreError(err, OperationType.DELETE, `dms/${dmId}/messages/${msg.id}`);
      }
    }
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 10, scale: 0.95 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      onContextMenu={(e) => {
        e.preventDefault();
        setShowOptions(true);
      }}
      onClick={() => setShowOptions(true)}
      // slide the message to the right to reply, like WhatsApp
      drag="x"
      dragDirectionLock
      dragConstraints={{ left: 0, right: 0 }}
      dragElastic={{ left: 0, right: 0.6 }}
      onDragEnd={(_, info) => { if (info.offset.x > 50) onReply(); }}
      style={{ touchAction: 'pan-y' }}
      className={`relative flex w-full ${isMe ? 'justify-end' : 'justify-start'} group mb-1 cursor-pointer`}
    >
      <span className="absolute -left-7 top-1/2 -translate-y-1/2 w-6 h-6 rounded-full bg-tac-blue/15 text-tac-blue flex items-center justify-center pointer-events-none"><Reply size={13} /></span>
      <div className={`relative max-w-[85%] lg:max-w-2xl px-2.5 py-1.5 rounded-xl shadow-sm ${isMe ? 'chat-bubble-mine bg-[#d9fdd3] dark:bg-[#005c4b] rounded-tr-none' : 'chat-bubble-theirs bg-white dark:bg-[#202c33] rounded-tl-none border border-black/5 dark:border-none'}`}>
        
        {/* Actions on Hover */}
        <div className={`absolute top-0 flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity z-10 ${isMe ? '-left-10' : '-right-10'}`}>
          <button 
            onClick={(e) => { e.stopPropagation(); handleDelete(); }}
            className="p-1.5 bg-white/90 dark:bg-slate-800 backdrop-blur rounded-full shadow-lg text-tac-red"
          >
            <Trash2 size={14} />
          </button>
        </div>

        {/* Mobile/Click Options Overlay */}
        <AnimatePresence>
          {showOptions && (
            <div 
              className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/20"
              onClick={(e) => { e.stopPropagation(); setShowOptions(false); }}
            >
              <motion.div 
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.9, opacity: 0 }}
                className="bg-white dark:bg-slate-900 rounded-3xl p-2 shadow-2xl min-w-[160px] border border-gray-100 dark:border-white/10"
                onClick={e => e.stopPropagation()}
              >
                <ReactionPicker mine={reactions?.find((r) => r.userId === myId)?.emoji} onPick={(e) => { onReact(e); setShowOptions(false); }} />
                <button 
                  onClick={() => { onReply(); setShowOptions(false); }}
                  className="w-full flex items-center gap-3 px-4 py-3 hover:bg-gray-50 dark:hover:bg-white/5 rounded-2xl transition-all text-tac-blue"
                >
                  <Reply size={18} />
                  <span className="text-sm font-black">Reply</span>
                </button>
                <button 
                  onClick={() => { handleDelete(); setShowOptions(false); }}
                  className="w-full flex items-center gap-3 px-4 py-3 hover:bg-red-50 dark:hover:bg-red-900/10 rounded-2xl transition-all text-tac-red"
                >
                  <Trash2 size={18} />
                  <span className="text-sm font-black">Delete Message</span>
                </button>
                <button 
                  onClick={() => setShowOptions(false)}
                  className="w-full flex items-center gap-3 px-4 py-3 hover:bg-gray-50 dark:hover:bg-white/5 rounded-2xl transition-all text-gray-400"
                >
                  <X size={18} />
                  <span className="text-sm font-bold">Cancel</span>
                </button>
              </motion.div>
            </div>
          )}
        </AnimatePresence>

        {msg.replyTo && (msg.replyTo.text || msg.replyTo.img || msg.replyTo.vid || msg.replyTo.sender) && (
          <div className={`mb-1.5 px-2.5 py-1.5 rounded-lg text-xs border-l-4 border-emerald-600 overflow-hidden ${isMe ? 'bg-black/[0.07] dark:bg-black/25' : 'bg-black/[0.05] dark:bg-white/10'}`}>
            <p className="font-bold text-emerald-700 dark:text-emerald-400 mb-0.5 text-left truncate">{msg.replyTo.sender}</p>
            <p className="opacity-70 line-clamp-2 leading-tight text-left dark:text-white/70">{msg.replyTo.text || (msg.replyTo.img ? 'Photo' : msg.replyTo.vid ? 'Video' : '')}</p>
          </div>
        )}

        {msg.img && (
          <div className="mb-2 rounded-lg overflow-hidden bg-white">
             <img src={msg.img} alt="media" className="w-full max-h-80 object-cover" />
          </div>
        )}

        {msg.vid && (
          <div className="mb-2 rounded-lg overflow-hidden bg-black aspect-video max-w-sm">
            <video 
              src={msg.vid} 
              controls 
              className="w-full h-full object-contain" 
              onError={(e) => {
                (e.currentTarget as HTMLVideoElement).style.display = 'none';
              }}
            />
          </div>
        )}

        {msg.voice && (
          <div className="mb-2 p-2 bg-white/10 rounded-xl">
             <audio 
               src={msg.voice} 
               controls 
               onPlay={(e) => pauseOthers(e.currentTarget)}
               className="w-full h-8" 
               onError={(e) => {
                 (e.currentTarget as HTMLAudioElement).style.display = 'none';
               }}
             />
          </div>
        )}

        {msg.location && (
          <a 
            href={msg.location.url} 
            target="_blank" 
            rel="noopener noreferrer"
            className="mb-2 block rounded-xl overflow-hidden bg-blue-50 dark:bg-blue-900/10 border border-blue-100 dark:border-blue-800"
          >
            <div className="p-3 flex items-center gap-3">
              <div className="w-10 h-10 bg-blue-500 rounded-full flex items-center justify-center text-white">
                <MapPin size={20} />
              </div>
              <div>
                <div className="text-[12px] font-black text-blue-600 dark:text-blue-400 uppercase tracking-widest">Shared Location</div>
                <div className="text-[10px] text-blue-400 line-clamp-1">Open in Google Maps</div>
              </div>
            </div>
          </a>
        )}

        {/* Message Content & Timestamp (Inline/Flex layout prevents any text collision or overlap) */}
        <div className="flex flex-wrap items-end justify-between gap-x-2.5 gap-y-1 text-left min-w-[70px] pt-0.5">
          {msg.text && !isAutoCaption(msg.text) && (
            <div className="chat-msg-text text-[#111b21] dark:text-slate-100 break-words whitespace-pre-wrap flex-1 min-w-[60px]">
              {msg.text}
            </div>
          )}
          <div className="ml-auto shrink-0 flex items-center gap-1 select-none self-end pb-0.5 pl-1">
            <span className="text-[10px] text-[#667781] dark:text-slate-400 font-medium leading-none">{msg.time}</span>
            {isMe && (
              // These used to be permanently blue ("read") regardless of what
              // had happened. Now: blue double = they've read it; grey
              // double = delivered (they're online, so it reached their
              // device); single grey = sent.
              msg.readBy?.length ? <CheckCheck size={12} className="text-[#53bdeb] shrink-0" />
              : msg.deliveredTo?.length ? <CheckCheck size={12} className="text-[#8696a0] shrink-0" />
              : <Check size={12} className="text-[#8696a0] shrink-0" />
            )}
          </div>
        </div>
        <ReactionChips reactions={reactions} myId={myId} onReact={onReact} />
      </div>
    </motion.div>
  );
};

export default DirectMessageView;
