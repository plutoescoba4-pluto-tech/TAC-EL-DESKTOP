import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Mic, 
  MicOff, 
  PhoneOff, 
  Users, 
  Radio, 
  Volume2, 
  Shield, 
  Circle,
  MessageSquare,
  Settings,
  MoreVertical,
  Lock,
  Headphones,
  Signal,
  BookOpen,
  Send,
  Bookmark,
  BookmarkCheck
} from 'lucide-react';
import { liveSessionService } from '../../services/liveSessionService';
import { VoiceMesh } from '../../lib/voiceMesh';
import { LiveKitMesh } from '../../lib/liveKitMesh';
import { LIVEKIT_ENABLED, liveHost } from '../../lib/liveKit';

// Clean voice: the phone removes echo and background noise and evens out the volume (like WhatsApp calls)
const MIC_CONSTRAINTS: MediaStreamConstraints = { audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true, channelCount: 1 } as MediaTrackConstraints };
import { VoiceSessionRecorder } from '../../lib/voiceRecorder';
import { voiceRecordingsService } from '../../services/voiceRecordingsService';
import { useAuth } from '../../context/AuthContext';
import { handleFirestoreError, OperationType } from '../../lib/firestore-errors';
import { localCollection } from '../../lib/localCollection';
import { supabase } from '../../supabase';
import type { RealtimeChannel } from '@supabase/supabase-js';

interface BulletinVerse {
  id: string;
  reference: string;
  text: string;
  postedBy: string;
  postedAt: string;
}

const VoiceConference: React.FC = () => {
  const { user, profile, quotaExceeded } = useAuth();
  const [activeRoom, setActiveRoom] = useState<any>(null);
  const [participants, setParticipants] = useState<any[]>([]);
  const [isJoined, setIsJoined] = useState(false);
  const [isMuted, setIsMuted] = useState(true);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isStartingRoom, setIsStartingRoom] = useState(false);
  const [micError, setMicError] = useState<string | null>(null);
  const [remoteStreams, setRemoteStreams] = useState<Record<string, MediaStream>>({});
  const [bulletinVerses, setBulletinVerses] = useState<BulletinVerse[]>([]);
  const [savedVerseIds, setSavedVerseIds] = useState<Set<string>>(new Set());
  const [verseRefInput, setVerseRefInput] = useState('');
  const [verseTextInput, setVerseTextInput] = useState('');
  const [postingVerse, setPostingVerse] = useState(false);
  const bulletinChannelRef = useRef<RealtimeChannel | null>(null);

  const audioContextRef = useRef<AudioContext | null>(null);
  const analystRef = useRef<AnalyserNode | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const intervalRef = useRef<any>(null);
  const voiceChannelRef = useRef<RealtimeChannel | null>(null);
  const meshRef = useRef<any>(null);
  const handRef = useRef(false);
  const canSpeakRef = useRef(true);
  const [canSpeak, setCanSpeak] = useState(true);
  const [handUp, setHandUp] = useState(false);
  const [hostBusy, setHostBusy] = useState<string | null>(null);
  const connectedPeerIdsRef = useRef<Set<string>>(new Set());
  // setInterval's callback in startMonitoring only closes over whatever
  // `isMuted` was at the moment it was created (join time) — a ref keeps it
  // reading the live value instead, so the speaking indicator (and the
  // mute-aware auto-clear below) stay correct after toggling mute later.
  const isMutedRef = useRef(true);
  const isSpeakingRef = useRef(false);
  // Host-only: records the mixed room audio so admin can publish it later.
  const recorderRef = useRef<VoiceSessionRecorder | null>(null);
  const isRecordingRef = useRef(false);
  const pendingAutoJoinRef = useRef<string | null>(null);
  const finishRecordingRef = useRef<() => void>(() => {});
  const [recordingNotice, setRecordingNotice] = useState<string | null>(null);

  const isAdmin = profile?.role === 'admin' || profile?.role === 'presbytery';
  const isHost = !!(activeRoom && user?.id === activeRoom.hostId);

  useEffect(() => {
    // Listen for active room
    const unsubRoom = liveSessionService.subscribeToActiveRooms((rooms) => {
      if (rooms.length > 0) {
        setActiveRoom(rooms[0]);
      } else {
        setActiveRoom(null);
        setIsJoined(false);
      }
    });

    return () => unsubRoom();
  }, []);

  useEffect(() => {
    if (activeRoom && user) {
      // Not tracking our own presence yet (self: null) — that only starts
      // once joinRoom() is called below. This just lets us see who's
      // already in the room before we join.
      const { channel, unsubscribe } = liveSessionService.subscribeParticipants(
        activeRoom.id,
        null,
        (parts) => {
          setParticipants(Object.entries(parts).map(([id, p]) => ({ id, ...p })));
        }
      );
      voiceChannelRef.current = channel;
      return () => {
        voiceChannelRef.current = null;
        unsubscribe();
      };
    }
  }, [activeRoom?.id, user?.id]);

  // Live Bulletin: the host shares Bible verses during the session, which
  // everyone present can save to their own notes. Broadcast over Realtime
  // rather than a table — there's no table for session-scoped verses, and a
  // "live" bulletin doesn't need to outlive the room anyway. Anyone viewing
  // the room (not just joined/unmuted) can see and save verses.
  useEffect(() => {
    if (!activeRoom) {
      setBulletinVerses([]);
      return;
    }
    const channel = supabase
      .channel(`voice-bulletin:${activeRoom.id}`, { config: { broadcast: { self: true } } })
      .on('broadcast', { event: 'verse' }, ({ payload }) => {
        setBulletinVerses((prev) => [payload as BulletinVerse, ...prev]);
      })
      .subscribe();
    bulletinChannelRef.current = channel;
    return () => {
      bulletinChannelRef.current = null;
      supabase.removeChannel(channel);
    };
  }, [activeRoom?.id]);

  const postVerse = async () => {
    if (!user || !profile || !verseRefInput.trim() || !verseTextInput.trim() || !bulletinChannelRef.current) return;
    setPostingVerse(true);
    try {
      const verse: BulletinVerse = {
        id: crypto.randomUUID(),
        reference: verseRefInput.trim(),
        text: verseTextInput.trim(),
        postedBy: profile.name || 'Host',
        postedAt: new Date().toISOString(),
      };
      await bulletinChannelRef.current.send({ type: 'broadcast', event: 'verse', payload: verse });
      setVerseRefInput('');
      setVerseTextInput('');
    } finally {
      setPostingVerse(false);
    }
  };

  const saveVerseToNotes = (verse: BulletinVerse) => {
    if (!user) return;
    localCollection.add(user.id, 'bookmarks', {
      reference: verse.reference,
      text: verse.text,
    });
    setSavedVerseIds((prev) => new Set(prev).add(verse.id));
  };

  // A recording only exists in the host's browser until the room ends, so
  // closing the tab mid-session would lose the whole prayer. Ask first.
  useEffect(() => {
    const warn = (e: BeforeUnloadEvent) => {
      if (recorderRef.current) {
        e.preventDefault();
        e.returnValue = '';
      }
    };
    window.addEventListener('beforeunload', warn);
    return () => window.removeEventListener('beforeunload', warn);
  }, []);

  // Safety net: if someone navigates away from this screen entirely while
  // still joined (not using the Leave button), make sure the mic actually
  // stops and the mesh tears down instead of silently running in the
  // background.
  useEffect(() => {
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
      if (streamRef.current) streamRef.current.getTracks().forEach((t) => t.stop());
      if (audioContextRef.current) audioContextRef.current.close();
      meshRef.current?.destroy();
      finishRecordingRef.current(); // saves the host's recording if they navigate away mid-session
    };
  }, []);

  // Completes a host's "Start Room": join once the room and its presence
  // channel have actually appeared in state.
  useEffect(() => {
    if (
      pendingAutoJoinRef.current &&
      activeRoom?.id === pendingAutoJoinRef.current &&
      voiceChannelRef.current &&
      !isJoined
    ) {
      pendingAutoJoinRef.current = null;
      joinRoom();
    }
  }, [activeRoom?.id, participants, isJoined]);

  // Keep the WebRTC mesh in sync with who's actually in the room: connect to
  // anyone new, drop anyone who left. This is what makes audio actually flow
  // between participants — without it, the room only ever showed presence
  // (names, mute/speaking icons) with no real audio connection underneath.
  useEffect(() => {
    if (!isJoined || !meshRef.current) return;
    const currentIds = new Set(participants.map((p) => p.id).filter((id) => id !== user?.id));

    for (const id of currentIds) {
      if (!connectedPeerIdsRef.current.has(id)) {
        meshRef.current.connectTo(id);
      }
    }
    for (const id of connectedPeerIdsRef.current) {
      if (!currentIds.has(id)) {
        meshRef.current.removePeer(id);
        setRemoteStreams((prev) => {
          const next = { ...prev };
          delete next[id];
          return next;
        });
      }
    }
    connectedPeerIdsRef.current = currentIds;
  }, [participants, isJoined, user?.id]);

  const startRoom = async () => {
    if (!user) return;
    setIsStartingRoom(true);
    try {
      const roomId = await liveSessionService.startRoom({
        title: 'Global Assembly Voice Prayer',
        hostId: user.id,
        hostName: profile?.name || 'Admin',
      });
      // The room + presence channel don't exist in state yet, so joining
      // right now silently did nothing. Queue it; the effect below joins
      // as soon as the channel is ready.
      pendingAutoJoinRef.current = roomId;
    } catch (e: any) {
      handleFirestoreError(e, OperationType.CREATE, 'voice_rooms');
    } finally {
      setIsStartingRoom(false);
    }
  };

  const [isEndingRoom, setIsEndingRoom] = useState(false);
  const [showConfirmEnd, setShowConfirmEnd] = useState(false);

  const endRoom = async () => {
    if (!activeRoom) return;
    
    setIsEndingRoom(true);
    const targetRoomId = activeRoom.id;

    // Immediate UI feedback
    setIsJoined(false);
    setActiveRoom(null);
    stopMonitoring();
    setShowConfirmEnd(false);

    try {
      voiceChannelRef.current?.untrack();
      if (LIVEKIT_ENABLED) { try { await liveHost.endRoom(targetRoomId); } catch (e) { console.warn('LiveKit room close:', e); } }
      await liveSessionService.endRoom(targetRoomId);
      // Clear any other orphan active rooms this host may have left dangling.
      if (user) await liveSessionService.endAllActiveRoomsStartedBy(user.id);
    } catch (e: any) {
      console.warn("End room backend sync warning:", e);
    } finally {
      setIsEndingRoom(false);
    }
  };

  const joinRoom = async (overrideId?: string) => {
    const roomId = overrideId || activeRoom?.id;
    if (!user || !roomId || !voiceChannelRef.current) return;

    try {
      await voiceChannelRef.current.track({
        hand: false, canSpeak: canSpeakRef.current,
        name: profile?.name || 'Member',
        photo: profile?.picUrl, recording: isRecordingRef.current,
        isMuted: true,
        isSpeaking: false,
      });
      setIsJoined(true);
      setIsMuted(true);
      isMutedRef.current = true;
      isSpeakingRef.current = false;
      startMonitoring(roomId, isHost);
    } catch (e: any) {
      handleFirestoreError(e, OperationType.WRITE, `voice_rooms/${roomId}/participants`);
    }
  };

  const leaveRoom = async () => {
    if (!user || !activeRoom) return;
    try {
      await voiceChannelRef.current?.untrack();
      setIsJoined(false);
      stopMonitoring();
    } catch (e) {
      console.error(e);
    }
  };

  const toggleHand = async () => {
    if (!voiceChannelRef.current) return;
    const next = !handRef.current;
    handRef.current = next; setHandUp(next);
    try { await voiceChannelRef.current.track({ hand: next, canSpeak: canSpeakRef.current, name: profile?.name || 'Member', photo: profile?.picUrl, recording: isRecordingRef.current, isMuted: isMutedRef.current, isSpeaking: false }); } catch (e) { console.warn(e); }
  };

  const hostAction = async (kind: 'allow' | 'stop' | 'remove', personId: string) => {
    if (!activeRoom) return;
    setHostBusy(personId); setMicError(null);
    try {
      if (kind === 'remove') await liveHost.remove(activeRoom.id, personId);
      else await liveHost.setSpeaker(activeRoom.id, personId, kind === 'allow');
    } catch (e: any) { setMicError(e?.message || 'That did not work. Please try again.'); }
    finally { setHostBusy(null); }
  };

  const toggleMute = async () => {
    if (!user || !activeRoom || !voiceChannelRef.current) return;
    const newMute = !isMuted;
    setIsMuted(newMute);
    isMutedRef.current = newMute;
    // Actually stop/start transmitting audio, not just flip a visual badge —
    // this is the real mute now that there's a real audio connection.
    meshRef.current?.setMuted(newMute);
    try {
      await voiceChannelRef.current.track({ hand: handRef.current, canSpeak: canSpeakRef.current, name: profile?.name || 'Member', photo: profile?.picUrl, recording: isRecordingRef.current, isMuted: newMute, isSpeaking });
    } catch (e: any) {
      console.error(e);
    }
  };

  const startLevelMeter = (stream: MediaStream) => {
    try { if (intervalRef.current) clearInterval(intervalRef.current); } catch { /* ignore */ }
    try { audioContextRef.current?.close(); } catch { /* ignore */ }
      const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
 audioContextRef.current = audioContext;
      audioContext.resume().catch(() => {}); // Safari/Chrome may start it suspended; the speaking indicator needs it running
      
      const source = audioContext.createMediaStreamSource(stream);
      const analyser = audioContext.createAnalyser();
      analyser.fftSize = 256;
      source.connect(analyser);
      analystRef.current = analyser;
      
      const bufferLength = analyser.frequencyBinCount;
      const dataArray = new Uint8Array(bufferLength);
      
      intervalRef.current = setInterval(async () => {
        if (isMutedRef.current) {
           if (isSpeakingRef.current) {
             isSpeakingRef.current = false;
             setIsSpeaking(false);
             await voiceChannelRef.current?.track({ hand: handRef.current, canSpeak: canSpeakRef.current, name: profile?.name || 'Member', photo: profile?.picUrl, recording: isRecordingRef.current, isMuted: true, isSpeaking: false });
           }
           return;
        }

        analyser.getByteFrequencyData(dataArray);
        let sum = 0;
        for (let i = 0; i < bufferLength; i++) {
          sum += dataArray[i];
        }
        const average = sum / bufferLength;
        const speaking = average > 20;
        
        if (speaking !== isSpeakingRef.current) {
          isSpeakingRef.current = speaking;
          setIsSpeaking(speaking);
          await voiceChannelRef.current?.track({ hand: handRef.current, canSpeak: canSpeakRef.current, name: profile?.name || 'Member', photo: profile?.picUrl, recording: isRecordingRef.current, isMuted: isMutedRef.current, isSpeaking: speaking });
        }
      }, 500);
  };

  const startMonitoring = async (roomId: string, asHost: boolean) => {
    if (!user) return;
    setMicError(null);
    const onRemoteStream = (peerId: string, remoteStream: MediaStream | null) => {
          if (remoteStream) recorderRef.current?.addStream(peerId, remoteStream);
          else recorderRef.current?.removeStream(peerId);
          setRemoteStreams((prev) => {
            const next = { ...prev };
            if (remoteStream) next[peerId] = remoteStream;
            else delete next[peerId];
            return next;
          });
    };
    const onPeerError = (peerId: string, err: unknown) => {
      console.warn(`Voice connection issue with ${peerId}:`, err);
    };
    const makeMesh = (localStream: MediaStream): any =>
      new VoiceMesh({ roomId, selfId: user.id, localStream, onRemoteStream, onPeerError });

    // LiveKit: the host (or an admin, or someone the host allowed) speaks; everyone else listens and can raise a hand.
    const retrack = () => voiceChannelRef.current?.track({ hand: handRef.current, canSpeak: canSpeakRef.current, name: profile?.name || 'Member', photo: profile?.picUrl, recording: isRecordingRef.current, isMuted: isMutedRef.current, isSpeaking: isSpeakingRef.current });
    const openMic = async (): Promise<MediaStream> => {
      const st = await navigator.mediaDevices.getUserMedia(MIC_CONSTRAINTS);
      st.getAudioTracks().forEach((t) => { t.enabled = !isMutedRef.current; });
      streamRef.current = st;
      startLevelMeter(st);
      return st;
    };
    const connectLiveKit = async () => {
      const mesh = await LiveKitMesh.connect({
        roomId, selfId: user.id, onRemoteStream, onPeerError,
        onPermission: async (can: boolean) => {
          canSpeakRef.current = can; setCanSpeak(can);
          if (can) {
            try { const st = await openMic(); await meshRef.current?.publishMic(st); meshRef.current?.setMuted(isMutedRef.current); } catch (e) { setMicError('You were allowed to speak, but the microphone could not start. Check microphone permission.'); }
          } else {
            handRef.current = false; setHandUp(false);
            await meshRef.current?.stopMic();
            streamRef.current?.getTracks().forEach((t) => t.stop());
          }
          retrack();
        },
      });
      meshRef.current = mesh;
      canSpeakRef.current = mesh.canPublish; setCanSpeak(mesh.canPublish);
      return mesh;
    };
    try {
      let stream: MediaStream;
      if (LIVEKIT_ENABLED) {
        let lk: any;
        try { lk = await connectLiveKit(); }
        catch (e: any) { setMicError(e?.message || 'Could not connect to the live server.'); setIsJoined(false); return; }
        stream = lk.canPublish ? await navigator.mediaDevices.getUserMedia(MIC_CONSTRAINTS) : new MediaStream();
        if (lk.canPublish) { await lk.publishMic(stream); lk.setMuted(true); }
      } else {
        stream = await navigator.mediaDevices.getUserMedia(MIC_CONSTRAINTS);
      }
      streamRef.current = stream;
      retrack();

      // Mic starts muted to match the UI's default muted state — the local
      // track exists (needed so joining/unmuting is instant) but doesn't
      // transmit until the person taps unmute.
      stream.getAudioTracks().forEach((t) => { t.enabled = false; });

      // This is the actual audio connection to everyone else in the room —
      // separate from the presence channel above, which only ever tracked
      // who's "in" the room, never carried any audio.
      if (!LIVEKIT_ENABLED) meshRef.current = makeMesh(stream);
      // The host's browser already receives everyone's audio, so it's the one
      // place the whole session can be recorded. Participants are told
      // (banner + presence flag) that the session is being recorded.
      if (asHost && !recorderRef.current) {
        try {
          recorderRef.current = new VoiceSessionRecorder(stream);
          isRecordingRef.current = true;
          voiceChannelRef.current?.track({ hand: handRef.current, canSpeak: canSpeakRef.current, name: profile?.name || 'Member', photo: profile?.picUrl, recording: true, isMuted: true, isSpeaking: false });
        } catch (recErr) {
          console.warn('Could not start session recording:', recErr);
        }
      }

      // Connect to everyone already in the room (the diffing effect above
      // handles anyone who joins/leaves after this point).
      participants.filter((p) => p.id !== user.id).forEach((p) => meshRef.current?.connectTo(p.id));
      connectedPeerIdsRef.current = new Set(participants.map((p) => p.id).filter((id) => id !== user.id));

      if (stream.getAudioTracks().length) startLevelMeter(stream);
      
    } catch (err: any) {
      console.error("Mic access denied", err);
      // Don't leave the person stranded: join as a LISTENER (receive-only) so they
      // can still hear the prayer without a microphone.
      if (!meshRef.current) {
        try {
          meshRef.current = makeMesh(new MediaStream());
          participants.filter((p) => p.id !== user.id).forEach((p) => meshRef.current?.connectTo(p.id));
          connectedPeerIdsRef.current = new Set(participants.map((p) => p.id).filter((id) => id !== user.id));
        } catch (meshErr) {
          console.warn('Could not start listen-only mode:', meshErr);
        }
      }
      // This used to fail completely silently — joining the room would
      // "work" but no mic permission prompt ever appeared and nothing told
      // you why you couldn't be heard.
      setMicError(
        err?.name === 'NotAllowedError' || err?.name === 'PermissionDeniedError'
          ? 'Microphone access was denied. Please allow microphone access in your browser settings to speak. You are connected as a listener.'
          : 'Could not access your microphone. Please check that a microphone is connected to speak. You are connected as a listener.'
      );
    }
  };

  const stopMonitoring = () => {
    if (intervalRef.current) clearInterval(intervalRef.current);
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
    }
    if (audioContextRef.current) {
      audioContextRef.current.close();
    }
    meshRef.current?.destroy();
    meshRef.current = null;
    connectedPeerIdsRef.current = new Set();
    setRemoteStreams({});
    setIsSpeaking(false);
    finishRecording();
  };

  /** Stops the host's recording and sends it to the admin's inbox. */
  const finishRecording = async () => {
    const recorder = recorderRef.current;
    if (!recorder) return;
    recorderRef.current = null;
    isRecordingRef.current = false;
    try {
      const { blob, durationSec } = await recorder.stop();
      // Under ~10s is almost certainly an accidental join/leave, not a prayer.
      if (durationSec < 10 || blob.size === 0) return;
      await voiceRecordingsService.uploadPending(blob, profile?.name || 'Host', durationSec);
      setRecordingNotice('Session recording saved — admin can now review it and post it as a sermon or save it to the library.');
    } catch (err: any) {
      console.error('Recording upload failed:', err);
      setRecordingNotice(`The session recording could not be saved: ${err?.message || 'upload failed'}. (Is the "voice-sanctuary" storage bucket set up?)`);
    }
  };

  finishRecordingRef.current = finishRecording;

  return (
    <div className="p-4 lg:p-8 space-y-8 max-w-7xl mx-auto min-h-[calc(100dvh-100px)]">
      {/* Not visible UI — this is the actual audio. Each remote
          participant's stream is attached here so their voice plays. */}
      {Object.entries(remoteStreams).map(([peerId, stream]) => (
        <audio
          key={peerId}
          autoPlay
          playsInline
          ref={(el) => { if (el && el.srcObject !== stream) el.srcObject = stream; }}
        />
      ))}

      {recordingNotice && (
        <div className="bg-emerald-50 border-2 border-emerald-200 p-4 rounded-2xl flex items-center justify-between gap-3 text-emerald-800">
          <p className="text-xs font-medium">{recordingNotice}</p>
          <button onClick={() => setRecordingNotice(null)} className="text-[10px] font-black uppercase shrink-0 opacity-60 hover:opacity-100">Dismiss</button>
        </div>
      )}

      {activeRoom && participants.some((p) => p.recording) && (
        <div className="flex items-center gap-2 text-[11px] font-black uppercase tracking-widest text-tac-red">
          <span className="w-2 h-2 rounded-full bg-tac-red animate-pulse" /> This prayer session is being recorded
        </div>
      )}

      {micError && (
        <div className="bg-red-50 border-2 border-red-200 p-4 rounded-2xl flex items-center justify-between gap-3 text-red-800">
          <div className="flex items-center gap-3">
            <MicOff className="text-tac-red shrink-0" />
            <p className="text-xs font-medium">{micError}</p>
          </div>
          <button onClick={() => setMicError(null)} className="text-[10px] font-black uppercase shrink-0 opacity-60 hover:opacity-100">Dismiss</button>
        </div>
      )}

      {quotaExceeded && (
        <div className="bg-orange-50 border-2 border-orange-200 p-4 rounded-2xl flex items-center gap-3 text-orange-800">
           <Shield className="text-orange-500" />
           <div className="text-xs font-medium">
             <p className="font-black uppercase tracking-widest">Sanctuary Quota Limit</p>
             <p>Real-time updates are limited right now. If you just ended a room but it's still showing, please refresh your browser.</p>
           </div>
        </div>
      )}
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="space-y-1">
          <div className="flex items-center gap-3">
             <div className="w-10 h-10 bg-tac-blue text-white rounded-2xl flex items-center justify-center shadow-lg">
                <Headphones size={24} />
             </div>
             <h2 className="text-3xl font-black font-serif text-tac-blue-dark dark:text-white tracking-tight">Voice Sanctuary</h2>
          </div>
          <p className="text-[var(--Sub)] font-medium">Real-time spiritual fellowship and prayer rooms.</p>
        </div>

        {!activeRoom && (
           <button 
             onClick={startRoom}
             disabled={isStartingRoom}
             className="flex items-center gap-3 px-8 py-4 bg-tac-blue text-white rounded-2xl font-black uppercase text-xs tracking-widest shadow-2xl shadow-tac-blue/30 active:scale-95 transition-all"
           >
             {isStartingRoom ? <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : <Radio size={18} />}
             Start Audio Room
           </button>
        )}

        {(isAdmin || activeRoom?.hostId === user?.id || !activeRoom?.hostId) && activeRoom && (
           <div className="flex items-center gap-2">
             <AnimatePresence>
               {showConfirmEnd ? (
                 <motion.div 
                   initial={{ width: 0, opacity: 0 }}
                   animate={{ width: 'auto', opacity: 1 }}
                   exit={{ width: 0, opacity: 0 }}
                   className="flex items-center gap-2 overflow-hidden"
                 >
                   <button 
                     onClick={endRoom}
                     disabled={isEndingRoom}
                     className="px-6 py-4 bg-tac-red text-white rounded-2xl font-black uppercase text-xs tracking-widest flex items-center gap-2 whitespace-nowrap"
                   >
                     {isEndingRoom ? <div className="w-4 h-4 border-2 border-white/20 border-t-white rounded-full animate-spin" /> : <PhoneOff size={16} />}
                     Confirm Close Sanctuary
                   </button>
                   <button 
                     onClick={() => setShowConfirmEnd(false)}
                     className="px-6 py-4 bg-gray-100 dark:bg-white/5 text-gray-500 rounded-2xl font-black uppercase text-xs tracking-widest"
                   >
                     Cancel
                   </button>
                 </motion.div>
               ) : (
                 <motion.button 
                   initial={{ opacity: 0 }}
                   animate={{ opacity: 1 }}
                   onClick={() => setShowConfirmEnd(true)}
                   className="flex items-center gap-3 px-8 py-4 bg-gray-100 dark:bg-white/5 text-tac-red rounded-2xl font-black uppercase text-xs tracking-widest hover:bg-tac-red hover:text-white transition-all active:scale-95"
                 >
                   <PhoneOff size={18} /> End Room
                 </motion.button>
               )}
             </AnimatePresence>
           </div>
        )}
      </header>

      {!activeRoom ? (
        <div className="flex-1 flex flex-col items-center justify-center py-20 text-center space-y-6">
           <div className="w-40 h-40 bg-tac-blue/5 dark:bg-white/5 rounded-[3rem] flex items-center justify-center text-tac-blue/20">
              <Radio size={80} strokeWidth={1} />
           </div>
           <div className="max-w-md">
              <h3 className="text-2xl font-black text-tac-blue-dark dark:text-white mb-2">No Active Room</h3>
              <p className="text-sm text-[var(--Sub)] font-medium">When the Admin or Presbytery starts a voice broadcast, it will appear here for all members to join.</p>
           </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 h-full bg-white dark:bg-slate-900/50 rounded-[3rem] border border-gray-100 dark:border-white/5 p-6 lg:p-12 shadow-2xl overflow-hidden relative">
           
           {/* Room Title Section */}
           <div className="lg:col-span-12 flex items-center justify-between border-b border-gray-50 dark:border-white/5 pb-8 mb-4">
              <div className="flex items-center gap-4">
                 <div className="w-12 h-12 bg-red-500 rounded-full flex items-center justify-center text-white animate-pulse">
                    <Radio size={24} />
                 </div>
                 <div>
                    <h3 className="text-xl font-black text-tac-blue-dark dark:text-white uppercase tracking-tight">{activeRoom.title}</h3>
                    <div className="flex items-center gap-2">
                       <Signal size={12} className="text-green-500" />
                       <span className="text-[10px] font-black uppercase tracking-widest text-green-500">Live & Synchronized</span>
                    </div>
                 </div>
              </div>
              <div className="flex items-center gap-2 bg-gray-50 dark:bg-white/5 px-4 py-2 rounded-xl">
                 <Users size={16} className="text-tac-blue" />
                 <span className="text-sm font-black text-tac-blue-dark dark:text-white">{participants.length}</span>
              </div>
           </div>

           {/* Participants Grid */}
           <div className="lg:col-span-9">
              <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-6">
                 <AnimatePresence>
                    {participants.map((p) => (
                       <motion.div 
                        key={p.id}
                        initial={{ scale: 0.8, opacity: 0 }}
                        animate={{ scale: 1, opacity: 1 }}
                        exit={{ scale: 0.8, opacity: 0 }}
                        className="relative group block text-center"
                       >
                          <div className={`relative w-24 h-24 lg:w-32 lg:h-32 mx-auto rounded-full p-1.5 transition-all duration-500 ${p.isSpeaking ? 'bg-tac-blue scale-105 shadow-[0_0_20px_rgba(46,65,108,0.4)]' : 'bg-transparent'}`}>
                             <div className="w-full h-full rounded-full bg-gray-100 dark:bg-slate-800 flex items-center justify-center overflow-hidden border-4 border-white dark:border-slate-900 relative">
                                {p.photo ? (
                                   <img src={p.photo} alt={p.name} className="w-full h-full object-cover" />
                                ) : (
                                   <span className="text-2xl font-black text-gray-400">{p.name[0]}</span>
                                )}
                                {p.isMuted && (
                                   <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                                      <MicOff size={24} className="text-white opacity-60" />
                                   </div>
                                )}
                             </div>
                             
                             {p.isSpeaking && (
                                <div className="absolute -inset-1 rounded-full border-2 border-tac-blue animate-ping opacity-20" />
                             )}
                          </div>
                          <p className="mt-4 text-xs font-black text-tac-blue-dark dark:text-white truncate px-2">{p.name}</p>
                          {p.id === activeRoom.hostId && (
                             <span className="inline-block mt-1 text-[8px] font-black uppercase tracking-widest text-tac-blue py-0.5 px-2 bg-tac-blue/10 rounded-full">Host</span>
                          )}
                          {LIVEKIT_ENABLED && p.hand && (
                             <span className="inline-block mt-1 ml-1 text-[9px] font-black uppercase tracking-widest text-amber-700 py-0.5 px-2 bg-amber-100 rounded-full">Hand up</span>
                          )}
                          {LIVEKIT_ENABLED && (isHost || isAdmin) && p.id !== user?.id && (
                             <div className="mt-2 flex items-center justify-center gap-1.5">
                                <button disabled={hostBusy === p.id} onClick={() => hostAction(p.canSpeak === false ? 'allow' : 'stop', p.id)}
                                  className="text-[9px] font-black uppercase tracking-wider px-2.5 py-1.5 rounded-full bg-tac-blue/10 text-tac-blue disabled:opacity-50">
                                  {p.canSpeak === false ? 'Let speak' : 'Mute speaker'}
                                </button>
                                <button disabled={hostBusy === p.id} onClick={() => hostAction('remove', p.id)}
                                  className="text-[9px] font-black uppercase tracking-wider px-2.5 py-1.5 rounded-full bg-tac-red/10 text-tac-red disabled:opacity-50">Remove</button>
                             </div>
                          )}
                       </motion.div>
                    ))}
                 </AnimatePresence>
              </div>
           </div>

           {/* Controls Sidebar */}
           <div className="lg:col-span-3 flex flex-col gap-6">
              <div className="bg-gray-50 dark:bg-white/5 rounded-3xl p-6 flex-1 flex flex-col gap-4">
                 <h4 className="text-[10px] font-black uppercase text-gray-400 tracking-widest border-b border-gray-100 dark:border-white/5 pb-2">Room Controls</h4>
                 
                 {isJoined ? (
                   <>
                    {LIVEKIT_ENABLED && !canSpeak ? (
                    <button
                      onClick={toggleHand}
                      className={`w-full py-6 rounded-2xl flex flex-col items-center gap-3 transition-all ${handUp ? 'bg-amber-100 text-amber-800' : 'bg-gray-100 dark:bg-white/5 text-gray-500'}`}
                    >
                      
                      <span className="text-[10px] font-black uppercase tracking-widest">{handUp ? 'Hand raised (tap to lower)' : 'Listening: raise hand to speak'}</span>
                    </button>
                    ) : (
                    <button 
                      onClick={toggleMute}
                      className={`w-full py-6 rounded-2xl flex flex-col items-center gap-3 transition-all ${isMuted ? 'bg-gray-100 dark:bg-white/5 text-gray-400' : 'bg-tac-blue text-white shadow-xl shadow-tac-blue/20'}`}
                    >
                      {isMuted ? <MicOff size={24} /> : <Mic size={24} />}
                      <span className="text-[10px] font-black uppercase tracking-widest">{isMuted ? 'Muted' : 'Unmuted'}</span>
                    </button>
                    )}

                    <button 
                      onClick={leaveRoom}
                      className="w-full py-6 rounded-2xl bg-tac-red/10 text-tac-red hover:bg-tac-red hover:text-white transition-all flex flex-col items-center gap-3 mt-4"
                    >
                       <PhoneOff size={24} />
                       <span className="text-[10px] font-black uppercase tracking-widest">Leave sanctuary</span>
                    </button>
                   </>
                 ) : (
                   <button 
                     onClick={() => joinRoom()}
                     className="w-full h-24 bg-tac-blue text-white rounded-2xl font-black uppercase tracking-widest text-xs shadow-2xl shadow-tac-blue/20 hover:scale-105 active:scale-95 transition-all flex flex-col items-center justify-center gap-2"
                   >
                     <Volume2 size={24} />
                     Join Fellowship
                   </button>
                 )}
              </div>

              <div className="bg-tac-blue-dark rounded-3xl p-6 text-white overflow-hidden relative flex flex-col gap-4 max-h-[32rem]">
                 <div className="flex items-center justify-between shrink-0">
                   <h5 className="font-black text-[10px] uppercase tracking-widest opacity-50 flex items-center gap-1.5">
                     <BookOpen size={12} /> Live Bulletin
                   </h5>
                   {bulletinVerses.length > 0 && (
                     <span className="text-[9px] font-black uppercase tracking-widest opacity-40">{bulletinVerses.length} posted</span>
                   )}
                 </div>

                 {isHost && (
                   <div className="space-y-2 shrink-0 bg-white/5 rounded-2xl p-3">
                     <input
                       value={verseRefInput}
                       onChange={(e) => setVerseRefInput(e.target.value)}
                       placeholder="Reference (e.g. John 3:16)"
                       className="w-full min-w-0 max-w-full box-border bg-white/10 rounded-lg px-3 py-2 text-xs outline-none placeholder:text-white/30"
                     />
                     <textarea
                       value={verseTextInput}
                       onChange={(e) => setVerseTextInput(e.target.value)}
                       placeholder="Verse text..."
                       rows={2}
                       className="w-full min-w-0 max-w-full box-border bg-white/10 rounded-lg px-3 py-2 text-xs outline-none resize-none placeholder:text-white/30"
                     />
                     <button
                       onClick={postVerse}
                       disabled={postingVerse || !verseRefInput.trim() || !verseTextInput.trim()}
                       className="w-full flex items-center justify-center gap-1.5 py-2 rounded-lg bg-tac-blue-light text-tac-blue-dark text-[10px] font-black uppercase tracking-widest disabled:opacity-40 transition-opacity"
                     >
                       <Send size={12} /> Post to Bulletin
                     </button>
                   </div>
                 )}

                 <div className="flex-1 overflow-y-auto space-y-3 pr-1 -mr-1">
                   {bulletinVerses.length === 0 ? (
                     <p className="text-xs font-medium leading-relaxed opacity-60">
                       {isHost ? 'Post a verse above for everyone in the sanctuary to follow along and save.' : "The host hasn't posted a verse yet."}
                     </p>
                   ) : (
                     bulletinVerses.map((v) => {
                       const saved = savedVerseIds.has(v.id);
                       return (
                         <div key={v.id} className="bg-white/5 rounded-2xl p-3.5 space-y-2">
                           <p className="text-xs font-medium leading-relaxed opacity-90">
                             "{v.text}"
                             <span className="font-black text-tac-blue-light mt-1 block">— {v.reference}</span>
                           </p>
                           <button
                             onClick={() => !saved && saveVerseToNotes(v)}
                             disabled={saved}
                             className={`flex items-center gap-1.5 text-[9px] font-black uppercase tracking-widest transition-all ${saved ? 'text-emerald-400' : 'text-white/50 hover:text-white'}`}
                           >
                             {saved ? <BookmarkCheck size={12} /> : <Bookmark size={12} />}
                             {saved ? 'Saved to notes' : 'Save to notes'}
                           </button>
                         </div>
                       );
                     })
                   )}
                 </div>
              </div>
           </div>
        </div>
      )}
    </div>
  );
};

export default VoiceConference;
