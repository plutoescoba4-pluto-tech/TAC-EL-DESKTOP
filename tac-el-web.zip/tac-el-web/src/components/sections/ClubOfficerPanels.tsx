import React, { useEffect, useState } from 'react';
import { CalendarDays, Clock, MapPin, Megaphone, Plus, Trash2, X } from 'lucide-react';
import { clubOfficersService, DAY_NAMES, TimetableEntry, ClubEvent } from '../../services/clubOfficersService';
import { clubsService } from '../../services/clubsService';

/** The three officer tools inside a club: notices, timetable, events (and club details for the Patron). */
const card = 'bg-white dark:bg-slate-800 p-5 rounded-3xl border border-gray-100 dark:border-white/5 shadow-sm';
const input = 'w-full px-4 py-3 bg-gray-50 dark:bg-white/5 border border-[var(--Bdr)] rounded-xl text-sm text-[var(--Text)] dark:text-white outline-none focus:ring-2 focus:ring-tac-blue/20';
const label = 'text-[10px] font-black uppercase tracking-widest text-gray-400 block mb-1 ml-1';
const primaryBtn = 'flex items-center justify-center gap-2 px-4 py-3 bg-tac-blue text-white rounded-xl text-[10px] font-black uppercase tracking-widest active:scale-95 transition-all disabled:opacity-60';

const fmtDate = (iso: string) => new Date(iso).toLocaleDateString(undefined, { weekday: 'short', day: 'numeric', month: 'short' });
const fmtTime = (iso: string) => new Date(iso).toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' });
const fmtHM = (t?: string) => {
  if (!t) return '';
  const [h, m] = t.split(':').map(Number);
  return new Date(2000, 0, 1, h, m).toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' });
};

const Empty: React.FC<{ text: string }> = ({ text }) => (
  <div className="text-center py-10 text-sm text-[var(--Sub)] font-medium">{text}</div>
);

// ---------------------------------------------------------------------------------------------
export const ClubNoticeComposer: React.FC<{ clubId: string; issuerId: string; onPosted: () => void }> = ({ clubId, issuerId, onPosted }) => {
  const [open, setOpen] = useState(false);
  const [title, setTitle] = useState('');
  const [body, setBody] = useState('');
  const [priority, setPriority] = useState<'normal' | 'high' | 'urgent'>('normal');
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  const post = async () => {
    if (!title.trim() || !body.trim()) { setErr('Please write a title and a message.'); return; }
    setBusy(true); setErr(null);
    try {
      await clubsService.addInstruction(clubId, { clubId, title: title.trim(), directive: body.trim(), priority, issuedBy: issuerId, date: new Date().toISOString() });
      setTitle(''); setBody(''); setPriority('normal'); setOpen(false);
      onPosted();
    } catch (e: any) {
      setErr(e?.message || 'Could not post the notice.');
    } finally { setBusy(false); }
  };

  if (!open) {
    return (
      <button onClick={() => setOpen(true)} className={primaryBtn}><Megaphone size={14} /> Post Notice</button>
    );
  }
  return (
    <div className={`${card} space-y-3 w-full`}>
      <div className="flex items-center justify-between">
        <p className="text-sm font-black text-tac-blue-dark dark:text-white">New notice for club members</p>
        <button onClick={() => setOpen(false)} className="p-1 text-gray-400"><X size={18} /></button>
      </div>
      <div><span className={label}>Title</span><input className={input} value={title} onChange={(e) => setTitle(e.target.value)} placeholder="e.g. Rehearsal moved to 6 PM" /></div>
      <div><span className={label}>Message</span><textarea className={`${input} h-28 resize-none`} value={body} onChange={(e) => setBody(e.target.value)} placeholder="Write the notice..." /></div>
      <div>
        <span className={label}>Importance</span>
        <select className={input} value={priority} onChange={(e) => setPriority(e.target.value as any)}>
          <option value="normal">Normal</option><option value="high">High</option><option value="urgent">Urgent</option>
        </select>
      </div>
      {err && <p className="text-[11px] font-bold text-tac-red">{err}</p>}
      <button onClick={post} disabled={busy} className={`${primaryBtn} w-full`}>{busy ? 'Posting…' : 'Post to club'}</button>
    </div>
  );
};

// ---------------------------------------------------------------------------------------------
export const ClubTimetablePanel: React.FC<{ clubId: string; canEdit: boolean; authorId: string }> = ({ clubId, canEdit, authorId }) => {
  const [rows, setRows] = useState<TimetableEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState<string | null>(null);
  const [adding, setAdding] = useState(false);
  const [busy, setBusy] = useState(false);
  const [day, setDay] = useState(0);
  const [start, setStart] = useState('17:00');
  const [end, setEnd] = useState('');
  const [title, setTitle] = useState('');
  const [venue, setVenue] = useState('');

  const load = () => clubOfficersService.getTimetable(clubId)
    .then((r) => { setRows(r); setErr(null); })
    .catch((e) => setErr(e.message))
    .finally(() => setLoading(false));
  useEffect(() => { setLoading(true); load(); }, [clubId]);

  const add = async () => {
    if (!title.trim() || !start) { setErr('Please give the activity a title and a start time.'); return; }
    setBusy(true); setErr(null);
    try {
      await clubOfficersService.addTimetableEntry(clubId, authorId, { day, start, end, title, venue });
      setTitle(''); setVenue(''); setEnd(''); setAdding(false);
      await load();
    } catch (e: any) { setErr(e.message); } finally { setBusy(false); }
  };
  const remove = async (id: string) => {
    if (!window.confirm('Remove this from the timetable?')) return;
    try { await clubOfficersService.deleteTimetableEntry(id); setRows((r) => r.filter((x) => x.id !== id)); }
    catch (e: any) { window.alert(e.message); }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-3">
        <h4 className="text-xl font-black text-tac-blue-dark dark:text-white tracking-tight">Club Timetable</h4>
        {canEdit && !adding && <button onClick={() => setAdding(true)} className={primaryBtn}><Plus size={14} /> Add</button>}
      </div>

      {adding && (
        <div className={`${card} space-y-3`}>
          <div className="grid grid-cols-2 gap-3">
            <div><span className={label}>Day</span>
              <select className={input} value={day} onChange={(e) => setDay(Number(e.target.value))}>
                {DAY_NAMES.map((d, i) => <option key={d} value={i}>{d}</option>)}
              </select></div>
            <div><span className={label}>Starts</span><input type="time" className={input} value={start} onChange={(e) => setStart(e.target.value)} /></div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div><span className={label}>Ends (optional)</span><input type="time" className={input} value={end} onChange={(e) => setEnd(e.target.value)} /></div>
            <div><span className={label}>Venue (optional)</span><input className={input} value={venue} onChange={(e) => setVenue(e.target.value)} placeholder="e.g. Main hall" /></div>
          </div>
          <div><span className={label}>Activity</span><input className={input} value={title} onChange={(e) => setTitle(e.target.value)} placeholder="e.g. Choir rehearsal" /></div>
          <div className="flex gap-2">
            <button onClick={() => setAdding(false)} className="flex-1 py-3 bg-gray-100 dark:bg-white/5 text-gray-500 rounded-xl text-[10px] font-black uppercase tracking-widest">Cancel</button>
            <button onClick={add} disabled={busy} className={`${primaryBtn} flex-1`}>{busy ? 'Saving…' : 'Save'}</button>
          </div>
        </div>
      )}

      {err && <p className="text-[11px] font-bold text-tac-red">{err}</p>}
      {loading ? <Empty text="Loading…" /> : rows.length === 0 ? (
        <Empty text={canEdit ? 'No timetable yet. Tap Add to create the first entry.' : 'The club officers have not posted a timetable yet.'} />
      ) : (
        <div className="space-y-5">
          {DAY_NAMES.map((name, i) => {
            const items = rows.filter((r) => r.day === i);
            if (items.length === 0) return null;
            return (
              <div key={name}>
                <p className="text-[10px] font-black uppercase tracking-widest text-tac-blue mb-2">{name}</p>
                <div className="space-y-2">
                  {items.map((r) => (
                    <div key={r.id} className={`${card} !p-4 flex items-start gap-3`}>
                      <div className="shrink-0 text-center w-20">
                        <Clock size={14} className="mx-auto text-tac-blue mb-1" />
                        <p className="text-xs font-black text-tac-blue-dark dark:text-white leading-tight">{fmtHM(r.start)}{r.end ? ` – ${fmtHM(r.end)}` : ''}</p>
                      </div>
                      <div className="min-w-0 flex-1">
                        <p className="font-black text-tac-blue-dark dark:text-white leading-tight">{r.title}</p>
                        {r.venue && <p className="text-xs text-[var(--Sub)] mt-1 flex items-center gap-1"><MapPin size={12} /> {r.venue}</p>}
                      </div>
                      {canEdit && <button onClick={() => remove(r.id)} className="p-2 text-gray-300 hover:text-tac-red" aria-label="Remove"><Trash2 size={16} /></button>}
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

// ---------------------------------------------------------------------------------------------
export const ClubEventsPanel: React.FC<{ clubId: string; canEdit: boolean; authorId: string }> = ({ clubId, canEdit, authorId }) => {
  const [rows, setRows] = useState<ClubEvent[]>([]);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState<string | null>(null);
  const [adding, setAdding] = useState(false);
  const [busy, setBusy] = useState(false);
  const [title, setTitle] = useState('');
  const [startsAt, setStartsAt] = useState('');
  const [location, setLocation] = useState('');
  const [description, setDescription] = useState('');

  const load = () => clubOfficersService.getClubEvents(clubId)
    .then((r) => { setRows(r); setErr(null); })
    .catch((e) => setErr(e.message))
    .finally(() => setLoading(false));
  useEffect(() => { setLoading(true); load(); }, [clubId]);

  const add = async () => {
    if (!title.trim() || !startsAt) { setErr('Please give the event a title and a date and time.'); return; }
    setBusy(true); setErr(null);
    try {
      await clubOfficersService.addClubEvent(clubId, authorId, { title, startsAt: new Date(startsAt).toISOString(), location, description });
      setTitle(''); setStartsAt(''); setLocation(''); setDescription(''); setAdding(false);
      await load();
    } catch (e: any) { setErr(e.message); } finally { setBusy(false); }
  };
  const remove = async (id: string) => {
    if (!window.confirm('Remove this event?')) return;
    try { await clubOfficersService.deleteClubEvent(id); setRows((r) => r.filter((x) => x.id !== id)); }
    catch (e: any) { window.alert(e.message); }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-3">
        <div>
          <h4 className="text-xl font-black text-tac-blue-dark dark:text-white tracking-tight">Upcoming Events</h4>
          <p className="text-[11px] text-[var(--Sub)] mt-1">Shown on every club member's calendar (Events page).</p>
        </div>
        {canEdit && !adding && <button onClick={() => setAdding(true)} className={primaryBtn}><Plus size={14} /> Add</button>}
      </div>

      {adding && (
        <div className={`${card} space-y-3`}>
          <div><span className={label}>Event</span><input className={input} value={title} onChange={(e) => setTitle(e.target.value)} placeholder="e.g. Youth retreat" /></div>
          <div><span className={label}>Date and time</span><input type="datetime-local" className={input} value={startsAt} onChange={(e) => setStartsAt(e.target.value)} /></div>
          <div><span className={label}>Place (optional)</span><input className={input} value={location} onChange={(e) => setLocation(e.target.value)} /></div>
          <div><span className={label}>Details (optional)</span><textarea className={`${input} h-20 resize-none`} value={description} onChange={(e) => setDescription(e.target.value)} /></div>
          <div className="flex gap-2">
            <button onClick={() => setAdding(false)} className="flex-1 py-3 bg-gray-100 dark:bg-white/5 text-gray-500 rounded-xl text-[10px] font-black uppercase tracking-widest">Cancel</button>
            <button onClick={add} disabled={busy} className={`${primaryBtn} flex-1`}>{busy ? 'Saving…' : 'Post event'}</button>
          </div>
        </div>
      )}

      {err && <p className="text-[11px] font-bold text-tac-red">{err}</p>}
      {loading ? <Empty text="Loading…" /> : rows.length === 0 ? (
        <Empty text={canEdit ? 'No upcoming events. Tap Add to post one.' : 'No upcoming club events yet.'} />
      ) : (
        <div className="space-y-3">
          {rows.map((e) => (
            <div key={e.id} className={`${card} flex items-start gap-4`}>
              <div className="shrink-0 w-14 h-14 rounded-2xl bg-tac-blue/10 text-tac-blue flex flex-col items-center justify-center">
                <CalendarDays size={16} />
                <span className="text-[9px] font-black uppercase leading-tight mt-0.5">{new Date(e.startsAt).toLocaleDateString(undefined, { day: 'numeric', month: 'short' })}</span>
              </div>
              <div className="min-w-0 flex-1">
                <p className="font-black text-tac-blue-dark dark:text-white leading-tight">{e.title}</p>
                <p className="text-xs text-[var(--Sub)] mt-1">{fmtDate(e.startsAt)} · {fmtTime(e.startsAt)}</p>
                {e.location && <p className="text-xs text-[var(--Sub)] mt-0.5 flex items-center gap-1"><MapPin size={12} /> {e.location}</p>}
                {e.description && <p className="text-xs text-[var(--Sub)] mt-2 leading-relaxed">{e.description}</p>}
              </div>
              {canEdit && <button onClick={() => remove(e.id)} className="p-2 text-gray-300 hover:text-tac-red" aria-label="Remove"><Trash2 size={16} /></button>}
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

// ---------------------------------------------------------------------------------------------
const COLORS = ['bg-tac-blue', 'bg-tac-red', 'bg-purple-600', 'bg-indigo-600', 'bg-cyan-600', 'bg-emerald-600', 'bg-amber-600', 'bg-pink-600'];

/** The Patron (or an admin) amends the club's own details. */
export const ClubManagePanel: React.FC<{ clubId: string; onSaved: (patch: { name: string; desc: string; color: string }) => void }> = ({ clubId, onSaved }) => {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [color, setColor] = useState('bg-tac-blue');
  const [meetingTime, setMeetingTime] = useState('');
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);

  useEffect(() => {
    setLoading(true);
    clubOfficersService.getClubDetails(clubId)
      .then((d) => { setName(d.name); setDescription(d.description); setColor(d.color); setMeetingTime(d.meetingTime); })
      .catch((e) => setMsg({ ok: false, text: e.message }))
      .finally(() => setLoading(false));
  }, [clubId]);

  const save = async () => {
    if (!name.trim()) { setMsg({ ok: false, text: 'The club needs a name.' }); return; }
    setBusy(true); setMsg(null);
    try {
      await clubOfficersService.updateClubDetails(clubId, { name, description, color, meetingTime });
      onSaved({ name: name.trim(), desc: description.trim(), color });
      setMsg({ ok: true, text: 'Club details saved.' });
    } catch (e: any) { setMsg({ ok: false, text: e.message }); } finally { setBusy(false); }
  };

  if (loading) return <Empty text="Loading…" />;
  return (
    <div className="space-y-6">
      <h4 className="text-xl font-black text-tac-blue-dark dark:text-white tracking-tight">Club Details</h4>
      <div className={`${card} space-y-4`}>
        <div><span className={label}>Club name</span><input className={input} value={name} onChange={(e) => setName(e.target.value)} /></div>
        <div><span className={label}>About the club</span><textarea className={`${input} h-28 resize-none`} value={description} onChange={(e) => setDescription(e.target.value)} /></div>
        <div><span className={label}>When it meets</span><input className={input} value={meetingTime} onChange={(e) => setMeetingTime(e.target.value)} placeholder="e.g. Fridays 5 PM" /></div>
        <div>
          <span className={label}>Colour</span>
          <div className="flex flex-wrap gap-2">
            {COLORS.map((c) => (
              <button key={c} type="button" onClick={() => setColor(c)} aria-label={c}
                className={`w-9 h-9 rounded-full ${c} border-4 ${color === c ? 'border-tac-blue-dark dark:border-white' : 'border-transparent'}`} />
            ))}
          </div>
        </div>
        {msg && <p className={`text-[11px] font-bold ${msg.ok ? 'text-green-600' : 'text-tac-red'}`}>{msg.text}</p>}
        <button onClick={save} disabled={busy} className={`${primaryBtn} w-full`}>{busy ? 'Saving…' : 'Save changes'}</button>
      </div>
    </div>
  );
};
