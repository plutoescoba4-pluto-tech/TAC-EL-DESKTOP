import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  BookOpen, Search, ChevronLeft, ChevronRight, Bookmark, Highlighter, 
  Sparkles, MessageSquare, Send, X, History, Star, Languages,
  RotateCcw, ExternalLink, Calendar, Plus, Save, Trash2, Heart, Mic, Volume2, VolumeX
} from 'lucide-react';
import { localCollection } from '../../lib/localCollection';
import { useAuth } from '../../context/AuthContext';
import { handleFirestoreError, OperationType } from '../../lib/firestore-errors';
import { trackActivity } from '../../services/memberMemoryService';
import { 
  fetchBibleVersions, fetchBibleBooks, fetchBibleChapters, 
  fetchBibleChapterContent, searchBible, bibleChat, fetchDailyVerse, 
  BibleVersion, BibleBook, BibleChapter, BibleSearchResponse 
} from '../../services/bibleService';

const BibleView: React.FC = () => {
  const { user, profile } = useAuth();
  const [activeTab, setActiveTab] = useState<'reader' | 'search' | 'chat' | 'saved'>('reader');
  
  // Versions
  const [versions, setVersions] = useState<BibleVersion[]>([]);
  const [selectedVersion, setSelectedVersion] = useState<string>('de4e12af7f28f599-01'); // Default KJV
  
  // Navigation
  const [books, setBooks] = useState<BibleBook[]>([]);
  const [selectedBook, setSelectedBook] = useState<string>('');
  const [chapters, setChapters] = useState<BibleChapter[]>([]);
  const [selectedChapter, setSelectedChapter] = useState<string>('');
  
  // Content
  const [content, setContent] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  
  // Search
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<BibleSearchResponse | null>(null);
  const [searching, setSearching] = useState(false);
  
  // Chat
  const [chatPrompt, setChatPrompt] = useState('');
  const [chatHistory, setChatHistory] = useState<any[]>([]);
  const [chatLoading, setChatLoading] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);
  
  // Favorites / Highlights
  const [bookmarks, setBookmarks] = useState<any[]>([]);
  const [highlights, setHighlights] = useState<any[]>([]);
  
  // Verse of Day
  const [dailyVerse, setDailyVerse] = useState<any>(null);
  const [isSpeaking, setIsSpeaking] = useState(false);

  const speakText = (text: string) => {
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    
    // Voices selection
    const voices = window.speechSynthesis.getVoices();
    const preferredVoice = voices.find(v => v.name.includes('Google') || v.name.includes('Premium')) || voices[0];
    if (preferredVoice) utterance.voice = preferredVoice;
    
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);
    setIsSpeaking(true);
    window.speechSynthesis.speak(utterance);
  };

  const stopSpeaking = () => {
    window.speechSynthesis.cancel();
    setIsSpeaking(false);
  };

  const handleReadChapter = () => {
    if (content?.content) {
      const div = document.createElement('div');
      div.innerHTML = content.content;
      speakText(div.innerText);
    }
  };

  const handleReadSelection = () => {
    const selection = window.getSelection()?.toString();
    if (selection) {
      speakText(selection);
    } else {
      handleReadChapter();
    }
  };

  // Initial Data
  useEffect(() => {
    const init = async () => {
      setLoading(true);
      const v = await fetchBibleVersions();
      setVersions(v);
      
      const dv = await fetchDailyVerse();
      setDailyVerse(dv);

      // Bookmarks/highlights: no `bookmarks`/`highlights` table yet (see
      // MIGRATION_NOTES.md) — stored locally per device for now via
      // localCollection, same pattern as memberMemoryService.
      if (user) {
        setBookmarks(localCollection.list(user.id, 'bookmarks'));
        setHighlights(localCollection.list(user.id, 'highlights'));
      }
      
      // Load initial books
      const b = await fetchBibleBooks(selectedVersion);
      setBooks(b);
      if (b.length > 0) {
        setSelectedBook(b[0].id);
        const c = await fetchBibleChapters(selectedVersion, b[0].id);
        setChapters(c);
        if (c.length > 0) {
          setSelectedChapter(c[0].id);
          loadChapter(selectedVersion, c[0].id);
        }
      }
      setLoading(false);
    };
    init();
  }, [user]);

  // Handle Version Change
  useEffect(() => {
    const changeVersion = async () => {
      if (!selectedVersion) return;
      const b = await fetchBibleBooks(selectedVersion);
      setBooks(b);
      // Try to keep same book/chapter if possible
      if (selectedBook) {
        const foundBook = b.find(bk => bk.name === books.find(ob => ob.id === selectedBook)?.name);
        const newBookId = foundBook?.id || b[0].id;
        setSelectedBook(newBookId);
        const c = await fetchBibleChapters(selectedVersion, newBookId);
        setChapters(c);
        const newChapterId = c[0].id;
        setSelectedChapter(newChapterId);
        loadChapter(selectedVersion, newChapterId);
      }
    };
    changeVersion();
  }, [selectedVersion]);

  const loadChapter = async (bibleId: string, chapterId: string) => {
    setLoading(true);
    try {
      const data = await fetchBibleChapterContent(bibleId, chapterId);
      setContent(data);

      // Track verse read (chapter level context)
      if (user) {
        const bookName = books.find(b => b.id === selectedBook)?.name || selectedBook;
        const chapterNum = chapters.find(c => c.id === chapterId)?.number || '1';
        trackActivity(user.id, 'verse', { book: bookName, chapter: chapterNum });
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const handleBookChange = async (bookId: string) => {
    setSelectedBook(bookId);
    setLoading(true);
    const c = await fetchBibleChapters(selectedVersion, bookId);
    setChapters(c);
    setSelectedChapter(c[0].id);
    await loadChapter(selectedVersion, c[0].id);
    setLoading(false);
  };

  const handleChapterChange = async (chapterId: string) => {
    setSelectedChapter(chapterId);
    await loadChapter(selectedVersion, chapterId);
  };

  const handlePrevChapter = () => {
    const idx = chapters.findIndex(c => c.id === selectedChapter);
    if (idx > 0) handleChapterChange(chapters[idx-1].id);
  };

  const handleNextChapter = () => {
    const idx = chapters.findIndex(c => c.id === selectedChapter);
    if (idx < chapters.length - 1) handleChapterChange(chapters[idx+1].id);
  };

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim()) return;
    setSearching(true);
    
    // Track search
    if (user) {
      trackActivity(user.id, 'search', searchQuery.trim());
    }

    const results = await searchBible(selectedVersion, searchQuery);
    setSearchResults(results);
    setSearching(false);
  };

  const handleChat = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatPrompt.trim() || chatLoading) return;
    
    const newMsg = { role: 'user', parts: [{ text: chatPrompt }] };
    setChatHistory(prev => [...prev, newMsg]);
    
    // Track question
    if (user) {
      trackActivity(user.id, 'question', { question: chatPrompt, timestamp: new Date().toISOString() });
    }

    setChatPrompt('');
    setChatLoading(true);
    
    try {
      const response = await bibleChat(chatPrompt, chatHistory);
      
      // Track answer
      if (user) {
        trackActivity(user.id, 'question', { question: chatPrompt, answer: response, timestamp: new Date().toISOString() });
      }

      setChatHistory(prev => [...prev, { role: 'model', parts: [{ text: response }] }]);
    } catch (err) {
      console.error(err);
    } finally {
      setChatLoading(false);
    }
  };

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chatHistory]);

  const toggleBookmark = async (verse: any) => {
    if (!user) return;
    const existing = bookmarks.find(b => b.verseId === verse.id);
    if (existing) {
      localCollection.remove(user.id, 'bookmarks', existing.id);
      setBookmarks(localCollection.list(user.id, 'bookmarks'));
    } else {
      const bookmarkData = {
        bibleId: selectedVersion,
        bookId: selectedBook,
        chapterId: selectedChapter,
        verseId: verse.id,
        reference: verse.reference,
        text: verse.text,
      };
      localCollection.add(user.id, 'bookmarks', bookmarkData);
      setBookmarks(localCollection.list(user.id, 'bookmarks'));

      // Track bookmark activity
      trackActivity(user.id, 'bookmark', { reference: verse.reference, text: verse.text });
    }
  };

  return (
    <div className="flex flex-col h-full bg-slate-50 dark:bg-slate-950 overflow-hidden">
      {/* Mobile-style Top Header */}
      <header className="bg-white dark:bg-slate-900 border-b border-[var(--Bdr)] p-4 flex items-center justify-between z-20 shrink-0">
        <div className="flex items-center gap-2">
          <div className="w-10 h-10 bg-tac-blue text-white rounded-xl flex items-center justify-center">
            <BookOpen size={24} />
          </div>
          <h1 className="text-xl font-black font-serif text-tac-blue-dark dark:text-white">Bible Reader</h1>
        </div>
        
        <div className="flex bg-gray-100 dark:bg-white/5 p-1 rounded-xl">
           {[
             { id: 'reader', icon: BookOpen },
             { id: 'search', icon: Search },
             { id: 'chat', icon: Sparkles },
             { id: 'saved', icon: Bookmark }
           ].map(t => (
             <button 
               key={t.id}
               onClick={() => setActiveTab(t.id as any)}
               className={`p-2 rounded-lg transition-all ${activeTab === t.id ? 'bg-white dark:bg-slate-800 shadow-sm text-tac-blue' : 'text-gray-400 hover:text-gray-600'}`}
             >
               <t.icon size={18} />
             </button>
           ))}
        </div>
      </header>

      {/* Main Content Viewport */}
      <div className="flex-1 overflow-y-auto relative no-scrollbar">
        <AnimatePresence mode="wait">
          {activeTab === 'reader' && (
            <motion.div 
              key="reader"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="max-w-3xl mx-auto p-4 sm:p-6 lg:p-8 space-y-6"
            >
              {/* Daily Verse Card */}
              {dailyVerse && (
                <div className="bg-gradient-to-br from-tac-blue-dark to-tac-blue rounded-[2.5rem] p-8 text-white relative overflow-hidden shadow-2xl shadow-tac-blue/20">
                  <div className="absolute top-0 right-0 p-4 opacity-10"><Heart size={80} /></div>
                  <div className="relative z-10 space-y-4">
                    <div className="flex items-center gap-2 text-[10px] font-black uppercase tracking-[0.2em] text-white/60">
                      <Calendar size={12} />
                      Verse of the Day
                    </div>
                    <blockquote className="text-xl sm:text-2xl font-serif font-medium leading-relaxed italic">
                      "{dailyVerse.text}"
                    </blockquote>
                    <cite className="block text-sm font-black uppercase tracking-widest text-white/70">— {dailyVerse.ref}</cite>
                  </div>
                </div>
              )}

              {/* Version & Navigation Selectors */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                <div className="flex flex-col gap-1">
                   <label className="text-[10px] font-black uppercase tracking-widest text-tac-blue/40 ml-2">Bible Version</label>
                   <div className="relative">
                     <Languages className="absolute left-4 top-1/2 -translate-y-1/2 text-tac-blue/30" size={16} />
                     <select 
                       value={selectedVersion}
                       onChange={(e) => setSelectedVersion(e.target.value)}
                       className="w-full pl-11 pr-4 py-3 bg-white dark:bg-slate-800 border border-[var(--Bdr)] rounded-2xl text-sm font-bold outline-none focus:ring-2 focus:ring-tac-blue/5 dark:text-white appearance-none"
                     >
                       {versions.map(v => (
                         <option key={v.id} value={v.id}>{v.name} ({v.abbreviation})</option>
                       ))}
                     </select>
                   </div>
                </div>
                
                <div className="flex flex-col gap-1">
                   <label className="text-[10px] font-black uppercase tracking-widest text-tac-blue/40 ml-2">Book</label>
                   <select 
                     value={selectedBook}
                     onChange={(e) => handleBookChange(e.target.value)}
                     className="w-full px-4 py-3 bg-white dark:bg-slate-800 border border-[var(--Bdr)] rounded-2xl text-sm font-bold outline-none focus:ring-2 focus:ring-tac-blue/5 dark:text-white appearance-none"
                   >
                     {books.map(b => (
                       <option key={b.id} value={b.id}>{b.name}</option>
                     ))}
                   </select>
                </div>

                <div className="flex flex-col gap-1">
                   <label className="text-[10px] font-black uppercase tracking-widest text-tac-blue/40 ml-2">Chapter</label>
                   <select 
                     value={selectedChapter}
                     onChange={(e) => handleChapterChange(e.target.value)}
                     className="w-full px-4 py-3 bg-white dark:bg-slate-800 border border-[var(--Bdr)] rounded-2xl text-sm font-bold outline-none focus:ring-2 focus:ring-tac-blue/5 dark:text-white appearance-none"
                   >
                     {chapters.map(c => (
                       <option key={c.id} value={c.id}>Chapter {c.number}</option>
                     ))}
                   </select>
                </div>
              </div>

              {/* Bible Text Content */}
              <div className="bg-white dark:bg-slate-900 rounded-[2.5rem] p-6 sm:p-10 border border-[var(--Bdr)] shadow-sm relative min-h-[400px]">
                {/* TTS Controls */}
                <div className="absolute top-6 right-6 flex items-center gap-2">
                   <button 
                     onClick={isSpeaking ? stopSpeaking : handleReadSelection}
                     title={isSpeaking ? "Stop Reading" : "Read Selection or Chapter"}
                     className={`w-10 h-10 rounded-full flex items-center justify-center transition-all ${
                       isSpeaking 
                         ? 'bg-tac-red text-white shadow-lg animate-pulse' 
                         : 'bg-tac-blue/5 text-tac-blue hover:bg-tac-blue hover:text-white'
                     }`}
                   >
                     {isSpeaking ? <VolumeX size={18} /> : <Mic size={18} />}
                   </button>
                </div>
                
                {loading ? (
                  <div className="absolute inset-0 flex flex-col items-center justify-center space-y-4">
                     <div className="w-12 h-12 border-4 border-tac-blue/10 border-t-tac-blue rounded-full animate-spin" />
                     <p className="text-[10px] font-black uppercase tracking-widest text-tac-blue/40">Fetching the Word...</p>
                  </div>
                ) : (
                  <div className="prose prose-slate dark:prose-invert max-w-none bible-content">
                    {content ? (
                      <div dangerouslySetInnerHTML={{ __html: content.content }} />
                    ) : (
                      <p className="text-center text-gray-400 italic">Select a book and chapter to begin reading.</p>
                    )}
                  </div>
                )}
              </div>

              {/* Reader Bottom Navigation */}
              <div className="flex items-center justify-between py-4">
                 <button 
                   onClick={handlePrevChapter}
                   disabled={loading || chapters.findIndex(c => c.id === selectedChapter) <= 0}
                   className="flex items-center gap-2 px-6 py-3 bg-white dark:bg-slate-800 border border-[var(--Bdr)] rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-gray-50 disabled:opacity-30 transition-all dark:text-white"
                 >
                   <ChevronLeft size={16} />
                   Previous
                 </button>
                 <button 
                   onClick={handleNextChapter}
                   disabled={loading || chapters.findIndex(c => c.id === selectedChapter) >= chapters.length - 1}
                   className="flex items-center gap-2 px-6 py-3 bg-tac-blue text-white rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-tac-blue-dark shadow-lg shadow-tac-blue/20 disabled:opacity-30 transition-all"
                 >
                   Next
                   <ChevronRight size={16} />
                 </button>
              </div>
            </motion.div>
          )}

          {activeTab === 'search' && (
            <motion.div 
              key="search"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="max-w-3xl mx-auto p-4 sm:p-6 lg:p-8 space-y-6"
            >
              <form onSubmit={handleSearch} className="relative">
                <Search className="absolute left-6 top-1/2 -translate-y-1/2 text-tac-blue/30" size={24} />
                <input 
                  type="text" 
                  autoFocus
                  placeholder="Search keywords, topics, or verses..." 
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-16 pr-6 py-6 bg-white dark:bg-slate-900 border border-[var(--Bdr)] rounded-[2rem] text-lg font-medium outline-none focus:ring-4 focus:ring-tac-blue/5 shadow-xl transition-all dark:text-white"
                />
              </form>

              {searching ? (
                <div className="flex flex-col items-center justify-center py-20 space-y-4">
                  <div className="w-10 h-10 border-4 border-tac-blue/10 border-t-tac-blue rounded-full animate-spin" />
                  <p className="text-xs font-black uppercase tracking-widest text-tac-blue/40">Searching the Scriptures...</p>
                </div>
              ) : searchResults ? (
                <div className="space-y-4">
                  <p className="text-[10px] font-black uppercase tracking-[0.2em] text-tac-blue/40 ml-4">Found {searchResults.total} Results</p>
                  <div className="grid grid-cols-1 gap-4">
                    {searchResults.verses.map(v => (
                       <div key={v.id} className="bg-white dark:bg-slate-900 p-6 rounded-[2rem] border border-[var(--Bdr)] shadow-sm hover:shadow-md transition-all group">
                          <div className="flex items-center justify-between mb-3">
                             <span className="px-4 py-1.5 bg-tac-blue/5 text-tac-blue dark:bg-tac-blue/20 dark:text-tac-blue-light rounded-full text-[10px] font-black uppercase tracking-widest">{v.reference}</span>
                             <button 
                               onClick={() => {
                                 // Close search and go to reader
                                 setSelectedBook(v.bookId);
                                 setSelectedChapter(v.chapterId);
                                 loadChapter(selectedVersion, v.chapterId);
                                 setActiveTab('reader');
                               }}
                               className="opacity-0 group-hover:opacity-100 p-2 text-tac-blue hover:bg-tac-blue/5 rounded-full transition-all"
                             >
                               <ExternalLink size={16} />
                             </button>
                          </div>
                          <p className="text-slate-600 dark:text-slate-300 font-serif leading-relaxed">{v.text}</p>
                       </div>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="text-center py-32 space-y-4 text-slate-300 dark:text-slate-700">
                  <Search size={64} className="mx-auto" />
                  <p className="font-serif italic text-lg text-slate-400">"Search the scriptures; for in them ye think ye have eternal life..."</p>
                </div>
              )}
            </motion.div>
          )}

          {activeTab === 'chat' && (
            <motion.div 
              key="chat"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="flex flex-col h-[calc(100dvh-140px)] max-w-3xl mx-auto w-full p-4"
            >
              <div className="flex-1 overflow-y-auto space-y-4 p-4 no-scrollbar">
                {chatHistory.length === 0 && (
                  <div className="flex flex-col items-center justify-center py-20 text-center space-y-6">
                    <div className="w-20 h-20 bg-tac-red/5 rounded-full flex items-center justify-center text-tac-red">
                      <Sparkles size={40} />
                    </div>
                    <div className="space-y-2 max-w-sm">
                      <h3 className="text-xl font-black text-tac-blue-dark dark:text-white">Bible Chaplain AI</h3>
                      <p className="text-sm text-slate-500 leading-relaxed font-medium">Ask questions about faith, meaning, or biblical doctrine. Our AI assistant provides scripture-based answers.</p>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 w-full">
                      {[
                        "What does the Bible say about anxiety?",
                        "Explain the concept of Grace.",
                        "Verses for a broken heart?",
                        "How to pray effectively?"
                      ].map(q => (
                        <button 
                          key={q}
                          onClick={() => setChatPrompt(q)}
                          className="p-4 bg-white dark:bg-slate-900 border border-[var(--Bdr)] rounded-2xl text-xs font-black text-left hover:border-tac-blue transition-all"
                        >
                          {q}
                        </button>
                      ))}
                    </div>
                  </div>
                )}
                
                {chatHistory.map((m, i) => (
                  <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                    <div className={`max-w-[85%] p-5 rounded-3xl text-sm font-serif leading-relaxed shadow-sm ${
                      m.role === 'user' 
                        ? 'bg-tac-blue text-white rounded-tr-none' 
                        : 'bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 rounded-tl-none border border-[var(--Bdr)]'
                    }`}>
                      {m.parts[0].text}
                    </div>
                  </div>
                ))}
                
                {chatLoading && (
                  <div className="flex justify-start">
                    <div className="bg-white dark:bg-slate-800 p-4 rounded-3xl rounded-tl-none border border-[var(--Bdr)] flex items-center gap-2">
                       <span className="w-2 h-2 bg-tac-blue rounded-full animate-bounce" />
                       <span className="w-2 h-2 bg-tac-blue rounded-full animate-bounce [animation-delay:0.2s]" />
                       <span className="w-2 h-2 bg-tac-blue rounded-full animate-bounce [animation-delay:0.4s]" />
                    </div>
                  </div>
                )}
                <div ref={chatEndRef} />
              </div>

              <form onSubmit={handleChat} className="p-4 bg-white dark:bg-slate-900 border border-[var(--Bdr)] rounded-[2.5rem] flex items-center gap-2 shadow-xl shrink-0">
                <input 
                  type="text" 
                  placeholder="Ask a question..." 
                  value={chatPrompt}
                  onChange={(e) => setChatPrompt(e.target.value)}
                  className="flex-1 bg-transparent border-none outline-none px-4 py-2 font-medium dark:text-white"
                />
                <button 
                  type="submit"
                  disabled={!chatPrompt.trim() || chatLoading}
                  className="w-12 h-12 bg-tac-blue text-white rounded-full flex items-center justify-center hover:scale-105 active:scale-95 transition-all disabled:opacity-50"
                >
                  <Send size={20} />
                </button>
              </form>
            </motion.div>
          )}

          {activeTab === 'saved' && (
            <motion.div 
              key="saved"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="max-w-3xl mx-auto p-4 sm:p-6 lg:p-8 space-y-6"
            >
              <div className="flex items-center justify-between mb-6">
                 <h3 className="text-xl font-black text-tac-blue-dark dark:text-white flex items-center gap-2">
                    <Bookmark className="text-tac-red" />
                    Saved Verses
                 </h3>
                 <span className="px-4 py-1.5 bg-gray-100 dark:bg-white/5 rounded-full text-[10px] font-black uppercase tracking-widest text-slate-400">
                    {bookmarks.length} Items
                 </span>
              </div>

              {bookmarks.length === 0 ? (
                <div className="text-center py-32 space-y-4 opacity-30">
                  <Star size={64} className="mx-auto" />
                  <p className="font-black uppercase tracking-widest text-xs">No bookmarks yet.</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 gap-4">
                  {bookmarks.map(b => (
                    <div key={b.id} className="bg-white dark:bg-slate-900 p-6 rounded-[2rem] border border-[var(--Bdr)] shadow-sm group">
                       <div className="flex items-center justify-between mb-3">
                          <span className="text-[10px] font-black uppercase tracking-widest text-tac-blue">{b.reference}</span>
                          <button 
                            onClick={() => {
                              if (!user) return;
                              localCollection.remove(user.id, 'bookmarks', b.id);
                              setBookmarks(localCollection.list(user.id, 'bookmarks'));
                            }}
                            className="p-2 text-slate-300 hover:text-tac-red hover:bg-tac-red/5 rounded-full transition-all"
                          >
                             <Trash2 size={16} />
                          </button>
                       </div>
                       <p className="text-slate-800 dark:text-slate-200 font-serif leading-relaxed">{b.text}</p>
                    </div>
                  ))}
                </div>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      <style>{`
        .bible-content h3 { font-family: 'Playfair Display', serif; font-weight: 900; font-size: 1.5rem; margin-bottom: 1.5rem; color: #1e293b; }
        .bible-content .v { font-size: 0.65rem; vertical-align: super; font-weight: 900; color: #3b82f6; margin-right: 4px; border: 1px solid #3b82f633; padding: 1px 3px; border-radius: 4px; }
        .bible-content p { font-family: 'Playfair Display', serif; line-height: 1.8; margin-bottom: 1.5rem; color: #334155; font-size: 1.125rem; }
        .dark .bible-content p { color: #cbd5e1; }
        .dark .bible-content h3 { color: white; }
        .bible-content .q1, .bible-content .q2 { display: block; padding-left: 1.5rem; }
        .bible-content .s1 { font-weight: 900; display: block; margin: 2rem 0 1rem; color: #3b82f6; text-transform: uppercase; font-size: 0.75rem; tracking: 0.2em; text-align: center; border-top: 1px solid #e2e8f0; padding-top: 2rem; }
      `}</style>
    </div>
  );
};

export default BibleView;
