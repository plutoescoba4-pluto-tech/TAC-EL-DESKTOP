import React, { useCallback, useEffect, useState } from 'react';
import { Bell, BellOff, Send } from 'lucide-react';
import { supabase } from '../../supabase';
import { useAuth } from '../../context/AuthContext';
import {
  disableNotifications, enableNotifications, getPushState, NOTIFICATION_CATEGORIES, PushState, serverPushAvailable, showTestNotification,
} from '../../lib/push';

/** Notifications screen: turn them on or off on this device, choose which kinds you want, send yourself a test. */
export const NotificationSettings: React.FC = () => {
  const { user } = useAuth();
  const [state, setState] = useState<PushState>(() => getPushState());
  const [prefs, setPrefs] = useState<Record<string, boolean>>({});
  const [note, setNote] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    if (!user) return;
    const { data } = await supabase.from('notification_prefs').select('*').eq('user_id', user.id).maybeSingle();
    const next: Record<string, boolean> = {};
    NOTIFICATION_CATEGORIES.forEach((c) => { next[c.id] = data ? data[c.id] !== false : true; });
    setPrefs(next);
  }, [user]);
  useEffect(() => { load(); }, [load]);

  const toggle = async (id: string, on: boolean) => {
    if (!user) return;
    const next = { ...prefs, [id]: on };
    setPrefs(next);
    const { error } = await supabase.from('notification_prefs').upsert({ user_id: user.id, ...next, updated_at: new Date().toISOString() }, { onConflict: 'user_id' });
    if (error) { setNote('Could not save that choice. Make sure 06d-push.sql has been run.'); setPrefs(prefs); }
  };

  const turnOn = async () => {
    if (!user) return;
    setBusy(true);
    const r = await enableNotifications(user.id);
    setBusy(false); setState(getPushState()); setNote(r.message);
  };
  const turnOff = async () => {
    setBusy(true);
    await disableNotifications();
    setBusy(false);
    setNote('Notifications are off for this device. To stop them completely, also switch them off in your browser or phone settings.');
  };
  const test = async () => {
    try { await showTestNotification(); setNote('A test notification was sent. If you did not see it, check your phone settings.'); }
    catch { setNote('Could not show a test notification here.'); }
  };

  return (
    <div className="max-w-2xl mx-auto p-4 lg:p-8 space-y-4">
      <div>
        <h2 className="text-2xl font-black font-serif text-tac-blue-dark dark:text-white">Notifications</h2>
        <p className="text-sm text-[var(--Sub)]">Choose what the church app may tell you about.</p>
      </div>

      <div className="rounded-3xl bg-white dark:bg-slate-900 border border-[var(--Bdr)] p-5">
        <div className="flex items-center gap-3">
          <div className={`w-11 h-11 rounded-2xl flex items-center justify-center ${state === 'granted' ? 'bg-emerald-50 text-emerald-600' : 'bg-gray-100 dark:bg-white/5 text-gray-400'}`}>
            {state === 'granted' ? <Bell size={20} /> : <BellOff size={20} />}
          </div>
          <div className="min-w-0">
            <p className="font-black text-sm">
              {state === 'granted' ? 'On for this device' : state === 'denied' ? 'Blocked on this device' : state === 'needs-install' ? 'Add the app to your Home Screen first' : state === 'unsupported' ? 'Not available in this browser' : 'Off'}
            </p>
            <p className="text-xs text-[var(--Sub)]">
              {state === 'needs-install' && 'On iPhone, open this app from the Home Screen icon (Share, then Add to Home Screen) to turn notifications on.'}
              {state === 'denied' && 'Allow notifications for this app in your browser or phone settings, then come back.'}
              {state === 'granted' && !serverPushAvailable() && 'You will see notifications while the app is open. Notifications while it is closed are being set up.'}
              {state === 'default' && 'Tap the button to allow notifications.'}
            </p>
          </div>
        </div>
        <div className="flex flex-wrap gap-2 mt-4">
          {state === 'default' && <button type="button" onClick={turnOn} disabled={busy} className="px-4 py-2.5 rounded-xl bg-tac-blue text-white text-xs font-black uppercase tracking-widest disabled:opacity-60">Turn on</button>}
          {state === 'granted' && <button type="button" onClick={test} className="px-4 py-2.5 rounded-xl bg-tac-blue text-white text-xs font-black uppercase tracking-widest inline-flex items-center gap-2"><Send size={13} /> Send a test</button>}
          {state === 'granted' && <button type="button" onClick={turnOff} disabled={busy} className="px-4 py-2.5 rounded-xl border border-[var(--Bdr)] text-xs font-black uppercase tracking-widest">Turn off here</button>}
        </div>
        {note && <p className="text-xs text-tac-blue font-semibold mt-3">{note}</p>}
      </div>

      <div className="rounded-3xl bg-white dark:bg-slate-900 border border-[var(--Bdr)] divide-y divide-[var(--Bdr)] overflow-hidden">
        {NOTIFICATION_CATEGORIES.map((c) => (
          <label key={c.id} className="flex items-center justify-between gap-4 p-4 cursor-pointer">
            <div className="min-w-0">
              <p className="font-bold text-sm">{c.label}</p>
              <p className="text-xs text-[var(--Sub)]">{c.hint}</p>
            </div>
            <input type="checkbox" className="w-5 h-5 accent-[#1B3F8B] shrink-0" checked={prefs[c.id] !== false} onChange={(e) => toggle(c.id, e.target.checked)} />
          </label>
        ))}
      </div>
    </div>
  );
};

export default NotificationSettings;
