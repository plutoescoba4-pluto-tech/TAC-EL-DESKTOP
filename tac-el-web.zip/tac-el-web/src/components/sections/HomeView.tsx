import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'motion/react';
import { 
  Bell, 
  Calendar, 
  BookOpen, 
  Users, 
  ChevronRight, 
  Clock, 
  MapPin,
  Heart,
  TrendingUp,
  CircleDot,
  Radio,
  PhoneOff,
  Image as ImageIcon,
  X,
  ChevronLeft,
  ChevronRight as ChevronRightIcon,
  ShieldCheck,
  Plus,
  Trash2,
  Star,
  Headphones,
  CalendarDays,
  Megaphone,
  Music,
  Info
} from 'lucide-react';
import { AnimatePresence } from 'motion/react';
import { CHURCH_NAME, ASSEMBLY, CHURCH_LOGO } from '../../constants';
import { useAuth } from '../../context/AuthContext';
import { supabase } from '../../supabase';
import { settingsService } from '../../services/settingsService';
import { noticesService } from '../../services/contentService';
import { eventsService } from '../../services/eventsService';
import { galleryService } from '../../services/contentService';
import { liveSessionService } from '../../services/liveSessionService';
import { Notice, Sermon, EventItem, HomeConfig, GalleryItem } from '../../types';
import { handleFirestoreError, OperationType } from '../../lib/firestore-errors';
import { compressImage } from '../../lib/image-utils';
import { uploadImage } from '../admin-portal/content/websiteShared';
import { fetchDailyVerse } from '../../services/bibleService';
import { FEATURES } from '../../lib/features';

const HomeView: React.FC = () => {
  const { profile, quotaExceeded } = useAuth();
  const navigate = useNavigate();
  const [notices, setNotices] = useState<Notice[]>([]);
  const [memberCount, setMemberCount] = useState(0);
  const [onlineCount, setOnlineCount] = useState(1);
  const [gallery, setGallery] = useState<GalleryItem[]>([]);
  const [config, setConfig] = useState<HomeConfig>({
    id: 'main',
    theme: '',
    motto: '',
    services: [],
    announcement: '',
    heroUrl: ''
  });
  const [events, setEvents] = useState<EventItem[]>([]);
  const [isEditingConfig, setIsEditingConfig] = useState(false);
  const [isEditingServices, setIsEditingServices] = useState(false);
  const [isEditingAnnouncement, setIsEditingAnnouncement] = useState(false);
  const [currentSlide, setCurrentSlide] = useState(0);
  const [dailyVerse, setDailyVerse] = useState<any>(null);
  const [showDailyPopup, setShowDailyPopup] = useState(false);
  const [activeVoiceRoom, setActiveVoiceRoom] = useState<any>(null);
  const [showVoicePrayerTriggered, setShowVoicePrayerTriggered] = useState(false);

  const handleStopRoom = async (roomId: string) => {
    try {
      await liveSessionService.endRoom(roomId);
    } catch (e) {
      console.warn("Stop room warn:", e);
    }
    setActiveVoiceRoom(null);
  };

  const isAdmin = profile?.role === 'admin';
  const logo = config?.logoUrl || CHURCH_LOGO;
  
  const slides = config.heroSlides && config.heroSlides.length > 0 
    ? config.heroSlides 
    : (config.heroUrl ? [config.heroUrl] : []);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide(prev => (prev + 1) % (slides.length || 1));
    }, 4000);
    return () => clearInterval(timer);
  }, [slides.length]);

  const handleSlideUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    try {
      // The picture goes to storage; only its link is saved in the home config (keeps the config small and fast).
      const url = await uploadImage(file, 'hero', { maxW: 1600, maxH: 1000 });
      const newSlides = [...(config.heroSlides || []), url];
      await handleSaveConfig({ heroSlides: newSlides });
      setCurrentSlide(newSlides.length - 1);
    } catch (err: any) {
      window.alert(err?.message || 'Could not upload that picture.');
    }
  };

  const removeSlide = async (index: number) => {
    const updated = slides.filter((_, i) => i !== index);
    await handleSaveConfig({ heroSlides: updated });
    setCurrentSlide(0);
  };

  useEffect(() => {
    // Notices listener - Real-time sync for important updates
    const unsubNotices = noticesService.subscribeNotices((rows) => setNotices(rows), 3);

    // Home config listener
    const unsubConfig = settingsService.subscribeHomeConfig((cfg) => {
      if (cfg) setConfig(cfg);
    });

    // One-time fetch for member count to save reads
    const fetchCount = async () => {
      try {
        const stats = await settingsService.getStats();
        if (stats?.memberCount) {
          setMemberCount(stats.memberCount);
        } else {
          // Fallback to approximate count if the stats setting doesn't exist yet
          setMemberCount(250 + Math.floor(Math.random() * 50));
        }
      } catch (e: any) {
        setMemberCount(312); // Steady fallback
      }
    };
    fetchCount();

    const loadStaticData = async () => {
      try {
        setEvents((await eventsService.getEvents()).slice(0, 5));
        setGallery(await galleryService.getGallery());

        // One-time online-members count. `presence` is now an ephemeral
        // Realtime channel, not a queryable collection, so this reads the
        // persisted profiles.online/last_seen columns instead.
        const fiveMinutesAgo = new Date(Date.now() - 5 * 60 * 1000).toISOString();
        const { data } = await supabase.from('profiles').select('id', { count: 'exact', head: true }).gte('last_seen', fiveMinutesAgo);
        setOnlineCount(Math.max(1, (data as any)?.length ?? 1));
      } catch (e: any) {
        console.error("Home static load failed", e);
      }
    };
    loadStaticData();

    // Real-time Living Word listener
    const unsubLW = settingsService.subscribeLivingWord((word) => {
      if (word?.ref && word?.text) {
        setDailyVerse(word);
      } else {
        fetchDailyVerse().then(setDailyVerse);
      }
    });

    // Check popup
    const today = new Date().toISOString().split('T')[0];
    const lastShown = localStorage.getItem('lastDailyBreadShown');
    if (lastShown !== today) {
      setTimeout(() => setShowDailyPopup(true), 2000);
      localStorage.setItem('lastDailyBreadShown', today);
    }

    // Listen for active voice room
    const unsubVoice = liveSessionService.subscribeToActiveRooms((rooms) => {
      setActiveVoiceRoom(rooms[0] ?? null);
    });

    return () => {
      unsubNotices();
      unsubConfig();
      unsubVoice();
      unsubLW();
    };
  }, []);

  const handleSaveConfig = async (newConfig: Partial<HomeConfig>) => {
    try {
      await settingsService.saveHomeConfig(newConfig);
      setIsEditingConfig(false);
    } catch (e) {
      console.error(e);
    }
  };

  return (
    <div className="p-3 lg:p-8 space-y-6 lg:space-y-8 max-w-7xl mx-auto overflow-x-hidden">
      {quotaExceeded && (
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-orange-50 dark:bg-orange-900/20 border-2 border-orange-200 dark:border-orange-500/30 p-4 rounded-2xl flex items-center gap-3 text-orange-800 dark:text-orange-200"
        >
          <div className="bg-orange-100 dark:bg-orange-500/20 p-2 rounded-xl">
             <ShieldCheck size={20} />
          </div>
          <div className="flex-1">
             <p className="text-sm font-black uppercase tracking-widest">Daily Sanctuary Quota Reached</p>
             <p className="text-xs font-medium opacity-80">Real-time fellowship updates are temporarily paused. You can still read the Bible and browse existing content.</p>
          </div>
        </motion.div>
      )}

      {/* Welcome Header */}
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-4 lg:gap-6">
        <div>
          <h1 className="text-2xl lg:text-4xl font-black font-serif text-tac-blue-dark dark:text-white leading-tight">
            Peace be with you, <br />
            <span className="text-tac-red">{profile?.name.split(' ')[0]}</span>
          </h1>
          <p className="text-[var(--Sub)] mt-1 lg:mt-2 text-xs lg:text-base font-medium">Welcome to the portal for {ASSEMBLY}.</p>
        </div>
        <div className="flex items-center gap-2 lg:gap-3">
          {activeVoiceRoom && (
            <button 
              onClick={() => setShowVoicePrayerTriggered(prev => !prev)}
              className="flex items-center gap-1.5 px-3 py-1 bg-red-50 dark:bg-red-900/30 text-red-600 dark:text-red-400 border border-red-200 dark:border-red-800/40 rounded-full text-xs font-bold hover:bg-red-100 dark:hover:bg-red-900/50 transition-all cursor-pointer shadow-sm"
              title="Trigger Live Voice Prayer"
            >
              <Radio size={13} className="animate-pulse" />
              <span className="text-[10px] font-black uppercase tracking-wider">
                {showVoicePrayerTriggered ? 'Close Prayer' : 'Trigger Voice Prayer'}
              </span>
            </button>
          )}
          <div className="flex items-center gap-1.5 opacity-60">
             <div className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse" />
             <p className="text-[10px] font-black uppercase text-tac-blue tracking-widest">{onlineCount.toLocaleString()} People Online</p>
          </div>
        </div>
      </header>

      {/* Live Voice Room Banner - Shown ONLY when triggered */}
      <AnimatePresence>
        {activeVoiceRoom && showVoicePrayerTriggered && (
          <motion.div 
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="group relative"
          >
            <div 
              className="bg-tac-blue-dark border-2 border-tac-blue/30 p-6 lg:p-8 rounded-[2rem] flex flex-col sm:flex-row items-center justify-between gap-6 overflow-hidden relative shadow-xl"
            >
               <div className="absolute top-0 right-0 p-8 opacity-5 -mr-4 -mt-4 transform rotate-12 group-hover:scale-110 transition-transform pointer-events-none">
                  <Radio size={100} className="text-tac-blue" />
               </div>

               {/* Close button at top-right */}
               <button 
                 onClick={(e) => {
                   e.stopPropagation();
                   setShowVoicePrayerTriggered(false);
                 }}
                 className="absolute top-4 right-4 p-2 bg-white/10 hover:bg-white/20 text-white/70 hover:text-white rounded-full transition-all z-20"
                 title="Close banner"
               >
                 <X size={18} />
               </button>
               
               <div className="flex items-center gap-6 pr-8">
                  <div className="w-16 h-16 bg-red-500 rounded-full flex items-center justify-center text-white shadow-[0_0_20px_rgba(239,68,68,0.4)] animate-pulse shrink-0">
                     <Radio size={30} />
                  </div>
                  <div className="text-center sm:text-left">
                     <div className="flex items-center justify-center sm:justify-start gap-2 mb-1">
                        <span className="text-[10px] font-black uppercase text-red-500 tracking-[0.2em] animate-pulse">Live Audio Conference</span>
                        <div className="w-1.5 h-1.5 bg-red-500 rounded-full" />
                     </div>
                     <h3 className="text-xl lg:text-2xl font-black text-white uppercase tracking-tight">{activeVoiceRoom.title || 'Global Assembly Voice Prayer'}</h3>
                     <p className="text-white/40 text-xs font-medium">Started by {activeVoiceRoom.hostName || 'Leader'} · Tap to join the sanctuary</p>
                  </div>
               </div>

               <div className="flex items-center gap-3 shrink-0 z-10">
                 {(profile?.role === 'admin' || profile?.role === 'presbytery' || activeVoiceRoom.hostId === profile?.uid) && (
                   <button 
                     onClick={async (e) => {
                       e.stopPropagation();
                       await handleStopRoom(activeVoiceRoom.id);
                       setShowVoicePrayerTriggered(false);
                     }}
                     className="px-5 py-3 bg-red-600 hover:bg-red-700 text-white rounded-xl font-black uppercase text-xs tracking-widest shadow-lg flex items-center gap-2 transition-all active:scale-95"
                   >
                     <PhoneOff size={16} /> Stop Room
                   </button>
                 )}
                 <button 
                   onClick={() => navigate('/dashboard/conference')}
                   className="px-8 py-3 bg-tac-blue hover:bg-blue-600 text-white rounded-xl font-black uppercase text-xs tracking-widest shadow-xl shadow-tac-blue/20 hover:scale-105 transition-all shrink-0"
                 >
                   Join Fellowship
                 </button>
               </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
  
      {/* Hero Slideshow Section */}
      <section className={`relative h-56 lg:h-[450px] rounded-[1.5rem] lg:rounded-[2.5rem] overflow-hidden shadow-2xl group ${slides.length === 0 ? 'bg-gradient-to-br from-tac-blue-dark via-tac-blue to-tac-red' : ''}`}>
        <AnimatePresence mode="wait">
          <motion.div
            key={currentSlide}
            initial={{ opacity: 0, scale: 1.1 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            transition={{ duration: 1.5, ease: "easeOut" }}
            className="absolute inset-0"
          >
            {slides[currentSlide] && (
              <img 
                src={slides[currentSlide]} 
                className="w-full h-full object-cover" 
                alt={`Church Slide ${currentSlide + 1}`}
              />
            )}
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-black/20" />
          </motion.div>
        </AnimatePresence>

        {/* Slideshow Controls */}
        <div className="absolute inset-0 p-8 flex flex-col justify-between">
          <div className="flex justify-between items-start">
             <div className="bg-white/10 backdrop-blur-md px-4 py-2 rounded-2xl border border-white/20 flex items-center gap-3">
                <div className="w-2 h-2 bg-tac-red rounded-full animate-pulse" />
                <span className="text-[10px] font-black uppercase text-white tracking-widest">Assembly Live Broadcast</span>
             </div>
             {isAdmin && (
               <div className="flex gap-2">
                 <input 
                   id="slide-upload" 
                   type="file" 
                   className="hidden" 
                   accept="image/*"
                   onChange={handleSlideUpload}
                 />
                 <button 
                   onClick={() => document.getElementById('slide-upload')?.click()}
                   className="p-3 bg-white/10 backdrop-blur-md hover:bg-white text-white hover:text-tac-blue-dark rounded-full transition-all border border-white/20 flex items-center gap-2 group"
                 >
                   <Plus size={18} />
                   <span className="hidden group-hover:block text-[10px] font-black uppercase pr-1">Add Slide</span>
                 </button>
                 {(config.heroSlides?.length || 0) > 0 && (
                   <button 
                     onClick={() => removeSlide(currentSlide)}
                     className="p-3 bg-red-500/20 backdrop-blur-md hover:bg-red-500 text-red-100 rounded-full transition-all border border-red-500/30 flex items-center gap-2 group"
                   >
                     <Trash2 size={18} />
                     <span className="hidden group-hover:block text-[10px] font-black uppercase pr-1">Remove</span>
                   </button>
                 )}
               </div>
             )}
          </div>

          <div className="flex items-center justify-between">
            <button 
              onClick={() => setCurrentSlide(prev => (prev - 1 + slides.length) % (slides.length || 1))}
              className="p-3 bg-black/20 backdrop-blur-md hover:bg-black/40 text-white rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
            >
              <ChevronLeft size={24} />
            </button>

            <div className="flex items-end gap-1.5 pb-2">
              {slides.map((_, i) => (
                <div 
                  key={i} 
                  className={`h-1.5 rounded-full transition-all duration-300 ${i === currentSlide ? 'w-8 bg-tac-red' : 'w-2 bg-white/30'}`} 
                />
              ))}
            </div>

            <button 
              onClick={() => setCurrentSlide(prev => (prev + 1) % (slides.length || 1))}
              className="p-3 bg-black/20 backdrop-blur-md hover:bg-black/40 text-white rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
            >
              <ChevronRightIcon size={24} />
            </button>
          </div>
        </div>
      </section>

      {/* Quick roll: every area has its own page, so Home stays short (a sideways roll on a phone) */}
      <section className="-mx-1">
        <div className="flex gap-3 overflow-x-auto snap-x pb-2 px-1 scrollbar-none">
          {[
            { l: 'Sermons', to: '/dashboard/sermons', e: <Headphones size={24} /> },
            { l: 'Events', to: '/dashboard/events', e: <CalendarDays size={24} /> },
            { l: 'Notices', to: '/dashboard/notices', e: <Megaphone size={24} /> },
            { l: 'Prayer', to: '/dashboard/prayers', e: <Heart size={24} /> },
            { l: 'Clubs', to: '/dashboard/clubs', e: <Users size={24} /> },
            { l: 'Hymns', to: '/dashboard/hymns', e: <Music size={24} /> },
            { l: 'Gallery', to: '/dashboard/gallery', e: <ImageIcon size={24} /> },
            { l: 'Info', to: '/dashboard/info', e: <Info size={24} /> },
          ].map((c) => (
            <button key={c.to} onClick={() => navigate(c.to)} className="snap-start shrink-0 w-[5.5rem] bg-white dark:bg-slate-900 border border-[var(--Bdr)] rounded-2xl py-3 flex flex-col items-center gap-1.5 shadow-sm active:scale-95 transition-all">
              <span className="text-tac-blue">{c.e}</span>
              <span className="text-[11px] font-black text-tac-blue-dark dark:text-white">{c.l}</span>
            </button>
          ))}
        </div>
      </section>

      {/* Annual Theme & Power Scripture Section */}
      {(config.churchTheme || config.themeScripture) && (
        <section className="relative overflow-hidden hidden lg:block">
           <div className="absolute inset-0 bg-tac-gold/5 dark:bg-tac-gold/10 rounded-[2.5rem]" />
           <div className="relative p-6 lg:p-10 border-2 border-tac-gold/20 rounded-[2.5rem] flex flex-col md:flex-row items-center justify-between gap-6">
              <div className="space-y-2 text-center md:text-left">
                 <div className="flex items-center justify-center md:justify-start gap-2 mb-2">
                    <Star size={16} className="text-tac-gold animate-spin-slow" />
                    <span className="text-[10px] font-black uppercase tracking-[0.3em] text-tac-gold">The Prophetic Theme</span>
                 </div>
                 <h2 className="text-2xl lg:text-4xl font-black font-serif text-tac-blue-dark dark:text-white uppercase leading-tight italic">
                    {config.churchTheme || "Faith Forward"}
                 </h2>
                 <div className="flex items-center justify-center md:justify-start gap-3 mt-4">
                    <div className="h-[1px] w-8 bg-tac-gold/40" />
                    <p className="text-lg font-bold text-tac-red font-serif italic">{config.themeScripture || "Isaiah 40:31"}</p>
                    <div className="h-[1px] w-8 bg-tac-gold/40" />
                 </div>
              </div>
              
              <div className="shrink-0 w-24 h-24 bg-tac-gold/10 rounded-full flex items-center justify-center border-4 border-tac-gold/20 shadow-xl shadow-tac-gold/10">
                 <div className="w-16 h-16 bg-tac-gold rounded-full flex items-center justify-center text-white font-black text-xl italic shadow-inner">
                    {new Date().getFullYear()}
                 </div>
              </div>
           </div>
        </section>
      )}

      {/* Verse of the Day Banner */}
      <AnimatePresence>
        {dailyVerse && (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="group relative cursor-pointer"
            onClick={FEATURES.bible ? () => navigate('/dashboard/bible') : undefined}
          >
            <div className="absolute inset-0 bg-gradient-to-r from-tac-blue-dark via-tac-blue to-tac-blue-dark blur-xl opacity-20" />
            <div className="relative bg-white dark:bg-slate-900 border-2 border-tac-blue/10 dark:border-tac-blue/20 p-6 lg:p-10 rounded-[2.5rem] flex flex-col md:flex-row items-center gap-6 lg:gap-10 shadow-xl overflow-hidden hover:border-tac-blue/30 transition-all">
               <div className="absolute top-0 right-0 p-8 opacity-5 -mr-4 -mt-4 transform rotate-12 group-hover:scale-110 transition-transform">
                  <BookOpen size={120} className="text-tac-blue" />
               </div>
               
               <div className="w-20 h-20 shrink-0 bg-tac-blue/5 dark:bg-tac-blue/20 rounded-[2rem] flex items-center justify-center text-tac-blue">
                  <Star size={32} />
               </div>

               <div className="flex-1 space-y-3 text-center md:text-left relative z-10">
                  <div className="flex items-center justify-center md:justify-start gap-2">
                    <div className="h-0.5 w-6 bg-tac-red" />
                    <span className="text-[10px] font-black uppercase tracking-[0.3em] text-tac-blue-dark dark:text-white/60">The Living Word</span>
                  </div>
                  <blockquote className="text-xl lg:text-2xl font-serif font-medium leading-relaxed italic text-tac-blue-dark dark:text-white group-hover:text-tac-blue transition-colors">
                    "{dailyVerse.text}"
                  </blockquote>
                  <div className="flex items-center justify-center md:justify-start gap-4">
                    <p className="text-sm font-black uppercase tracking-[0.2em] text-tac-blue">— {dailyVerse.ref}</p>
                    {FEATURES.bible && <button className="flex items-center gap-1.5 text-[10px] font-black uppercase tracking-widest text-slate-400 hover:text-tac-blue transition-colors">
                      Open Bible <ChevronRight size={12} />
                    </button>}
                  </div>
               </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Grid Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Recent Notices */}
        <section className="lg:col-span-2 space-y-6">
           <div className="flex items-center justify-between">
             <h3 className="text-xl font-black font-serif text-tac-blue-dark dark:text-white flex items-center gap-3">
               <Bell className="text-tac-red" size={24} /> Recent Notices
             </h3>
             <button onClick={() => navigate('/dashboard/notices')} className="text-sm font-bold text-tac-blue hover:underline">View All</button>
           </div>
           
           <div className="space-y-4">
             {notices.length > 0 ? notices.slice(0, 3).map(n => (
               <NoticeCard key={n.id} notice={n} />
             )) : (
               <div className="card text-center py-10 text-[var(--Sub)] italic text-sm">
                 Connecting to assembly broadcast...
               </div>
             )}
           </div>
        </section>

        {/* Quick Actions & Info */}
        <section className="space-y-8 hidden lg:block">
           <div className="space-y-4">
             <div className="flex items-center justify-between">
                <h3 className="text-xl font-black font-serif text-tac-blue-dark dark:text-white">Assembly Services</h3>
                {isAdmin && (
                  <button 
                    onClick={() => setIsEditingServices(!isEditingServices)}
                    className="text-[10px] font-black uppercase text-tac-blue px-3 py-1 bg-tac-blue/5 dark:bg-tac-blue/20 rounded-lg"
                  >
                    Edit
                  </button>
                )}
             </div>
             <div className="space-y-3">
               {config.services.map((s, idx) => (
                 <div key={s.id} className="relative group">
                    <ServiceTime 
                      label={s.label} 
                      time={s.time} 
                      icon={<CircleDot className={idx === 0 ? 'text-tac-red' : idx === 1 ? 'text-tac-blue' : 'text-tac-gold'} size={14} />} 
                    />
                    {isAdmin && isEditingServices && (
                       <button 
                        onClick={async () => {
                          const updated = config.services.filter(x => x.id !== s.id);
                          await handleSaveConfig({ services: updated });
                        }}
                        className="absolute -top-2 -right-2 bg-red-500 text-white p-1 rounded-full shadow-lg"
                       >
                         <X size={12} />
                       </button>
                    )}
                 </div>
               ))}
               {isAdmin && isEditingServices && (
                 <button 
                  onClick={async () => {
                    const label = prompt("Service Name:");
                    const time = prompt("Service Time:");
                    if (label && time) {
                      const updated = [...config.services, { id: Date.now().toString(), label, time }];
                      await handleSaveConfig({ services: updated });
                    }
                  }}
                  className="w-full py-3 border-2 border-dashed border-gray-200 rounded-2xl text-[10px] font-black uppercase text-gray-400 hover:border-tac-blue hover:text-tac-blue transition-all"
                 >
                   + Add Service
                 </button>
               )}
             </div>
           </div>

           <div className="card bg-gray-50/50 dark:bg-slate-900/50 border-dashed border-2 border-[var(--Bdr)] p-6">
              <div className="flex items-center justify-between mb-4">
                <h4 className="text-sm font-black text-tac-blue-dark dark:text-white">Assembly Media</h4>
                <button onClick={() => navigate('/dashboard/gallery')} className="text-[10px] font-bold text-tac-blue dark:text-tac-blue-light hover:underline">View All</button>
              </div>
              {gallery.length > 0 ? (
                <div className="grid grid-cols-3 gap-2">
                   {gallery.map(item => (
                     <div key={item.id} className="aspect-square bg-gray-200 dark:bg-slate-800 rounded-xl overflow-hidden hover:opacity-80 transition-opacity cursor-pointer shadow-sm">
                        {item.type === 'vid' ? (
                          <div className="w-full h-full bg-tac-blue-dark flex items-center justify-center text-white/50">
                            <CircleDot size={16} />
                          </div>
                        ) : (
                          <img src={item.src} alt="Media" className="w-full h-full object-cover" />
                        )}
                     </div>
                   ))}
                </div>
              ) : (
                <div className="py-8 text-center text-[10px] text-[var(--Sub)] font-black uppercase tracking-widest opacity-40">
                  No media posted yet
                </div>
              )}
           </div>
        </section>
      </div>

      {/* Upcoming Events Horizontal */}
      <section className="space-y-6 hidden lg:block">
        <div className="flex items-center justify-between">
          <h3 className="text-xl font-black font-serif text-tac-blue-dark flex items-center gap-3">
            <Calendar className="text-tac-red" size={24} /> Upcoming Calendar
          </h3>
          <button onClick={() => navigate('/dashboard/events')} className="text-sm font-bold text-tac-blue hover:underline">Full Schedule</button>
        </div>
        
        <div className="flex overflow-x-auto gap-4 pb-4 px-1 -mx-1 snap-x scrollbar-hide">
          {events.length > 0 ? events.map((ev, i) => (
             <EventSmallCard key={ev.id} event={ev} />
          )) : notices.filter(n => n.eventDate).map(n => (
             <EventSmallCard 
               key={n.id} 
               event={{ 
                 id: n.id, 
                 title: n.title, 
                 startDate: n.eventDate!, 
                 type: 'conference', 
                 summary: n.body,
                 createdAt: n.createdAt 
               }} 
             />
          ))}
          {events.length === 0 && notices.filter(n => n.eventDate).length === 0 && (
            <div className="w-full py-8 text-center text-[var(--Sub)] font-medium bg-gray-50 dark:bg-slate-900 rounded-[2rem] border border-dashed border-gray-200 dark:border-white/10">
               No upcoming pinned events in the calendar.
            </div>
          )}
        </div>
      </section>

      {/* Daily Bread Popup Notification */}
      <AnimatePresence>
        {showDailyPopup && dailyVerse && (
          <motion.div 
            initial={{ opacity: 0, x: 100 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 100 }}
            className="fixed bottom-6 right-6 z-50 w-full max-w-sm"
          >
             <div className="bg-white dark:bg-slate-900 border-2 border-tac-blue rounded-[2rem] p-6 shadow-[0_20px_50px_rgba(0,0,0,0.2)] dark:shadow-black/40 relative overflow-hidden group">
                <div className="absolute top-0 right-0 p-4 opacity-5 pointer-events-none group-hover:scale-110 transition-transform">
                   <BookOpen size={100} className="text-tac-blue" />
                </div>
                
                <button 
                  onClick={() => setShowDailyPopup(false)}
                  className="absolute top-4 right-4 p-2 text-gray-400 hover:text-tac-blue transition-colors"
                >
                  <X size={16} />
                </button>

                <div className="flex items-center gap-3 mb-4">
                   <div className="bg-tac-blue/10 text-tac-blue p-2 rounded-xl">
                      <Bell size={18} />
                   </div>
                   <span className="text-[10px] font-black uppercase tracking-[0.2em] text-tac-blue">Daily Bread Suggestion</span>
                </div>

                <div className="space-y-3 relative z-10">
                   <p className="text-lg font-serif font-black italic leading-tight text-tac-blue-dark dark:text-white line-clamp-4">
                      "{dailyVerse.text}"
                   </p>
                   <div className="flex items-center justify-between pt-2">
                      <p className="text-xs font-black uppercase text-tac-red tracking-widest">— {dailyVerse.ref}</p>
                      {FEATURES.bible && <button 
                        onClick={() => navigate('/dashboard/bible')}
                        className="px-4 py-2 bg-tac-blue text-white text-[9px] font-black uppercase tracking-widest rounded-lg hover:scale-105 transition-transform"
                      >
                        Read More
                      </button>}
                   </div>
                </div>
             </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

const NoticeCard: React.FC<{ notice: Notice }> = ({ notice }) => (
  <motion.div 
    whileHover={{ x: 5 }}
    className="bg-white dark:bg-slate-800 border border-[var(--Bdr)] rounded-2xl p-4 shadow-sm flex gap-4 transition-all hover:bg-white dark:hover:bg-slate-700/50 hover:shadow-md cursor-pointer"
  >
    <div className={`shrink-0 w-1 rounded-full ${notice.type === 'pin' ? 'bg-tac-red' : notice.type === 'urg' ? 'bg-orange-500' : 'bg-tac-blue'}`} />
    <div className="flex-1 space-y-1">
      <div className="flex items-center justify-between">
        <span className="text-[10px] font-black uppercase text-tac-blue/40 tracking-widest">{notice.date}</span>
        {notice.type === 'pin' && <span className="text-[10px] font-black bg-tac-red/10 text-tac-red px-2 py-0.5 rounded-full uppercase tracking-tighter">Pinned</span>}
      </div>
      <h4 className="text-lg font-black text-tac-blue-dark dark:text-white tracking-tight leading-tight">{notice.title}</h4>
      <p className="text-sm text-[var(--Sub)] line-clamp-2 leading-relaxed">{notice.body}</p>
    </div>
    <div className="shrink-0 flex items-center text-tac-blue/20">
      <ChevronRight size={24} />
    </div>
  </motion.div>
);

const ServiceTime: React.FC<{ label: string; time: string; icon: React.ReactNode }> = ({ label, time, icon }) => (
  <div className="flex items-center gap-3 px-4 py-3 bg-white dark:bg-slate-800 rounded-2xl border border-[var(--Bdr)] shadow-sm">
    <div className="shrink-0">{icon}</div>
    <div className="flex-1">
      <p className="text-[10px] font-black uppercase text-[var(--Sub)] tracking-widest">{label}</p>
      <p className="text-sm font-bold text-tac-blue-dark dark:text-white">{time}</p>
    </div>
  </div>
);

const EventSmallCard: React.FC<{ event: EventItem }> = ({ event }) => {
  const date = new Date(event.startDate);
  const day = date.getDate();
  const month = date.toLocaleString('default', { month: 'short' }).toUpperCase();
  const year = date.getFullYear();

  return (
    <div className="shrink-0 w-64 bg-white dark:bg-slate-800 rounded-3xl p-5 border border-[var(--Bdr)] shadow-sm snap-start space-y-4">
      <div className="flex items-start justify-between">
        <div className="bg-tac-red text-white w-12 h-14 rounded-2xl flex flex-col items-center justify-center shadow-lg shadow-tac-red/20">
          <span className="text-lg font-black font-serif leading-none">{day}</span>
          <span className="text-[9px] font-black uppercase tracking-widest mt-1">{month}</span>
        </div>
        <div className="p-2 bg-gray-50 dark:bg-white/5 rounded-xl text-tac-blue/30"><MapPin size={20} /></div>
      </div>
      <div className="space-y-1">
         <h5 className="font-black text-tac-blue-dark dark:text-white leading-tight line-clamp-2">{event.title}</h5>
         <p className="text-[11px] text-[var(--Sub)] flex items-center gap-1 font-medium">
           {event.location || 'Assembiy Grounds'} · {date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
         </p>
      </div>
    </div>
  );
};

export default HomeView;
