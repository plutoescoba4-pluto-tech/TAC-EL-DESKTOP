import React, { useCallback, useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Search, MessageCircle, Paperclip } from 'lucide-react';
import { supabase } from '../../supabase';
import { subscribeQuery } from '../../lib/realtime';
import { useAuth } from '../../context/AuthContext';

/**
 * "Messages": your direct-message conversations, newest first, with unread counts.
 * Starts a new chat from the Members list (open a member, then Message).
 * Data comes from the my_dm_threads() database function (06-chat.sql), which never downloads
 * photos or voice notes just to draw a preview.
 */
interface Thread {
  other_id: string;
  other_name: string | null;
  last_text: string | null;
  last_is_rich: boolean;
  last_at: string;
  last_sender_id: string;
  unread_count: number;
}

const when = (iso: string) => {
  const d = new Date(iso);
  const now = new Date();
  if (d.toDateString() === now.toDateString()) return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  if (now.getTime() - d.getTime() < 6 * 86400000) return d.toLocaleDateString([], { weekday: 'short' });
  return d.toLocaleDateString([], { day: 'numeric', month: 'short' });
};

export const MessagesList: React.FC = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [threads, setThreads] = useState<Thread[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [search, setSearch] = useState('');

  const load = useCallback(async () => {
    const { data, error } = await supabase.rpc('my_dm_threads');
    if (error) setError('Could not load your messages. Make sure 06-chat.sql has been run.');
    else { setError(null); setThreads((data as Thread[]) ?? []); }
    setLoading(false);
  }, []);

  useEffect(() => {
    load();
    // any new or read message anywhere refreshes the list
    const unsub = subscribeQuery({ table: 'direct_messages', orderBy: { column: 'created_at', ascending: false }, limit: 1 }, () => { load(); });
    return () => unsub();
  }, [load]);

  const open = (otherId: string) => {
    if (!user) return;
    const ids = [user.id, otherId].sort();
    navigate(`/dashboard/chat/direct/${ids[0]}_${ids[1]}`);
  };

  const shown = threads.filter((t) => (t.other_name || '').toLowerCase().includes(search.trim().toLowerCase()));

  return (
    <div className="max-w-2xl mx-auto p-4 lg:p-8 space-y-4">
      <div>
        <h2 className="text-2xl font-black font-serif text-tac-blue-dark dark:text-white">Messages</h2>
        <p className="text-sm text-[var(--Sub)]">Your private conversations.</p>
      </div>

      <div className="relative">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
        <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search your conversations"
          className="w-full pl-11 pr-4 py-3 rounded-2xl bg-white dark:bg-slate-800 border border-[var(--Bdr)] text-sm outline-none focus:border-tac-blue" />
      </div>

      {error && <p className="text-sm text-tac-red">{error}</p>}
      {loading && <p className="text-xs text-gray-400">Loading…</p>}

      {!loading && !error && threads.length === 0 && (
        <div className="text-center py-16 rounded-3xl border border-dashed border-gray-200 dark:border-white/10">
          <MessageCircle size={40} className="mx-auto text-gray-200 dark:text-white/10 mb-3" />
          <p className="font-bold text-sm">No conversations yet</p>
          <p className="text-xs text-[var(--Sub)] mt-1">Open a member in the Members list and tap Message to start one.</p>
        </div>
      )}

      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-[var(--Bdr)] overflow-hidden divide-y divide-[var(--Bdr)]">
        {shown.map((t) => {
          const mine = t.last_sender_id === user?.id;
          const preview = t.last_is_rich ? null : t.last_text;
          return (
            <button key={t.other_id} type="button" onClick={() => open(t.other_id)} className="w-full flex items-center gap-3 p-4 text-left hover:bg-gray-50 dark:hover:bg-white/5">
              <div className="w-12 h-12 rounded-full bg-tac-blue/10 text-tac-blue font-black flex items-center justify-center shrink-0">
                {(t.other_name || '?').trim().charAt(0).toUpperCase()}
              </div>
              <div className="min-w-0 flex-1">
                <div className="flex items-baseline justify-between gap-2">
                  <p className={`truncate text-sm ${t.unread_count ? 'font-black' : 'font-bold'}`}>{t.other_name || 'Member'}</p>
                  <span className={`shrink-0 text-[11px] ${t.unread_count ? 'text-tac-blue font-black' : 'text-gray-400'}`}>{when(t.last_at)}</span>
                </div>
                <div className="flex items-center justify-between gap-2">
                  <p className={`truncate text-xs ${t.unread_count ? 'text-[var(--Text)] font-semibold' : 'text-[var(--Sub)]'}`}>
                    {mine ? 'You: ' : ''}
                    {preview ?? <span className="inline-flex items-center gap-1"><Paperclip size={11} /> Attachment</span>}
                  </p>
                  {t.unread_count > 0 && (
                    <span className="shrink-0 min-w-[20px] h-5 px-1.5 rounded-full bg-tac-blue text-white text-[10px] font-black flex items-center justify-center">
                      {t.unread_count > 99 ? '99+' : t.unread_count}
                    </span>
                  )}
                </div>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
};

export default MessagesList;
