import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { SermonMedia } from '../shared/SermonMedia';
import { Search, Play, Volume2, Calendar, User, Tag, Clock, Plus, X, Video, BookOpen, ExternalLink, Trash2 } from 'lucide-react';
import { sermonsService } from '../../services/contentService';
import { useAuth } from '../../context/AuthContext';
import { Sermon } from '../../types';
import { handleFirestoreError, OperationType } from '../../lib/firestore-errors';
import { trackActivity } from '../../services/memberMemoryService';
import { MAX_BINARY_FILE_BYTES, MAX_FIRESTORE_PAYLOAD_BYTES, calculatePayloadSizeBytes } from '../../lib/image-utils';

const SermonView: React.FC = () => {
  const { user, profile } = useAuth();
  const [sermons, setSermons] = useState<Sermon[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [isAdding, setIsAdding] = useState(false);
  const [newSermon, setNewSermon] = useState({ title: '', speaker: '', summary: '', type: 'Sunday Service', videoUrl: '', audioUrl: '' });
  const [uploadError, setUploadError] = useState<string | null>(null);

  const handleVideoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > MAX_BINARY_FILE_BYTES) {
        setUploadError(`Direct video upload must be under 6 MB (file is ${(file.size / (1024 * 1024)).toFixed(1)} MB). For sermon recordings, please paste a YouTube or streaming link into the Video URL field below.`);
        return;
      }
      setUploadError(null);
      const reader = new FileReader();
      reader.onload = (event) => {
        setNewSermon({ ...newSermon, videoUrl: event.target?.result as string });
      };
      reader.readAsDataURL(file);
    }
  };

  useEffect(() => {
    const fetchSermons = async () => {
      try {
        setSermons(await sermonsService.getSermons());
      } catch (error: any) {
        handleFirestoreError(error, OperationType.GET, 'sermons');
      }
    };
    fetchSermons();
  }, []);

  const handleAddSermon = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newSermon.title || !newSermon.speaker) return;

    const sermonData = {
      title: newSermon.title,
      speaker: newSermon.speaker,
      date: new Date().toISOString().split('T')[0],
      videoUrl: newSermon.videoUrl || undefined,
      audioUrl: newSermon.audioUrl || undefined,
    };
    // NOTE: `summary`/`type`/`color` have no columns on `sermons` yet — not
    // persisted. See MIGRATION_NOTES.md.

    const size = calculatePayloadSizeBytes(sermonData);
    if (size > MAX_FIRESTORE_PAYLOAD_BYTES) {
      setUploadError(`Sermon data is too large (${Math.round(size / 1024)} KB). Please provide a video streaming URL instead of a large raw video.`);
      return;
    }

    try {
      const newId = await sermonsService.addSermon(sermonData);
      // Show it immediately instead of waiting for a manual refresh — this
      // is what was actually broken: the sermon WAS saving, the list just
      // never re-rendered to show it.
      setSermons((prev) => [
        { id: newId, ...sermonData, type: sermonData.videoUrl ? 'video' : sermonData.audioUrl ? 'audio' : 'message' } as Sermon,
        ...prev,
      ]);
      setNewSermon({ title: '', speaker: '', summary: '', type: 'Sunday Service', videoUrl: '', audioUrl: '' });
      setIsAdding(false);
      setUploadError(null);
    } catch (err: any) {
       console.error(err);
       setUploadError(err?.message || 'Failed to save sermon to database.');
    }
  };

  const handleDelete = async (id: string) => {
    if (!window.confirm('Delete this sermon?')) return;
    try {
      await sermonsService.deleteSermon(id);
      setSermons((prev) => prev.filter((s) => s.id !== id));
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `sermons/${id}`);
    }
  };

  const filtered = sermons.filter(s => 
    s.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
    s.speaker.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const isAdmin = profile?.role === 'admin';
  const isStaff = isAdmin || profile?.role === 'presbytery';

  const handleTrackSermon = (sermon: Sermon) => {
    if (user) {
      trackActivity(user.id, 'sermon', { title: sermon.title, id: sermon.id });
    }
  };

  return (
    <div className="p-4 lg:p-8 max-w-5xl mx-auto space-y-8">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-3xl font-black font-serif text-tac-blue-dark dark:text-white tracking-tight">Sermon Library</h2>
          <p className="text-[var(--Sub)] font-medium">Spiritual nourishment through the spoken word.</p>
        </div>
        <div className="flex items-center gap-3">
          <div className="relative group">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-tac-blue/30" size={18} />
            <input 
              type="text" 
              placeholder="Search library..." 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-11 pr-4 py-2.5 bg-white dark:bg-white/5 dark:text-white border border-[var(--Bdr)] rounded-2xl w-full md:w-64 outline-none focus:ring-4 focus:ring-tac-blue/5 transition-all"
            />
          </div>
          {isStaff && (
            <button onClick={() => setIsAdding(true)} className="p-3 bg-tac-red text-white rounded-2xl shadow-lg shadow-tac-red/20 active:scale-95">
              <Plus size={20} />
            </button>
          )}
        </div>
      </header>

      <AnimatePresence>
        {isAdding && (
          <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} className="overflow-hidden">
            <form onSubmit={handleAddSermon} className="card bg-tac-blue-dark text-white p-6 space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-bold">Add New Sermon</h3>
                <button type="button" onClick={() => setIsAdding(false)}><X size={20} /></button>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <input required placeholder="Sermon Title" value={newSermon.title} onChange={e => setNewSermon({...newSermon, title: e.target.value})} className="bg-white/5 border border-white/10 rounded-xl px-4 py-3 outline-none" />
                <input required placeholder="Speaker Name" value={newSermon.speaker} onChange={e => setNewSermon({...newSermon, speaker: e.target.value})} className="bg-white/5 border border-white/10 rounded-xl px-4 py-3 outline-none" />
                <div className="flex flex-col gap-2">
                   <label className="text-[10px] font-black uppercase text-white/40 tracking-widest px-1">Sermon Video (Direct Upload)</label>
                   <input type="file" accept="video/*" onChange={handleVideoUpload} className="bg-white/5 border border-white/10 rounded-xl px-4 py-2 outline-none text-xs" />
                </div>
                <div className="flex flex-col gap-2">
                   <label className="text-[10px] font-black uppercase text-white/40 tracking-widest px-1">Or YouTube URL</label>
                   <input placeholder="https://youtube.com/..." value={newSermon.videoUrl.startsWith('data:') ? '' : newSermon.videoUrl} onChange={e => setNewSermon({...newSermon, videoUrl: e.target.value})} className="bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 outline-none" />
                </div>
                <select value={newSermon.type} onChange={e => setNewSermon({...newSermon, type: e.target.value})} className="bg-white/5 border border-white/10 rounded-xl px-4 py-3 outline-none md:col-span-2">
                  <option value="Sunday Service">Sunday Service</option>
                  <option value="Wednesday Study">Bible Study</option>
                  <option value="Conference">Conference</option>
                  <option value="Special Program">Special Program</option>
                </select>
              </div>
              <textarea placeholder="Brief summary of the message..." value={newSermon.summary} onChange={e => setNewSermon({...newSermon, summary: e.target.value})} className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 outline-none min-h-[100px]" />
              {uploadError && (
                <div className="p-3 bg-red-500/20 border border-red-500/30 rounded-xl text-xs text-red-200 flex items-center gap-2 font-medium">
                  <span className="font-black">!</span>
                  <span>{uploadError}</span>
                </div>
              )}
              <button type="submit" className="w-full py-4 bg-white text-tac-blue-dark rounded-2xl font-black shadow-lg">Upload to Library</button>
            </form>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="space-y-4">
        {filtered.map((s, i) => (
          <SermonListItem 
            key={s.id} 
            sermon={s} 
            index={i} 
            isStaff={isStaff} 
            onDelete={() => handleDelete(s.id)} 
            onTrack={() => handleTrackSermon(s)}
          />
        ))}
      </div>
    </div>
  );
};

const SermonListItem: React.FC<{ sermon: Sermon; index: number; isStaff: boolean; onDelete: () => void; onTrack: () => void }> = ({ sermon, index, isStaff, onDelete, onTrack }) => (
  <motion.div
    initial={{ opacity: 0, y: 10 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ delay: index * 0.05 }}
    className="card group hover:shadow-xl transition-all flex flex-col gap-3 p-4 md:p-6"
    onClick={onTrack}
  >
    <div className="space-y-1.5">
      <span className="text-[10px] font-black bg-tac-blue/5 text-tac-blue px-2 py-0.5 rounded-full uppercase tracking-tighter">{sermon.type}</span>
      <h3 className="text-lg md:text-xl font-black text-tac-blue-dark dark:text-white leading-tight break-words">{sermon.title}</h3>
      {sermon.scripture && <p className="text-xs font-bold text-tac-blue">{sermon.scripture}</p>}
      {sermon.summary && <p className="text-sm text-[var(--Sub)] line-clamp-3 leading-relaxed">{sermon.summary}</p>}
    </div>
    <SermonMedia sermon={sermon} />
    <div className="flex items-center justify-between border-t border-[var(--Bdr)] pt-3 gap-2">
      <div className="flex flex-wrap gap-x-4 gap-y-1">
        <div className="flex items-center gap-1 text-[var(--Sub)] text-xs font-bold uppercase tracking-wider"><User size={14} className="text-tac-red" /> {sermon.speaker}</div>
        <div className="flex items-center gap-1 text-[var(--Sub)] text-xs font-bold uppercase tracking-wider"><Calendar size={14} className="text-tac-blue" /> {sermon.date}</div>
      </div>
      {isStaff && <button onClick={(e) => { e.stopPropagation(); onDelete(); }} className="p-2.5 bg-red-50 dark:bg-red-500/10 text-red-500 rounded-xl hover:bg-red-500 hover:text-white transition-all shrink-0"><Trash2 size={18} /></button>}
    </div>
  </motion.div>
);

export default SermonView;
