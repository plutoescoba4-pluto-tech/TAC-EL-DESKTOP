import { pauseOthers, playPreview } from '../../lib/singleAudio';
import { isAutoCaption } from '../../lib/chatText';
import { createPortal } from 'react-dom';
import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Send, 
  Image as ImageIcon, 
  Smile, 
  MoreVertical, 
  Reply, 
  X, 
  Mic, 
  Plus, 
  Camera, 
  File, 
  User,
  Check,
  CheckCheck,
  MapPin,
  Trash2,
  StopCircle,
  Play,
  Pause,
  Video,
  RotateCcw,
  RefreshCw
} from 'lucide-react';
import { chatService } from '../../services/chatService';
import { useChatTheme, themeVars, themeAttrs, wallpaperProps } from '../../lib/chatTheme';
import ChatThemePanel from '../chat/ChatThemePanel';
import { useHiddenMessages } from '../../lib/chatHidden';
import { supabase } from '../../supabase';
import { markConversationRead, GLOBAL_CONV } from '../../lib/chatUnread';
import { ONLINE_WINDOW_MS } from '../../lib/presenceStatus';
import { ChatSoundToggle } from '../chat/ChatSoundToggle';
import { ReactionPicker, ReactionChips, useReactions, MuteButton, useMySuspension, SuspendedNotice } from '../chat/ChatExtras';
import type { Reaction } from '../../services/chatService';
import { authService } from '../../services/authService';
import { useAuth } from '../../context/AuthContext';
import type { RealtimeChannel } from '@supabase/supabase-js';
import { ChatMessage } from '../../types';
import { handleFirestoreError, OperationType } from '../../lib/firestore-errors';
import { 
  MAX_FIRESTORE_PAYLOAD_BYTES, 
  MAX_BINARY_FILE_BYTES, 
  calculatePayloadSizeBytes, 
  processFileForChat 
} from '../../lib/image-utils';
import { useHoldMic } from '../../lib/useHoldMic';
import { WhatsAppAudioRecorder } from '../chat/WhatsAppAudioRecorder';

const ChatView: React.FC = () => {
  const { user, profile } = useAuth();
  const presenceChannelRef = useRef<RealtimeChannel | null>(null);
  const [onlineCount, setOnlineCount] = useState<number | null>(null);

  // Real "N online" for the group header (it used to say "Connected Online"
  // unconditionally): members whose heartbeat is fresh.
  useEffect(() => {
    const load = async () => {
      const since = new Date(Date.now() - ONLINE_WINDOW_MS).toISOString();
      const { count } = await supabase.from('profiles').select('id', { count: 'exact', head: true }).gte('last_seen', since);
      setOnlineCount(count ?? 0);
    };
    load();
    const t = setInterval(load, 30000);
    return () => clearInterval(t);
  }, []);
  const isAdmin = profile?.role === 'admin';
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const { hidden: hiddenIds, hide: hideForMe } = useHiddenMessages(user?.id);
  const { theme: chatTheme } = useChatTheme(user?.id, 'group');
  const wallpaper = wallpaperProps(chatTheme.wallpaper);
  const reactions = useReactions('group');
  const suspendedUntil = useMySuspension(user?.id);
  const [inputText, setInputText] = useState('');
  const [replyingTo, setReplyTo] = useState<ChatMessage | null>(null);
  const [showAttach, setShowAttach] = useState(false);
  const [showEmojis, setShowEmojis] = useState(false);
  const [showAudioRecorder, setShowAudioRecorder] = useState(false);
  const [releaseSignal, setReleaseSignal] = useState<{ kind: 'send' | 'cancel'; n: number } | null>(null);
  const holdMic = useHoldMic({
    onTap: () => setShowAudioRecorder(true),
    onHoldStart: () => { setReleaseSignal(null); setShowAudioRecorder(true); },
    onRelease: (kind) => setReleaseSignal({ kind, n: Date.now() }),
  });
  const [isRecording, setIsRecording] = useState(false);
  const [othersTyping, setOthersTyping] = useState<string[]>([]);
  const [othersRecording, setOthersRecording] = useState<string[]>([]);
  const typingTimeoutRef = useRef<any>(null);
  const [isVideoRecording, setIsVideoRecording] = useState(false);
  const [recordingTime, setRecordingTime] = useState(0);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  const [showCamera, setShowCamera] = useState(false);
  const [cameraStream, setCameraStream] = useState<MediaStream | null>(null);
  const [facing, setFacing] = useState<'user' | 'environment'>(() => {
    try { return localStorage.getItem('tac_cam_facing') === 'environment' ? 'environment' : 'user'; } catch { return 'user'; }
  });
  const openCam = async (face: 'user' | 'environment') => {
    const size = { width: { ideal: 1280 }, height: { ideal: 720 } };
    try { return await navigator.mediaDevices.getUserMedia({ video: { facingMode: { exact: face }, ...size }, audio: false }); }
    catch {
      try { return await navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: face }, ...size }, audio: false }); }
      catch { return await navigator.mediaDevices.getUserMedia({ video: true, audio: false }); }
    }
  };
  const flipCamera = async () => {
    const next = facing === 'user' ? 'environment' : 'user';
    const curId = cameraStream?.getVideoTracks()[0]?.getSettings().deviceId;
    try {
      cameraStream?.getTracks().forEach((t) => t.stop());
      let stream = await openCam(next);
      if (curId && stream.getVideoTracks()[0]?.getSettings().deviceId === curId) {
        const cams = (await navigator.mediaDevices.enumerateDevices()).filter((d) => d.kind === 'videoinput');
        if (cams.length > 1) {
          stream.getTracks().forEach((t) => t.stop());
          const i = cams.findIndex((d) => d.deviceId === curId);
          stream = await navigator.mediaDevices.getUserMedia({ video: { deviceId: { exact: cams[(i + 1) % cams.length].deviceId } }, audio: false });
        }
      }
      const fm = stream.getVideoTracks()[0]?.getSettings().facingMode;
      const shown: 'user' | 'environment' = fm === 'environment' || fm === 'user' ? fm : next;
      setFacing(shown);
      try { localStorage.setItem('tac_cam_facing', shown); } catch { /* fine */ }
      setCameraStream(stream);
    } catch { setSendError('Could not switch the camera. This device may have only one.'); }
  };
  const [recordingStream, setRecordingStream] = useState<MediaStream | null>(null);
  const [audioBlob, setAudioBlob] = useState<Blob | null>(null);
  const [videoBlob, setVideoBlob] = useState<Blob | null>(null);
  const [showAudioPreview, setShowAudioPreview] = useState(false);
  const [showVideoPreview, setShowVideoPreview] = useState(false);
  const [showBgSettings, setShowBgSettings] = useState(false);
  const [isClearingAll, setIsClearingAll] = useState(false);
  const [sendError, setSendError] = useState<string | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  // Auto-dismiss send errors
  useEffect(() => {
    if (sendError) {
      const t = setTimeout(() => setSendError(null), 6000);
      return () => clearTimeout(t);
    }
  }, [sendError]);

  const [clearError, setClearError] = useState<string | null>(null);
  const handleClearAllMessages = async () => {
    setClearError(null);
    try {
      await chatService.clearAllMessages();
      setMessages([]);
      setIsClearingAll(false);
    } catch (err: any) {
      // keep the box open and say why: nothing was deleted
      setClearError(err?.message || 'Could not clear the chat. Nothing was deleted.');
    }
  };
  const seenRequested = useRef<Set<string>>(new Set()); // message ids already sent to markSeen
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const videoRef = useRef<HTMLVideoElement>(null);
  const liveVideoRef = useRef<HTMLVideoElement>(null);
  const timerRef = useRef<any>(null);

  // Categorized Emojis
  const emojiCategories = [
    { label: 'Smileys', emojis: ['😀', '😃', '😄', '😁', '😅', '😂', '🤣', '😊', '😇', '🙂', '🙃', '😉', '😌', '😍', '🥰', '😘', '😗', '😙', '😚', '😋', '😛', '😝', '😜', '🤪', '🤨', '🧐', '🤓', '😎', '🤩', '🥳', '😏', '😒', '😞', '😔', '😟', '😕', '🙁', '☹️', '😣', '😖', '😫', '😩', '🥺', '😢', '😭', '😤', '😠', '😡', '🤬', '🤯', '😳', '🥵', '🥶', '😱', '😨', '😰', '😥', '😓', '🤗', '🤔', '🤭', '🤫', '🤥', '😶', '😐', '😑', '😬', '🙄', '😯', '😦', '😧', '😮', '😲', '🥱', '😴', '🤤', '😪', '😵', '🤐', '🥴', '🤢', '🤮', '🤧', '😷', '🤒', '🤕'] },
    { label: 'Religious', emojis: ['🙏', '🙌', '⛪', '📖', '✝️', '🕊️', '😇', '✨', '👑', '🌈', '💎', '💡', '🔔', '💒', '🕍', '🕋', '🕌', '🕯️', '📿', '🧿', '☀️', '⭐', '🌙'] },
    { label: 'Hearts', emojis: ['❤️', '🧡', '💛', '💚', '💙', '💜', '🖤', '🤍', '🤎', '💔', '❣️', '💕', '💞', '💓', '💗', '💖', '💘', '💝', '💟'] },
    { label: 'Hands', emojis: ['👏', '🙌', '👐', '🤲', '🤝', '👍', '👎', '👊', '✊', '🤛', '🤜', '🤞', '✌️', '🤟', '🤘', '👌', '🤏', '👈', '👉', '👆', '👇', '🖐️', '✋', '🖖', '👋', '🤙', '💪'] },
    { label: 'Activities', emojis: ['⚽', '🏀', '🏈', '⚾', '🥎', '🎾', '🏐', '🏉', '🥏', '🎱', '🪀', '🏓', '🏸', '🏒', '🏑', '🥍', '🏏', '🥅', '⛳', '🪁', '🏹', '🎣', '🤿', '🥊', '🥋', '🎽', '🛹'] }
  ];
  const [activeCategory, setActiveCategory] = useState(0);

  const backgrounds = [
    'bg-[#efeae2]',
    'bg-gray-100',
    'bg-blue-50',
    'bg-stone-200'
  ];

  useEffect(() => {
    // Opening the chat counts as reading everything currently in it.
    if (user?.id) markConversationRead(user.id, GLOBAL_CONV);
    const unsub = chatService.subscribeToGlobalChat((msgs) => {
      setMessages(msgs);
      if (user?.id) markConversationRead(user.id, GLOBAL_CONV);
      setTimeout(() => {
        if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
      }, 100);

      // Mark incoming messages delivered + read (this chat is open, so "delivered"
      // and "read" happen together — no separate "app was backgrounded" state to
      // track here). Only writes for messages we haven't already marked, to avoid
      // redundant writes on every snapshot.
      if (user?.id) {
        const unseen = msgs
          .filter((m) => m.senderId !== user.id) // sender already has themself in both arrays from send-time
          .filter((m) => !m.deliveredTo?.includes(user.id) || !m.readBy?.includes(user.id))
          .map((m) => m.id)
          .filter((id) => !seenRequested.current.has(id));
        if (unseen.length) {
          unseen.forEach((id) => seenRequested.current.add(id));
          chatService.markSeen(unseen, user.id).catch(() => {
            unseen.forEach((id) => seenRequested.current.delete(id)); // allow a retry
          });
        }
      }
    }, 100);

    return () => {
      unsub();
      if (cameraStream) cameraStream.getTracks().forEach(t => t.stop());
      if (recordingStream) recordingStream.getTracks().forEach(t => t.stop());
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [cameraStream, recordingStream]);

  // --- Presence: typing & recording indicators, WhatsApp-style ---
  // Ephemeral Realtime Presence channel, not a Firestore-style presence
  // collection — one subscription both reads everyone else's state and lets
  // us push our own via channel.track(). No stale-doc cleanup needed: a
  // disconnected client's presence disappears from the sync event instantly.
  useEffect(() => {
    if (!user?.id) return;
    const { channel, unsubscribe } = chatService.subscribeGlobalPresence(
      { uid: user.id, name: profile?.name || 'Member' },
      (state) => {
        const typing: string[] = [];
        const recording: string[] = [];
        for (const [uid, s] of Object.entries(state)) {
          if (uid === user.id) continue; // never show our own indicator to ourselves
          if (s.recording) recording.push(s.name || 'Someone');
          else if (s.typing) typing.push(s.name || 'Someone');
        }
        setOthersTyping(typing);
        setOthersRecording(recording);
      }
    );
    presenceChannelRef.current = channel;
    return () => {
      presenceChannelRef.current = null;
      unsubscribe();
    };
  }, [user?.id]);

  // Push OUR OWN typing state whenever it changes
  useEffect(() => {
    if (!user?.id || !profile || !presenceChannelRef.current) return;
    const track = () => presenceChannelRef.current?.track({ name: profile.name, typing: inputText.trim().length > 0, recording: false });
    track();
    if (typingTimeoutRef.current) clearTimeout(typingTimeoutRef.current);
    if (inputText.trim().length > 0) {
      // Auto-clear "typing" after 4s of no keystrokes, matching WhatsApp's own timeout behavior
      typingTimeoutRef.current = setTimeout(() => {
        presenceChannelRef.current?.track({ name: profile.name, typing: false, recording: false });
      }, 4000);
    }
    return () => { if (typingTimeoutRef.current) clearTimeout(typingTimeoutRef.current); };
  }, [inputText, user?.id, profile?.name]);

  useEffect(() => {
    if (!user?.id || !profile || !presenceChannelRef.current) return;
    presenceChannelRef.current.track({ name: profile.name, recording: showAudioRecorder, typing: false });
  }, [showAudioRecorder, user?.id, profile?.name]);

  useEffect(() => {
    if (showCamera && cameraStream && videoRef.current) {
      videoRef.current.srcObject = cameraStream;
    }
  }, [showCamera, cameraStream]);

  useEffect(() => {
    if (isVideoRecording && recordingStream && liveVideoRef.current) {
      liveVideoRef.current.srcObject = recordingStream;
    }
  }, [isVideoRecording, recordingStream]);

  const handleSendMessage = async (textOverride?: string, mediaData?: any) => {
    if (!textOverride && !inputText.trim() && !mediaData) return;
    if (!user || !profile) return;

    const msgData: any = {
      senderId: user.id,
      senderColor: profile.color || 'bg-tac-blue',
      text: textOverride || inputText.trim(),
      ...mediaData
    };

    if (replyingTo) {
      // chat_messages stores reply_to_id (a real FK) and reconstructs the
      // preview via a join on read — not a denormalized snapshot object.
      msgData.replyToId = replyingTo.id;
      msgData.replyQuote = { sender: replyingTo.senderName, text: replyingTo.text || (replyingTo.img ? 'Photo' : replyingTo.vid ? 'Video' : 'Voice message') };
    }

    // Defensive check before sending
    const estimatedSize = calculatePayloadSizeBytes(msgData);
    if (estimatedSize > MAX_FIRESTORE_PAYLOAD_BYTES) {
      setSendError(`Attachment is too large (${Math.round(estimatedSize / 1024)} KB). The maximum database limit is 9 MB. Please attach a shorter clip or smaller file.`);
      return;
    }

    // WhatsApp style: the message appears and the box clears at once; the server catches up quietly
    const tmpId = `tmp-${Date.now()}`;
    const prevInput = inputText; const prevReply = replyingTo;
    setMessages((prev) => [...prev, {
      ...msgData, id: tmpId, senderId: user?.id, senderName: profile.name,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }), createdAt: new Date().toISOString(),
      replyTo: replyingTo ? { sender: replyingTo.senderName, text: replyingTo.text || (replyingTo.img ? 'Photo' : replyingTo.vid ? 'Video' : 'Voice message'), img: replyingTo.img } : undefined,
      deliveredTo: [], readBy: [],
    } as any]);
    setInputText(''); setReplyTo(null); setShowAttach(false); setShowEmojis(false); setSendError(null);
    setTimeout(() => { if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight; }, 30);
    try {
      await chatService.sendGlobalMessage(msgData);
    } catch (err: any) {
      setMessages((prev) => prev.filter((m) => m.id !== tmpId));
      setInputText(prevInput); setReplyTo(prevReply);
      if (err.message?.includes('exceeds the maximum allowed size') || err.message?.includes('cannot be written because its size')) {
        setSendError('Message exceeds the database size limit. Please reduce the size of the photo, video, or attachment.');
      } else {
        setSendError(err.message || 'Failed to send message. Please try again.');
      }
      console.error('Send failed:', err);
    }
  };

  const startCamera = async () => {
    try {
      const stream = await openCam(facing);
      setCameraStream(stream);
      setShowCamera(true);
    } catch (err) {
      console.error('Camera failed:', err);
      setSendError('Could not access camera. Please check permissions.');
    }
  };

  const capturePhoto = () => {
    if (!videoRef.current) return;
    const canvas = document.createElement('canvas');
    let w = videoRef.current.videoWidth || 800;
    let h = videoRef.current.videoHeight || 600;
    const maxDim = 900;
    if (w > maxDim || h > maxDim) {
      if (w > h) {
        h = Math.round((h * maxDim) / w);
        w = maxDim;
      } else {
        w = Math.round((w * maxDim) / h);
        h = maxDim;
      }
    }
    canvas.width = w;
    canvas.height = h;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.drawImage(videoRef.current, 0, 0, w, h);
      const dataUrl = canvas.toDataURL('image/jpeg', 0.65);
      stopCamera();
      handleSendMessage("Captured a photo", { img: dataUrl });
    }
  };

  const stopCamera = () => {
    if (cameraStream) {
      cameraStream.getTracks().forEach(t => t.stop());
      setCameraStream(null);
    }
    setShowCamera(false);
  };

  const startRecording = async (type: 'audio' | 'video' = 'audio') => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        audio: true, 
        video: type === 'video' ? { facingMode: 'user', width: { ideal: 640 }, height: { ideal: 480 } } : false 
      });
      
      setRecordingStream(stream);

      const options: MediaRecorderOptions = {};
      if (type === 'video') {
        if (MediaRecorder.isTypeSupported('video/webm;codecs=vp8,opus')) {
          options.mimeType = 'video/webm;codecs=vp8,opus';
        } else if (MediaRecorder.isTypeSupported('video/webm')) {
          options.mimeType = 'video/webm';
        } else if (MediaRecorder.isTypeSupported('video/mp4')) {
          options.mimeType = 'video/mp4';
        }
        options.videoBitsPerSecond = 250000; // 250 kbps keeps 15s around ~470 KB
        options.audioBitsPerSecond = 32000;
      } else {
        if (MediaRecorder.isTypeSupported('audio/webm;codecs=opus')) {
          options.mimeType = 'audio/webm;codecs=opus';
        } else if (MediaRecorder.isTypeSupported('audio/webm')) {
          options.mimeType = 'audio/webm';
        } else if (MediaRecorder.isTypeSupported('audio/mp4')) {
          options.mimeType = 'audio/mp4';
        }
        options.audioBitsPerSecond = 32000;
      }

      const recorder = new MediaRecorder(stream, options);
      mediaRecorderRef.current = recorder;
      chunksRef.current = [];

      recorder.ondataavailable = (e) => {
        if (e.data.size > 0) chunksRef.current.push(e.data);
      };

      recorder.onstop = () => {
        const mimeType = type === 'video' ? (recorder.mimeType || 'video/webm') : (recorder.mimeType || 'audio/webm');
        const blob = new Blob(chunksRef.current, { type: mimeType });
        
        if (blob.size > MAX_BINARY_FILE_BYTES) {
          setSendError(`Recording is too large (${Math.round(blob.size / 1024)} KB). Maximum allowed size is ${Math.round(MAX_BINARY_FILE_BYTES / 1024)} KB. Please record a shorter clip (under 15 seconds for video).`);
          stream.getTracks().forEach(t => t.stop());
          setRecordingStream(null);
          return;
        }

        const url = URL.createObjectURL(blob);
        
        if (type === 'video') {
          setVideoBlob(blob);
          setVideoUrl(url);
          setShowVideoPreview(true);
        } else {
          setAudioBlob(blob);
          setAudioUrl(url);
          setShowAudioPreview(true);
        }
        stream.getTracks().forEach(t => t.stop());
        setRecordingStream(null);
      };

      recorder.start();
      if (type === 'video') {
        setIsVideoRecording(true);
      } else {
        setIsRecording(true);
      }
      setRecordingTime(0);
      timerRef.current = setInterval(() => {
        setRecordingTime(prev => {
          const next = prev + 1;
          // Auto stop video at 15 seconds, voice at 90 seconds
          if (type === 'video' && next >= 15) {
            stopRecording(true);
          } else if (type === 'audio' && next >= 90) {
            stopRecording(true);
          }
          return next;
        });
      }, 1000);
    } catch (err) {
      console.error('Recording failed:', err);
      setSendError('Media access denied. Please check microphone/camera permissions.');
    }
  };

  const stopRecording = (shouldSave = true) => {
    if (mediaRecorderRef.current && (isRecording || isVideoRecording)) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      setIsVideoRecording(false);
      if (recordingStream) {
        recordingStream.getTracks().forEach(t => t.stop());
        setRecordingStream(null);
      }
      clearInterval(timerRef.current);
      if (!shouldSave) {
        setAudioUrl(null);
        setAudioBlob(null);
        setShowAudioPreview(false);
        setVideoUrl(null);
        setVideoBlob(null);
        setShowVideoPreview(false);
      }
    }
  };

  const handleSendAudio = async () => {
    if (!audioUrl || !audioBlob) return;
    if (audioBlob.size > MAX_BINARY_FILE_BYTES) {
      setSendError(`Audio recording is too large (${Math.round(audioBlob.size / 1024)} KB). Please record a shorter message.`);
      return;
    }
    const reader = new FileReader();
    reader.onload = (e) => {
      const base64 = e.target?.result as string;
      handleSendMessage("Voice message", { audio: base64 });
      setAudioUrl(null);
      setAudioBlob(null);
      setShowAudioPreview(false);
    };
    reader.readAsDataURL(audioBlob);
  };

  const handleSendVideo = async () => {
    if (!videoUrl || !videoBlob) return;
    if (videoBlob.size > MAX_BINARY_FILE_BYTES) {
      setSendError(`Video recording is too large (${Math.round(videoBlob.size / 1024)} KB). Please record a shorter clip (under 15s).`);
      return;
    }
    const reader = new FileReader();
    reader.onload = (e) => {
      const base64 = e.target?.result as string;
      handleSendMessage("Video message", { vid: base64 });
      setVideoUrl(null);
      setVideoBlob(null);
      setShowVideoPreview(false);
    };
    reader.readAsDataURL(videoBlob);
  };

  const handleLocation = () => {
    if ("geolocation" in navigator) {
      navigator.geolocation.getCurrentPosition((pos) => {
        const { latitude, longitude } = pos.coords;
        const mapUrl = `https://www.google.com/maps?q=${latitude},${longitude}`;
        handleSendMessage("Shared my location", { location: mapUrl });
      }, (err) => {
        console.error(err);
        setSendError(err.code === 1 ? "Location permission was denied. Allow location access in your browser settings." : "Could not get your location. Make sure GPS is on and try again.");
      }, { enableHighAccuracy: true, timeout: 15000, maximumAge: 30000 });
    } else {
      setSendError("This device cannot share a location.");
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Reset input so user can choose the same file again
    e.target.value = '';
    setShowAttach(false);

    if (file.type.startsWith('image/')) {
      try {
        const processed = await processFileForChat(file);
        if (processed.isOverLimit) {
          setSendError(`Image file is too large (${Math.round(processed.sizeBytes / 1024)} KB). Please choose a smaller picture.`);
          return;
        }
        handleSendMessage(`Shared photo: ${file.name}`, { img: processed.dataUrl });
      } catch (err) {
        console.error('Image compression failed:', err);
        setSendError('Failed to process image file.');
      }
    } else {
      if (file.size > MAX_BINARY_FILE_BYTES) {
        setSendError(`File '${file.name}' is too large (${(file.size / (1024 * 1024)).toFixed(1)} MB). Storage limit is ${Math.round(MAX_BINARY_FILE_BYTES / 1024)} KB. Please upload a smaller file or share a link.`);
        return;
      }
      const reader = new FileReader();
      reader.onload = (event) => {
        const result = event.target?.result as string;
        if (file.type.startsWith('video/')) {
          handleSendMessage(`Shared video: ${file.name}`, { vid: result });
        } else {
          handleSendMessage(`Shared file: ${file.name}`, { file: result });
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const addEmoji = (emoji: string) => {
    setInputText(prev => prev + emoji);
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const handleAttach = (type: string) => {
    if (type === 'camera') {
      startCamera();
    } else if (type === 'location') {
      handleLocation();
    } else if (type === 'file' || type === 'image') {
      document.getElementById('file-input')?.click();
    }
    setShowAttach(false);
  };

  return (
    <div {...themeAttrs(chatTheme)} style={themeVars(chatTheme)} className="chat-scope flex flex-col h-full flex-1 min-h-0 bg-[#efeae2] dark:bg-[#0b141a] relative overflow-hidden font-sans">
      {/* Background Settings */}
      <AnimatePresence>
        {showBgSettings && (
          <motion.div
            initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }}
            className="absolute top-16 right-3 left-3 sm:left-auto sm:w-96 max-h-[80vh] overflow-y-auto bg-white dark:bg-slate-800 rounded-3xl p-5 shadow-2xl z-[80] border border-gray-100 dark:border-white/10"
          >
            <ChatThemePanel uid={user?.id} scope="group" scopeLabel="the church chat" onClose={() => setShowBgSettings(false)} />
          </motion.div>
        )}
      </AnimatePresence>

      {/* Clear All Messages Confirmation Modal */}
      <AnimatePresence>
        {isClearingAll && (
          <div className="fixed inset-0 z-[150] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
             <motion.div 
               initial={{ scale: 0.9, opacity: 0 }}
               animate={{ scale: 1, opacity: 1 }}
               exit={{ scale: 0.9, opacity: 0 }}
               className="bg-white dark:bg-slate-900 rounded-3xl p-6 shadow-2xl max-w-sm w-full border border-gray-100 dark:border-white/10 text-center"
             >
                <div className="w-14 h-14 bg-red-100 dark:bg-red-900/20 text-tac-red rounded-2xl flex items-center justify-center mx-auto mb-4">
                   <Trash2 size={28} />
                </div>
                <h3 className="text-base font-black text-tac-blue-dark dark:text-white mb-2">Clear Church Fellowship Chat?</h3>
                <p className="text-xs text-gray-500 dark:text-gray-400 mb-6">This will remove all previous messages in the church fellowship chat history for everyone.</p>
                {clearError && <p className="text-[11px] font-bold text-tac-red mb-4 text-left">{clearError}</p>}
                <div className="grid grid-cols-2 gap-3">
                   <button 
                     onClick={() => setIsClearingAll(false)}
                     className="py-3 bg-gray-100 dark:bg-white/5 text-gray-500 rounded-xl font-bold text-xs hover:bg-gray-200 transition-all"
                   >
                     Cancel
                   </button>
                   <button 
                     onClick={handleClearAllMessages}
                     className="py-3 bg-tac-red text-white rounded-xl font-bold text-xs shadow-lg shadow-tac-red/20 hover:scale-105 active:scale-95 transition-all"
                   >
                     Clear All
                   </button>
                </div>
             </motion.div>
          </div>
        )}
      </AnimatePresence>

      <div className="flex items-center justify-between p-3 bg-white dark:bg-slate-900 border-b border-[var(--Bdr)] shrink-0 z-30 shadow-sm sticky top-0">
         <div className="flex items-center gap-3">
            <div className={`w-10 h-10 rounded-2xl flex items-center justify-center text-white font-black shadow-lg ${profile?.color || 'bg-tac-blue'}`}>
               {profile?.name.charAt(0)}
            </div>
            <div>
               <h3 className="text-sm font-black text-tac-blue-dark dark:text-white leading-tight">Assembly Fellowship</h3>
               {othersRecording.length > 0 ? (
                 <div className="text-[10px] text-tac-red font-bold flex items-center gap-1">
                   <Mic size={10} className="animate-pulse" />
                   {othersRecording.slice(0, 2).join(', ')}{othersRecording.length > 2 ? ` +${othersRecording.length - 2}` : ''} recording audio…
                 </div>
               ) : othersTyping.length > 0 ? (
                 <div className="text-[10px] text-tac-blue dark:text-tac-blue-light font-bold flex items-center gap-1 italic">
                   {othersTyping.slice(0, 2).join(', ')}{othersTyping.length > 2 ? ` +${othersTyping.length - 2}` : ''} typing…
                 </div>
               ) : (
                 <div className="text-[10px] text-green-600 dark:text-green-400 font-bold flex items-center gap-1">
                   <div className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse" />
                   {onlineCount === null ? 'Fellowship chat' : `${onlineCount} ${onlineCount === 1 ? 'member' : 'members'} online`}
                 </div>
               )}
            </div>
         </div>
         <div className="flex items-center gap-1">
           <MuteButton userId={user?.id} target="group" />
           <ChatSoundToggle />
           <button 
             onClick={() => setIsClearingAll(true)} 
             className="p-2.5 text-gray-400 hover:text-tac-red hover:bg-red-50 dark:hover:bg-white/5 rounded-full transition-all"
             title="Clear all fellowship chat history"
           >
              <Trash2 size={18} />
           </button>
           <button 
             onClick={() => setShowBgSettings(!showBgSettings)} 
             className="p-2.5 text-tac-blue-dark dark:text-white/60 hover:bg-gray-100 dark:hover:bg-white/5 rounded-full transition-all"
             title="Change chat background wallpaper"
           >
              <ImageIcon size={20} />
           </button>
         </div>
      </div>

      {/* Messages Area */}
      <div 
        ref={scrollRef}
        className={`flex-1 min-h-0 overflow-y-auto overscroll-contain p-4 lg:px-12 space-y-2 relative scroll-smooth ${wallpaper.className}`}
        style={wallpaper.style}
      >
        <div className="flex justify-center mb-6">
           <span className="px-4 py-1.5 bg-white dark:bg-slate-800 shadow-sm rounded-lg text-[10px] uppercase font-black text-tac-blue tracking-[0.2em] border border-tac-blue/5">Church Global Fellowship</span>
        </div>

        {messages.filter((m) => !hiddenIds.has(m.id)).map((msg) => (
          <MessageBubble 
            key={msg.id} 
            msg={msg} 
            onHideForMe={() => hideForMe(msg.id)}
            isMe={msg.senderId === user?.id} 
            onReply={() => setReplyTo(msg)}
            reactions={reactions[msg.id]}
            myId={user?.id}
            onReact={(emoji) => { if (user) chatService.react('group', msg.id, user.id, emoji).catch((e) => console.warn('Reaction failed:', e)); }}
          />
        ))}
        {othersTyping.length > 0 && (
          <div className="flex justify-start">
            <div className="bg-white dark:bg-slate-800 rounded-2xl rounded-bl-md px-4 py-3 shadow-sm flex items-center gap-1" aria-label="typing">
              <span className="w-2 h-2 rounded-full bg-gray-400 animate-bounce" style={{ animationDelay: '0ms' }} />
              <span className="w-2 h-2 rounded-full bg-gray-400 animate-bounce" style={{ animationDelay: '150ms' }} />
              <span className="w-2 h-2 rounded-full bg-gray-400 animate-bounce" style={{ animationDelay: '300ms' }} />
            </div>
          </div>
        )}
      </div>

      {/* Emoji Picker Overlay */}
      <AnimatePresence>
        {showEmojis && (
          <motion.div 
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 350, opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            // In-flow (not an absolute overlay) and placed directly above the
            // input bar in the flex column — it used to be `absolute bottom-0`
            // with a huge z-index, which visually sat ON TOP of the input bar
            // and Send button. You could pick an emoji, but then couldn't see
            // or tap Send to actually send it — this is that bug.
            className="relative shrink-0 bg-white dark:bg-[#111b21] z-20 flex flex-col shadow-[0_-4px_10px_rgba(0,0,0,0.15)] overflow-hidden border-t border-black/10 dark:border-white/10"
          >
            {/* Mobile drag handle bar */}
            <div 
              className="w-12 h-1.5 bg-gray-300 dark:bg-gray-600 rounded-full mx-auto my-2 cursor-pointer shrink-0 active:scale-95 transition-transform" 
              onClick={() => setShowEmojis(false)} 
              title="Close emoji picker"
            />

            {/* Header: scrolling categories on the left, FIXED visible close button on the right */}
            <div className="flex items-center justify-between bg-gray-100 dark:bg-[#202c33] shrink-0 border-b border-black/5 dark:border-white/5 pl-2 pr-3 py-1">
              <div className="flex-1 flex items-center overflow-x-auto scrollbar-none gap-1 py-0.5">
                {emojiCategories.map((cat, idx) => (
                  <button
                    key={cat.label}
                    type="button"
                    onClick={() => setActiveCategory(idx)}
                    className={`px-3 py-1.5 text-[11px] font-black uppercase tracking-wider rounded-xl transition-all shrink-0 ${activeCategory === idx ? 'text-tac-blue bg-white dark:bg-[#111b21] shadow-sm' : 'text-gray-500 dark:text-gray-400 hover:text-gray-700'}`}
                  >
                    {cat.label}
                  </button>
                ))}
              </div>
              <button 
                type="button"
                onClick={() => setShowEmojis(false)} 
                className="shrink-0 p-2 ml-2 text-gray-700 hover:text-black dark:text-gray-300 dark:hover:text-white bg-gray-200 dark:bg-white/10 rounded-full active:scale-90 transition-all flex items-center justify-center shadow-sm"
                title="Close emojis"
              >
                <X size={18} />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-4 grid grid-cols-7 sm:grid-cols-9 lg:grid-cols-12 gap-y-4">
              {emojiCategories[activeCategory].emojis.map(e => (
                <button key={e} onClick={() => addEmoji(e)} className="text-3xl hover:scale-125 transition-transform p-1 flex justify-center items-center">
                  {e}
                </button>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Real-time Send Error Alert Banner */}
      <AnimatePresence>
        {sendError && (
          <motion.div 
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 20, opacity: 0 }}
            className="mx-3 mb-2 p-3 bg-red-50 dark:bg-red-950/70 border border-red-200 dark:border-red-800/70 rounded-2xl flex items-center justify-between text-xs text-red-600 dark:text-red-300 font-semibold shadow-md z-30"
          >
            <div className="flex items-center gap-2">
              <span className="text-base shrink-0 font-black">!</span>
              <p className="leading-snug">{sendError}</p>
            </div>
            <button 
              type="button"
              onClick={() => setSendError(null)}
              className="p-1 hover:bg-black/5 dark:hover:bg-white/10 rounded-full shrink-0 ml-2"
              title="Dismiss"
            >
              <X size={14} />
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Reply Preview */}
      <AnimatePresence>
        {replyingTo && (
          <motion.div 
            initial={{ y: 50, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 50, opacity: 0 }}
            className="px-4 py-2 bg-white/80 dark:bg-slate-900/80 backdrop-blur-sm border-t border-gray-200 dark:border-white/10 flex items-center gap-3"
          >
            <div className="flex-1 bg-gray-50 dark:bg-white/5 border-l-4 border-tac-blue rounded-lg p-2 text-xs text-left">
               <p className="font-bold text-tac-blue">{replyingTo.senderName}</p>
               <p className="text-gray-500 dark:text-gray-400 truncate">{replyingTo.text || 'Media Message'}</p>
            </div>
            <button onClick={() => setReplyTo(null)} className="p-1.5 hover:bg-gray-200 dark:hover:bg-white/10 rounded-full">
              <X size={18} className="text-gray-400" />
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Attachment Panel */}
      <AnimatePresence>
        {showAttach && (
          <motion.div 
            initial={{ y: 200, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 200, opacity: 0 }}
            className="absolute bottom-20 left-4 right-4 bg-white dark:bg-slate-800 rounded-3xl p-6 shadow-2xl grid grid-cols-3 gap-6 z-50 border border-gray-100 dark:border-white/10"
          >
             <AttachBtn onClick={() => handleAttach('image')} icon={<ImageIcon size={24} />} label="Gallery" color="bg-purple-500" />
             <AttachBtn onClick={() => handleAttach('camera')} icon={<Camera size={24} />} label="Camera" color="bg-red-500" />
             <AttachBtn onClick={() => handleAttach('file')} icon={<File size={24} />} label="Document" color="bg-blue-500" />
             <AttachBtn onClick={() => handleAttach('location')} icon={<MapPin size={24} />} label="Location" color="bg-green-500" />
             <AttachBtn onClick={() => { setShowAttach(false); setShowAudioRecorder(true); }} icon={<Mic size={24} />} label="Audio Rec" color="bg-orange-500" />
             <AttachBtn onClick={() => startRecording('video')} icon={<Video size={24} />} label="Video Rec" color="bg-red-600" />
             <button onClick={() => setShowAttach(false)} className="flex flex-col items-center gap-2 p-3 hover:bg-gray-50 dark:hover:bg-white/5 rounded-2xl transition-all">
                <div className="w-14 h-14 bg-gray-100 dark:bg-white/5 text-gray-500 dark:text-gray-400 rounded-full flex items-center justify-center"><X size={24} /></div>
                <span className="text-[10px] font-black uppercase text-gray-400">Close</span>
             </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Audio Recording Preview Overlay */}
      <AnimatePresence>
        {showAudioPreview && audioUrl && (
          <motion.div 
            initial={{ y: 50, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 50, opacity: 0 }}
            className="absolute bottom-0 inset-x-0 bg-[#f0f2f5] dark:bg-[#111b21] z-[60] border-t border-gray-200 dark:border-white/10 p-4"
          >
             <div className="bg-white dark:bg-[#202c33] rounded-3xl p-4 shadow-xl flex items-center gap-4">
                <button 
                  onClick={() => {
                    playPreview(audioUrl);
                  }}
                  className="w-12 h-12 bg-tac-blue text-white rounded-full flex items-center justify-center hover:scale-110 active:scale-95 transition-all"
                >
                  <Play size={24} />
                </button>
                <div className="flex-1">
                   <div className="h-1 bg-gray-100 dark:bg-white/10 rounded-full w-full overflow-hidden">
                      <div className="h-full bg-tac-blue animate-progress" />
                   </div>
                   <p className="text-[10px] font-black uppercase text-tac-blue tracking-widest mt-2">Preview Voice Message</p>
                </div>
                <div className="flex items-center gap-2">
                  <button 
                    onClick={() => {
                      setAudioUrl(null);
                      setAudioBlob(null);
                      setShowAudioPreview(false);
                    }}
                    className="p-3 text-tac-red hover:bg-tac-red/5 rounded-full transition-colors"
                  >
                    <Trash2 size={24} />
                  </button>
                  <button 
                    onClick={handleSendAudio}
                    className="w-12 h-12 bg-[#005c4b] text-white rounded-full flex items-center justify-center shadow-lg active:scale-95 transition-all"
                  >
                    <Send size={24} />
                  </button>
                </div>
             </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Video Recording Preview Overlay */}
      <AnimatePresence>
        {showVideoPreview && videoUrl && (
          <motion.div 
            initial={{ y: 50, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 50, opacity: 0 }}
            className="absolute bottom-0 inset-x-0 bg-black z-[70] p-4"
          >
             <div className="bg-white dark:bg-slate-800 rounded-3xl p-4 shadow-xl flex flex-col gap-4">
                <video src={videoUrl} controls className="w-full aspect-video rounded-2xl bg-black" />
                <div className="flex items-center justify-between">
                  <button 
                    onClick={() => {
                      setVideoUrl(null);
                      setVideoBlob(null);
                      setShowVideoPreview(false);
                    }}
                    className="p-3 text-tac-red hover:bg-tac-red/5 rounded-full transition-colors flex items-center gap-2 font-black uppercase text-[10px] tracking-widest"
                  >
                    <Trash2 size={24} />
                    Discard
                  </button>
                  <button 
                    onClick={handleSendVideo}
                    className="h-14 px-8 bg-[#005c4b] text-white rounded-2xl flex items-center justify-center gap-3 shadow-lg active:scale-95 transition-all font-black uppercase text-[10px] tracking-widest"
                  >
                    <Send size={24} />
                    Send Video Message
                  </button>
                </div>
             </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Input Section - Static at Bottom */}
      {suspendedUntil && <SuspendedNotice until={suspendedUntil} />}
      <div style={suspendedUntil ? { display: 'none' } : undefined} className="bg-white dark:bg-slate-900 p-2 lg:p-4 flex flex-col gap-2 relative border-t border-[var(--Bdr)] shrink-0 z-30 sticky bottom-0">
        <input 
          id="file-input" 
          type="file" 
          className="hidden" 
          onChange={handleFileUpload}
        />

        <AnimatePresence>
          {(isRecording || isVideoRecording) && (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 h-[100dvh] bg-black z-[150] flex flex-col overflow-hidden"
            >
              {isVideoRecording ? (
                <div className="flex-1 relative bg-black min-h-0 flex items-center justify-center">
                  <video ref={liveVideoRef} autoPlay playsInline muted className={`max-w-full max-h-full w-auto h-auto object-contain ${facing === 'user' ? 'scale-x-[-1]' : ''}`} />
                  <div className="absolute top-0 inset-x-0 p-8 flex justify-between bg-gradient-to-b from-black/60 to-transparent text-white">
                    <div className="flex items-center gap-3">
                       <div className="w-3 h-3 bg-red-500 rounded-full animate-pulse" />
                       <span className="font-black text-xl tabular-nums">{formatTime(recordingTime)}</span>
                    </div>
                    <button onClick={() => stopRecording(false)} className="p-2 bg-black/20 backdrop-blur-md rounded-full"><X size={24} /></button>
                  </div>
                  <div className="absolute bottom-0 inset-x-0 p-12 flex justify-center bg-gradient-to-t from-black/60 to-transparent">
                     <button 
                        onClick={() => stopRecording(true)}
                        className="w-24 h-24 bg-white/20 backdrop-blur-md rounded-full p-2 border-4 border-white flex items-center justify-center group"
                     >
                        <div className="w-full h-full bg-red-500 rounded-full group-active:scale-90 transition-transform" />
                     </button>
                  </div>
                </div>
              ) : (
                <div className="flex-1 flex flex-col items-center justify-center p-8 bg-[#0b141a]">
                  <div className="w-32 h-32 bg-tac-red rounded-full flex items-center justify-center shadow-2xl shadow-tac-red/50 mb-8 animate-pulse text-white">
                    <Mic size={48} />
                  </div>
                  <h3 className="text-4xl font-black text-white tabular-nums mb-2">{formatTime(recordingTime)}</h3>
                  <p className="text-white/40 font-bold uppercase tracking-widest text-xs">Recording Voice Message</p>
                  
                  <div className="fixed bottom-12 inset-x-0 flex justify-center gap-4 px-8 max-w-lg mx-auto w-full">
                     <button 
                      onClick={() => stopRecording(false)}
                      className="h-16 px-8 bg-white/5 border border-white/10 text-white rounded-3xl font-black uppercase text-xs tracking-widest flex items-center gap-2"
                     >
                       <X size={18} /> Cancel
                     </button>
                     <button 
                      onClick={() => stopRecording(true)}
                      className="h-16 flex-1 bg-tac-red text-white rounded-3xl font-black uppercase text-xs tracking-widest shadow-xl shadow-tac-red/20 flex items-center justify-center gap-2"
                     >
                       <Send size={18} /> Stop & Send
                     </button>
                  </div>
                </div>
              )}
            </motion.div>
          )}
        </AnimatePresence>

        <div className="flex items-center gap-1 sm:gap-2">
          <button 
            type="button" 
            onClick={() => setShowAttach(!showAttach)}
            className={`w-10 h-10 sm:w-11 sm:h-11 flex items-center justify-center text-gray-500 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-white/5 rounded-full transition-all shrink-0 ${showAttach ? 'rotate-45 text-tac-red' : ''}`}
          >
            <Plus size={24} />
          </button>

          <div className="flex-1 bg-white dark:bg-white/10 rounded-2xl flex items-center px-1 shadow-sm transition-shadow focus-within:shadow-md border border-gray-100 dark:border-white/10 min-w-0">
            <button 
              type="button" 
              onClick={() => setShowEmojis(!showEmojis)}
              className={`p-2 sm:p-2.5 text-gray-500 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-white/5 rounded-full shrink-0 ${showEmojis ? 'text-tac-blue' : ''}`}
             >
                <Smile size={24} />
             </button>

            <input 
              type="text" 
              placeholder="Message" 
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
              className="flex-1 py-3 sm:py-4 text-sm sm:text-base outline-none px-2 text-[#111b21] dark:text-white bg-transparent placeholder:text-gray-400 min-w-0"
            />
            
            {!inputText.trim() && (
              <button type="button" onClick={() => handleAttach('camera')} className="p-2 sm:p-2.5 text-gray-500 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-white/5 rounded-full shrink-0">
                <Camera size={24} />
              </button>
            )}
          </div>
          
          <button 
            type="button"
            onClick={inputText.trim() ? () => handleSendMessage() : undefined}
            {...(inputText.trim() ? {} : holdMic)}
            style={{ touchAction: 'none', WebkitTouchCallout: 'none', userSelect: 'none' }}
            className={`w-10 h-10 sm:w-12 sm:h-12 rounded-full flex items-center justify-center shadow-lg transition-all active:scale-95 shrink-0 ${inputText.trim() ? 'bg-tac-blue text-white' : 'bg-[#005c4b] text-white hover:bg-[#007a63]'}`}
            title={inputText.trim() ? 'Send message' : 'Record voice note (WhatsApp style)'}
          >
            {inputText.trim() ? (
              <Send size={18} className="sm:w-5 sm:h-5" />
            ) : (
              <Mic size={18} />
            )}
          </button>
        </div>
      </div>

      {/* WhatsApp Voice Recording Dedicated Page/Screen */}
      <WhatsAppAudioRecorder
        isOpen={showAudioRecorder}
        releaseSignal={releaseSignal}
        onClose={() => setShowAudioRecorder(false)}
        onSend={(_blob, dataUrl) => {
          handleSendMessage("Voice message", { audio: dataUrl });
          setShowAudioRecorder(false);
        }}
        onError={(err) => setSendError(err)}
      />

      {/* Camera Modal Overlay */}
      {createPortal(
<AnimatePresence>
        {showCamera && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 h-[100dvh] bg-black z-[100] flex flex-col overflow-hidden"
          >
            <div className="px-4 pb-3 pt-[max(0.75rem,env(safe-area-inset-top))] flex justify-between items-center bg-black/40 backdrop-blur-md absolute top-0 w-full z-10 text-white">
              <button onClick={stopCamera} className="p-2">
                <X size={24} />
              </button>
              <h3 className="font-black uppercase text-[10px] tracking-widest">Live Camera</h3>
              <button onClick={flipCamera} className="p-2" title="Switch camera" aria-label="Switch camera"><RefreshCw size={22} /></button>
            </div>
            <div className="flex-1 min-h-0 flex items-center justify-center bg-black">
              <video 
                ref={videoRef} 
                autoPlay 
                playsInline 
                muted
                className="max-w-full max-h-full w-auto h-auto object-contain scale-x-[-1]"
              />
            </div>
            <div className="pt-4 pb-[max(1.25rem,env(safe-area-inset-bottom))] flex justify-center bg-black/40 backdrop-blur-md absolute bottom-0 w-full">
               <button 
                 onClick={capturePhoto}
                 className="w-16 h-16 bg-white rounded-full border-4 border-tac-blue p-1 flex items-center justify-center active:scale-90 transition-transform"
               >
                 <div className="w-full h-full bg-white rounded-full border-2 border-gray-100" />
               </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>,
 document.body)}
    </div>
  );
};

const ChatAudioPlayer: React.FC<{ src: string }> = ({ src }) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [progress, setProgress] = useState(0);
  const [duration, setDuration] = useState(0);
  const [currentTime, setCurrentTime] = useState(0);
  const audioRef = useRef<HTMLAudioElement>(null);

  const togglePlay = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!audioRef.current) return;
    if (isPlaying) {
      audioRef.current.pause();
    } else {
      audioRef.current.play().catch(err => console.warn("Audio play error:", err));
    }
  };

  const handleTimeUpdate = () => {
    if (audioRef.current) {
      setCurrentTime(audioRef.current.currentTime);
      if (audioRef.current.duration) {
        setProgress((audioRef.current.currentTime / audioRef.current.duration) * 100);
      }
    }
  };

  const handleLoadedMetadata = () => {
    if (audioRef.current) {
      setDuration(audioRef.current.duration);
    }
  };

  const handleSeek = (e: React.MouseEvent<HTMLDivElement>) => {
    e.stopPropagation();
    if (!audioRef.current || !duration) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const clickX = e.clientX - rect.left;
    const newTime = (clickX / rect.width) * duration;
    audioRef.current.currentTime = newTime;
    setProgress((newTime / duration) * 100);
  };

  const formatTime = (secs: number) => {
    if (isNaN(secs) || secs <= 0) return '0:00';
    const m = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  return (
    <div 
      className="mb-2 p-2.5 bg-black/5 dark:bg-white/5 backdrop-blur rounded-xl border border-black/5 dark:border-white/5 flex items-center gap-3 select-none"
      onClick={e => e.stopPropagation()}
      onPointerDown={e => e.stopPropagation()}
    >
      <button 
        type="button"
        onClick={togglePlay}
        className={`w-10 h-10 rounded-full flex items-center justify-center text-white shadow-md active:scale-90 transition-all shrink-0 ${
          isPlaying ? 'bg-tac-red' : 'bg-tac-blue hover:bg-blue-600'
        }`}
        title={isPlaying ? "Pause voice message" : "Play voice message"}
      >
        {isPlaying ? <Pause size={18} /> : <Play size={18} className="ml-0.5" />}
      </button>

      <audio 
        ref={audioRef}
        src={src}
        onPlay={(e) => { pauseOthers(e.currentTarget); setIsPlaying(true); }}
        onPause={() => setIsPlaying(false)}
        onEnded={() => { setIsPlaying(false); setProgress(0); }}
        onTimeUpdate={handleTimeUpdate}
        onLoadedMetadata={handleLoadedMetadata}
        onError={() => console.warn("Voice message failed to load")}
        preload="metadata"
      />

      <div className="flex-1 min-w-[130px]">
        <div 
          onClick={handleSeek}
          className="h-2 bg-black/10 dark:bg-white/10 rounded-full overflow-hidden cursor-pointer relative"
        >
          <div 
            className="h-full bg-tac-blue transition-all duration-100" 
            style={{ width: `${progress}%` }} 
          />
        </div>
        <div className="flex justify-between items-center mt-1 text-[10px] text-gray-500 dark:text-gray-400 font-bold">
          <span>{formatTime(currentTime)}</span>
          <span>{formatTime(duration)}</span>
        </div>
      </div>
    </div>
  );
};

const MessageBubble: React.FC<{ msg: ChatMessage; isMe: boolean; onReply: () => void; reactions?: Reaction[]; myId?: string; onReact: (emoji: string | null) => void; onHideForMe: () => void }> = ({ msg, isMe, onReply, reactions, myId, onReact, onHideForMe }) => {
  const [showOptions, setShowOptions] = useState(false);
  const [dragOffset, setDragOffset] = useState(0);
  const { profile } = useAuth();
  const isAdmin = profile?.role === 'admin';
  const isPresbytery = profile?.role === 'presbytery';
  const isStaff = isAdmin || isPresbytery;

  const [isDeleting, setIsDeleting] = useState(false);

  // "Delete for everyone": the sender, or an admin (the database allows exactly these two).
  const canDeleteForAll = isMe || isAdmin;

  const handleDelete = async () => {
    if (!canDeleteForAll) return;
    try {
      await chatService.deleteMessage(msg.id);
    } catch (err: any) {
      console.warn('Delete for everyone failed:', err);
      window.alert(err?.message || 'Could not delete the message.');
    }
  };

  // Tap a message to open its menu (Reply / React / Delete) — phones have no hover, and sliding is easy to miss.
  const handleTap = (e: any) => {
    const t = e?.target as HTMLElement | null;
    if (!t || !t.closest) return;
    if (t.closest('[data-chat-overlay], button, a, audio, video, img, input, textarea')) return;
    setShowOptions(true);
  };

  return (
    <>
      <div className={`relative flex w-full ${isMe ? 'justify-end' : 'justify-start'} group mb-1 overflow-visible`}>
        {/* Slide-to-reply indicator revealed when sliding message to the right */}
        <div 
          className={`absolute left-1 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full flex items-center justify-center transition-all duration-100 pointer-events-none z-0 ${
            dragOffset >= 50 
              ? 'bg-tac-blue text-white shadow-md ring-4 ring-tac-blue/20 scale-110' 
              : 'bg-tac-blue/20 text-tac-blue'
          }`}
          style={{
            opacity: Math.min(Math.max(dragOffset / 40, 0), 1),
            transform: `translateY(-50%) scale(${Math.min(0.6 + dragOffset / 100, 1.15)})`
          }}
        >
          <Reply size={16} />
        </div>

        {/* Message Bubble draggable right to reply */}
        <motion.div 
          drag="x"
          dragDirectionLock
          dragConstraints={{ left: 0, right: 0 }}
          dragElastic={{ left: 0, right: 0.6 }}
          onDrag={(_, info) => {
            if (info.offset.x > 0) {
              setDragOffset(info.offset.x);
            } else {
              setDragOffset(0);
            }
          }}
          onDragEnd={(_, info) => {
            if (info.offset.x > 50) {
              onReply();
            }
            setDragOffset(0);
          }}
          onTap={handleTap}
          onContextMenu={(e) => {
            e.preventDefault();
            setShowOptions(true);
          }}
          className={`relative max-w-[85%] lg:max-w-2xl px-2.5 py-1.5 rounded-xl shadow-[0_1px_0.5px_rgba(0,0,0,0.1)] touch-pan-y z-10 ${
            isMe ? 'chat-bubble-mine bg-[#d9fdd3] dark:bg-[#005c4b] rounded-tr-none' : 'chat-bubble-theirs bg-white dark:bg-[#202c33] rounded-tl-none border border-black/5 dark:border-none'
          }`}
        >
          
        {/* Actions on Hover */}
        <div className={`absolute top-0 flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity z-10 ${isMe ? '-left-20' : '-right-20'}`}>
          <button 
            type="button"
            onClick={(e) => { e.stopPropagation(); onReply(); }}
            className="p-1.5 bg-white/90 dark:bg-slate-800 backdrop-blur rounded-full shadow-lg"
            title="Reply (or slide message to right)"
          >
            <Reply size={16} className="text-gray-500" />
          </button>
          {isMe && (
            <button 
              type="button"
              onClick={(e) => { e.stopPropagation(); setIsDeleting(true); }}
              className="p-1.5 bg-white/90 dark:bg-slate-800 backdrop-blur rounded-full shadow-lg text-tac-red"
              title="Delete message"
            >
              <Trash2 size={16} />
            </button>
          )}
        </div>

        {/* Delete Confirmation Overlay */}
        <AnimatePresence>
          {isDeleting && (
            <div 
              data-chat-overlay="true"
              className="fixed inset-0 z-[160] flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm"
              onClick={() => setIsDeleting(false)}
            >
              <motion.div 
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.9, opacity: 0 }}
                className="bg-white dark:bg-slate-900 rounded-[2.5rem] p-8 shadow-2xl max-w-sm w-full border border-gray-100 dark:border-white/10"
                onClick={e => e.stopPropagation()}
              >
                 <div className="w-16 h-16 bg-red-50 dark:bg-red-500/10 text-tac-red rounded-full flex items-center justify-center mx-auto mb-6">
                    <Trash2 size={32} />
                 </div>
                 <h3 className="text-xl font-black text-tac-blue-dark dark:text-white uppercase tracking-widest text-center mb-2">Delete message?</h3>
                 <p className="text-sm text-gray-500 dark:text-gray-400 text-center mb-6 font-medium">
                   {canDeleteForAll
                     ? 'Delete it just for you, or for everyone in the chat?'
                     : 'This removes it from your view only. Other members will still see it.'}
                 </p>
                 <div className="space-y-3">
                    <button
                      onClick={() => { onHideForMe(); setIsDeleting(false); }}
                      className="w-full py-4 bg-gray-100 dark:bg-white/5 text-tac-blue-dark dark:text-white rounded-2xl font-black uppercase text-[11px] tracking-widest hover:bg-gray-200 active:scale-95 transition-all"
                    >
                      Delete for me
                    </button>
                    {canDeleteForAll && (
                      <button
                        onClick={() => { handleDelete(); setIsDeleting(false); }}
                        className="w-full py-4 bg-tac-red text-white rounded-2xl font-black uppercase text-[11px] tracking-widest shadow-lg shadow-tac-red/20 active:scale-95 transition-all"
                      >
                        Delete for everyone
                      </button>
                    )}
                    <button
                      onClick={() => setIsDeleting(false)}
                      className="w-full py-3 text-gray-400 rounded-2xl font-bold uppercase text-[10px] tracking-widest hover:text-gray-600 transition-all"
                    >
                      Cancel
                    </button>
                 </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>

        {/* Right-Click / Long-Press Options Overlay */}
        <AnimatePresence>
          {showOptions && !isDeleting && (
            <div 
              data-chat-overlay="true"
              className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/20"
              onClick={() => setShowOptions(false)}
            >
              <motion.div 
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.9, opacity: 0 }}
                className="bg-white dark:bg-slate-900 rounded-3xl p-2 shadow-2xl min-w-[160px] border border-gray-100 dark:border-white/10"
                onClick={e => e.stopPropagation()}
              >
                <ReactionPicker mine={reactions?.find((r) => r.userId === myId)?.emoji} onPick={(e) => { onReact(e); setShowOptions(false); }} />
                <button 
                  onClick={() => { onReply(); setShowOptions(false); }}
                  className="w-full flex items-center gap-3 px-4 py-3 hover:bg-gray-50 dark:hover:bg-white/5 rounded-2xl transition-all"
                >
                  <Reply size={18} className="text-tac-blue" />
                  <span className="text-sm font-black text-tac-blue-dark dark:text-white">Reply Message</span>
                </button>
                {(
                  <button 
                    onClick={() => { setIsDeleting(true); setShowOptions(false); }}
                    className="w-full flex items-center gap-3 px-4 py-3 hover:bg-red-50 dark:hover:bg-red-900/10 rounded-2xl transition-all text-tac-red"
                  >
                    <Trash2 size={18} />
                    <span className="text-sm font-black">Delete Message</span>
                  </button>
                )}
                <button 
                  onClick={() => setShowOptions(false)}
                  className="w-full flex items-center gap-3 px-4 py-3 hover:bg-gray-50 dark:hover:bg-white/5 rounded-2xl transition-all text-gray-400"
                >
                  <X size={18} />
                  <span className="text-sm font-bold">Cancel</span>
                </button>
              </motion.div>
            </div>
          )}
        </AnimatePresence>

      {!isMe && (
        <p className={`text-[11px] font-black mb-0.5 opacity-90 ${msg.senderColor?.replace('bg-', 'text-') || 'text-tac-blue'}`}>{msg.senderName}</p>
      )}

      {msg.replyTo && (msg.replyTo.text || msg.replyTo.img || msg.replyTo.vid || msg.replyTo.sender) && (
        <div className={`mb-1.5 px-2.5 py-1.5 rounded-lg text-xs border-l-4 border-emerald-600 overflow-hidden ${isMe ? 'bg-black/[0.07] dark:bg-black/25' : 'bg-black/[0.05] dark:bg-white/10'}`}>
          <p className="font-bold text-emerald-700 dark:text-emerald-400 mb-0.5 text-left truncate">{msg.replyTo.sender}</p>
          <p className="opacity-70 line-clamp-2 leading-tight text-left dark:text-white/70">{msg.replyTo.text || (msg.replyTo.img ? 'Photo' : msg.replyTo.vid ? 'Video' : '')}</p>
        </div>
      )}

      {msg.img && (
        <div 
          className="mb-2 rounded-lg overflow-hidden border border-black/5 bg-white cursor-pointer"
          onClick={e => e.stopPropagation()}
        >
           <img src={msg.img} alt="Chat media" className="w-full max-h-80 object-cover" />
        </div>
      )}

      {msg.file && (
        <div className="mb-2" onClick={e => e.stopPropagation()}>
           <a 
            href={msg.file} 
            download={msg.text?.split(':').pop()?.trim() || 'file'}
            target="_blank" 
            rel="noreferrer"
            className="flex items-center gap-3 p-3 bg-white/50 backdrop-blur rounded-lg border border-black/5 hover:bg-white transition-all group/file"
          >
            <div className="w-10 h-10 bg-tac-blue-dark/5 text-tac-blue-dark rounded-full flex items-center justify-center shrink-0 group-hover/file:bg-tac-blue-dark group-hover/file:text-white transition-all">
              <File size={20} />
            </div>
            <div className="min-w-0 flex-1">
              <p className="text-[10px] font-black uppercase text-tac-blue-dark tracking-widest truncate">Document Shared</p>
              <p className="text-[11px] text-gray-500 font-medium truncate italic">{msg.text?.split(':').pop()?.trim() || 'View File'}</p>
            </div>
          </a>
        </div>
      )}

      {msg.vid && (
        <div 
          className="mb-2 rounded-lg overflow-hidden border border-black/5 bg-black"
          onClick={e => e.stopPropagation()}
          onPointerDown={e => e.stopPropagation()}
        >
          <video 
            src={msg.vid} 
            controls 
            className="w-full max-h-80 object-contain" 
            onError={(e) => {
              (e.currentTarget as HTMLVideoElement).style.display = 'none';
            }}
          />
        </div>
      )}

      {msg.audio && (
        <ChatAudioPlayer src={msg.audio} />
      )}

      {msg.location && (
        <a 
          href={msg.location} 
          target="_blank" 
          rel="noreferrer"
          onClick={e => e.stopPropagation()}
          className="mb-2 block p-3 bg-white rounded-lg border border-black/5 hover:bg-gray-50 transition-all"
        >
          <div className="flex items-center gap-3">
             <div className="w-10 h-10 bg-tac-red/10 text-tac-red rounded-full flex items-center justify-center">
               <MapPin size={20} />
             </div>
             <div>
               <p className="text-[10px] font-black uppercase text-tac-red tracking-widest">Shared Location</p>
               <p className="text-[11px] text-gray-500 font-medium">Click to view on Map</p>
             </div>
          </div>
        </a>
      )}

      {/* Message Content & Timestamp (Inline/Flex layout prevents any text collision or overlap) */}
      <div className="flex flex-wrap items-end justify-between gap-x-2.5 gap-y-1 text-left min-w-[70px] pt-0.5">
        {msg.text && !isAutoCaption(msg.text) && !msg.file && (
          <div className="chat-msg-text text-[#111b21] dark:text-slate-100 break-words whitespace-pre-wrap flex-1 min-w-[60px]">
            {msg.text}
          </div>
        )}
        <div className="ml-auto shrink-0 flex items-center gap-1 select-none self-end pb-0.5 pl-1">
          <span className="text-[10px] text-[#667781] dark:text-slate-400 font-medium leading-none">{msg.time}</span>
          {isMe && (() => {
            // "Delivered/read by at least one other person" — waiting for a
            // literal 100% in a large group chat would rarely resolve, so this
            // matches how most large-group chat apps actually behave, not a
            // strict "everyone" requirement.
            const deliveredCount = msg.deliveredTo?.length ?? 1;
            const readCount = msg.readBy?.length ?? 1;
            if (readCount > 1) {
              return <CheckCheck size={14} className="text-[#53bdeb] shrink-0" />; // read — blue double tick
            }
            if (deliveredCount > 1) {
              return <CheckCheck size={14} className="text-[#667781] dark:text-slate-400 shrink-0" />; // delivered — gray double tick
            }
            return <Check size={14} className="text-[#667781] dark:text-slate-400 shrink-0" />; // sent only — single gray tick
          })()}
          <button 
            type="button"
            onClick={(e) => { e.stopPropagation(); setShowOptions(true); }}
            className="p-0.5 text-gray-400 hover:text-gray-600 dark:hover:text-white transition-colors"
            title="More options"
          >
            <MoreVertical size={11} />
          </button>
        </div>
      </div>
      <ReactionChips reactions={reactions} myId={myId} onReact={onReact} />
    </motion.div>
    </div>
    </>
  );
};

const AttachBtn: React.FC<{ onClick: () => void; icon: React.ReactNode; label: string; color: string }> = ({ onClick, icon, label, color }) => (
  <button 
    onClick={onClick}
    className="flex flex-col items-center gap-3 group p-2 rounded-2xl transition-all hover:bg-gray-50"
  >
    <div className={`w-16 h-16 rounded-full flex items-center justify-center text-white shadow-xl transition-all group-hover:scale-110 group-active:scale-90 ${color}`}>
      {icon}
    </div>
    <span className="text-[11px] font-black uppercase text-gray-500 tracking-wider">{label}</span>
  </button>
);

export default ChatView;
