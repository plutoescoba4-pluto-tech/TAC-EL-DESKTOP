import { FEATURES } from '../../lib/features';
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import { 
  BookOpen, 
  Plus, 
  Trash2, 
  ExternalLink, 
  Search, 
  Filter,
  Heart,
  MessageCircle,
  Share2,
  Clock,
  User,
  MoreVertical,
  X,
  Check,
  Zap
} from 'lucide-react';
import { buildInChristService } from '../../services/pendingSchemaServices';
import { useAuth } from '../../context/AuthContext';
import { handleFirestoreError, OperationType } from '../../lib/firestore-errors';

interface BuildContent {
  id: string;
  title: string;
  category: 'Article' | 'Devotional' | 'Doctrine' | 'Foundation';
  body: string;
  author: string;
  authorId: string;
  likes: number;
  comments: number;
  createdAt: any;
  externalUrl?: string;
  color?: string;
}

const CATEGORIES = ['All', 'Article', 'Devotional', 'Doctrine', 'Foundation'];

const BuildInChristView: React.FC = () => {
  const { user, profile } = useAuth();
  const navigate = useNavigate();
  const [content, setContent] = useState<BuildContent[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('All');
  const [searchTerm, setSearchTerm] = useState('');
  const [isAdding, setIsAdding] = useState(false);
  
  // Form State
  const [newContent, setNewContent] = useState({
    title: '',
    category: 'Article' as BuildContent['category'],
    body: '',
    externalUrl: '',
    color: 'bg-tac-blue'
  });

  const isStaff = profile?.role === 'admin' || profile?.role === 'presbytery';

  useEffect(() => {
    const fetchData = async () => {
      try {
        setContent(await buildInChristService.getAll() as any);
      } catch (err: any) {
        handleFirestoreError(err, OperationType.LIST, 'buildInChrist');
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  const handleAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !profile) return;
    
    try {
      await buildInChristService.add({
        ...newContent,
        authorName: profile.name,
        authorId: user.id,
        likes: 0,
        comments: 0,
      } as any);
      setIsAdding(false);
      setNewContent({
        title: '',
        category: 'Article',
        body: '',
        externalUrl: '',
        color: 'bg-tac-blue'
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, 'buildInChrist');
    }
  };

  const handleDelete = async (id: string) => {
    if (!window.confirm('Remove this spiritual resource?')) return;
    try {
      await buildInChristService.remove(id);
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `buildInChrist/${id}`);
    }
  };

  const filtered = content.filter(item => {
    const matchesFilter = filter === 'All' || item.category === filter;
    const matchesSearch = item.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
                         item.body.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesFilter && matchesSearch;
  });

  return (
    <div className="min-h-[calc(100dvh-64px)] bg-gray-50 dark:bg-slate-950 p-4 lg:p-8">
      <div className="max-w-6xl mx-auto space-y-8">
        
        {/* Header Section */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
          <div className="space-y-2">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-tac-blue/10 rounded-2xl flex items-center justify-center text-tac-blue">
                <BookOpen size={28} />
              </div>
              <h1 className="text-3xl font-black text-tac-blue-dark dark:text-white uppercase tracking-tighter">Build In Christ</h1>
            </div>
            <p className="text-gray-500 dark:text-gray-400 font-medium max-w-xl">
              Equipping the saints for the work of ministry and for building up the body of Christ.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            {FEATURES.bible && <button 
              onClick={() => navigate('/dashboard/bible')}
              className="flex items-center gap-2 px-6 py-3 bg-tac-blue/5 text-tac-blue border border-tac-blue/20 rounded-2xl font-black uppercase tracking-widest text-[10px] hover:bg-tac-blue hover:text-white transition-all shadow-sm"
            >
              <BookOpen size={16} />
              Bible Reader
            </button>}
            <div className="relative">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
              <input 
                type="text" 
                placeholder="Search word..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-12 pr-4 py-3 bg-white dark:bg-white/5 border border-[var(--Bdr)] rounded-2xl w-64 outline-none focus:ring-4 focus:ring-tac-blue/5 transition-all text-sm"
              />
            </div>
            {isStaff && (
              <button 
                onClick={() => setIsAdding(true)}
                className="flex items-center gap-2 px-6 py-3 bg-tac-blue text-white rounded-2xl font-black uppercase tracking-widest text-xs shadow-xl shadow-tac-blue/20 hover:scale-[1.02] active:scale-95 transition-all"
              >
                <Plus size={18} />
                New Word
              </button>
            )}
          </div>
        </div>

        {/* Integration Hint */}
        {FEATURES.bible && <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="p-6 bg-gradient-to-r from-tac-blue to-tac-blue-dark rounded-[2rem] text-white flex flex-col md:flex-row items-center justify-between gap-6 shadow-2xl relative overflow-hidden group"
        >
           <div className="absolute top-0 right-0 w-64 h-64 bg-white/5 rounded-full -translate-y-1/2 translate-x-1/2 blur-3xl group-hover:scale-125 transition-transform duration-1000" />
           <div className="relative z-10 flex items-center gap-6">
              <div className="w-16 h-16 bg-white/10 backdrop-blur-md rounded-[1.5rem] flex items-center justify-center text-tac-gold animate-bounce">
                 <Zap size={32} />
              </div>
              <div>
                 <h2 className="text-xl font-black uppercase tracking-widest mb-1">Spirit-Led Study</h2>
                 <p className="text-sm text-white/70 font-medium max-w-md">Click the floating circle <BookOpen size={14} className="inline mx-1" /> to access the Holy Bible and Seek AI while exploring these resources.</p>
              </div>
           </div>
           <button 
             onClick={() => navigate('/dashboard/bible')}
             className="relative z-10 px-8 py-4 bg-white text-tac-blue-dark rounded-2xl font-black uppercase tracking-widest text-[10px] hover:scale-105 active:scale-95 transition-all shadow-xl"
           >
              Open Full Bible
           </button>
        </motion.div>}

        {/* Filter Bar */}
        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pb-2">
          {CATEGORIES.map((cat) => (
            <button
              key={cat}
              onClick={() => setFilter(cat)}
              className={`px-6 py-2.5 rounded-full text-[10px] font-black uppercase tracking-widest transition-all shrink-0 ${
                filter === cat 
                ? 'bg-tac-blue text-white shadow-lg shadow-tac-blue/20' 
                : 'bg-white dark:bg-white/5 text-gray-500 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-white/10'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Content Grid */}
        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1,2,3].map(i => (
              <div key={i} className="h-64 bg-white dark:bg-slate-900 rounded-[2.5rem] animate-pulse border border-[var(--Bdr)]" />
            ))}
          </div>
        ) : filtered.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filtered.map((item, idx) => (
              <ContentCard key={item.id} item={item} index={idx} isStaff={isStaff} onDelete={() => handleDelete(item.id)} />
            ))}
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center py-20 text-center space-y-4">
            <div className="w-16 h-16 bg-gray-100 dark:bg-white/5 rounded-full flex items-center justify-center text-gray-400">
              <BookOpen size={32} />
            </div>
            <div>
              <p className="text-tac-blue-dark dark:text-white font-black uppercase tracking-widest">No resources found</p>
              <p className="text-sm text-gray-500">More spiritual content coming soon.</p>
            </div>
          </div>
        )}
      </div>

      {/* Add Modal */}
      <AnimatePresence>
        {isAdding && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
              onClick={() => setIsAdding(false)}
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative bg-white dark:bg-slate-900 w-full max-w-xl rounded-[2.5rem] overflow-hidden border border-[var(--Bdr)] shadow-2xl"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="p-8">
                <div className="flex items-center justify-between mb-8">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-tac-blue/10 text-tac-blue rounded-xl flex items-center justify-center">
                      <Plus size={20} />
                    </div>
                    <div>
                      <h2 className="text-xl font-black text-tac-blue-dark dark:text-white uppercase tracking-tight">Add Spiritual Content</h2>
                      <p className="text-xs text-gray-500 font-medium uppercase tracking-widest">Foundation for the saints</p>
                    </div>
                  </div>
                  <button onClick={() => setIsAdding(false)} className="p-2 hover:bg-gray-100 dark:hover:bg-white/5 rounded-full">
                    <X size={20} />
                  </button>
                </div>

                <form onSubmit={handleAdd} className="space-y-6">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <label className="text-[10px] font-black uppercase text-gray-400 tracking-widest pl-1">Category</label>
                      <select 
                        required
                        value={newContent.category}
                        onChange={(e) => setNewContent({...newContent, category: e.target.value as any})}
                        className="w-full bg-gray-50 dark:bg-white/5 border border-gray-100 dark:border-white/5 rounded-2xl p-4 outline-none focus:ring-4 focus:ring-tac-blue/5 font-black uppercase text-xs"
                      >
                        {CATEGORIES.slice(1).map(c => <option key={c} value={c}>{c}</option>)}
                      </select>
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] font-black uppercase text-gray-400 tracking-widest pl-1">Theme Color</label>
                      <div className="flex gap-2">
                        {['bg-tac-blue', 'bg-tac-red', 'bg-purple-600', 'bg-green-600'].map(c => (
                          <button 
                            key={c}
                            type="button"
                            onClick={() => setNewContent({...newContent, color: c})}
                            className={`w-10 h-10 rounded-full transition-all ${c} ${newContent.color === c ? 'ring-4 ring-offset-2 ring-tac-blue scale-110' : 'opacity-60'}`}
                          />
                        ))}
                      </div>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label className="text-[10px] font-black uppercase text-gray-400 tracking-widest pl-1">Title</label>
                    <input 
                      required
                      type="text"
                      value={newContent.title}
                      onChange={(e) => setNewContent({...newContent, title: e.target.value})}
                      placeholder="Title of the word..."
                      className="w-full bg-gray-50 dark:bg-white/5 border border-gray-100 dark:border-white/5 rounded-2xl p-4 outline-none focus:ring-4 focus:ring-tac-blue/5 transition-all"
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="text-[10px] font-black uppercase text-gray-400 tracking-widest pl-1">Body Text</label>
                    <textarea 
                      required
                      rows={4}
                      value={newContent.body}
                      onChange={(e) => setNewContent({...newContent, body: e.target.value})}
                      placeholder="Write the spiritual content here..."
                      className="w-full bg-gray-50 dark:bg-white/5 border border-gray-100 dark:border-white/5 rounded-2xl p-4 outline-none focus:ring-4 focus:ring-tac-blue/5 resize-none transition-all"
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="text-[10px] font-black uppercase text-gray-400 tracking-widest pl-1">External Link (Optional)</label>
                    <input 
                      type="url"
                      value={newContent.externalUrl}
                      onChange={(e) => setNewContent({...newContent, externalUrl: e.target.value})}
                      placeholder="https://..."
                      className="w-full bg-gray-50 dark:bg-white/5 border border-gray-100 dark:border-white/5 rounded-2xl p-4 outline-none focus:ring-4 focus:ring-tac-blue/5 transition-all"
                    />
                  </div>

                  <div className="pt-4">
                    <button 
                      type="submit"
                      className="w-full py-4 bg-tac-blue text-white rounded-2xl font-black uppercase tracking-widest shadow-xl shadow-tac-blue/20 active:scale-95 transition-all"
                    >
                      Publish to Library
                    </button>
                  </div>
                </form>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};

const ContentCard: React.FC<{ item: BuildContent; index: number; isStaff: boolean; onDelete: () => void }> = ({ item, index, isStaff, onDelete }) => (
  <motion.div 
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ delay: index * 0.05 }}
    className="bg-white dark:bg-slate-900 rounded-[2.5rem] border border-[var(--Bdr)] overflow-hidden flex flex-col group hover:shadow-2xl hover:shadow-tac-blue/5 transition-all duration-500"
  >
    <div className={`p-8 ${item.color || 'bg-tac-blue'} relative overflow-hidden shrink-0`}>
       <div className="absolute top-4 right-4 flex items-center gap-2">
          <span className="px-3 py-1 bg-white/20 backdrop-blur-md rounded-full text-[8px] font-black uppercase text-white tracking-widest">
            {item.category}
          </span>
       </div>
       <BookOpen className="text-white/20 absolute -bottom-4 -left-4" size={120} />
       <div className="relative z-10 space-y-4">
          <h3 className="text-xl font-black text-white leading-tight">{item.title}</h3>
          <div className="flex items-center gap-2 text-white/60">
             <User size={12} />
             <span className="text-[10px] font-bold uppercase tracking-widest">{item.authorName}</span>
          </div>
       </div>
    </div>
    
    <div className="p-8 flex-1 flex flex-col justify-between space-y-6">
       <p className="text-gray-600 dark:text-gray-400 text-sm line-clamp-4 leading-relaxed font-medium">
         {item.body}
       </p>
       
       <div className="flex items-center justify-between pt-6 border-t border-gray-50 dark:border-white/5">
          <div className="flex items-center gap-4">
             <div className="flex items-center gap-1.5 text-gray-400 group/stat">
                <Heart size={16} className="group-hover/stat:text-tac-red transition-colors" />
                <span className="text-xs font-black">{item.likes}</span>
             </div>
             <div className="flex items-center gap-1.5 text-gray-400">
                <MessageCircle size={16} />
                <span className="text-xs font-black">{item.comments}</span>
             </div>
          </div>
          
          <div className="flex items-center gap-2">
             {item.externalUrl && (
               <a 
                 href={item.externalUrl} 
                 target="_blank" 
                 className="p-2.5 bg-gray-50 dark:bg-white/5 text-tac-blue rounded-xl hover:bg-tac-blue hover:text-white transition-all shadow-sm"
               >
                 <ExternalLink size={16} />
               </a>
             )}
             {isStaff && (
               <button 
                 onClick={onDelete}
                 className="p-2.5 bg-red-50 dark:bg-red-500/10 text-tac-red rounded-xl hover:bg-tac-red hover:text-white transition-all shadow-sm"
               >
                 <Trash2 size={16} />
               </button>
             )}
          </div>
       </div>
    </div>
  </motion.div>
);

export default BuildInChristView;
