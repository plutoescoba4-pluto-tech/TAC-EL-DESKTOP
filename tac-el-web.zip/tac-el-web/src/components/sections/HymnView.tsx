import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Music4, Search, Book, Plus, X, Save, Trash2, Edit2 } from 'lucide-react';
import { hymnsService } from '../../services/contentService';
import { useAuth } from '../../context/AuthContext';
import { Hymn, HymnSection } from '../../types';
import { HymnSectionsEditor, HymnSectionsView } from '../shared/HymnSections';
import { handleFirestoreError, OperationType } from '../../lib/firestore-errors';

const HymnView: React.FC = () => {
  const { profile } = useAuth();
  const [search, setSearch] = useState('');
  const [hymns, setHymns] = useState<Hymn[]>([]);
  const [loading, setLoading] = useState(true);
  const [isAdding, setIsAdding] = useState(false);
  const [editingHymn, setEditingHymn] = useState<Hymn | null>(null);
  
  const emptyForm: Partial<Hymn> = { number: 0, title: '', sections: [], category: 'Worship' };
  const [form, setForm] = useState<Partial<Hymn>>(emptyForm);
  const [formError, setFormError] = useState<string | null>(null);

  // Only the admin edits hymns. Presbytery and members read them.
  const isAdmin = profile?.role === 'admin';

  const fetchHymns = async () => {
    try {
      setHymns(await hymnsService.getHymns());
    } catch (error: any) {
      handleFirestoreError(error, OperationType.LIST, 'hymns');
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => { fetchHymns(); }, []);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleaned = (form.sections || []).map((x: HymnSection) => ({ ...x, text: x.text.trim() })).filter((x: HymnSection) => x.text);
    if (!cleaned.length) { setFormError('Add at least one verse or chorus (paste the hymn, then split it).'); return; }
    setFormError(null);
    try {
      const data = { ...form, sections: cleaned };
      if (editingHymn) await hymnsService.updateHymn(editingHymn.id, data);
      else await hymnsService.addHymn(data as any);
      setIsAdding(false);
      setEditingHymn(null);
      setForm(emptyForm);
      await fetchHymns(); // the list used to stay out of date until the page was reloaded
    } catch (err: any) {
      setFormError(err?.message || 'Could not save the hymn.');
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this hymn?')) return;
    try {
      await hymnsService.deleteHymn(id);
      await fetchHymns();
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `hymns/${id}`);
    }
  };

  const filteredHymns = hymns.filter(h => 
    h.title.toLowerCase().includes(search.toLowerCase()) || 
    h.number.toString().includes(search)
  );

  return (
    <div className="p-4 lg:p-8 max-w-5xl mx-auto space-y-8">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
           <div className="flex items-center gap-3">
             <h2 className="text-3xl font-black font-serif text-tac-blue-dark dark:text-white">Church Hymnal</h2>
             {isAdmin && (
               <button 
                 onClick={() => setIsAdding(true)} 
                 className="p-2 bg-tac-blue text-white rounded-xl shadow-lg hover:rotate-90 transition-transform"
               >
                 <Plus size={20} />
               </button>
             )}
           </div>
           <p className="text-[var(--Sub)] font-medium">Digital library of {hymns.length} assembly hymns.</p>
        </div>
        <div className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-tac-blue/30" size={18} />
          <input 
            type="text" 
            placeholder="Search by number or title..." 
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-12 pr-6 py-3 bg-white dark:bg-slate-800 border border-[var(--Bdr)] rounded-2xl w-full md:w-80 outline-none focus:ring-2 focus:ring-tac-blue/5 dark:text-white"
          />
        </div>
      </header>

      {/* Add / Edit Form */}
      <AnimatePresence>
        {(isAdding || editingHymn) && (
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="bg-tac-blue-dark p-6 lg:p-8 rounded-[2.5rem] text-white space-y-6 shadow-2xl"
          >
             <div className="flex items-center justify-between">
                <h3 className="text-xl font-black">{editingHymn ? 'Edit Hymn' : 'Add New Hymn'}</h3>
                <button 
                  onClick={() => { setIsAdding(false); setEditingHymn(null); }} 
                  className="p-2 hover:bg-white/10 rounded-full"
                >
                  <X size={20} />
                </button>
             </div>

             <form onSubmit={handleSave} className="space-y-4">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                   <div className="space-y-1">
                      <label className="text-[10px] font-black uppercase tracking-widest text-white/40">Hymn No.</label>
                      <input 
                         type="number"
                         required
                         value={form.number}
                         onChange={e => setForm({...form, number: parseInt(e.target.value)})}
                         className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 outline-none focus:border-white/30"
                      />
                   </div>
                   <div className="md:col-span-2 space-y-1">
                      <label className="text-[10px] font-black uppercase tracking-widest text-white/40">Title</label>
                      <input 
                         type="text"
                         required
                         value={form.title}
                         onChange={e => setForm({...form, title: e.target.value})}
                         className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 outline-none focus:border-white/30"
                         placeholder="Hymn Name"
                      />
                   </div>
                   <div className="space-y-1">
                      <label className="text-[10px] font-black uppercase tracking-widest text-white/40">Category</label>
                      <select 
                         value={form.category}
                         onChange={e => setForm({...form, category: e.target.value})}
                         className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 outline-none focus:border-white/30"
                      >
                         <option value="Worship">Worship</option>
                         <option value="Praise">Praise</option>
                         <option value="Youth">Youth</option>
                         <option value="Communion">Communion</option>
                         <option value="Revival">Revival</option>
                      </select>
                   </div>
                </div>

                <HymnSectionsEditor tone="dark" sections={form.sections || []} onChange={(sections) => setForm({ ...form, sections })} />
                {formError && <p className="text-sm text-red-300">{formError}</p>}

                <button type="submit" className="w-full h-14 bg-white text-tac-blue-dark rounded-xl font-black uppercase tracking-widest flex items-center justify-center gap-2 hover:scale-[1.01] active:scale-95 transition-all">
                   <Save size={18} />
                   {editingHymn ? 'Update Hymn' : 'Add to Hymnal'}
                </button>
             </form>
          </motion.div>
        )}
      </AnimatePresence>

      {loading ? (
        <div className="flex flex-col items-center justify-center py-24 space-y-4">
           <div className="w-12 h-12 border-4 border-tac-blue/10 border-t-tac-blue rounded-full animate-spin" />
           <p className="text-xs font-black uppercase tracking-widest text-tac-blue/40">Opening Hymn Books...</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-4">
          {filteredHymns.map(hymn => (
            <details key={hymn.id} className="group bg-white dark:bg-slate-900 border border-[var(--Bdr)] rounded-3xl overflow-hidden shadow-sm transition-all hover:shadow-md">
              <summary className="p-6 flex items-center justify-between cursor-pointer list-none">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-tac-blue/5 dark:bg-tac-blue/20 text-tac-blue dark:text-tac-blue-light rounded-xl flex items-center justify-center font-black text-lg">
                    {hymn.number}
                  </div>
                  <div>
                    <h3 className="font-black text-tac-blue-dark dark:text-white">{hymn.title}</h3>
                    <span className="text-[10px] font-bold uppercase tracking-widest text-tac-blue/40 dark:text-white/40">{hymn.category}</span>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                   {isAdmin && (
                     <div className="flex items-center gap-2 mr-4">
                        <button 
                          onClick={(e) => { e.preventDefault(); setEditingHymn(hymn); setForm(hymn); }} 
                          className="p-2 text-gray-300 dark:text-gray-600 hover:text-tac-blue transition-colors"
                        >
                           <Edit2 size={16} />
                        </button>
                        <button 
                          onClick={(e) => { e.preventDefault(); handleDelete(hymn.id); }} 
                          className="p-2 text-gray-300 dark:text-gray-600 hover:text-tac-red transition-colors"
                        >
                           <Trash2 size={16} />
                        </button>
                     </div>
                   )}
                   <Book className="text-tac-blue/20 group-open:rotate-180 transition-transform" />
                </div>
              </summary>
              <div className="px-6 pb-8 space-y-6 pt-2 border-t border-gray-50 dark:border-white/5">
                 <HymnSectionsView sections={hymn.sections} />
              </div>
            </details>
          ))}
          {filteredHymns.length === 0 && (
            <div className="text-center py-24 bg-white dark:bg-slate-900 rounded-[2.5rem] border border-dashed border-gray-200 dark:border-white/10">
               <Music4 size={48} className="mx-auto text-gray-200 dark:text-white/10 mb-4" />
               <p className="text-[var(--Sub)] font-medium">No hymns found matching your search.</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default HymnView;
