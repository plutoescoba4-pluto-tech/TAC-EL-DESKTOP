import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Users, 
  Search, 
  MessageSquare,
  ChevronRight,
  Filter,
  Zap,
  Shield,
  Crown,
  Activity
} from 'lucide-react';
import { membersService } from '../../services/membersService';
import { useAuth } from '../../context/AuthContext';
import { useNavigate } from 'react-router-dom';
import { handleFirestoreError, OperationType } from '../../lib/firestore-errors';
import { UserProfile } from '../../types';
import { useChatUnread } from '../../lib/chatUnread';
import { lastSeenLabel } from '../../lib/presenceStatus';

const NetworkView: React.FC = () => {
  const { user, profile } = useAuth();
  const navigate = useNavigate();
  const [members, setMembers] = useState<UserProfile[]>([]);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<'all' | 'online' | 'presbytery' | 'admin'>('all');

  useEffect(() => {
    const fetchUsers = async () => {
      try {
        setMembers(await membersService.getAllMembers());
      } catch (error: any) {
        handleFirestoreError(error, OperationType.LIST, 'users');
      } finally {
        setLoading(false);
      }
    };
    fetchUsers();
  }, []);

  const filteredMembers = members.filter(m => {
    // Hide myself
    if (m.uid === user?.id) return false;
    // Hide people with no names
    if (!m.name) return false;

    const matchesSearch = (
      m.name.toLowerCase().includes(search.toLowerCase()) || 
      m.email?.toLowerCase().includes(search.toLowerCase())
    );

    const matchesFilter = 
      filter === 'all' ? true :
      filter === 'online' ? m.online :
      filter === 'presbytery' ? m.role === 'presbytery' :
      filter === 'admin' ? m.role === 'admin' : true;

    return matchesSearch && matchesFilter;
  });

  const chatUnread = useChatUnread();

  const startPrivateChat = (otherUid: string) => {
    if (!user) return;
    const ids = [user.id, otherUid].sort();
    const dmId = `${ids[0]}_${ids[1]}`;
    navigate(`/dashboard/chat/direct/${dmId}`);
  };

  return (
    <div className="p-4 lg:p-8 max-w-7xl mx-auto space-y-8 min-h-dvh pb-20">
      {/* Top Network Header Bar - Styled like Church Chat Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 bg-white dark:bg-slate-900 rounded-3xl border border-[var(--Bdr)] shadow-md">
         <div className="flex items-center gap-3">
            <div className="w-11 h-11 bg-tac-blue text-white rounded-2xl flex items-center justify-center font-black shadow-lg shadow-tac-blue/20 shrink-0">
               <Zap size={22} fill="currentColor" />
            </div>
            <div>
               <h3 className="text-base font-black text-tac-blue-dark dark:text-white leading-tight">Presbytery Network</h3>
               <div className="text-[10px] text-green-600 dark:text-green-400 font-bold flex items-center gap-1.5 mt-0.5">
                 <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
                 Connected Online ({members.filter(m => m.online).length} Members Active)
               </div>
            </div>
         </div>

         <div className="relative group min-w-[240px]">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 group-focus-within:text-tac-blue transition-colors" size={18} />
            <input 
              type="text" 
              placeholder="Search members..." 
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-11 pr-4 py-2.5 bg-gray-50 dark:bg-slate-800 border border-gray-100 dark:border-white/10 rounded-2xl text-xs font-bold text-tac-blue-dark dark:text-white outline-none focus:ring-2 focus:ring-tac-blue/20 transition-all"
            />
         </div>
      </div>

      {/* Network Filters Section */}
      <div className="flex overflow-x-auto gap-2 pb-2 scrollbar-none">
        <FilterTag active={filter === 'all'} label="All Members" onClick={() => setFilter('all')} icon={<Users size={14} />} />
        <FilterTag active={filter === 'online'} label="Online Now" onClick={() => setFilter('online')} icon={<div className="w-2 h-2 bg-green-500 rounded-full" />} />
        <FilterTag active={filter === 'presbytery'} label="Presbytery" onClick={() => setFilter('presbytery')} icon={<Crown size={14} />} />
        <FilterTag active={filter === 'admin'} label="Administrators" onClick={() => setFilter('admin')} icon={<Shield size={14} />} />
      </div>

      {loading ? (
        <div className="flex flex-col items-center justify-center py-24 space-y-4">
           <div className="w-12 h-12 border-4 border-tac-blue/10 border-t-tac-blue rounded-full animate-spin" />
           <p className="text-[10px] font-black uppercase tracking-[0.2em] text-tac-blue/40">Syncing Network...</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
           <AnimatePresence mode="popLayout">
             {filteredMembers.map((member, idx) => (
               <motion.div 
                 key={member.uid}
                 layout
                 initial={{ opacity: 0, y: 20 }}
                 animate={{ opacity: 1, y: 0 }}
                 exit={{ opacity: 0, scale: 0.95 }}
                 transition={{ delay: idx * 0.03 }}
                 onClick={() => startPrivateChat(member.uid)}
                 className="group bg-white dark:bg-slate-800 rounded-[2rem] p-5 border border-[var(--Bdr)] hover:border-tac-blue/20 hover:shadow-2xl hover:shadow-tac-blue/5 transition-all cursor-pointer relative overflow-hidden"
               >
                  <div className="absolute top-0 right-0 w-24 h-24 bg-tac-blue/5 rounded-full -translate-y-12 translate-x-12 group-hover:scale-150 transition-transform duration-700" />
                  
                  <div className="flex items-center gap-4 relative z-10">
                    <div className="relative">
                      <div className={`w-14 h-14 rounded-2xl shadow-xl flex items-center justify-center text-xl font-black text-white ${member.color || 'bg-tac-blue'}`}>
                        {member.picUrl ? <img src={member.picUrl} className="w-full h-full object-cover rounded-2xl" /> : member.name[0]}
                      </div>
                      {member.online && (
                        <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-green-500 rounded-full border-2 border-white dark:border-slate-800 shadow-sm" />
                      )}
                      {(chatUnread.dmBySender[member.uid] ?? 0) > 0 && (
                        <div className="absolute -top-2 -right-2 min-w-[20px] h-5 px-1.5 bg-tac-red text-white text-[10px] font-black rounded-full flex items-center justify-center shadow-lg">
                          {chatUnread.dmBySender[member.uid]}
                        </div>
                      )}
                    </div>
                    <div>
                        <h4 className="font-black text-tac-blue-dark dark:text-white leading-none mb-1 group-hover:text-tac-blue transition-colors line-clamp-1">{member.name}</h4>
                        <div className="flex items-center gap-2">
                           <span className={`text-[9px] font-black uppercase tracking-widest px-2 py-0.5 rounded-lg ${
                             member.role === 'admin' ? 'bg-tac-red/10 text-tac-red' : 
                             member.role === 'presbytery' ? 'bg-tac-gold/10 text-tac-gold' : 
                             'bg-tac-blue/10 text-tac-blue'
                           }`}>
                             {member.role}
                           </span>
                           {member.role === 'presbytery' && <Crown size={12} className="text-tac-gold" />}
                        </div>
                        <div className="text-[10px] text-gray-400 mt-1">
                          {member.online ? <span className="text-green-600 font-bold">online</span> : lastSeenLabel(member.lastSeen)}
                        </div>
                    </div>
                  </div>

                  <div className="mt-6 flex items-center justify-between relative z-10">
                    <div className="flex -space-x-2">
                       <div className="w-8 h-8 rounded-full bg-gray-50 dark:bg-white/5 border-2 border-white dark:border-slate-800 flex items-center justify-center text-gray-400 group-hover:bg-tac-blue group-hover:text-white transition-all">
                          <MessageSquare size={14} />
                       </div>
                    </div>
                    <button className="flex items-center gap-1.5 text-[10px] font-black uppercase tracking-widest text-tac-blue translate-x-4 opacity-0 group-hover:translate-x-0 group-hover:opacity-100 transition-all duration-300">
                       Chat Now
                       <ChevronRight size={14} />
                    </button>
                  </div>
               </motion.div>
             ))}
           </AnimatePresence>

           {filteredMembers.length === 0 && (
             <div className="col-span-full py-24 text-center">
                <div className="w-16 h-16 bg-gray-50 dark:bg-white/5 rounded-full flex items-center justify-center mx-auto mb-4 text-gray-300">
                   <Users size={32} />
                </div>
                <h3 className="text-lg font-black text-tac-blue-dark dark:text-white">No members found</h3>
                <p className="text-sm text-gray-400">Try adjusting your search or filters.</p>
             </div>
           )}
        </div>
      )}
    </div>
  );
};

const FilterTag: React.FC<{ active: boolean; label: string; onClick: () => void; icon: React.ReactNode }> = ({ active, label, onClick, icon }) => (
  <button 
    onClick={onClick}
    className={`flex items-center gap-2.5 px-5 py-2.5 rounded-full text-[10px] font-black uppercase tracking-widest transition-all whitespace-nowrap border shadow-sm ${
      active 
        ? 'bg-tac-blue-dark text-white border-tac-blue-dark shadow-xl shadow-tac-blue/10 scale-105' 
        : 'bg-white dark:bg-slate-800 text-gray-400 border-[var(--Bdr)] hover:bg-gray-50 dark:hover:bg-white/5'
    }`}
  >
    {icon}
    {label}
  </button>
);

export default NetworkView;
