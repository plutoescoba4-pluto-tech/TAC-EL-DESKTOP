import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Image as ImageIcon, Video, Plus, X, Trash2 } from 'lucide-react';
import { galleryService } from '../../services/contentService';
import { useAuth } from '../../context/AuthContext';
import { GalleryItem } from '../../types';
import { handleFirestoreError, OperationType } from '../../lib/firestore-errors';
import { compressImage } from '../../lib/image-utils';

const GalleryView: React.FC = () => {
  const { profile } = useAuth();
  const [items, setItems] = useState<GalleryItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [uploadError, setUploadError] = useState<string | null>(null);

  useEffect(() => {
    const fetchGallery = async () => {
      try {
        setItems(await galleryService.getGallery());
      } catch (error: any) {
        handleFirestoreError(error, OperationType.LIST, 'gallery');
      } finally {
        setLoading(false);
      }
    };
    fetchGallery();
  }, []);

  const isAdmin = profile?.role === 'admin';
  const isMediaMentor = profile?.teams?.media === 'mentor';
  const canManage = isAdmin || isMediaMentor;

  const handleDelete = async (id: string) => {
    if (!window.confirm('Are you sure you want to remove this from the gallery?')) return;
    try {
      await galleryService.deletePhoto(id);
      setItems((prev) => prev.filter((i) => i.id !== id)); // take it off the screen straight away
    } catch (err: any) {
      console.error('Delete failed:', err);
      window.alert(err?.message || 'Could not delete this photo. Please try again.');
    }
  };

  const handleUpload = () => {
    if (!canManage || uploading) return;
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*,video/*';
    input.onchange = async (e: any) => {
      const file = e.target.files[0];
      if (!file) return;

      setUploadError(null);
      setUploading(true);

      const reader = new FileReader();
      reader.onerror = () => {
        setUploading(false);
        setUploadError('Could not read that file. Please try a different photo or video.');
      };
      reader.onload = async (event) => {
        let result = event.target?.result as string;
        const type = file.type.startsWith('video/') ? 'vid' : 'img';

        if (type === 'vid') {
          // NOTE: gallery_photos (per your schema) only has image_url — no
          // video column yet, so a video upload is blocked here rather than
          // silently saved as a broken "image." See MIGRATION_NOTES.md for
          // how to add real video support.
          setUploading(false);
          setUploadError('Video gallery posts aren\u2019t supported yet \u2014 the database only has a column for photos right now. Please upload a photo, or ask about adding video support.');
          return;
        }

        try {
          if (file.size > 200 * 1024) {
            result = await compressImage(result, 1200, 1200, 0.7);
          }
        } catch (err) {
          console.error('Compression failed:', err);
        }

        try {
          const newId = await galleryService.addPhoto(result, profile?.uid);
          // Show it immediately instead of waiting for a manual refresh.
          setItems((prev) => [{ id: newId, src: result, type: 'img', uploadedBy: profile?.uid, createdAt: new Date().toISOString() }, ...prev]);
        } catch (err: any) {
          handleFirestoreError(err, OperationType.CREATE, 'gallery');
          setUploadError(err?.message || 'Upload failed. Please check your connection and try again.');
        } finally {
          setUploading(false);
        }
      };
      reader.readAsDataURL(file);
    };
    input.click();
  };

  return (
    <div className="p-4 lg:p-8 space-y-8 max-w-6xl mx-auto">
      <header className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl lg:text-3xl font-black font-serif text-tac-blue-dark dark:text-white tracking-tight">Church Gallery</h2>
          <p className="text-[var(--Sub)] font-medium text-sm">Capturing moments of worship and community.</p>
        </div>
        {canManage && (
          <button 
            onClick={handleUpload}
            disabled={uploading}
            className="w-full sm:w-auto flex items-center justify-center gap-2 bg-tac-blue text-white px-6 py-3 rounded-2xl font-black uppercase tracking-widest text-[10px] shadow-xl shadow-tac-blue/20 hover:scale-[1.02] active:scale-95 transition-all disabled:opacity-60 disabled:hover:scale-100"
          >
            {uploading ? (
              <>
                <span className="w-3.5 h-3.5 border-2 border-white/40 border-t-white rounded-full animate-spin" />
                Posting...
              </>
            ) : (
              <>
                <Plus size={16} />
                Post to Gallery
              </>
            )}
          </button>
        )}
      </header>

      {uploadError && (
        <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-900/40 text-red-700 dark:text-red-400 text-sm font-medium rounded-2xl px-4 py-3 flex items-center justify-between gap-3">
          <span>{uploadError}</span>
          <button onClick={() => setUploadError(null)} className="shrink-0 font-black text-xs uppercase opacity-70 hover:opacity-100">Dismiss</button>
        </div>
      )}

      {loading ? (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {[1, 2, 3, 4, 5, 6, 7, 8].map(i => (
            <div key={i} className="aspect-square bg-gray-100 dark:bg-white/5 animate-pulse rounded-2xl" />
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 lg:gap-6">
          <AnimatePresence>
            {items.map((item, index) => (
              <motion.div
                key={item.id}
                layout
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                transition={{ delay: index * 0.05 }}
                className="group relative aspect-square rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition-all cursor-pointer"
              >
                {item.type === 'vid' && item.src ? (
                  <video 
                    src={item.src} 
                    className="w-full h-full object-cover" 
                    onError={(e) => {
                      (e.currentTarget as HTMLVideoElement).style.display = 'none';
                    }}
                  />
                ) : (
                  <img src={item.src || ''} alt="" className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" />
                )}
                
                <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                   {item.type === 'vid' ? <Video className="text-white" size={32} /> : <ImageIcon className="text-white" size={32} />}
                </div>

                {canManage && (
                  <button 
                    onClick={(e) => { e.stopPropagation(); handleDelete(item.id); }}
                    className="absolute top-2 right-2 p-2 bg-red-500 text-white rounded-full opacity-100 md:opacity-0 md:group-hover:opacity-100 transition-opacity shadow-lg hover:bg-red-600 active:scale-95"
                  >
                    <Trash2 size={16} />
                  </button>
                )}
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      )}

      {!loading && items.length === 0 && (
        <div className="card text-center py-20 bg-gray-50/50 dark:bg-slate-900/50 border-dashed border-2 border-[var(--Bdr)]">
           <ImageIcon className="mx-auto text-tac-blue/20 mb-4" size={48} />
           <p className="text-[var(--Sub)] font-medium">The gallery is currently empty.</p>
        </div>
      )}
    </div>
  );
};

export default GalleryView;
