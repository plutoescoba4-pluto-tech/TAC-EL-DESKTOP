import React, { useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { 
  LoginRolePicker, 
  MemberLogin, 
  PresbyteryLogin, 
  AdminLogin, 
  JoinChurch, 
  VerifyPending 
} from './entry';

type AuthView = 'picker' | 'member' | 'presbytery' | 'admin' | 'join' | 'verify';

export const Auth: React.FC = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const [view, setView] = useState<AuthView>(
    location.pathname === '/register' ? 'join' : 'member'
  );

  return (
    <div className="min-h-dvh bg-gray-50 dark:bg-slate-950 flex flex-col justify-center py-12 px-4 sm:px-6 lg:px-8 relative overflow-hidden">
      {/* Background Ambience */}
      <div className="absolute top-0 -left-40 w-96 h-96 bg-tac-blue/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 -right-40 w-96 h-96 bg-tac-red/10 rounded-full blur-3xl pointer-events-none" />

      <div className="relative z-10 w-full max-w-lg mx-auto bg-white/90 dark:bg-slate-900/90 backdrop-blur-xl border border-[var(--Bdr)] rounded-[2.5rem] p-6 sm:p-10 shadow-2xl">
        {view === 'picker' && (
          <LoginRolePicker onSelectRole={(role) => setView(role)} />
        )}
        {view === 'member' && (
          <MemberLogin 
            onBack={() => navigate('/')} 
            onJoinClick={() => setView('join')} 
          />
        )}
        {view === 'presbytery' && (
          <PresbyteryLogin 
            onBack={() => setView('picker')} 
          />
        )}
        {view === 'admin' && (
          <AdminLogin 
            onBack={() => setView('picker')} 
          />
        )}
        {view === 'join' && (
          <JoinChurch 
            onBack={() => setView('member')} 
            onLoginClick={() => setView('member')} 
          />
        )}
        {view === 'verify' && (
          <VerifyPending 
            onBack={() => setView('member')} 
            onLoginClick={() => setView('member')} 
          />
        )}
      </div>

      <div className="text-center mt-6 text-[10px] font-black uppercase tracking-[0.2em] text-[var(--Sub)]">
        The Apostolic Church Ghana · East Legon Assembly
      </div>
    </div>
  );
};

export default Auth;
