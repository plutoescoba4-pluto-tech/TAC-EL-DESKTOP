import React, { useEffect, useState } from 'react';
import { supabase } from '../../supabase';

/**
 * Shown for a moment when the desktop app opens (and right after linking), like WhatsApp's
 * "Loading your chats": it really fetches the first screens' data so the app opens ready.
 */
const CHURCH_LOGO = '/icons/icon-192.png';

export const DesktopLoading: React.FC<{ onDone: () => void }> = ({ onDone }) => {
  const [progress, setProgress] = useState(4);

  useEffect(() => {
    let finished = false;
    const started = Date.now();
    const tasks = [
      supabase.from('chat_messages').select('id').order('created_at', { ascending: false }).limit(60),
      supabase.rpc('my_dm_threads'),
      supabase.from('notifications').select('id').order('created_at', { ascending: false }).limit(30),
      supabase.from('notices').select('id').order('created_at', { ascending: false }).limit(20),
      supabase.from('events').select('id').order('starts_at', { ascending: false }).limit(20),
    ];
    let done = 0;
    tasks.forEach((t) => Promise.resolve(t).catch(() => {}).finally(() => {
      done += 1;
      setProgress(Math.min(96, 8 + Math.round((done / tasks.length) * 88)));
    }));

    const finish = () => {
      if (finished) return;
      finished = true;
      setProgress(100);
      setTimeout(onDone, 350);
    };
    // a short minimum so it does not flash, and a maximum so it can never hang
    Promise.allSettled(tasks).then(() => setTimeout(finish, Math.max(0, 1200 - (Date.now() - started))));
    const cap = setTimeout(finish, 8000);
    return () => clearTimeout(cap);
  }, [onDone]);

  return (
    <div className="min-h-dvh flex flex-col items-center justify-center bg-tac-blue-dark text-white">
      <img src={CHURCH_LOGO} alt="" className="w-24 h-24 rounded-3xl bg-white p-1.5 object-contain shadow-2xl" />
      <h2 className="mt-8 text-xl font-black tracking-wide">Loading your chats</h2>
      <div className="mt-5 h-1.5 w-64 rounded-full bg-white/15 overflow-hidden">
        <div className="h-full bg-white rounded-full transition-all duration-500" style={{ width: `${progress}%` }} />
      </div>
      <p className="mt-4 text-xs text-white/50">TAC-EL for Desktop</p>
    </div>
  );
};

export default DesktopLoading;
