import React, { useEffect, useState } from 'react';
import { ArrowLeft, MonitorSmartphone, MessageCircle, Bell, Music2 } from 'lucide-react';
import { LinkWithPhone } from '../entry/LinkWithPhone';
import { supabase } from '../../supabase';
import { isDesktopApp } from '../../lib/desktop';
import Auth from '../Auth';

/**
 * The first page of the desktop app (before anyone is signed in): a branded welcome with
 * a code to scan with the phone. Like WhatsApp for desktop, with an email sign-in as the other way in.
 * Shown instead of the normal website-style landing page when running inside the desktop app.
 */
const CHURCH_LOGO = '/icons/icon-192.png';

export const DesktopWelcome: React.FC = () => {
  const [useEmail, setUseEmail] = useState(false);
  const [desktopUrl, setDesktopUrl] = useState<string | null>(null);

  // In a browser we also offer the desktop app (the link is saved by the admin in Admin > Website > App links).
  useEffect(() => {
    if (isDesktopApp) return;
    supabase.from('site_settings').select('value').eq('key', 'app_links').maybeSingle().then(({ data }) => setDesktopUrl(data?.value?.desktop_url || null));
  }, []);

  if (useEmail) {
    return (
      <div className="min-h-dvh bg-gray-50 dark:bg-slate-950">
        <div className="max-w-md mx-auto pt-6 px-4">
          <button type="button" onClick={() => setUseEmail(false)} className="flex items-center gap-1.5 text-xs font-black uppercase tracking-widest text-gray-500 hover:text-tac-blue">
            <ArrowLeft size={14} /> Back to phone code
          </button>
        </div>
        <Auth />
      </div>
    );
  }

  return (
    <div className="min-h-dvh flex bg-white dark:bg-slate-950">
      {/* left: brand and the three steps */}
      <div className="hidden md:flex w-[46%] bg-tac-blue-dark text-white p-12 flex-col justify-between">
        <div>
          <img src={CHURCH_LOGO} alt="" className="w-16 h-16 rounded-2xl bg-white p-1 object-contain" />
          <h1 className="text-3xl font-black font-serif mt-8 leading-tight">{isDesktopApp ? 'TAC-EL for Desktop' : 'TAC-EL on your computer'}</h1>
          <p className="text-white/70 mt-2 text-sm">The Apostolic Church Ghana · East Legon Assembly</p>

          <ol className="mt-12 space-y-6">
            {[
              ['1', 'Open TAC-EL on your phone.'],
              ['2', 'Go to Linked Devices and tap Link a device.'],
              ['3', 'Point your phone at the code on this screen.'],
            ].map(([n, text]) => (
              <li key={n} className="flex items-start gap-4">
                <span className="w-8 h-8 rounded-full bg-white/10 border border-white/20 flex items-center justify-center text-sm font-black shrink-0">{n}</span>
                <span className="text-white/90 pt-1">{text}</span>
              </li>
            ))}
          </ol>
        </div>

        <div className="flex gap-6 text-white/60 text-xs">
          <span className="flex items-center gap-1.5"><MessageCircle size={14} /> Chats</span>
          <span className="flex items-center gap-1.5"><Bell size={14} /> Alerts</span>
          <span className="flex items-center gap-1.5"><Music2 size={14} /> Hymns</span>
          <span className="flex items-center gap-1.5"><MonitorSmartphone size={14} /> Up to 3 devices</span>
        </div>
      </div>

      {/* right: the code */}
      <div className="flex-1 flex flex-col items-center justify-center p-8">
        <div className="w-full max-w-sm">
          <h2 className="text-2xl font-black text-tac-blue-dark dark:text-white text-center mb-1">Scan to sign in</h2>
          <p className="text-sm text-gray-500 dark:text-gray-400 text-center mb-6">Use your phone to link this computer to your account.</p>
          <LinkWithPhone embedded />
          <button type="button" onClick={() => setUseEmail(true)} className="block mx-auto mt-6 text-xs font-black uppercase tracking-widest text-tac-blue hover:underline">
            Sign in with email instead
          </button>
          {desktopUrl && (
            <a href={desktopUrl} target="_blank" rel="noreferrer" className="block text-center mt-4 text-xs font-bold text-gray-500 hover:text-tac-blue">
              Prefer an app? Download TAC-EL for Desktop
            </a>
          )}
        </div>
      </div>
    </div>
  );
};

export default DesktopWelcome;
