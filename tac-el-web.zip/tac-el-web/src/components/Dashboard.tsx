import React, { useState, useEffect } from 'react';
import { useNavigate, Routes, Route, Link, useLocation, Navigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import { Mic, 
  Home, 
  BookOpen, 
  Calendar, 
  Users, 
  MessageSquare, 
  Heart, 
  Image as ImageIcon,
  Bell,
  Menu,
  X,
  LogOut,
  User as UserIcon,
  Settings,
  Shield,
  Search,
  Church,
  Info,
  ScrollText,
  Music4,
  HardHat,
  Plus,
  Trash2,
  MoreHorizontal,
  CheckCircle2,
  Megaphone,
  Zap,
  ChevronLeft,
  Headphones,
  Radio,
  PhoneOff,
  Globe,
  ShieldAlert,
  IdCard,
  MonitorSmartphone,
} from 'lucide-react';
import { DISTRICT, ASSEMBLY, CHURCH_LOGO } from '../constants';
import { authService } from '../services/authService';
import { startChatNotifications, useChatUnread } from '../lib/chatUnread';
import { settingsService } from '../services/settingsService';
import { noticesService } from '../services/contentService';
import { liveSessionService } from '../services/liveSessionService';
import { updateRequestsService } from '../services/pendingSchemaServices';
import { supportTicketsService } from '../services/supportTicketsService';
import { useAuth } from '../context/AuthContext';
import { Notice, HomeConfig, UserProfile } from '../types';

import { handleFirestoreError, OperationType } from '../lib/firestore-errors';

// Components
import HomeView from './sections/HomeView';
import NoticeView from './sections/NoticeView';
import SermonView from './sections/SermonView';
import EventView from './sections/EventView';
import GalleryView from './sections/GalleryView';
// TeamView import removed — /teams retired in favor of /clubs; see route comment below for why the file is kept on disk
import Chat from './member-portal/Chat';
import ChatChooser from './member-portal/ChatChooser';
import MessagesList from './sections/MessagesList';
import NotificationSettings from './sections/NotificationSettings';
import LinkedDevices from './sections/LinkedDevices';
import { LinkedDeviceWatcher } from './pwa/LinkedDeviceWatcher';
import { PwaPrompts } from './pwa/PwaPrompts';
import DirectMessageView from './sections/DirectMessageView';
import NetworkView from './sections/NetworkView';
import MyGiving from './member-portal/MyGiving';
import ChurchInfo from './sections/ChurchInfo';
import MyProfile from './member-portal/MyProfile';
import AdminInbox from './sections/AdminInbox';
import UpdateView from './sections/UpdateView';
import ChurchList from './sections/ChurchList';
import SiteSettings from './sections/SiteSettings';
import HymnView from './sections/HymnView';
import BibleView from './sections/BibleView';
import ConductView from './sections/ConductView';
import ProfileCompletion from './sections/ProfileCompletion';
import Notifications from './member-portal/Notifications';
import BuildInChristView from './sections/BuildInChristView';
import VoiceConference from './sections/VoiceConference';
import FloatingAssistiveTab from './FloatingAssistiveTab';
import { FEATURES } from '../lib/features';
import AdminHome from './admin-portal/AdminHome';
import { fetchMyPerms } from '../lib/offices';
import PresbyteryHome from './presbytery-portal/PresbyteryHome';
import BottomNav from './shared/BottomNav';
import { RequireRole } from './shared/RequireRole';
import { clubsService } from '../services/clubsService';

// Portal Components
import PrayerRequests from './member-portal/PrayerRequests';
import ClubsHub from './member-portal/clubs/ClubsHub';
import AppFrame from './admin-portal/attendance/AppFrame';
import MembershipPage from './admin-portal/member-crm/MembershipPage';
import { 
  Dashboard as PresbyteryDashboard,
  Directives as PresbyteryDirectives,
  NoticeApprovals as PresbyteryNoticeApprovals,
  ClubOversight as PresbyteryClubOversight,
  ElderDirectory as PresbyteryElderDirectory 
} from './presbytery-portal';

import {
  Roster as LeaderRoster,
  Attendance as LeaderAttendance,
  MeetingNotes as LeaderMeetingNotes,
  RegistrationApprovals as LeaderRegistrationApprovals,
  Instructions as LeaderInstructions
} from './group-leader-portal';

import {
  DailyDashboard as TreasurerDaily,
  FinanceReports as TreasurerReports,
  Charts as TreasurerCharts,
  PaystackReconciliation,
  LedgerTools as AccountantLedger,
  AssetTracking
} from './office-portal';

import {
  Directory as AdminDirectory,
  ProfileEditor as AdminProfileEditor,
  VisitorPipeline,
  BatchEntry,
  PledgeManager,
  ManageClubs,
  MembershipApplications,
  HymnsManager,
  BibleVersions,
  SermonsManager,
  VoiceRecordings,
  EventsManager,
  NoticesManager,
  GalleryManager,
  HeroSlideshow,
  KinAiSettings,
  WebsiteManager,
  ChatReports,
  TacIdSettings,
  ChatWallpaperLibrary,
  SmsPush,
  UserManagement
} from './admin-portal';

/** Chat screens (church chat and private messages) fill the space between the top bar and the
 *  bottom bar and never scroll the page; only the message list inside them scrolls, like WhatsApp. */
const ChatShell: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <div className="flex-1 min-h-0 flex flex-col">{children}</div>
);

const Dashboard: React.FC = () => {
  const { user, profile, loading, quotaExceeded, refreshProfile } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [isSidebarOpen, setSidebarOpen] = useState(window.innerWidth >= 1024);
  const [activeNotification, setActiveNotification] = useState<Notice | null>(null);
  const [pendingUpdates, setPendingUpdates] = useState(0);
  const chatUnread = useChatUnread();
  const [editingMember, setEditingMember] = useState<UserProfile | null>(null);
  const [directoryRefreshKey, setDirectoryRefreshKey] = useState(0);
  // what this person's offices allow (the database decides; administrators can do everything)
  const [perms, setPerms] = useState<string[]>([]);
  useEffect(() => { if (profile?.uid) fetchMyPerms().then(setPerms); }, [profile?.uid, profile?.offices?.join(',')]);
  const [unreadEmergencies, setUnreadEmergencies] = useState(0);
  const [isEmergencyPanelOpen, setEmergencyPanelOpen] = useState(false);
  const [emergencies, setEmergencies] = useState<any[]>([]);
  const [unreadNotices, setUnreadNotices] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [creatingProfile, setCreatingProfile] = useState(false);
  const [selectedRole, setSelectedRole] = useState<'member' | 'presbytery' | 'admin'>('member');
  const [adminPass, setAdminPass] = useState('');
  const [activeVoiceRoom, setActiveVoiceRoom] = useState<any>(null);
  const [showVoicePrayerBanner, setShowVoicePrayerBanner] = useState(false);
  const [isGroupLeader, setIsGroupLeader] = useState(false);
  const [checkingLeader, setCheckingLeader] = useState(true);

  useEffect(() => {
    if (!user?.id) { setCheckingLeader(false); return; }
    const check = () => clubsService.isUserAnyClubLeader(user.id).then(setIsGroupLeader);
    check().finally(() => setCheckingLeader(false));
    // Re-check now and then: when an admin gives this person a club role, the leader menu appears without a restart.
    const t = setInterval(check, 30000);
    const onVisible = () => { if (document.visibilityState === 'visible') check(); };
    document.addEventListener('visibilitychange', onVisible);
    return () => { clearInterval(t); document.removeEventListener('visibilitychange', onVisible); };
  }, [user?.id]);

  // Active Voice Room Listener & One-Time Cleanup of Stale Hosted Voice Rooms
  useEffect(() => {
    if (!user) return;
    // Deactivate any room still marked active after 12h (a host who never
    // explicitly ended it) so a stale banner doesn't pop up for everyone.
    const cleanupStaleRooms = async () => {
      try {
        const rooms = await liveSessionService.getActiveRoomsOlderThan(12);
        await Promise.all(rooms.map((r) => liveSessionService.endRoom(r.id)));
      } catch { /* ignore */ }
    };
    if (profile?.role === 'admin') cleanupStaleRooms(); // members cannot end other people's rooms; the database cleans up too

    return liveSessionService.subscribeToActiveRooms((rooms) => {
      setActiveVoiceRoom(rooms[0] ?? null);
    });
  }, [user]);

  useEffect(() => {
    if (!loading && !user) {
      navigate('/login');
    }
  }, [user, loading, navigate]);

  // Real-time Notification Listener
  useEffect(() => {
    if (!user || !profile) return;

    return noticesService.subscribeNotices((notices) => {
      if (notices.length === 0) return;
      const latestNotice = notices[0];
      const lastSeenId = localStorage.getItem(`lastSeenNotice_${user.id}`);

      if (latestNotice.id !== lastSeenId) {
        setActiveNotification(latestNotice);
        setTimeout(() => setActiveNotification(prev => prev?.id === latestNotice.id ? null : prev), 8000);
      }
    }, 1);
  }, [user, profile]);

  // Pending Updates Listener for Admin
  useEffect(() => {
    if (!profile || profile.role !== 'admin') return;

    return updateRequestsService.subscribeAll((rows) => {
      setPendingUpdates(rows.filter(r => r.status === 'pending').length);
    });
  }, [profile]);

  // Unread Emergencies Listener for Admin
  useEffect(() => {
    if (!profile || profile.role !== 'admin') return;

    const seenKey = `tac_seen_emergencies_${profile.uid}`;
    const readSeen = (): Set<string> => {
      try { return new Set<string>(JSON.parse(localStorage.getItem(seenKey) || '[]')); } catch { return new Set<string>(); }
    };
    const load = () => {
      supportTicketsService.getUnread().then((rows) => {
        const seen = readSeen();
        setEmergencies(rows);
        // The badge counts only alerts the admin has not opened yet.
        setUnreadEmergencies(rows.filter((r) => !seen.has(r.id)).length);
      }).catch((error) => {
        handleFirestoreError(error, OperationType.LIST, 'emergencyRequests');
      });
    };
    load();
    const t = setInterval(load, 60000);
    return () => clearInterval(t);
  }, [profile]);

  // App-wide chat listener: unread badges, new-message sound, tab-title count.
  const isChatScreen = location.pathname === '/dashboard/chat' || location.pathname.startsWith('/dashboard/chat/');
  const ChatWrap: React.ElementType = isChatScreen ? ChatShell : React.Fragment;
  // Why a Presbytery/Admin Google sign-in did not give the role (set by AuthContext, shown once).
  const [claimMsg, setClaimMsg] = useState<string | null>(() => {
    try { const m = sessionStorage.getItem('tac_claim_error'); if (m) sessionStorage.removeItem('tac_claim_error'); return m; } catch { return null; }
  });
  const pathRef = React.useRef(location.pathname);
  pathRef.current = location.pathname;
  useEffect(() => {
    if (!user || !profile) return;
    return startChatNotifications(user.id, () => pathRef.current);
  }, [user?.id, !!profile]);

  // Unread Notices Listener for All
  useEffect(() => {
    if (!user || !profile) return;

    return noticesService.subscribeNotices((notices) => {
      const lastSeenId = localStorage.getItem(`lastSeenNotice_${user.id}`);
      if (!lastSeenId) {
        setUnreadNotices(notices.length);
      } else {
        const lastSeenIndex = notices.findIndex(n => n.id === lastSeenId);
        setUnreadNotices(lastSeenIndex === -1 ? notices.length : lastSeenIndex);
      }
    }, 20);
  }, [user, profile]);

  const markEmergencyRead = async (id: string) => {
    try {
      await supportTicketsService.setStatus(id, 'read');
    } catch (e) {
      console.error(e);
    }
  };

  const markNotificationSeen = (id: string) => {
    if (user) {
      localStorage.setItem(`lastSeenNotice_${user.id}`, id);
    }
    setActiveNotification(null);
  };

  const handleCreateProfile = async () => {
    if (!user) return;
    
    if ((selectedRole === 'admin' || selectedRole === 'presbytery') && !adminPass.trim()) {
      setError(selectedRole === 'admin' ? "Enter the Admin Passkey." : "Enter the Elder Passcode.");
      return;
    }

    setCreatingProfile(true);
    setError(null);
    try {
      const meta = (user as any).user_metadata || {};
      await authService.createProfileForNewUser(
        user.id,
        user.email || '',
        meta.full_name || meta.name || 'TAC Member'
      );
      // The account always starts as a member; the server verifies the passcode.
      if (selectedRole === 'admin' || selectedRole === 'presbytery') {
        await authService.claimRole(selectedRole, adminPass);
      }
      await refreshProfile();
    } catch (err: any) {
      setError(err.message || "Failed to initialize profile. Please contact admin.");
    } finally {
      setCreatingProfile(false);
    }
  };

  const [siteConfig, setSiteConfig] = useState<HomeConfig | null>(null);

  useEffect(() => {
    return settingsService.subscribeHomeConfig((cfg) => {
      if (cfg) setSiteConfig(cfg);
    });
  }, []);

  const logo = siteConfig?.logoUrl || CHURCH_LOGO;

  if (loading) {
    return (
      <div className="min-h-dvh flex flex-col items-center justify-center bg-tac-blue-dark">
        <motion.div 
          initial={{ scale: 0.5, opacity: 0 }}
          animate={{ 
            scale: [1, 1.05, 1], 
            opacity: 1,
            rotateY: [0, 360]
          }}
          transition={{ 
            scale: { repeat: Infinity, duration: 2 },
            rotateY: { duration: 3, ease: "easeInOut", repeat: Infinity }
          }}
          className="w-32 h-32 bg-white rounded-[2rem] flex items-center justify-center p-4 mb-6 shadow-2xl ring-8 ring-white/5"
        >
          <img src={logo} alt="Church Logo" className="w-full h-full object-contain" />
        </motion.div>
        <div className="text-center space-y-2">
          <p className="text-white text-xs font-black uppercase tracking-[0.4em] animate-pulse">The Apostolic Church Ghana</p>
          <p className="text-white/40 text-[9px] font-bold uppercase tracking-[0.2em]">{ASSEMBLY}</p>
        </div>
      </div>
    );
  }

  if (user && !profile) {
    return (
      <div className="min-h-dvh flex flex-col items-center justify-center bg-[var(--Bg)] p-6 text-center">
        <motion.div 
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="w-24 h-24 bg-tac-blue/10 rounded-3xl flex items-center justify-center mb-8 text-tac-blue shadow-inner"
        >
          <Shield size={48} />
        </motion.div>
        
        <h2 className="text-3xl font-black font-serif text-tac-blue-dark mb-3">Initialize Portal</h2>
        <p className="text-[var(--Sub)] max-w-sm mb-8 leading-relaxed font-medium">
          Welcome to the {DISTRICT} digital portal. Please select your role to continue.
        </p>

        <div className="w-full max-w-sm mb-8 space-y-6">
           <div className="grid grid-cols-3 gap-3">
              {(['member', 'presbytery', 'admin'] as const).map(role => (
                <button 
                  key={role}
                  type="button"
                  onClick={() => setSelectedRole(role)}
                  className={`py-4 rounded-2xl border-2 transition-all flex flex-col items-center gap-2 ${selectedRole === role ? 'border-tac-blue bg-tac-blue/5' : 'border-gray-100'}`}
                >
                  <span className={`text-[10px] font-black uppercase tracking-widest ${selectedRole === role ? 'text-tac-blue' : 'text-gray-300'}`}>{role}</span>
                  {role === 'admin' && <Shield size={16} className={selectedRole === 'admin' ? 'text-tac-blue' : 'text-gray-200'} />}
                </button>
              ))}
           </div>

           {(selectedRole === 'admin' || selectedRole === 'presbytery') && (
             <motion.div 
               initial={{ opacity: 0, y: -10 }}
               animate={{ opacity: 1, y: 0 }}
               className="space-y-2"
             >
                <label className="text-[10px] font-black uppercase text-tac-blue/40 tracking-widest text-left block">{selectedRole === 'admin' ? 'Admin Passkey' : 'Elder Passcode'}</label>
                <input 
                  type="password" 
                  value={adminPass}
                  onChange={(e) => setAdminPass(e.target.value)}
                  className="w-full h-14 bg-white border border-[var(--Bdr)] rounded-2xl px-6 outline-none focus:ring-2 focus:ring-tac-blue/5"
                />
             </motion.div>
           )}
        </div>

        {error && (
          <div className="mb-8 p-4 bg-red-50 border border-red-100 rounded-2xl flex items-start gap-3 text-left max-w-sm">
            <X className="text-tac-red shrink-0 mt-0.5" size={16} />
            <p className="text-tac-red text-xs font-bold">{error}</p>
          </div>
        )}

        <div className="flex flex-col gap-4 w-full max-w-sm">
          <button 
            onClick={handleCreateProfile}
            disabled={creatingProfile}
            className="group relative w-full h-16 bg-tac-blue text-white rounded-2xl font-black uppercase tracking-widest text-xs flex items-center justify-center gap-3 overflow-hidden shadow-xl shadow-tac-blue/20 hover:shadow-2xl hover:scale-[1.02] active:scale-95 transition-all disabled:opacity-50 disabled:scale-100"
          >
            <div className="absolute inset-0 bg-gradient-to-r from-white/0 via-white/10 to-white/0 -translate-x-full group-hover:translate-x-full transition-transform duration-1000" />
            {creatingProfile ? (
              <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
            ) : (
              <CheckCircle2 size={20} />
            )}
            {creatingProfile ? 'Building Profile...' : 'Complete Registration'}
          </button>
          
          <div className="grid grid-cols-2 gap-3">
            <button 
              onClick={() => window.location.reload()}
              disabled={creatingProfile}
              className="h-14 border border-[var(--Bdr)] bg-white text-[var(--Sub)] rounded-2xl font-black uppercase tracking-widest text-[10px] flex items-center justify-center gap-2 hover:bg-gray-50 transition-all"
            >
              <Search size={14} />
              Retry
            </button>
            <button 
              onClick={() => authService.logout()}
              disabled={creatingProfile}
              className="h-14 border border-[var(--Bdr)] bg-white text-[var(--Sub)] rounded-2xl font-black uppercase tracking-widest text-[10px] flex items-center justify-center gap-2 hover:border-tac-red/20 hover:text-tac-red transition-all"
            >
              <LogOut size={14} />
              Sign Out
            </button>
          </div>
        </div>

        <div className="mt-12 flex items-center gap-3 text-tac-blue/40 font-black uppercase tracking-widest text-[10px]">
           <div className="w-8 h-[1px] bg-tac-blue/10" />
           {DISTRICT} Portal Security
           <div className="w-8 h-[1px] bg-tac-blue/10" />
        </div>
      </div>
    );
  }

  if (!profile) return null;

  if (profile.isProfileComplete === false) {
    return <ProfileCompletion profile={profile} onComplete={refreshProfile} />;
  }

  const isAdmin = profile.role === 'admin';
  const isPresbytery = profile.role === 'presbytery';
  const isStaff = isAdmin || isPresbytery;
  const myOffices: string[] = profile.offices ?? (profile.office ? [profile.office] : []);
  const isTreasurer = myOffices.includes('treasurer') || myOffices.includes('assistant_treasurer');
  const isAccountant = myOffices.includes('accountant');
  const isInventoryOfficer = myOffices.includes('inventory_officer');
  const isAuditor = myOffices.includes('auditor');
  const can = (p: string) => isAdmin || perms.includes(p);
  const hasTools = !isAdmin && ['register.view', 'attendance.view', 'visitors.manage', 'assets.view', 'media.manage', 'money.view'].some((p) => perms.includes(p));

  const toggleSidebar = () => setSidebarOpen(!isSidebarOpen);

  return (
    <div className="flex h-[100dvh] bg-[var(--Bg)] overflow-hidden font-sans">
      {/* Mobile Sidebar Overlay */}
      <AnimatePresence>
        {isSidebarOpen && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={toggleSidebar}
            className="fixed inset-0 bg-black/50 z-40 lg:hidden"
          />
        )}
      </AnimatePresence>

      {/* Sidebar */}
      <motion.aside 
        initial={false}
        animate={{ x: isSidebarOpen ? 0 : -280 }}
        className="fixed inset-y-0 left-0 w-[280px] bg-tac-blue-dark z-50 flex flex-col shadow-2xl transition-transform"
      >
        <div className="p-6 pt-10 overflow-y-auto flex-1">
            <div className="flex items-center gap-4 mb-10 px-2 cursor-pointer" onClick={() => navigate('/dashboard')}>
              <div className="w-14 h-14 bg-white rounded-2xl flex items-center justify-center p-2 shadow-2xl ring-8 ring-white/5">
                 <img src={siteConfig?.logoUrl || CHURCH_LOGO} alt="The Apostolic Church Logo" className="w-full h-full object-contain" />
              </div>
              <div className="min-w-0">
                <h2 className="text-white font-black text-base leading-none uppercase tracking-tighter truncate">TAC GHANA</h2>
                <p className="text-white/40 text-[9px] uppercase font-bold tracking-[0.2em] mt-1.5 truncate">{ASSEMBLY}</p>
                <p className="text-white/30 text-[8px] uppercase font-bold tracking-widest mt-0.5 truncate">Madina District</p>
              </div>
            </div>

             <div className="space-y-1">
               {isAdmin && (
                 <NavGroup title="Admin">
                   <NavItem to="/dashboard" icon={<Home size={20} />} label="Admin Home" active={location.pathname === '/dashboard'} onClick={() => setSidebarOpen(false)} />
                   <NavItem to="/dashboard/profile" icon={<UserIcon size={20} />} label="My Account" active={location.pathname === '/dashboard/profile'} onClick={() => setSidebarOpen(false)} />
                 </NavGroup>
               )}
               {!isAdmin && (<>
               <NavGroup title="Main">
                 <NavItem to="/dashboard" icon={<Home size={20} />} label="Home" active={location.pathname === '/dashboard'} onClick={() => setSidebarOpen(false)} />
                 <NavItem to="/dashboard/sermons" icon={<BookOpen size={20} />} label="Sermons" active={location.pathname === '/dashboard/sermons'} onClick={() => setSidebarOpen(false)} />
                 <NavItem to="/dashboard/events" icon={<Calendar size={20} />} label="Events" active={location.pathname === '/dashboard/events'} onClick={() => setSidebarOpen(false)} />
                 <NavItem to="/dashboard/gallery" icon={<ImageIcon size={20} />} label="Gallery" active={location.pathname === '/dashboard/gallery'} onClick={() => setSidebarOpen(false)} />
               </NavGroup>

               <NavGroup title="Spiritual">
                  <NavItem to="/dashboard/prayers" icon={<Heart size={20} />} label="Prayer Requests" active={location.pathname === '/dashboard/prayers'} onClick={() => setSidebarOpen(false)} />
                  {!isAdmin && !isPresbytery && <NavItem to="/dashboard/clubs" icon={<Users size={20} />} label="Clubs" active={location.pathname === '/dashboard/clubs'} onClick={() => setSidebarOpen(false)} />}
                  <NavItem to="/dashboard/hymns" icon={<Music4 size={20} />} label="Hymns" active={location.pathname === '/dashboard/hymns'} onClick={() => setSidebarOpen(false)} />
                  <NavItem to="/dashboard/conference" icon={<Headphones size={20} />} label="Voice Sanctuary" active={location.pathname === '/dashboard/conference'} onClick={() => setSidebarOpen(false)} />
                  <NavItem to="/dashboard/conduct" icon={<ScrollText size={20} />} label="Protocol & Conduct" active={location.pathname === '/dashboard/conduct'} onClick={() => setSidebarOpen(false)} />
                  <NavItem to="/dashboard/build-in-christ" icon={<BookOpen size={20} />} label="Build in Christ" active={location.pathname === '/dashboard/build-in-christ'} onClick={() => setSidebarOpen(false)} />
               </NavGroup>

               <NavGroup title="Ministry">
                 <NavItem to="/dashboard/notices" icon={<Bell size={20} />} label="Notices" active={location.pathname === '/dashboard/notices'} onClick={() => setSidebarOpen(false)} />
                 {isStaff && <NavItem to="/dashboard/updates" icon={<Zap size={20} />} label="Updates" active={location.pathname === '/dashboard/updates'} badge={isAdmin && pendingUpdates > 0 ? pendingUpdates.toString() : undefined} onClick={() => setSidebarOpen(false)} />}
                 {/* Teams nav item removed — /teams retired in favor of /clubs, see Dashboard.tsx route comment */}
                 <NavItem to="/dashboard/network" icon={<Zap size={20} />} label="Network" active={location.pathname === '/dashboard/network'} onClick={() => setSidebarOpen(false)} />
                 <NavItem to="/dashboard/chat" icon={<MessageSquare size={20} />} label="Church Chat" badge={chatUnread.total > 0 ? (chatUnread.total > 99 ? '99+' : String(chatUnread.total)) : undefined} active={location.pathname.startsWith('/dashboard/chat')} onClick={() => setSidebarOpen(false)} />
                 <NavItem to="/dashboard/messages" icon={<MessageSquare size={20} />} label="Messages" />
                 <NavItem to="/dashboard/notification-settings" icon={<Bell size={20} />} label="Notifications" />
                 <NavItem to="/dashboard/linked-devices" icon={<MonitorSmartphone size={20} />} label="Linked Devices" />
               </NavGroup>

               {isGroupLeader && !isAdmin && (
                 <NavGroup title="My Group">
                   <NavItem to="/dashboard/leader/roster" icon={<Users size={20} />} label="Group Roster" active={location.pathname === '/dashboard/leader/roster'} onClick={() => setSidebarOpen(false)} />
                   <NavItem to="/dashboard/leader/approvals" icon={<Shield size={20} />} label="Join Approvals" active={location.pathname === '/dashboard/leader/approvals'} onClick={() => setSidebarOpen(false)} />
                   <NavItem to="/dashboard/leader/attendance" icon={<Calendar size={20} />} label="Attendance" active={location.pathname === '/dashboard/leader/attendance'} onClick={() => setSidebarOpen(false)} />
                   <NavItem to="/dashboard/leader/notes" icon={<ScrollText size={20} />} label="Meeting Notes" active={location.pathname === '/dashboard/leader/notes'} onClick={() => setSidebarOpen(false)} />
                   <NavItem to="/dashboard/leader/instructions" icon={<Bell size={20} />} label="Instructions" active={location.pathname === '/dashboard/leader/instructions'} onClick={() => setSidebarOpen(false)} />
                 </NavGroup>
               )}

               {(isTreasurer || isAccountant || hasTools) && !isAdmin && !isPresbytery && (
                 <NavGroup title="My Office">
                   {isTreasurer && <NavItem to="/dashboard/office/treasurer" icon={<Heart size={20} />} label="Treasury & Finance" active={location.pathname.startsWith('/dashboard/office')} onClick={() => setSidebarOpen(false)} />}
                   {isAccountant && <NavItem to="/dashboard/office/ledger" icon={<Heart size={20} />} label="Ledger" active={location.pathname === '/dashboard/office/ledger'} onClick={() => setSidebarOpen(false)} />}
                   {hasTools && <NavItem to="/dashboard/admin" icon={<Users size={20} />} label="My office tools" active={location.pathname.startsWith('/dashboard/admin')} onClick={() => setSidebarOpen(false)} />}
                 </NavGroup>
               )}

               </>)}

               {isPresbytery && (
                 <NavGroup title="Administration">
                   <NavItem to="/dashboard/presbytery" icon={<Shield size={20} />} label="Presbytery Council" active={location.pathname.startsWith('/dashboard/presbytery')} onClick={() => setSidebarOpen(false)} />
                   <NavItem to="/dashboard/office/treasurer" icon={<Heart size={20} />} label="Treasury & Finance" active={location.pathname.startsWith('/dashboard/office')} onClick={() => setSidebarOpen(false)} />
                   {isAdmin && <NavItem to="/dashboard/admin/voice-recordings" icon={<Radio size={20} />} label="Voice Recordings" active={location.pathname === '/dashboard/admin/voice-recordings'} onClick={() => setSidebarOpen(false)} />}
                   {isAdmin && <NavItem to="/dashboard/admin/clubs" icon={<Users size={20} />} label="Manage Clubs" active={location.pathname === '/dashboard/admin/clubs'} onClick={() => setSidebarOpen(false)} />}
                   {isAdmin && <NavItem to="/dashboard/admin/directory" icon={<Users size={20} />} label="Member CRM" active={location.pathname === '/dashboard/admin/directory'} onClick={() => setSidebarOpen(false)} />}
                   {isAdmin && <NavItem to="/dashboard/admin/inbox" icon={<Shield size={20} />} label="Admin Inbox" active={location.pathname === '/dashboard/admin/inbox'} badge="2" onClick={() => setSidebarOpen(false)} />}
                   {isAdmin && <NavItem to="/dashboard/admin/members" icon={<Users size={20} />} label="Church List" active={location.pathname === '/dashboard/admin/members'} onClick={() => setSidebarOpen(false)} />}
                   {isAdmin && <NavItem to="/dashboard/admin/settings" icon={<Settings size={20} />} label="Site Settings" active={location.pathname === '/dashboard/admin/settings'} onClick={() => setSidebarOpen(false)} />}
                   {isAdmin && <NavItem to="/dashboard/admin/website" icon={<Globe size={20} />} label="Website" active={location.pathname === '/dashboard/admin/website'} onClick={() => setSidebarOpen(false)} />}
                   {isAdmin && <NavItem to="/dashboard/admin/chat-reports" icon={<ShieldAlert size={20} />} label="Chat Reports" active={location.pathname === '/dashboard/admin/chat-reports'} onClick={() => setSidebarOpen(false)} />}
                   {isAdmin && <NavItem to="/dashboard/admin/tac-id" icon={<IdCard size={20} />} label="Member IDs" active={location.pathname === '/dashboard/admin/tac-id'} onClick={() => setSidebarOpen(false)} />}
                   {isAdmin && <NavItem to="/dashboard/admin/chat-wallpapers" icon={<ImageIcon size={20} />} label="Chat Wallpapers" active={location.pathname === '/dashboard/admin/chat-wallpapers'} onClick={() => setSidebarOpen(false)} />}
                 </NavGroup>
               )}

               {!isAdmin && <NavGroup title="Other">
                  <NavItem to="/dashboard/give" icon={<Heart size={20} />} label="Give / Tithe" active={location.pathname === '/dashboard/give'} onClick={() => setSidebarOpen(false)} />
                  <NavItem to="/dashboard/profile" icon={<UserIcon size={20} />} label="My Profile" active={location.pathname === '/dashboard/profile'} onClick={() => setSidebarOpen(false)} />
                  <NavItem to="/dashboard/info" icon={<Info size={20} />} label="Information" active={location.pathname === '/dashboard/info'} onClick={() => setSidebarOpen(false)} />
               </NavGroup>}
             </div>
        </div>

        <div className="p-6 space-y-4 bg-black/10 border-t border-white/5">
          <div className="bg-white/5 rounded-2xl p-4 flex items-center gap-3">
             <div className={`w-10 h-10 rounded-full flex items-center justify-center text-lg font-bold text-white shadow-inner ${profile.color || 'bg-tac-blue'}`}>
               {profile.picUrl ? <img src={profile.picUrl} className="w-full h-full object-cover rounded-full" /> : profile.name[0]}
             </div>
             <div className="flex-1 min-w-0">
               <p className="text-white text-sm font-black truncate">{profile.name}</p>
               <p className="text-white/40 text-[10px] uppercase font-bold tracking-widest">{profile.role}</p>
             </div>
             <Link to="/dashboard/profile" className="text-white/30 hover:text-white transition-colors">
               <MoreHorizontal size={20} />
             </Link>
          </div>
          <button 
            onClick={() => authService.logout()}
            className="w-full flex items-center gap-3 px-4 py-3 bg-red-500/10 hover:bg-red-500 text-red-500 hover:text-white rounded-xl text-sm font-black transition-all group"
          >
            <LogOut size={20} className="group-hover:translate-x-1 transition-transform" />
            Sign Out
          </button>
        </div>
      </motion.aside>

      {/* Main Content Area */}
      <div className={`flex-1 flex flex-col min-w-0 relative transition-all duration-300 ${isSidebarOpen ? 'lg:pl-[280px]' : 'lg:pl-0'}`}>
        {/* Topbar */}
        <header className="sticky top-0 z-40 h-16 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-b border-[var(--Bdr)] flex items-center justify-between px-4 lg:px-8 shrink-0 shadow-sm shadow-black/5">
          <div className="flex items-center gap-4">
            <button onClick={toggleSidebar} className="p-2 flex items-center gap-2 text-tac-blue-dark dark:text-white hover:bg-gray-100 dark:hover:bg-white/5 rounded-lg transition-all active:scale-95">
              <Menu size={24} />
              <span className="text-[10px] hidden xs:inline font-black uppercase tracking-widest">Menu</span>
            </button>
            {location.pathname !== '/dashboard' && (
              <button 
                onClick={() => navigate(-1)} 
                className="flex items-center gap-2 p-2 px-3 bg-gray-50 dark:bg-white/5 border border-gray-100 dark:border-white/10 rounded-xl text-tac-blue hover:bg-gray-100 transition-all font-black text-[10px] uppercase tracking-widest shadow-sm"
              >
                <ChevronLeft size={16} />
                Back
              </button>
            )}
            <div className="hidden sm:flex items-center gap-2 bg-gray-50 dark:bg-white/5 border border-gray-100 dark:border-white/10 px-4 h-10 rounded-full text-tac-blue/40 focus-within:ring-2 focus-within:ring-tac-blue/5 focus-within:border-tac-blue/20 transition-all">
              <Search size={18} />
              <input type="text" placeholder="Search portal..." className="bg-transparent border-none outline-none text-sm text-[var(--Text)] dark:text-white font-medium w-48 lg:w-64 placeholder:text-gray-300 dark:placeholder:text-white/20" />
            </div>
          </div>

          <div className="flex items-center gap-2 sm:gap-4">
             {!isAdmin && (
               <button onClick={() => navigate('/dashboard/conference')} className="flex items-center gap-1.5 h-9 px-3 rounded-full bg-tac-blue text-white text-[11px] font-black uppercase tracking-wider shadow-md active:scale-95 transition-all" aria-label="Voice room">
                 <Mic size={16} /> <span>Voice room</span>
               </button>
             )}
             <div className="hidden xs:flex flex-col items-end mr-2">
                <span className="text-[10px] font-black uppercase text-tac-blue dark:text-tac-blue-light tracking-tighter bg-tac-blue/5 dark:bg-tac-blue/20 px-2 py-0.5 rounded-full">{profile.role}</span>
             </div>
              {isAdmin && (
                <div className="relative">
                  <div 
                    onClick={async (e) => { 
                      e.stopPropagation(); 
                      setEmergencyPanelOpen(!isEmergencyPanelOpen);
                      // Clear unread numbers when viewed
                      if (!isEmergencyPanelOpen && unreadEmergencies > 0) {
                        // Clear the red number right away and remember which alerts were opened
                        // (even if marking them read in the database fails, it must not come back).
                        try {
                          const seenKey = `tac_seen_emergencies_${profile?.uid}`;
                          const seen = new Set<string>(JSON.parse(localStorage.getItem(seenKey) || '[]'));
                          emergencies.forEach((em) => seen.add(em.id));
                          localStorage.setItem(seenKey, JSON.stringify([...seen].slice(-300)));
                        } catch { /* storage blocked */ }
                        setUnreadEmergencies(0);
                        for (const em of emergencies) {
                          if (em.status === 'unread') {
                            await markEmergencyRead(em.id);
                          }
                        }
                      }
                    }}
                    className="p-2.5 text-tac-blue-dark dark:text-white hover:bg-gray-100 dark:hover:bg-white/5 rounded-full transition-colors group cursor-pointer"
                  >
                    <Shield size={20} className={unreadEmergencies > 0 ? "text-tac-red animate-pulse" : ""} />
                    {unreadEmergencies > 0 && (
                      <span className="absolute top-1 right-1 w-4 h-4 bg-tac-red text-white text-[8px] flex items-center justify-center rounded-full border-2 border-white dark:border-slate-900 font-black animate-bounce">
                        {unreadEmergencies}
                      </span>
                    )}
                  </div>
                  
                  {/* Emergency Dropdown */}
                  <AnimatePresence>
                    {isEmergencyPanelOpen && (
                      <>
                        {/* Invisible overlay to close on click outside */}
                        <div className="fixed inset-0 z-40" onClick={() => setEmergencyPanelOpen(false)} />
                        <motion.div 
                          initial={{ opacity: 0, y: 10, scale: 0.95 }}
                          animate={{ opacity: 1, y: 0, scale: 1 }}
                          exit={{ opacity: 0, y: 10, scale: 0.95 }}
                          className="fixed sm:absolute top-20 sm:top-full left-4 right-4 sm:left-auto sm:right-0 mt-2 sm:w-80 bg-white dark:bg-slate-800 rounded-3xl shadow-2xl border border-gray-100 dark:border-white/5 overflow-hidden z-[100] pointer-events-auto max-h-[80vh] flex flex-col"
                          onClick={(e) => e.stopPropagation()}
                        >
                          <div className="p-4 bg-tac-red text-white flex items-center justify-between shrink-0">
                              <h4 className="text-[10px] font-black uppercase tracking-widest flex items-center gap-2">
                                <Shield size={14} /> Emergency Console
                              </h4>
                              <button onClick={() => setEmergencyPanelOpen(false)} className="p-1 hover:bg-white/20 rounded-full sm:hidden">
                                <X size={16} />
                              </button>
                          </div>
                          <div className="overflow-y-auto flex-1 divide-y divide-gray-50 dark:divide-white/5 bg-white dark:bg-slate-800">

                              {emergencies.length > 0 ? emergencies.map((em) => (
                                <div key={em.id} className="p-4 hover:bg-gray-50 dark:hover:bg-white/5 transition-all text-left">
                                  <div className="flex items-center justify-between mb-2">
                                      <span className="font-black text-[10px] uppercase text-tac-blue-dark dark:text-white truncate">{em.userName}</span>
                                      <span className="text-[8px] font-bold text-gray-400">{em.createdAt?.toDate?.()?.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                                  </div>
                                  <p className="text-xs text-[var(--Sub)] font-medium leading-relaxed mb-3 line-clamp-3">{em.message}</p>
                                  <div className="flex gap-2">
                                      <button 
                                        onClick={() => markEmergencyRead(em.id)}
                                        className="flex-1 py-2 bg-tac-blue/10 text-tac-blue rounded-lg text-[9px] font-black uppercase tracking-widest hover:bg-tac-blue hover:text-white transition-all"
                                      >
                                        Acknowledge
                                      </button>
                                      <button 
                                        onClick={() => { navigate('/dashboard/admin/inbox'); setEmergencyPanelOpen(false); }}
                                        className="p-2 bg-gray-50 dark:bg-white/5 text-gray-400 rounded-lg hover:text-tac-red transition-all"
                                      >
                                        <Trash2 size={12} />
                                      </button>
                                  </div>
                                </div>
                              )) : (
                                <div className="p-8 text-center opacity-30">
                                  <CheckCircle2 size={32} className="mx-auto mb-2" />
                                  <p className="text-[10px] font-black uppercase tracking-widest">No unread emergencies</p>
                                </div>
                              )}
                          </div>
                          <div className="p-3 bg-gray-50 dark:bg-white/5 text-center">
                              <button 
                                onClick={() => { navigate('/dashboard/admin/inbox'); setEmergencyPanelOpen(false); }}
                                className="text-[9px] font-black uppercase tracking-widest text-tac-blue hover:underline"
                              >
                                View All Requests
                              </button>
                          </div>
                        </motion.div>
                      </>
                    )}
                  </AnimatePresence>
                </div>
              )}

              {activeVoiceRoom && (
                <button 
                  onClick={() => setShowVoicePrayerBanner(prev => !prev)}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold transition-all shadow-sm ${
                    showVoicePrayerBanner 
                      ? 'bg-tac-blue text-white shadow-tac-blue/30' 
                      : 'bg-red-50 dark:bg-red-950/40 text-red-600 dark:text-red-400 border border-red-200 dark:border-red-900/50 hover:bg-red-100'
                  }`}
                  title="Trigger Global Assembly Voice Prayer"
                >
                  <div className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
                  <Radio size={14} />
                  <span className="hidden sm:inline font-black tracking-wider uppercase text-[10px]">
                    {showVoicePrayerBanner ? 'Hide Voice Prayer' : 'Live Voice Prayer'}
                  </span>
                </button>
              )}

              <button 
                onClick={() => navigate('/dashboard/notifications')}
                className="relative p-2.5 text-tac-blue-dark dark:text-white hover:bg-gray-100 dark:hover:bg-white/5 rounded-full transition-colors"
              >
                <Bell size={20} className={unreadNotices > 0 ? "text-tac-red animate-pulse" : ""} />
                {unreadNotices > 0 && (
                  <span className="absolute top-1.5 right-1.5 w-4 h-4 bg-tac-red text-white text-[8px] flex items-center justify-center rounded-full border-2 border-white dark:border-slate-900 font-black">
                    {unreadNotices > 9 ? '9+' : unreadNotices}
                  </span>
                )}
              </button>
             <button onClick={() => navigate('/dashboard/profile')} className="p-0.5 border-2 border-transparent hover:border-tac-blue/20 rounded-full transition-all">
               <div className={`w-9 h-9 rounded-full flex items-center justify-center text-sm font-bold text-white shadow-md ${profile.color || 'bg-tac-blue'}`}>
                 {profile.picUrl ? <img src={profile.picUrl} className="w-full h-full object-cover rounded-full" /> : profile.name[0]}
               </div>
             </button>
          </div>
        </header>

        {/* Global Quota Alert */}
        <AnimatePresence>
          {quotaExceeded && (
            <motion.div 
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="bg-orange-500 text-white overflow-hidden shrink-0"
            >
               <div className="px-4 lg:px-8 py-2 flex items-center justify-center gap-3">
                  <Shield size={14} className="shrink-0 animate-pulse" />
                  <p className="text-[9px] xs:text-[10px] font-black uppercase tracking-widest text-center">
                    Sanctuary Quota Limit Reached. Real-time updates paused.
                  </p>
                  <button 
                    onClick={() => window.location.reload()}
                    className="flex items-center gap-1 bg-white/20 px-2 py-0.5 rounded-full text-[9px] font-bold hover:bg-white/40 transition-all"
                  >
                    <Search size={10} />
                    Retry
                  </button>
               </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Global Announcement Alert Bar */}
        <AnimatePresence>
          {siteConfig?.announcement && (
            <motion.div 
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="bg-tac-red text-white overflow-hidden"
            >
               <div className="px-4 lg:px-8 py-2 flex items-center justify-center gap-3">
                  <Megaphone size={14} className="shrink-0 animate-bounce" />
                  <p className="text-[10px] xs:text-[11px] font-black uppercase tracking-widest text-center truncate">
                    {siteConfig.announcement}
                  </p>
                  <Info size={14} className="shrink-0 opacity-50 cursor-pointer hover:opacity-100 transition-opacity" onClick={() => navigate('/dashboard/notices')} />
               </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Global Active Voice Prayer Alert Bar - Shown ONLY when triggered */}
        <AnimatePresence>
          {activeVoiceRoom && showVoicePrayerBanner && (
            <motion.div 
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="bg-gradient-to-r from-tac-blue-dark via-slate-900 to-tac-blue text-white overflow-hidden shrink-0 border-b border-tac-blue/30 shadow-lg relative"
            >
               <div className="px-4 lg:px-8 py-2.5 flex flex-wrap items-center justify-between gap-3 max-w-7xl mx-auto">
                  <div className="flex items-center gap-3 min-w-0">
                     <div className="w-8 h-8 bg-red-500/20 text-red-400 rounded-full flex items-center justify-center shrink-0 animate-pulse border border-red-500/40">
                        <Radio size={16} />
                     </div>
                     <div className="min-w-0">
                        <div className="flex items-center gap-2">
                           <span className="text-[9px] font-black uppercase text-red-400 tracking-widest animate-pulse">LIVE AUDIO BROADCAST</span>
                           <span className="text-white/40 text-[10px]">·</span>
                           <p className="text-xs font-black uppercase tracking-tight text-white truncate">
                              {activeVoiceRoom.title || 'Global Assembly Voice Prayer'}
                           </p>
                        </div>
                        <p className="text-[10px] text-white/60 font-medium truncate">
                           Started by {activeVoiceRoom.hostName || 'Leader'} · Tap to join sanctuary
                        </p>
                     </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                     {(profile?.role === 'admin' || profile?.role === 'presbytery' || activeVoiceRoom.hostId === user?.id) && (
                        <button 
                          onClick={async () => {
                             try {
                               await liveSessionService.endRoom(activeVoiceRoom.id);
                             } catch (err) {
                               console.warn("Stop room from header warn:", err);
                             }
                             setActiveVoiceRoom(null);
                             setShowVoicePrayerBanner(false);
                          }}
                          className="px-3 py-1.5 bg-red-600/90 hover:bg-red-600 text-white rounded-xl text-[10px] font-black uppercase tracking-wider transition-all flex items-center gap-1.5 active:scale-95 shadow-md"
                          title="Stop / End Voice Room"
                        >
                           <PhoneOff size={12} />
                           <span>Stop Room</span>
                        </button>
                     )}

                     <button 
                       onClick={() => navigate('/dashboard/conference')}
                       className="px-4 py-1.5 bg-tac-blue hover:bg-blue-600 text-white rounded-xl text-[10px] font-black uppercase tracking-wider transition-all shadow-md active:scale-95"
                     >
                        Join Room
                     </button>

                     <button 
                       onClick={() => setShowVoicePrayerBanner(false)}
                       className="p-1.5 hover:bg-white/10 text-white/70 hover:text-white rounded-full transition-colors ml-1"
                       aria-label="Close voice room banner"
                       title="Close banner"
                     >
                        <X size={16} />
                     </button>
                  </div>
               </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Dynamic Viewport */}
        <main className={`flex-1 min-h-0 bg-[var(--Bg)] relative pb-20 lg:pb-0 ${isChatScreen ? 'overflow-hidden flex flex-col' : 'overflow-y-auto scroll-smooth'}`}>
          {claimMsg && (
            <div className="m-3 p-3.5 bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-800 rounded-2xl text-xs font-bold text-red-600 dark:text-red-300 flex items-start gap-3">
              <span className="flex-1 leading-snug">{claimMsg}</span>
              <button onClick={() => setClaimMsg(null)} className="shrink-0 p-1 -m-1 text-red-400 hover:text-red-600" aria-label="Dismiss"><X size={16} /></button>
            </div>
          )}
          <ChatWrap>
          <Routes>
            <Route path="/" element={isAdmin ? <AdminHome /> : isPresbytery ? <PresbyteryHome /> : <HomeView />} />
            <Route path="/notices" element={<NoticeView />} />
            <Route path="/sermons" element={<SermonView />} />
            <Route path="/events" element={<EventView />} />
            <Route path="/gallery" element={<GalleryView />} />
            {/* /teams (old instant-join system) retired in favor of /clubs (approval-based, matches design).
                sections/TeamView.tsx kept on disk for later — has tasks/gallery features worth porting
                into the clubs system eventually, but not wired into routing anymore. */}
            <Route path="/chat" element={<Chat />} />
            <Route path="/chat-menu" element={<ChatChooser />} />
            <Route path="/network" element={<NetworkView />} />
            <Route path="/updates" element={<UpdateView />} />
            <Route path="/messages" element={<MessagesList />} />
            <Route path="/notification-settings" element={<NotificationSettings />} />
            <Route path="/linked-devices" element={<LinkedDevices />} />
            <Route path="/chat/direct/:dmId" element={<DirectMessageView />} />
            <Route path="/give" element={<MyGiving />} />
            <Route path="/bible" element={FEATURES.bible ? <BibleView /> : <Navigate to="/dashboard" replace />} />
            <Route path="/hymns" element={<HymnView />} />
            <Route path="/conference" element={<VoiceConference />} />
            <Route path="/conduct" element={<ConductView />} />
            <Route path="/build-in-christ" element={<BuildInChristView />} />
            <Route path="/info" element={<ChurchInfo />} />
            <Route path="/profile" element={<MyProfile />} />
            <Route path="/notifications" element={<Notifications />} />
            <Route path="/prayers" element={<PrayerRequests />} />
            <Route path="/clubs" element={isAdmin ? <Navigate to="/dashboard/admin/clubs" replace /> : isPresbytery ? <Navigate to="/dashboard" replace /> : <ClubsHub />} />

            {/* Presbytery Portal — guarded: presbytery or admin only */}
            <Route path="/presbytery" element={<RequireRole allow={['presbytery']} isAdmin={isAdmin} isPresbytery={isPresbytery}><PresbyteryDashboard /></RequireRole>} />
            <Route path="/presbytery/directives" element={<RequireRole allow={['presbytery']} isAdmin={isAdmin} isPresbytery={isPresbytery}><PresbyteryDirectives /></RequireRole>} />
            <Route path="/presbytery/approvals" element={<RequireRole allow={['presbytery']} isAdmin={isAdmin} isPresbytery={isPresbytery}><PresbyteryNoticeApprovals /></RequireRole>} />
            <Route path="/presbytery/oversight" element={<RequireRole allow={['presbytery']} isAdmin={isAdmin} isPresbytery={isPresbytery}><PresbyteryClubOversight /></RequireRole>} />
            <Route path="/presbytery/elders" element={<RequireRole allow={['presbytery']} isAdmin={isAdmin} isPresbytery={isPresbytery}><PresbyteryElderDirectory /></RequireRole>} />

            {/* Group Leader Portal — guarded: real check via clubsService.isUserAnyClubLeader */}
            <Route path="/leader/roster" element={<RequireRole allow={['groupLeader']} isAdmin={isAdmin} isGroupLeader={isGroupLeader} checking={checkingLeader}><LeaderRoster /></RequireRole>} />
            <Route path="/leader/attendance" element={<RequireRole allow={['groupLeader']} isAdmin={isAdmin} isGroupLeader={isGroupLeader} checking={checkingLeader}><LeaderAttendance /></RequireRole>} />
            <Route path="/leader/notes" element={<RequireRole allow={['groupLeader']} isAdmin={isAdmin} isGroupLeader={isGroupLeader} checking={checkingLeader}><LeaderMeetingNotes /></RequireRole>} />
            <Route path="/leader/approvals" element={<RequireRole allow={['groupLeader']} isAdmin={isAdmin} isGroupLeader={isGroupLeader} checking={checkingLeader}><LeaderRegistrationApprovals /></RequireRole>} />
            <Route path="/leader/instructions" element={<RequireRole allow={['groupLeader']} isAdmin={isAdmin} isGroupLeader={isGroupLeader} checking={checkingLeader}><LeaderInstructions /></RequireRole>} />

            {/* Office Portal — real check now: profile.office, set via AssignOffices.
                Presbytery council gets view access to all of these for financial
                oversight, same as admin; office-holder-only would otherwise shut
                the council itself out of seeing the treasury. */}
            <Route path="/office/treasurer" element={<RequireRole allow={['office', 'presbytery']} isAdmin={isAdmin} isPresbytery={isPresbytery} isOffice={isTreasurer}><TreasurerDaily /></RequireRole>} />
            <Route path="/office/reports" element={<RequireRole allow={['office', 'presbytery']} isAdmin={isAdmin} isPresbytery={isPresbytery} isOffice={isTreasurer || isAuditor}><TreasurerReports /></RequireRole>} />
            <Route path="/office/charts" element={<RequireRole allow={['office', 'presbytery']} isAdmin={isAdmin} isPresbytery={isPresbytery} isOffice={isTreasurer || isAuditor}><TreasurerCharts /></RequireRole>} />
            <Route path="/office/paystack" element={<RequireRole allow={['office', 'presbytery']} isAdmin={isAdmin} isPresbytery={isPresbytery} isOffice={isTreasurer}><PaystackReconciliation /></RequireRole>} />
            <Route path="/office/ledger" element={<RequireRole allow={['office', 'presbytery']} isAdmin={isAdmin} isPresbytery={isPresbytery} isOffice={isAccountant || isAuditor}><AccountantLedger /></RequireRole>} />
            <Route path="/office/assets" element={<RequireRole allow={['office', 'presbytery']} isAdmin={isAdmin} isPresbytery={isPresbytery} isOffice={isInventoryOfficer}><AssetTracking /></RequireRole>} />

            {/* Admin Portal — guarded: admin only */}
            <Route path="/admin" element={<RequireRole allow={['office']} isAdmin={isAdmin} isOffice={hasTools}><AdminHome isAdmin={isAdmin} perms={perms} /></RequireRole>} />
            <Route path="/admin/membership" element={<RequireRole allow={['office']} isAdmin={isAdmin} isOffice={can('register.view') || can('visitors.manage')}><MembershipPage isAdmin={isAdmin} perms={perms} /></RequireRole>} />
            <Route path="/admin/assets" element={<RequireRole allow={['office']} isAdmin={isAdmin} isOffice={can('assets.view')}><AppFrame title="Assets" src="/apps/assets/index.html" /></RequireRole>} />
            <Route path="/admin/register" element={<RequireRole allow={['office']} isAdmin={isAdmin} isOffice={can('register.view')}><AppFrame title="Register" src="/apps/register/index.html" /></RequireRole>} />
            <Route path="/admin/attendance" element={<RequireRole allow={['office']} isAdmin={isAdmin} isOffice={can('attendance.view')}><AppFrame title="Attendance" src="/apps/attendance/index.html" /></RequireRole>} />
            <Route path="/admin/inbox" element={<RequireRole allow={[]} isAdmin={isAdmin}><AdminInbox /></RequireRole>} />
            <Route path="/admin/members" element={<RequireRole allow={[]} isAdmin={isAdmin}><ChurchList /></RequireRole>} />
            <Route path="/admin/settings" element={<RequireRole allow={[]} isAdmin={isAdmin}><SiteSettings /></RequireRole>} />
            <Route path="/admin/directory" element={
              <RequireRole allow={[]} isAdmin={isAdmin}>
                <AdminDirectory key={directoryRefreshKey} onEditMember={(m) => setEditingMember(m)} />
                <AdminProfileEditor
                  member={editingMember}
                  isOpen={!!editingMember}
                  onClose={() => setEditingMember(null)}
                  onUpdated={() => setDirectoryRefreshKey((k) => k + 1)}
                />
              </RequireRole>
            } />
            <Route path="/admin/pipeline" element={<RequireRole allow={['office']} isAdmin={isAdmin} isOffice={can('visitors.manage')}><VisitorPipeline /></RequireRole>} />
            <Route path="/admin/batches" element={<RequireRole allow={[]} isAdmin={isAdmin}><BatchEntry /></RequireRole>} />
            <Route path="/admin/pledges" element={<RequireRole allow={[]} isAdmin={isAdmin}><PledgeManager /></RequireRole>} />
            <Route path="/admin/clubs" element={<RequireRole allow={[]} isAdmin={isAdmin}><ManageClubs /></RequireRole>} />
            <Route path="/admin/memberships" element={<RequireRole allow={[]} isAdmin={isAdmin}><MembershipApplications /></RequireRole>} />
            <Route path="/admin/assign-offices" element={<Navigate to="/dashboard/admin/membership?tab=roles" replace />} />
            <Route path="/admin/hymns" element={<RequireRole allow={[]} isAdmin={isAdmin}><HymnsManager /></RequireRole>} />
            <Route path="/admin/bibles" element={FEATURES.bible ? <RequireRole allow={[]} isAdmin={isAdmin}><BibleVersions /></RequireRole> : <Navigate to="/dashboard" replace />} />
            <Route path="/admin/sermons" element={<RequireRole allow={['office']} isAdmin={isAdmin} isOffice={can('media.manage')}><SermonsManager /></RequireRole>} />
            <Route path="/admin/voice-recordings" element={<RequireRole allow={[]} isAdmin={isAdmin}><VoiceRecordings /></RequireRole>} />
            <Route path="/admin/events" element={<RequireRole allow={[]} isAdmin={isAdmin}><EventsManager /></RequireRole>} />
            <Route path="/admin/notices" element={<RequireRole allow={[]} isAdmin={isAdmin}><NoticesManager /></RequireRole>} />
            <Route path="/admin/gallery" element={<RequireRole allow={['office']} isAdmin={isAdmin} isOffice={can('media.manage')}><GalleryManager /></RequireRole>} />
            <Route path="/admin/tac-id" element={<RequireRole allow={[]} isAdmin={isAdmin}><TacIdSettings /></RequireRole>} />
            <Route path="/admin/chat-wallpapers" element={<RequireRole allow={[]} isAdmin={isAdmin}><ChatWallpaperLibrary /></RequireRole>} />
            <Route path="/admin/chat-reports" element={<RequireRole allow={[]} isAdmin={isAdmin}><ChatReports /></RequireRole>} />
            <Route path="/admin/website" element={<RequireRole allow={['office']} isAdmin={isAdmin} isOffice={can('media.manage')}><WebsiteManager /></RequireRole>} />
            <Route path="/admin/hero" element={<RequireRole allow={['office']} isAdmin={isAdmin} isOffice={can('media.manage')}><HeroSlideshow /></RequireRole>} />
            <Route path="/admin/kin-ai" element={FEATURES.kinAi ? <RequireRole allow={[]} isAdmin={isAdmin}><KinAiSettings /></RequireRole> : <Navigate to="/dashboard" replace />} />
            <Route path="/admin/sms" element={<RequireRole allow={[]} isAdmin={isAdmin}><SmsPush /></RequireRole>} />
            <Route path="/admin/users" element={<RequireRole allow={[]} isAdmin={isAdmin}><UserManagement /></RequireRole>} />
          </Routes>
          </ChatWrap>
          
          <footer className={isChatScreen
            ? 'shrink-0 py-1.5 border-t border-gray-100 dark:border-white/5 bg-white/60 dark:bg-slate-900/60 text-center text-[9px] font-black uppercase tracking-[0.2em] text-gray-400 dark:text-gray-500'
            : 'py-6 border-t border-gray-100 dark:border-white/5 text-center text-[10px] font-black uppercase tracking-[0.2em] text-gray-400 dark:text-gray-500 pb-20 lg:pb-6'}>
            POWERED BY PLUTO-TECH · LEARN BUILD INSPIRE
          </footer>

          {(FEATURES.bible || FEATURES.seekAi) && <FloatingAssistiveTab />}
          <PwaPrompts />
          <LinkedDeviceWatcher />
        </main>

        {/* Mobile Navigation Bar */}
        {!isAdmin && <BottomNav unreadChatCount={chatUnread.total} />}

        {/* Real-time Notification Popup */}
        <AnimatePresence>
          {activeNotification && (
            <motion.div 
              initial={{ opacity: 0, y: 100 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="fixed bottom-24 inset-x-0 flex justify-center z-[100] px-4 pointer-events-none"
            >
               <motion.div 
                className="pointer-events-auto bg-tac-blue-dark text-white p-5 rounded-3xl shadow-2xl border border-white/10 flex flex-col gap-3 relative overflow-hidden group w-full max-w-[400px]"
                whileHover={{ scale: 1.02 }}
               >
                  <div className="absolute top-0 left-0 w-1 h-full bg-tac-red" />
                  
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-2 text-tac-red font-black text-[10px] uppercase tracking-widest">
                       <Bell size={14} className="animate-swing" />
                       New Assembly Notice
                    </div>
                    <button 
                      onClick={() => markNotificationSeen(activeNotification.id)}
                      className="p-1 hover:bg-white/10 rounded-full transition-colors"
                    >
                      <X size={18} />
                    </button>
                  </div>

                  <div>
                    <h4 className="text-lg font-black leading-tight mb-1">{activeNotification.title}</h4>
                    <p className="text-xs text-white/60 line-clamp-2 leading-relaxed">{activeNotification.body}</p>
                  </div>

                  <div className="flex items-center gap-2 pt-1">
                    <button 
                      onClick={() => {
                        markNotificationSeen(activeNotification.id);
                        navigate('/dashboard/notifications');
                      }}
                      className="text-[10px] font-black uppercase tracking-widest bg-white text-tac-blue-dark px-4 py-2 rounded-xl transition-transform active:scale-95"
                    >
                      Read Full Notice
                    </button>
                    <button 
                      onClick={() => markNotificationSeen(activeNotification.id)}
                      className="text-[10px] font-black uppercase tracking-widest text-white/40 hover:text-white px-4 py-2 transition-colors"
                    >
                      Dismiss
                    </button>
                  </div>
               </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};

const NavGroup: React.FC<{ title: string; children: React.ReactNode }> = ({ title, children }) => (
  <div className="mb-6">
    <h4 className="text-[10px] font-black uppercase text-white/20 tracking-[0.2em] mb-3 ml-3">{title}</h4>
    <nav className="space-y-1">
      {children}
    </nav>
  </div>
);

const NavItem: React.FC<{ to: string; icon: React.ReactNode; label: string; active?: boolean; badge?: string; onClick?: () => void }> = ({ to, icon, label, active, badge, onClick }) => (
  <Link 
    to={to}
    onClick={onClick}
    className={`flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-bold transition-all group ${active ? 'bg-white text-tac-blue-dark shadow-xl' : 'text-white/50 hover:bg-white/5 hover:text-white'}`}
  >
    <span className={`${active ? 'text-tac-red' : 'group-hover:text-white transition-colors'}`}>{icon}</span>
    <span className="flex-1">{label}</span>
    {badge && <span className="px-2 py-0.5 bg-tac-red text-white text-[9px] rounded-full font-black shadow-lg animate-bounce">{badge}</span>}
  </Link>
);

export default Dashboard;
