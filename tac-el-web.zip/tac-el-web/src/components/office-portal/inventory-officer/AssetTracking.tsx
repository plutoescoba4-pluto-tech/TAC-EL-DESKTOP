import React, { useState, useEffect } from 'react';
import { officesService, ChurchAsset } from '../../../services/officesService';
import { Package, Plus, Search, CheckCircle2, ShieldCheck, MapPin, Wrench } from 'lucide-react';
import { Card, Button, Badge } from '../../ui';

export const AssetTracking: React.FC = () => {
  const [assets, setAssets] = useState<ChurchAsset[]>([]);
  const [search, setSearch] = useState('');
  const [showAdd, setShowAdd] = useState(false);
  const [name, setName] = useState('');
  const [category, setCategory] = useState<ChurchAsset['category']>('audio_visual');
  const [location, setLocation] = useState('Sanctuary Main Stage');
  const [condition, setCondition] = useState<ChurchAsset['condition']>('excellent');
  const [valueGhs, setValueGhs] = useState('');
  const [saving, setSaving] = useState(false);

  const loadAssets = async () => {
    const list = await officesService.getAssets();
    setAssets(list);
  };

  useEffect(() => {
    loadAssets();
  }, []);

  const handleAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    setSaving(true);
    try {
      await officesService.addAsset({
        name: name.trim(),
        category,
        location,
        condition,
        valueGhs: parseFloat(valueGhs || '0')
      });

      setName('');
      setValueGhs('');
      setShowAdd(false);
      await loadAssets();
    } finally {
      setSaving(false);
    }
  };

  const filtered = assets.filter(a => 
    a.name.toLowerCase().includes(search.toLowerCase()) ||
    a.location.toLowerCase().includes(search.toLowerCase())
  );

  const totalAssetValue = assets.reduce((acc, a) => acc + (a.valueGhs || 0), 0);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-xl font-black text-tac-blue-dark dark:text-white uppercase tracking-tight">
            Church Asset & Equipment Tracking
          </h2>
          <p className="text-xs text-[var(--Sub)]">
            Registry of sanctuary equipment, audio gear, vehicles, and physical properties
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="bg-tac-blue/10 dark:bg-white/5 border border-tac-blue/20 px-4 py-2 rounded-2xl">
            <span className="text-[10px] font-black uppercase text-tac-blue block">Total Property Valuation</span>
            <span className="text-lg font-black text-tac-blue-dark dark:text-white">GH₵ {totalAssetValue.toLocaleString()}</span>
          </div>
          <Button
            variant="primary"
            onClick={() => setShowAdd(!showAdd)}
            icon={<Plus size={16} />}
          >
            {showAdd ? 'Cancel' : 'Register Asset'}
          </Button>
        </div>
      </div>

      <div className="flex items-center gap-3 bg-white dark:bg-slate-900 border border-[var(--Bdr)] rounded-2xl px-4 py-3">
        <Search size={18} className="text-gray-400" />
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search assets by name or location..."
          className="bg-transparent border-none outline-none text-sm text-[var(--Text)] dark:text-white font-medium w-full"
        />
      </div>

      {showAdd && (
        <Card className="animate-fadeIn border-tac-blue">
          <h3 className="text-sm font-black uppercase tracking-wider text-tac-blue-dark dark:text-white mb-4">
            Register Church Asset
          </h3>

          <form onSubmit={handleAdd} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
                  Asset Name & Model
                </label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Yamaha Grand Piano"
                  className="w-full px-4 py-2.5 bg-gray-50 dark:bg-slate-800 border border-[var(--Bdr)] rounded-2xl text-sm font-bold outline-none"
                />
              </div>

              <div>
                <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
                  Category
                </label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value as any)}
                  className="w-full px-4 py-2.5 bg-gray-50 dark:bg-slate-800 border border-[var(--Bdr)] rounded-2xl text-sm font-bold outline-none"
                >
                  <option value="audio_visual">Audio / Visual & Media</option>
                  <option value="instrument">Musical Instruments</option>
                  <option value="furniture">Furniture & Pews</option>
                  <option value="vehicle">Church Minibus / Vehicle</option>
                  <option value="property">Sanctuary Fixtures & Property</option>
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
                  Location / Room
                </label>
                <input
                  type="text"
                  required
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  placeholder="e.g. Sanctuary Main Stage"
                  className="w-full px-4 py-2.5 bg-gray-50 dark:bg-slate-800 border border-[var(--Bdr)] rounded-2xl text-sm outline-none"
                />
              </div>

              <div>
                <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
                  Current Condition
                </label>
                <select
                  value={condition}
                  onChange={(e) => setCondition(e.target.value as any)}
                  className="w-full px-4 py-2.5 bg-gray-50 dark:bg-slate-800 border border-[var(--Bdr)] rounded-2xl text-sm font-bold outline-none"
                >
                  <option value="excellent">Excellent Condition</option>
                  <option value="good">Good Working Condition</option>
                  <option value="fair">Fair (Routine wear)</option>
                  <option value="needs_repair">Needs Repair / Servicing</option>
                  <option value="retired">Retired / Decommissioned</option>
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
                  Estimated Value (GH₵)
                </label>
                <input
                  type="number"
                  value={valueGhs}
                  onChange={(e) => setValueGhs(e.target.value)}
                  placeholder="e.g. 15000"
                  className="w-full px-4 py-2.5 bg-gray-50 dark:bg-slate-800 border border-[var(--Bdr)] rounded-2xl text-sm outline-none"
                />
              </div>
            </div>

            <div className="flex justify-end gap-3 pt-2">
              <Button type="button" variant="ghost" onClick={() => setShowAdd(false)}>
                Cancel
              </Button>
              <Button type="submit" variant="primary" loading={saving}>
                Add to Inventory
              </Button>
            </div>
          </form>
        </Card>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filtered.map((asset) => (
          <Card key={asset.id}>
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-tac-blue/10 text-tac-blue flex items-center justify-center shrink-0">
                  <Package size={22} />
                </div>
                <div>
                  <h4 className="font-bold text-sm text-tac-blue-dark dark:text-white uppercase">{asset.name}</h4>
                  <p className="text-[11px] text-[var(--Sub)] flex items-center gap-1 mt-0.5">
                    <MapPin size={12} />
                    {asset.location}
                  </p>
                </div>
              </div>
              <Badge variant={asset.condition === 'excellent' ? 'green' : asset.condition === 'good' ? 'blue' : 'amber'}>
                {asset.condition.replace('_', ' ')}
              </Badge>
            </div>

            <div className="mt-4 pt-3 border-t border-[var(--Bdr)] flex items-center justify-between text-xs">
              <span className="uppercase text-[10px] font-bold text-gray-400">{asset.category.replace('_', ' ')}</span>
              <span className="font-mono font-black text-tac-blue-dark dark:text-white">
                GH₵ {asset.valueGhs?.toLocaleString()}
              </span>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
};
export default AssetTracking;
