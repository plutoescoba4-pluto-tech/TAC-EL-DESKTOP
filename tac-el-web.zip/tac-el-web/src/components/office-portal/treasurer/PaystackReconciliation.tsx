import React, { useEffect, useState } from 'react';
import { supabase } from '../../../supabase';
import { CreditCard, Smartphone, CheckCircle2, RefreshCw, Search, Download, AlertCircle } from 'lucide-react';
import { Card, Button, Badge } from '../../ui';

interface PaystackLog {
  ref: string;
  donor: string;
  type: string;
  channel: string;
  amount: number;
  status: 'settled' | 'pending' | 'reversed';
  date: string;
}

/** Real online payments only: giving_transactions rows that came through
 *  Paystack (mobile money / card). Cash and manual bank entries are excluded. */
async function loadPaystackLogs(): Promise<PaystackLog[]> {
  const { data, error } = await supabase
    .from('giving_transactions')
    .select('id, amount, method, momo_provider, paystack_reference, status, created_at, funds(name), profiles(full_name)')
    .in('method', ['momo', 'card'])
    .order('created_at', { ascending: false })
    .limit(200);
  if (error) throw error;
  return (data ?? []).map((r: any) => ({
    ref: r.paystack_reference || r.id,
    donor: r.profiles?.full_name || 'Guest',
    type: (r.funds?.name || '').toLowerCase(),
    channel: r.method === 'card' ? 'Card' : r.momo_provider ? `${r.momo_provider} MoMo` : 'Mobile Money',
    amount: Number(r.amount),
    status: r.status === 'success' ? 'settled' : r.status === 'failed' ? 'reversed' : 'pending',
    date: new Date(r.created_at).toLocaleString('en-GB', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' }),
  }));
}

export const PaystackReconciliation: React.FC = () => {
  const [logs, setLogs] = useState<PaystackLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);

  useEffect(() => {
    loadPaystackLogs()
      .then(setLogs)
      .catch((e) => setLoadError(e?.message || 'Could not load payments.'))
      .finally(() => setLoading(false));
  }, []);

  const [search, setSearch] = useState('');

  const totalSettled = logs.filter(l => l.status === 'settled').reduce((a, b) => a + b.amount, 0);
  const q = search.trim().toLowerCase();
  const shown = q ? logs.filter(l => (l.ref + l.donor + l.type + l.channel).toLowerCase().includes(q)) : logs;

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-xl font-black text-tac-blue-dark dark:text-white uppercase tracking-tight">
            Paystack & Mobile Money Reconciliation
          </h2>
          <p className="text-xs text-[var(--Sub)]">
            Verify automated digital collections, fees, and bank settlement batches
          </p>
        </div>

        <div className="bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800 px-4 py-2 rounded-2xl">
          <span className="text-[10px] font-black uppercase text-emerald-600 block">Settled (Gross)</span>
          <span className="text-lg font-black text-emerald-700 dark:text-emerald-400">GH₵ {totalSettled.toFixed(2)}</span>
        </div>
      </div>

      <Card>
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-xs font-black uppercase tracking-wider text-tac-blue-dark dark:text-white">
            Settlement Logs ({logs.length} Transactions)
          </h3>
          <Badge variant={loadError ? 'amber' : 'green'}>{loadError ? 'Could not load' : 'Live from database'}</Badge>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-gray-50 dark:bg-white/5 text-gray-500 font-black uppercase tracking-wider">
              <tr>
                <th className="p-3">Reference</th>
                <th className="p-3">Donor / Member</th>
                <th className="p-3">Channel</th>
                <th className="p-3">Gross (GH₵)</th>
                                <th className="p-3">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[var(--Bdr)]">
              {shown.map((log) => (
                <tr key={log.ref} className="hover:bg-gray-50/50 dark:hover:bg-white/5">
                  <td className="p-3 font-mono font-bold text-tac-blue">{log.ref}</td>
                  <td className="p-3 font-bold text-[var(--Text)] dark:text-white">
                    {log.donor}
                    <span className="block text-[10px] text-gray-400 uppercase font-semibold">{log.type}</span>
                  </td>
                  <td className="p-3 text-[var(--Sub)]">{log.channel}</td>
                  <td className="p-3 font-mono">GH₵ {log.amount.toFixed(2)}</td>
                  <td className="p-3">
                    <Badge variant={log.status === 'settled' ? 'green' : 'amber'}>
                      {log.status.toUpperCase()}
                    </Badge>
                  </td>
                </tr>
              ))}
              {!loading && shown.length === 0 && (
                <tr><td colSpan={5} className="p-6 text-center text-[var(--Sub)]">
                  {loadError ? loadError : 'No online (Mobile Money / card) payments yet.'}
                </td></tr>
              )}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
};
export default PaystackReconciliation;
