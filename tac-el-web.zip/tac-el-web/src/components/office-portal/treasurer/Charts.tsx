import React from 'react';
import { BarChart3, PieChart, TrendingUp } from 'lucide-react';
import { Card, Badge } from '../../ui';

export const Charts: React.FC = () => {
  const breakdown = [
    { label: 'Tithes', pct: 54, color: 'bg-tac-blue', amount: 'GH₵ 24,500' },
    { label: 'Sunday Offerings', pct: 28, color: 'bg-emerald-500', amount: 'GH₵ 12,800' },
    { label: 'Welfare & Benevolence', pct: 10, color: 'bg-amber-500', amount: 'GH₵ 4,600' },
    { label: 'Building Project Pledge', pct: 8, color: 'bg-tac-red', amount: 'GH₵ 3,900' }
  ];

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-black text-tac-blue-dark dark:text-white uppercase tracking-tight">
          Treasury Financial Charts & Breakdown
        </h2>
        <p className="text-xs text-[var(--Sub)]">
          Visual distribution of revenue streams and assembly collections
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-xs font-black uppercase tracking-wider text-tac-blue-dark dark:text-white flex items-center gap-1.5">
              <PieChart size={16} className="text-tac-blue" />
              Revenue Share Allocation
            </h3>
            <Badge variant="blue">Current Quarter</Badge>
          </div>

          <div className="space-y-4">
            {breakdown.map((item, idx) => (
              <div key={idx} className="space-y-1.5">
                <div className="flex justify-between text-xs font-bold">
                  <span className="text-[var(--Text)] dark:text-white">{item.label}</span>
                  <span className="text-gray-400">{item.amount} ({item.pct}%)</span>
                </div>
                <div className="w-full h-3 bg-gray-100 dark:bg-white/10 rounded-full overflow-hidden">
                  <div className={`h-full ${item.color} rounded-full`} style={{ width: `${item.pct}%` }} />
                </div>
              </div>
            ))}
          </div>
        </Card>

        <Card>
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-xs font-black uppercase tracking-wider text-tac-blue-dark dark:text-white flex items-center gap-1.5">
              <TrendingUp size={16} className="text-emerald-500" />
              6-Month Giving Growth
            </h3>
            <Badge variant="green">+14.2% YoY</Badge>
          </div>

          <div className="h-48 flex items-end justify-between gap-2 pt-8">
            {[
              { m: 'Nov', val: 60 },
              { m: 'Dec', val: 95 },
              { m: 'Jan', val: 70 },
              { m: 'Feb', val: 78 },
              { m: 'Mar', val: 88 },
              { m: 'Apr', val: 92 }
            ].map((col, idx) => (
              <div key={idx} className="flex-1 flex flex-col items-center gap-2">
                <div
                  className="w-full bg-tac-blue/80 hover:bg-tac-blue rounded-t-xl transition-all"
                  style={{ height: `${col.val}%` }}
                />
                <span className="text-[10px] font-black uppercase text-gray-400">{col.m}</span>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
};
export default Charts;
