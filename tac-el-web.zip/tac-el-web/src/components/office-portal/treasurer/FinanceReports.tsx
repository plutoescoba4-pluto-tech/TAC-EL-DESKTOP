import React, { useState } from 'react';
import { FileText, Download, Filter, Calendar } from 'lucide-react';
import { Card, Button, Badge } from '../../ui';

export const FinanceReports: React.FC = () => {
  const [period, setPeriod] = useState<'monthly' | 'quarterly' | 'annual'>('monthly');

  const lineItems = [
    { category: 'Tithe Remittances to Area', budget: 15000, actual: 16200, variance: 1200 },
    { category: 'Sanctuary Utilities & Power (ECG/Water)', budget: 3500, actual: 3100, variance: -400 },
    { category: 'Honorarium & Guest Ministers', budget: 2500, actual: 2000, variance: -500 },
    { category: 'Welfare & Hospital Visits', budget: 2000, actual: 2350, variance: 350 },
    { category: 'Media & Streaming Internet Bandwidth', budget: 1200, actual: 1100, variance: -100 }
  ];

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-xl font-black text-tac-blue-dark dark:text-white uppercase tracking-tight">
            Treasury Financial Reports
          </h2>
          <p className="text-xs text-[var(--Sub)]">
            Budget variance, operating expense breakdowns, and statutory audit statements
          </p>
        </div>

        <div className="flex gap-2">
          {(['monthly', 'quarterly', 'annual'] as const).map((p) => (
            <button
              key={p}
              onClick={() => setPeriod(p)}
              className={`px-3 py-1.5 rounded-xl text-xs font-black uppercase transition-all ${
                period === p
                  ? 'bg-tac-blue text-white shadow-md'
                  : 'bg-gray-100 dark:bg-white/5 text-[var(--Sub)] hover:text-tac-blue'
              }`}
            >
              {p}
            </button>
          ))}
        </div>
      </div>

      <Card>
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-xs font-black uppercase tracking-wider text-tac-blue-dark dark:text-white">
            Expenditure Budget vs Actual ({period.toUpperCase()})
          </h3>
          <Badge variant="blue">General Fund</Badge>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-gray-50 dark:bg-white/5 text-gray-500 font-black uppercase tracking-wider">
              <tr>
                <th className="p-3">Expense Head</th>
                <th className="p-3">Budgeted (GH₵)</th>
                <th className="p-3">Actual Spent (GH₵)</th>
                <th className="p-3">Variance (GH₵)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[var(--Bdr)]">
              {lineItems.map((item, idx) => (
                <tr key={idx} className="hover:bg-gray-50/50 dark:hover:bg-white/5">
                  <td className="p-3 font-bold text-tac-blue-dark dark:text-white">{item.category}</td>
                  <td className="p-3 font-mono">GH₵ {item.budget.toFixed(2)}</td>
                  <td className="p-3 font-mono font-bold">GH₵ {item.actual.toFixed(2)}</td>
                  <td className={`p-3 font-mono font-bold ${item.variance > 0 ? 'text-red-500' : 'text-emerald-500'}`}>
                    {item.variance > 0 ? `+GH₵ ${item.variance}` : `-GH₵ ${Math.abs(item.variance)}`}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
};
export default FinanceReports;
