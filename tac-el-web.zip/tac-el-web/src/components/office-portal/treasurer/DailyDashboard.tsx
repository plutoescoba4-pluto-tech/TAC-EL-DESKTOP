import React, { useState, useEffect } from 'react';
import { givingService, ensureFundExists } from '../../../services/givingService';
import { officesService } from '../../../services/officesService';
import { useAuth } from '../../../context/AuthContext';
import { Donation } from '../../../types';
import { DollarSign, TrendingUp, TrendingDown, Calendar, CreditCard, ShieldCheck, Download, Plus } from 'lucide-react';
import { Card, Button, Badge } from '../../ui';

// Welfare and Seed Offering aren't in the schema's seeded funds (only
// Tithe/Offering/Building Fund/Missions/Thanksgiving) — created on first use
// below via ensureFundExists (admin-only to create; works fine to just read
// once an admin has opened this screen a single time).
const FUND_OPTIONS = ['Tithe', 'Offering', 'Welfare', 'Seed Offering', 'Building Fund', 'Missions', 'Thanksgiving'] as const;

export const DailyDashboard: React.FC = () => {
  const { profile } = useAuth();
  const [donations, setDonations] = useState<Donation[]>([]);
  const [loading, setLoading] = useState(true);
  const [entryFund, setEntryFund] = useState<typeof FUND_OPTIONS[number]>('Tithe');
  const [entryAmount, setEntryAmount] = useState('');
  const [entryNote, setEntryNote] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [entryError, setEntryError] = useState<string | null>(null);
  const [entrySuccess, setEntrySuccess] = useState(false);

  const loadDonations = () => {
    givingService.getAllDonations().then((all) => {
      setDonations(all);
      setLoading(false);
    });
  };

  useEffect(() => {
    loadDonations();
    // Self-heals the two missing funds once, if this session is an admin —
    // harmless no-op for everyone else since it just reads first.
    if (profile?.role === 'admin') {
      ensureFundExists('Welfare').catch(() => {});
      ensureFundExists('Seed Offering').catch(() => {});
    }
  }, [profile?.role]);

  const handleRecordEntry = async () => {
    const amount = parseFloat(entryAmount);
    if (!amount || amount <= 0) {
      setEntryError('Enter a valid amount greater than zero.');
      return;
    }
    setSubmitting(true);
    setEntryError(null);
    setEntrySuccess(false);
    try {
      // Make sure the fund exists first (Welfare/Seed Offering aren't in
      // the seeded funds) so a missing fund fails loudly instead of the
      // entry being filed under the wrong one.
      await ensureFundExists(entryFund);
      await givingService.recordDonation({
        userId: 'guest',
        userName: entryNote.trim() || `Service Count — ${entryFund}`,
        date: new Date().toISOString(),
        amount,
        type: entryFund,
        channel: 'cash',
      });
      setEntryAmount('');
      setEntryNote('');
      setEntrySuccess(true);
      setTimeout(() => setEntrySuccess(false), 3000);
      loadDonations();
    } catch (err: any) {
      setEntryError(err?.message || 'Could not record this entry. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  const totalTithes = donations.filter(d => d.type === 'tithe').reduce((a, b) => a + (b.amount || 0), 0);
  const totalOfferings = donations.filter(d => d.type === 'offering').reduce((a, b) => a + (b.amount || 0), 0);
  const totalWelfare = donations.filter(d => d.type === 'welfare').reduce((a, b) => a + (b.amount || 0), 0);
  // Everything else (seed, building fund, missions, thanksgiving) — still
  // part of total intake even though it isn't broken out in its own card.
  const totalOther = donations.filter(d => !['tithe', 'offering', 'welfare'].includes(d.type)).reduce((a, b) => a + (b.amount || 0), 0);
  const grandTotal = totalTithes + totalOfferings + totalWelfare + totalOther;

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-xl font-black text-tac-blue-dark dark:text-white uppercase tracking-tight">
            Treasurer Daily Financial Register
          </h2>
          <p className="text-xs text-[var(--Sub)]">
            Daily treasury intake, offering tallies, and banking reconciliation
          </p>
        </div>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <Card className="text-center p-4 bg-emerald-50/50 dark:bg-emerald-950/20 border-emerald-200/50">
          <span className="text-[10px] font-black uppercase text-emerald-600">Total Treasury Intake</span>
          <p className="text-2xl font-black text-emerald-700 dark:text-emerald-400 mt-1">GH₵ {grandTotal.toFixed(2)}</p>
        </Card>
        <Card className="text-center p-4">
          <span className="text-[10px] font-black uppercase text-gray-400">Total Tithes</span>
          <p className="text-2xl font-black text-tac-blue mt-1">GH₵ {totalTithes.toFixed(2)}</p>
        </Card>
        <Card className="text-center p-4">
          <span className="text-[10px] font-black uppercase text-gray-400">Divine Offerings</span>
          <p className="text-2xl font-black text-tac-blue-dark dark:text-white mt-1">GH₵ {totalOfferings.toFixed(2)}</p>
        </Card>
        <Card className="text-center p-4">
          <span className="text-[10px] font-black uppercase text-gray-400">Welfare & Needy</span>
          <p className="text-2xl font-black text-amber-600 mt-1">GH₵ {totalWelfare.toFixed(2)}</p>
        </Card>
      </div>

      <Card>
        <h3 className="text-xs font-black uppercase tracking-wider text-tac-blue-dark dark:text-white mb-1">
          Record Today's Count
        </h3>
        <p className="text-[11px] text-[var(--Sub)] mb-4">
          Enter the totals counted after service — tithes, offerings, welfare, seed and the rest — straight into the register.
        </p>

        {entrySuccess && (
          <div className="mb-3 p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/30 text-emerald-700 dark:text-emerald-400 text-xs font-bold">
            Entry recorded in the register.
          </div>
        )}
        {entryError && (
          <div className="mb-3 p-3 rounded-xl bg-red-50 dark:bg-red-950/30 text-tac-red text-xs font-medium flex items-start justify-between gap-3">
            <span>{entryError}</span>
            <button onClick={() => setEntryError(null)} className="shrink-0 text-[10px] font-black uppercase opacity-70 hover:opacity-100">Dismiss</button>
          </div>
        )}

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 min-w-0">
          <div className="min-w-0">
            <label className="text-[10px] font-black uppercase tracking-widest text-gray-400 mb-1 block">Fund</label>
            <select
              value={entryFund}
              onChange={(e) => setEntryFund(e.target.value as typeof FUND_OPTIONS[number])}
              className="w-full min-w-0 max-w-full box-border bg-gray-50 dark:bg-slate-800 border border-[var(--Bdr)] rounded-xl px-3 py-2.5 text-sm outline-none focus:border-tac-blue"
            >
              {FUND_OPTIONS.map((f) => <option key={f} value={f}>{f}</option>)}
            </select>
          </div>
          <div className="min-w-0">
            <label className="text-[10px] font-black uppercase tracking-widest text-gray-400 mb-1 block">Amount (GH₵)</label>
            <input
              type="number"
              inputMode="decimal"
              min="0"
              step="0.01"
              value={entryAmount}
              onChange={(e) => setEntryAmount(e.target.value)}
              placeholder="0.00"
              className="w-full min-w-0 max-w-full box-border bg-gray-50 dark:bg-slate-800 border border-[var(--Bdr)] rounded-xl px-3 py-2.5 text-sm outline-none focus:border-tac-blue"
            />
          </div>
          <div className="min-w-0">
            <label className="text-[10px] font-black uppercase tracking-widest text-gray-400 mb-1 block">Note (optional)</label>
            <input
              type="text"
              value={entryNote}
              onChange={(e) => setEntryNote(e.target.value)}
              placeholder="e.g. Sunday 1st service"
              className="w-full min-w-0 max-w-full box-border bg-gray-50 dark:bg-slate-800 border border-[var(--Bdr)] rounded-xl px-3 py-2.5 text-sm outline-none focus:border-tac-blue"
            />
          </div>
        </div>

        <Button
          onClick={handleRecordEntry}
          loading={submitting}
          icon={<Plus size={14} />}
          className="mt-4 w-full sm:w-auto"
        >
          Record Entry
        </Button>
      </Card>

      <Card>
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-xs font-black uppercase tracking-wider text-tac-blue-dark dark:text-white">
            Daily Intake Ledger ({donations.length} Entries)
          </h3>
          <Badge variant="blue">Audited Flow</Badge>
        </div>

        <div className="divide-y divide-[var(--Bdr)] max-h-96 overflow-y-auto">
          {donations.length === 0 ? (
            <p className="py-8 text-center text-xs text-[var(--Sub)]">No recorded receipts for this cycle.</p>
          ) : (
            donations.map((d) => (
              <div key={d.id} className="py-3 flex items-center justify-between gap-3 text-xs">
                <div>
                  <p className="font-bold text-tac-blue-dark dark:text-white uppercase">{d.type}</p>
                  <p className="text-[10px] text-gray-400">{d.userName} · {d.date}</p>
                </div>
                <span className="font-mono font-black text-emerald-600">GH₵ {d.amount?.toFixed(2)}</span>
              </div>
            ))
          )}
        </div>
      </Card>
    </div>
  );
};
export default DailyDashboard;
