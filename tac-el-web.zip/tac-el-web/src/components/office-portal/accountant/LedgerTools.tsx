import React, { useState, useEffect } from 'react';
import { officesService, LedgerEntry } from '../../../services/officesService';
import { useAuth } from '../../../context/AuthContext';
import { BookOpen, Plus, Trash2, ArrowUpRight, ArrowDownLeft, FileText, Check } from 'lucide-react';
import { Card, Button, Badge } from '../../ui';

export const LedgerTools: React.FC = () => {
  const { profile } = useAuth();
  const [entries, setEntries] = useState<LedgerEntry[]>([]);
  const [showAdd, setShowAdd] = useState(false);
  const [type, setType] = useState<'income' | 'expense'>('expense');
  const [category, setCategory] = useState<LedgerEntry['category']>('utilities');
  const [amount, setAmount] = useState('');
  const [description, setDescription] = useState('');
  const [voucherNumber, setVoucherNumber] = useState('');
  const [saving, setSaving] = useState(false);

  const loadEntries = async () => {
    const list = await officesService.getLedgerEntries();
    setEntries(list);
  };

  useEffect(() => {
    loadEntries();
  }, []);

  const handleAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    const num = parseFloat(amount);
    if (!num || !description.trim()) return;

    setSaving(true);
    try {
      await officesService.addLedgerEntry({
        type,
        category,
        amount: num,
        description: description.trim(),
        date: new Date().toISOString().split('T')[0],
        recordedBy: profile?.name || 'Accountant',
        voucherNumber: voucherNumber.trim() || `PV-${Date.now().toString().slice(-4)}`
      });

      setAmount('');
      setDescription('');
      setVoucherNumber('');
      setShowAdd(false);
      await loadEntries();
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (confirm('Delete this ledger voucher?')) {
      await officesService.deleteLedgerEntry(id);
      await loadEntries();
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-xl font-black text-tac-blue-dark dark:text-white uppercase tracking-tight">
            Accountant Ledger Tools
          </h2>
          <p className="text-xs text-[var(--Sub)]">
            Record journal entries, payment vouchers (PV), and financial transactions
          </p>
        </div>

        <Button
          variant="primary"
          onClick={() => setShowAdd(!showAdd)}
          icon={<Plus size={16} />}
        >
          {showAdd ? 'Cancel' : 'New Journal Voucher'}
        </Button>
      </div>

      {showAdd && (
        <Card className="animate-fadeIn border-tac-blue">
          <h3 className="text-sm font-black uppercase tracking-wider text-tac-blue-dark dark:text-white mb-4">
            Record Ledger Transaction
          </h3>

          <form onSubmit={handleAdd} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
                  Entry Nature
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setType('expense')}
                    className={`py-2 rounded-xl text-xs font-black uppercase transition-all ${
                      type === 'expense'
                        ? 'bg-red-500 text-white shadow-sm'
                        : 'bg-gray-100 dark:bg-white/5 text-gray-500'
                    }`}
                  >
                    Expense
                  </button>
                  <button
                    type="button"
                    onClick={() => setType('income')}
                    className={`py-2 rounded-xl text-xs font-black uppercase transition-all ${
                      type === 'income'
                        ? 'bg-emerald-500 text-white shadow-sm'
                        : 'bg-gray-100 dark:bg-white/5 text-gray-500'
                    }`}
                  >
                    Income
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
                  Category
                </label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value as any)}
                  className="w-full px-4 py-2.5 bg-gray-50 dark:bg-slate-800 border border-[var(--Bdr)] rounded-2xl text-sm font-bold outline-none"
                >
                  <option value="utilities">Utilities & Power</option>
                  <option value="honorarium">Honorarium & Guest Ministers</option>
                  <option value="maintenance">Sanctuary Maintenance</option>
                  <option value="welfare">Welfare & Needy Support</option>
                  <option value="building_project">Building Project</option>
                  <option value="tithes">Tithes</option>
                  <option value="offerings">Offerings</option>
                  <option value="other">Other</option>
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
                  Amount (GH₵)
                </label>
                <input
                  type="number"
                  step="any"
                  required
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  placeholder="0.00"
                  className="w-full px-4 py-2.5 bg-gray-50 dark:bg-slate-800 border border-[var(--Bdr)] rounded-2xl text-sm font-bold outline-none font-mono"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
                  Voucher / PV Reference
                </label>
                <input
                  type="text"
                  value={voucherNumber}
                  onChange={(e) => setVoucherNumber(e.target.value)}
                  placeholder="e.g. PV-2026-081"
                  className="w-full px-4 py-2.5 bg-gray-50 dark:bg-slate-800 border border-[var(--Bdr)] rounded-2xl text-sm outline-none"
                />
              </div>

              <div>
                <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
                  Description / Narration
                </label>
                <input
                  type="text"
                  required
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="e.g. ECG electricity payment for sanctuary"
                  className="w-full px-4 py-2.5 bg-gray-50 dark:bg-slate-800 border border-[var(--Bdr)] rounded-2xl text-sm outline-none"
                />
              </div>
            </div>

            <div className="flex justify-end gap-3 pt-2">
              <Button type="button" variant="ghost" onClick={() => setShowAdd(false)}>
                Cancel
              </Button>
              <Button type="submit" variant="primary" loading={saving}>
                Save Ledger Entry
              </Button>
            </div>
          </form>
        </Card>
      )}

      <Card>
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-xs font-black uppercase tracking-wider text-tac-blue-dark dark:text-white">
            General Ledger Journal ({entries.length} Records)
          </h3>
          <Badge variant="blue">General Journal</Badge>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-gray-50 dark:bg-white/5 text-gray-500 font-black uppercase tracking-wider">
              <tr>
                <th className="p-3">Date</th>
                <th className="p-3">Voucher</th>
                <th className="p-3">Narration / Account</th>
                <th className="p-3">Category</th>
                <th className="p-3 text-right">Amount (GH₵)</th>
                <th className="p-3 text-center">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[var(--Bdr)]">
              {entries.length === 0 ? (
                <tr>
                  <td colSpan={6} className="p-6 text-center text-gray-400">
                    No ledger entries created yet.
                  </td>
                </tr>
              ) : (
                entries.map((entry) => (
                  <tr key={entry.id} className="hover:bg-gray-50/50 dark:hover:bg-white/5">
                    <td className="p-3 text-gray-400">{entry.date}</td>
                    <td className="p-3 font-mono font-bold text-tac-blue">{entry.voucherNumber || 'PV'}</td>
                    <td className="p-3 font-bold text-[var(--Text)] dark:text-white">{entry.description}</td>
                    <td className="p-3 uppercase text-[10px] text-gray-400 font-bold">{entry.category}</td>
                    <td className={`p-3 font-mono font-bold text-right ${entry.type === 'income' ? 'text-emerald-500' : 'text-red-500'}`}>
                      {entry.type === 'income' ? '+' : '-'}GH₵ {entry.amount.toFixed(2)}
                    </td>
                    <td className="p-3 text-center">
                      <button
                        onClick={() => handleDelete(entry.id)}
                        className="text-gray-400 hover:text-red-500 p-1"
                      >
                        <Trash2 size={14} />
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
};
export default LedgerTools;
