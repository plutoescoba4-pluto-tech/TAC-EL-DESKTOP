import { supabase } from '../supabase';
import type { RealtimeChannel } from '@supabase/supabase-js';

/**
 * Ephemeral presence (typing/recording indicators, live-voice-room participant
 * lists, "who's online right now"). Nothing is written to a table — state
 * lives only in the Realtime server for as long as the channel is open, and
 * clears automatically the instant a client disconnects. This replaces the
 * old Firestore `presence` collection and per-keystroke doc writes.
 *
 * Usage:
 *   const { channel, unsubscribe } = subscribePresence('chat:global', { key: uid, meta: { name, typing: false } }, (state) => { ... });
 *   channel.track({ name, typing: true });   // update your own presence
 *   unsubscribe();                            // on cleanup
 */
export function subscribePresence<T extends Record<string, any>>(
  channelName: string,
  self: { key: string; meta: T } | null,
  onChange: (state: Record<string, T[]>) => void
): { channel: RealtimeChannel; unsubscribe: () => void } {
  const channel = supabase.channel(channelName, {
    config: { presence: self ? { key: self.key } : undefined },
  });

  channel.on('presence', { event: 'sync' }, () => {
    onChange(channel.presenceState<T>() as unknown as Record<string, T[]>);
  });

  channel.subscribe(async (status) => {
    if (status === 'SUBSCRIBED' && self) {
      await channel.track(self.meta);
    }
  });

  return {
    channel,
    unsubscribe: () => {
      supabase.removeChannel(channel);
    },
  };
}

interface SubscribeQueryOptions {
  table: string;
  /** Simple equality filters, e.g. { sender_id: uid } */
  match?: Record<string, string | number | boolean>;
  orderBy?: { column: string; ascending?: boolean };
  limit?: number;
  select?: string;
  /** Raw PostgREST `or` filter, e.g. "and(a.eq.1,b.eq.2),and(a.eq.2,b.eq.1)" */
  or?: string;
}

// Every subscription gets its OWN channel. supabase.channel(name) returns the
// already-existing channel when the name repeats, and adding a listener to an
// already-subscribed channel throws; removing it would also silently kill the
// other subscriber. A unique suffix avoids both problems.
let queryChannelSeq = 0;

/**
 * Behaves like Firestore's onSnapshot(query, cb): runs the query immediately,
 * calls back with the full row set, then re-runs it (and calls back again)
 * whenever any row in the table changes. Returns a plain () => void, so
 * existing `const unsub = subscribeX(...); return () => unsub();` component
 * cleanup code needs no restructuring.
 *
 * Simple and correct rather than maximally efficient: every change triggers
 * one refetch instead of patching the array client-side. Fine at this app's
 * scale; worth optimizing later only if a specific list gets hot.
 */
export function subscribeQuery<T = any>(
  opts: SubscribeQueryOptions,
  callback: (rows: T[]) => void,
  onError?: (err: unknown) => void
): () => void {
  const { table, match, orderBy, limit, select = '*', or } = opts;

  const runQuery = async () => {
    try {
      let q = supabase.from(table).select(select);
      if (match) {
        for (const [col, val] of Object.entries(match)) {
          q = q.eq(col, val);
        }
      }
      if (or) q = q.or(or);
      if (orderBy) q = q.order(orderBy.column, { ascending: orderBy.ascending ?? true });
      if (limit) q = q.limit(limit);
      const { data, error } = await q;
      if (error) throw error;
      callback((data ?? []) as T[]);
    } catch (err) {
      onError?.(err);
    }
  };

  runQuery();

  const channelName = `table:${table}:${JSON.stringify(match ?? {})}:${++queryChannelSeq}`;
  const channel = supabase
    .channel(channelName)
    .on('postgres_changes', { event: '*', schema: 'public', table }, () => {
      runQuery();
    })
    .subscribe();

  return () => {
    supabase.removeChannel(channel);
  };
}
