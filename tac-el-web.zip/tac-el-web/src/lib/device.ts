import { isDesktopApp } from './desktop';
import { APP_TARGET, isNativeApp } from './target';

/**
 * What kind of device is this?  Phones and tablets are "mobile"; everything else (a Windows, Mac or Linux
 * computer, in the desktop app or in a browser) is a computer.
 * On a computer the app opens with the welcome screen and a code to scan with the phone (like WhatsApp Web).
 * On a phone the person signs in directly, and is the one who scans.
 */
export const isMobileDevice = (): boolean => {
  if (typeof navigator === 'undefined') return false;
  const ua = navigator.userAgent || '';
  if (/android|iphone|ipad|ipod|mobile/i.test(ua)) return true;
  return navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1;   // an iPad pretending to be a Mac
};

/** True in the desktop app and in a browser on a computer. */
export const isComputer = (): boolean => isDesktopApp || !isMobileDevice();

/**
 * What the person should see:
 *   phone            the phone experience (sign in directly, scan to link computers)
 *   computer         the computer experience (welcome screen with a code to scan, or email)
 *   wrong-computer   the PHONE app opened on a computer: point them to TAC-EL Web
 *   wrong-phone      the COMPUTER app opened on a phone: point them to the phone app
 * "Continue anyway" lets anyone (an admin, a tester) use the app they opened.
 */
export type AppFlow = 'phone' | 'computer' | 'wrong-computer' | 'wrong-phone';
const CONTINUE_KEY = 'tac_continue_anyway';

export function appFlow(): AppFlow {
  const mobile = isMobileDevice() || isNativeApp();
  let forced = false;
  try { forced = sessionStorage.getItem(CONTINUE_KEY) === '1'; } catch { /* ignore */ }
  if (APP_TARGET === 'mobile') return mobile || forced ? 'phone' : 'wrong-computer';
  if (APP_TARGET === 'web') return !mobile || forced ? 'computer' : 'wrong-phone';
  return isComputer() ? 'computer' : 'phone';      // development: decided by the device
}

export function continueAnyway() {
  try { sessionStorage.setItem(CONTINUE_KEY, '1'); } catch { /* ignore */ }
  window.location.reload();
}
