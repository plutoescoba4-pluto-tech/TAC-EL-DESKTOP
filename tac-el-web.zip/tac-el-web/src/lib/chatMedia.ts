import { supabase } from '../supabase';
import type { ChatMessage } from '../types';

/**
 * Chat photos, voice notes, videos and files live in the PRIVATE Storage bucket "chat-media",
 * not inside the message rows (which made every chat reload download megabytes of base64).
 *
 *   in the database a message holds   sb:<path>           e.g. sb:3f2…/group/9c1….webp
 *   on screen it becomes              a signed link (valid 6 hours), created below
 *
 * Old messages that still hold a data: URL keep working: anything not starting with "sb:"
 * is shown as it is.
 *
 * Paths:  <sender id>/group/<file>                group chat
 *         <sender id>/dm/<recipient id>/<file>    direct message
 * (the database rules in 06-chat.sql decide who can read which)
 */

const BUCKET = 'chat-media';
const PREFIX = 'sb:';
const SIGN_SECONDS = 6 * 60 * 60;
const REFRESH_BEFORE_MS = 30 * 60 * 1000;

export type MediaScope = { type: 'group' } | { type: 'dm'; recipientId: string };

const EXT: Record<string, string> = {
  'image/jpeg': 'jpg', 'image/png': 'png', 'image/webp': 'webp', 'image/gif': 'gif',
  'video/mp4': 'mp4', 'video/webm': 'webm', 'video/quicktime': 'mov',
  'audio/webm': 'webm', 'audio/ogg': 'ogg', 'audio/mpeg': 'mp3', 'audio/mp4': 'm4a', 'audio/aac': 'aac', 'audio/wav': 'wav',
  'application/pdf': 'pdf',
};

/** Uploads a data: URL to private storage and returns its "sb:" reference.
 *  Anything else (already a reference, a normal link, nothing) is returned unchanged. */
export async function offloadMedia(value: string | undefined, uid: string, scope: MediaScope): Promise<string | undefined> {
  if (!value || !value.startsWith('data:')) return value;
  const blob = await (await fetch(value)).blob();
  const mime = (blob.type || 'application/octet-stream').split(';')[0];
  const ext = EXT[mime] || mime.split('/')[1]?.replace(/[^a-z0-9]/g, '') || 'bin';
  const folder = scope.type === 'group' ? `${uid}/group` : `${uid}/dm/${scope.recipientId}`;
  const path = `${folder}/${crypto.randomUUID()}.${ext}`;
  const { error } = await supabase.storage.from(BUCKET).upload(path, blob, { contentType: mime, upsert: false });
  if (error) throw new Error(`Could not upload the attachment: ${error.message}`);
  return PREFIX + path;
}

const cache = new Map<string, { url: string; exp: number }>();

/** Turns every "sb:" reference in these messages into a signed link (in place). */
export async function resolveChatMedia(msgs: ChatMessage[]): Promise<void> {
  const fields = ['img', 'vid', 'voice', 'audio', 'file'] as const;
  const need = new Set<string>();
  const visit = (v?: string) => {
    if (!v || !v.startsWith(PREFIX)) return;
    const path = v.slice(PREFIX.length);
    const hit = cache.get(path);
    if (!hit || hit.exp - Date.now() < REFRESH_BEFORE_MS) need.add(path);
  };
  for (const m of msgs) {
    fields.forEach((f) => visit(m[f]));
    visit(m.replyTo?.img);
    visit(m.replyTo?.vid);
  }
  if (need.size) {
    const { data, error } = await supabase.storage.from(BUCKET).createSignedUrls([...need], SIGN_SECONDS);
    if (error) console.warn('Could not sign chat media links:', error.message);
    (data ?? []).forEach((d: any) => {
      if (d?.signedUrl && d?.path) cache.set(d.path, { url: d.signedUrl, exp: Date.now() + SIGN_SECONDS * 1000 });
    });
  }
  const sub = (v?: string) => (v && v.startsWith(PREFIX) ? cache.get(v.slice(PREFIX.length))?.url : v);
  for (const m of msgs) {
    fields.forEach((f) => { (m as any)[f] = sub(m[f]); });
    if (m.replyTo) { m.replyTo.img = sub(m.replyTo.img); m.replyTo.vid = sub(m.replyTo.vid); }
  }
}
