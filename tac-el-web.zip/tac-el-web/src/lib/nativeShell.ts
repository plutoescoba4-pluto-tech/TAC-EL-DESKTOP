import { isNativeApp } from './target';

/**
 * Small touches for the Android app: the phone's Back button, the status bar colour and the splash screen.
 * Does nothing in a browser.
 */
export async function startNativeShell(): Promise<void> {
  if (!isNativeApp()) return;
  try {
    const { StatusBar, Style } = await import('@capacitor/status-bar');
    await StatusBar.setStyle({ style: Style.Dark });
    await StatusBar.setBackgroundColor({ color: '#0D2660' });
  } catch { /* not critical */ }
  try {
    const { App } = await import('@capacitor/app');
    // Back goes back in the app; at the very first screen it leaves the app (like any Android app).
    await App.addListener('backButton', ({ canGoBack }) => {
      if (canGoBack && window.history.length > 1) window.history.back();
      else App.exitApp();
    });
  } catch { /* not critical */ }
  try {
    const { SplashScreen } = await import('@capacitor/splash-screen');
    await SplashScreen.hide();
  } catch { /* not critical */ }
}
