const KEY = 'tac_chat_sound';
export const isChatSoundOn = () => {
  try { return localStorage.getItem(KEY) !== 'off'; } catch { return true; }
};
export const setChatSoundOn = (on: boolean) => {
  try { localStorage.setItem(KEY, on ? 'on' : 'off'); } catch { /* ignore */ }
};

let ctx: AudioContext | null = null;

/** Short two-note "pop" generated with WebAudio, so there's no sound asset
 *  to host. Browsers only allow audio after the user has interacted with
 *  the page, which is always true by the time anyone is logged in and chatting. */
export function playMessageSound() {
  if (!isChatSoundOn()) return;
  try {
    ctx = ctx || new (window.AudioContext || (window as any).webkitAudioContext)();
    if (ctx.state === 'suspended') ctx.resume();
    const now = ctx.currentTime;
    [[880, 0], [1175, 0.09]].forEach(([freq, offset]) => {
      const osc = ctx!.createOscillator();
      const gain = ctx!.createGain();
      osc.type = 'sine';
      osc.frequency.value = freq;
      gain.gain.setValueAtTime(0.0001, now + offset);
      gain.gain.exponentialRampToValueAtTime(0.15, now + offset + 0.01);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + offset + 0.16);
      osc.connect(gain).connect(ctx!.destination);
      osc.start(now + offset);
      osc.stop(now + offset + 0.18);
    });
  } catch { /* audio unavailable — silently skip */ }
}
