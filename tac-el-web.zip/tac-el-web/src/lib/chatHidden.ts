import { useCallback, useEffect, useState } from 'react';
import { chatService } from '../services/chatService';

/**
 * "Delete for me": hides a message from this person's view only (everyone else still sees it).
 * It is remembered on this device straight away, and also saved to the database
 * (table chat_message_hides, see 09-chat-delete-for-me.sql) so it follows the person to other
 * devices. If that table has not been created yet, the device memory still works.
 */
const key = (uid: string) => `tac_chat_hidden_${uid}`;
const MAX_REMEMBERED = 1000;

function readLocal(uid?: string | null): string[] {
  if (!uid) return [];
  try {
    const v = JSON.parse(localStorage.getItem(key(uid)) || '[]');
    return Array.isArray(v) ? v.filter((x) => typeof x === 'string') : [];
  } catch { return []; }
}

function writeLocal(uid: string, ids: string[]) {
  try { localStorage.setItem(key(uid), JSON.stringify(ids.slice(-MAX_REMEMBERED))); } catch { /* storage full or blocked */ }
}

export function useHiddenMessages(uid?: string | null) {
  const [hidden, setHidden] = useState<Set<string>>(() => new Set<string>(readLocal(uid)));

  useEffect(() => {
    if (!uid) return;
    let alive = true;
    setHidden(new Set<string>(readLocal(uid)));
    chatService.getHiddenIds(uid).then((ids) => {
      if (!alive || !ids.length) return;
      setHidden((prev) => {
        const next = new Set<string>(prev);
        ids.forEach((id) => next.add(id));
        writeLocal(uid, [...next]);
        return next;
      });
    }).catch(() => { /* table not created yet: device memory only */ });
    return () => { alive = false; };
  }, [uid]);

  const hide = useCallback((messageId: string) => {
    if (!uid) return;
    setHidden((prev) => {
      const next = new Set<string>(prev);
      next.add(messageId);
      writeLocal(uid, [...next]);
      return next;
    });
    chatService.hideForMe(uid, messageId).catch(() => { /* best effort */ });
  }, [uid]);

  return { hidden, hide };
}
