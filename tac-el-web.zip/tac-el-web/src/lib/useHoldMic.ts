import { useRef } from 'react';

/** WhatsApp-style mic button.
 *  Quick tap  -> onTap (opens the recorder so you can record hands-free).
 *  Press and hold -> onHoldStart, then onRelease('send') when you let go, or onRelease('cancel') if you slide left. */
export function useHoldMic(opts: { onTap: () => void; onHoldStart: () => void; onRelease: (what: 'send' | 'cancel') => void }) {
  const timer = useRef<any>(null);
  const held = useRef(false);
  const cancelled = useRef(false);
  const startX = useRef(0);

  const clear = () => { if (timer.current) { clearTimeout(timer.current); timer.current = null; } };
  return {
    onPointerDown: (e: React.PointerEvent) => {
      startX.current = e.clientX; held.current = false; cancelled.current = false;
      try { (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId); } catch { /* not supported */ }
      timer.current = setTimeout(() => { held.current = true; opts.onHoldStart(); }, 350);
    },
    onPointerMove: (e: React.PointerEvent) => {
      if (held.current && startX.current - e.clientX > 90) cancelled.current = true;
    },
    onPointerUp: () => {
      clear();
      if (held.current) { held.current = false; opts.onRelease(cancelled.current ? 'cancel' : 'send'); }
      else opts.onTap();
    },
    onPointerCancel: () => { clear(); if (held.current) { held.current = false; opts.onRelease('cancel'); } },
    onContextMenu: (e: React.MouseEvent) => e.preventDefault(),
  };
}
