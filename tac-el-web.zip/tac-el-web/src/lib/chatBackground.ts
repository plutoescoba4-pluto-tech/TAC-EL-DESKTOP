import { useCallback, useEffect, useState } from 'react';

/**
 * Each person's own chat wallpaper. It is saved on THIS device (browser storage), per person, so
 * it needs no database change and nobody else ever sees it.
 *   - a preset is a Tailwind colour class ("bg-gray-100") or a pattern link ("https://...")
 *   - a picture the person uploads from their gallery is stored as a small "data:image/jpeg..." string
 */
const key = (uid: string) => `tac_chat_bg_${uid}`;
const EVENT = 'tac-chat-bg-changed';

export const isImageBg = (bg?: string | null): boolean =>
  !!bg && (bg.startsWith('http') || bg.startsWith('data:'));

export function readChatBg(uid?: string | null): string {
  if (!uid) return '';
  try { return localStorage.getItem(key(uid)) || ''; } catch { return ''; }
}

export function saveChatBg(uid: string, value: string): void {
  try {
    if (value) localStorage.setItem(key(uid), value);
    else localStorage.removeItem(key(uid));
  } catch {
    throw new Error('There is not enough space on this device to save that wallpaper. Try a smaller picture.');
  }
  window.dispatchEvent(new CustomEvent(EVENT, { detail: { uid } }));
}

/** Shrinks a picture from the gallery to a wallpaper-sized JPEG (max 1280 px, usually under 300 KB). */
export async function fileToWallpaper(file: File): Promise<string> {
  if (!file.type.startsWith('image/')) throw new Error('Please choose a picture (JPG, PNG or WebP).');
  const url = URL.createObjectURL(file);
  try {
    const img = new Image();
    await new Promise<void>((resolve, reject) => {
      img.onload = () => resolve();
      img.onerror = () => reject(new Error('Could not read that picture. Please try another one.'));
      img.src = url;
    });
    const MAX = 1280;
    const scale = Math.min(1, MAX / Math.max(img.naturalWidth, img.naturalHeight));
    const canvas = document.createElement('canvas');
    canvas.width = Math.max(1, Math.round(img.naturalWidth * scale));
    canvas.height = Math.max(1, Math.round(img.naturalHeight * scale));
    const ctx = canvas.getContext('2d');
    if (!ctx) throw new Error('This browser could not process the picture.');
    ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
    let quality = 0.78;
    let out = canvas.toDataURL('image/jpeg', quality);
    while (out.length > 700_000 && quality > 0.4) {
      quality -= 0.1;
      out = canvas.toDataURL('image/jpeg', quality);
    }
    return out;
  } finally {
    URL.revokeObjectURL(url);
  }
}

/** [wallpaper, setWallpaper] for this person. Updates every chat screen that is open. */
export function useChatBg(uid?: string | null): [string, (value: string) => void] {
  const [bg, setBgState] = useState<string>(() => readChatBg(uid));
  useEffect(() => {
    setBgState(readChatBg(uid));
    const onChange = () => setBgState(readChatBg(uid));
    window.addEventListener(EVENT, onChange);
    return () => window.removeEventListener(EVENT, onChange);
  }, [uid]);
  const setBg = useCallback((value: string) => {
    if (!uid) return;
    saveChatBg(uid, value);
  }, [uid]);
  return [bg, setBg];
}
