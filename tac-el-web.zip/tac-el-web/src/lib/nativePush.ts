import { supabase } from '../supabase';

/**
 * Notifications inside the Android app (Capacitor). Delivered by Google's Firebase Cloud Messaging (free),
 * sent by our own Edge Function (send-push). Nothing else from Firebase is used.
 * Only called when the app is running natively; in a browser these functions are never reached.
 */
const FLAG = 'tac_native_push';          // 'on' | 'denied' | absent
const TOKEN = 'tac_native_push_token';

async function plugin() {
  const mod = await import('@capacitor/push-notifications');
  return mod.PushNotifications;
}

export function nativeState(): 'granted' | 'denied' | 'default' {
  const v = localStorage.getItem(FLAG);
  return v === 'on' ? 'granted' : v === 'denied' ? 'denied' : 'default';
}

async function register(): Promise<void> {
  const PushNotifications = await plugin();
  await PushNotifications.removeAllListeners();
  await PushNotifications.addListener('registration', async (t) => {
    localStorage.setItem(TOKEN, t.value);
    await supabase.rpc('save_native_push_token', { p_token: t.value, p_platform: 'android' });
  });
  await PushNotifications.addListener('registrationError', (e) => console.warn('Push registration failed:', e));
  // tapping a notification opens the screen it is about
  await PushNotifications.addListener('pushNotificationActionPerformed', (action) => {
    const url = (action.notification?.data as any)?.url;
    if (typeof url === 'string' && url.startsWith('/')) window.location.assign(url);
  });
  await PushNotifications.register();
}

export async function nativeEnable(): Promise<{ ok: boolean; message: string }> {
  const PushNotifications = await plugin();
  let perm = await PushNotifications.checkPermissions();
  if (perm.receive === 'prompt' || perm.receive === 'prompt-with-rationale') perm = await PushNotifications.requestPermissions();
  if (perm.receive !== 'granted') {
    localStorage.setItem(FLAG, 'denied');
    return { ok: false, message: 'Notifications were not allowed. You can allow them in the phone settings for TAC-EL.' };
  }
  await register();
  localStorage.setItem(FLAG, 'on');
  return { ok: true, message: 'Notifications are on.' };
}

/** Each time the app opens (signed in): make sure this phone's address is saved. */
export async function nativeSync(): Promise<boolean> {
  if (localStorage.getItem(FLAG) !== 'on') return false;
  try { await register(); return true; } catch { return false; }
}

export async function nativeDisable(): Promise<void> {
  const token = localStorage.getItem(TOKEN);
  try {
    if (token) await supabase.rpc('delete_native_push_token', { p_token: token });
    const PushNotifications = await plugin();
    await PushNotifications.unregister();
  } catch { /* nothing to remove */ }
  localStorage.removeItem(FLAG);
  localStorage.removeItem(TOKEN);
}
