/**
 * One place to switch big features on or off.
 *
 * Everything marked false is HIDDEN from the app (menus, buttons, pages, the floating helper)
 * but the code stays in the project. To bring one back, change false to true.
 *
 *   bible  : the Bible reader (Sanctuary tab, Scriptures menu, "Open Bible" buttons, Bible admin page)
 *   seekAi : the Seek AI study helper
 *   kinAi  : the Kin AI assistant and its admin settings page
 *
 * The AI keys are NOT in the app. When you switch seekAi/kinAi/bible on, the keys must be set
 * on the server (GEMINI_API_KEY, GROQ_KEY_1..3, BIBLE_API_KEY), never in the code.
 */
export const FEATURES = {
  bible: false,
  seekAi: false,
  kinAi: false,
} as const;
