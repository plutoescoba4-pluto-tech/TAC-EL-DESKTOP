import { useCallback, useEffect, useMemo, useState } from 'react';
import type { CSSProperties } from 'react';
import { supabase } from '../supabase';
import { fileToWallpaper } from './chatBackground';

/**
 * A person's chat look: wallpaper, bubble colours, text size and light/dark.
 *  - "all" is the default for every chat; one chat (a person, or the church group) can have its own look on top.
 *  - Saved on the person's account (table chat_theme_settings, 12-chat-themes.sql) and also kept on the device,
 *    so it shows instantly and still works if that table has not been created yet.
 */
export type TextSize = 'small' | 'normal' | 'large' | 'xlarge';
export type ChatMode = 'app' | 'light' | 'dark';

export interface ChatTheme {
  wallpaper?: string;        // picture link, "#colour", or a tailwind class preset
  mine?: string;             // my bubble colour (#rrggbb)
  theirs?: string;           // other people's bubble colour
  size?: TextSize;
  mode?: ChatMode;
}

export const TEXT_SCALE: Record<TextSize, number> = { small: 0.88, normal: 1, large: 1.15, xlarge: 1.32 };
export const TEXT_LABEL: Record<TextSize, string> = { small: 'Small', normal: 'Normal', large: 'Large', xlarge: 'Extra large' };

export const BUBBLE_COLOURS = ['#d9fdd3', '#dbeafe', '#fde68a', '#fecdd3', '#e9d5ff', '#ccfbf1', '#1B3F8B', '#005c4b', '#C0272D', '#334155'];
export const THEIRS_COLOURS = ['#ffffff', '#f1f5f9', '#e0f2fe', '#fef3c7', '#fce7f3', '#ede9fe', '#202c33', '#1e293b'];
export const PRESET_WALLPAPERS = ['#efeae2', '#e5ddd5', '#f3f4f6', '#dbeafe', '#fef3c7', '#dcfce7', '#fce7f3', '#0b141a', '#1e293b', '#0D2660'];

interface Store { all: ChatTheme; chats: Record<string, ChatTheme> }
const EVENT = 'tac-chat-theme-changed';
const key = (uid: string) => `tac_chat_theme_${uid}`;
const empty = (): Store => ({ all: {}, chats: {} });

function readStore(uid?: string | null): Store {
  if (!uid) return empty();
  try {
    const v = JSON.parse(localStorage.getItem(key(uid)) || 'null');
    if (v && typeof v === 'object') return { all: v.all || {}, chats: v.chats || {} };
  } catch { /* ignore */ }
  // first run: carry over the wallpaper saved by the older picker
  try {
    const old = localStorage.getItem(`tac_chat_bg_${uid}`);
    if (old) return { all: { wallpaper: old }, chats: {} };
  } catch { /* ignore */ }
  return empty();
}
function writeStore(uid: string, s: Store) {
  try { localStorage.setItem(key(uid), JSON.stringify(s)); } catch { /* storage full: still kept in memory this session */ }
  window.dispatchEvent(new CustomEvent(EVENT, { detail: { uid } }));
}

const rowToTheme = (r: any): ChatTheme => ({
  wallpaper: r.wallpaper || undefined, mine: r.bubble_mine || undefined, theirs: r.bubble_theirs || undefined,
  size: r.text_size || undefined, mode: r.mode || undefined,
});
const themeToRow = (uid: string, scope: string, t: ChatTheme) => ({
  user_id: uid, scope, wallpaper: t.wallpaper ?? null, bubble_mine: t.mine ?? null, bubble_theirs: t.theirs ?? null,
  text_size: t.size ?? null, mode: t.mode ?? null, updated_at: new Date().toISOString(),
});

/** The look for one chat: the person's default, with this chat's own choices on top. */
export function mergeTheme(all: ChatTheme, chat?: ChatTheme): ChatTheme {
  const out: ChatTheme = { ...all };
  if (chat) (Object.keys(chat) as (keyof ChatTheme)[]).forEach((k) => { if (chat[k] !== undefined) (out as any)[k] = chat[k]; });
  return out;
}

export function useChatTheme(uid?: string | null, scope?: string) {
  const [store, setStore] = useState<Store>(() => readStore(uid));

  useEffect(() => {
    if (!uid) return;
    setStore(readStore(uid));
    const onChange = (e: Event) => {
      const d = (e as CustomEvent).detail;
      if (!d || d.uid === uid) setStore(readStore(uid));
    };
    window.addEventListener(EVENT, onChange);
    let alive = true;
    (async () => {
      const { data, error } = await supabase.from('chat_theme_settings').select('*').eq('user_id', uid);
      if (!alive || error || !data) return;                       // table not created yet: device copy only
      if (data.length === 0) return;                              // nothing saved on the account yet: keep this device's copy
      const next = empty();
      data.forEach((r: any) => { if (r.scope === 'all') next.all = rowToTheme(r); else next.chats[r.scope] = rowToTheme(r); });
      writeStore(uid, next);
    })();
    return () => { alive = false; window.removeEventListener(EVENT, onChange); };
  }, [uid]);

  const theme = useMemo(() => mergeTheme(store.all, scope ? store.chats[scope] : undefined), [store, scope]);
  const hasOverride = !!(scope && store.chats[scope] && Object.values(store.chats[scope]).some((v) => v !== undefined));

  /** Change some fields. target 'chat' only changes this chat; 'all' changes the default. */
  const update = useCallback((patch: Partial<ChatTheme>, target: 'all' | 'chat' = 'all') => {
    if (!uid) return;
    const cur = readStore(uid);
    const sc = target === 'chat' && scope ? scope : 'all';
    const base = sc === 'all' ? cur.all : cur.chats[sc] || {};
    const merged: ChatTheme = { ...base, ...patch };
    (Object.keys(merged) as (keyof ChatTheme)[]).forEach((k) => { if (merged[k] === undefined || (merged[k] as any) === '') delete merged[k]; });
    if (sc === 'all') cur.all = merged; else cur.chats[sc] = merged;
    // "All chats" must really mean all: take the same choices out of every chat's own look, or that chat would keep the old one
    const touched: string[] = [];
    if (sc === 'all') {
      Object.keys(cur.chats).forEach((cs) => {
        const o = { ...cur.chats[cs] } as any; let changed = false;
        Object.keys(patch).forEach((k) => { if (o[k] !== undefined) { delete o[k]; changed = true; } });
        if (changed) { touched.push(cs); if (Object.keys(o).length) cur.chats[cs] = o; else delete cur.chats[cs]; }
      });
    }
    writeStore(uid, cur);
    touched.forEach((cs) => {
      if (cur.chats[cs]) supabase.from('chat_theme_settings').upsert(themeToRow(uid, cs, cur.chats[cs]), { onConflict: 'user_id,scope' }).then(() => {}, () => {});
      else supabase.from('chat_theme_settings').delete().eq('user_id', uid).eq('scope', cs).then(() => {}, () => {});
    });
    supabase.from('chat_theme_settings').upsert(themeToRow(uid, sc, merged), { onConflict: 'user_id,scope' }).then(
      ({ error }) => { if (error) console.warn('Chat theme kept on this device only:', error.message); },
      () => { /* offline: kept on this device */ });
  }, [uid, scope]);

  /** Remove this chat's own look (it goes back to the default). */
  const resetChat = useCallback(() => {
    if (!uid || !scope) return;
    const cur = readStore(uid);
    delete cur.chats[scope];
    writeStore(uid, cur);
    supabase.from('chat_theme_settings').delete().eq('user_id', uid).eq('scope', scope).then(() => {}, () => {});
  }, [uid, scope]);

  /** Back to the plain look everywhere. */
  const resetAll = useCallback(() => {
    if (!uid) return;
    writeStore(uid, empty());
    try { localStorage.removeItem(`tac_chat_bg_${uid}`); } catch { /* ignore */ }
    supabase.from('chat_theme_settings').delete().eq('user_id', uid).then(() => {}, () => {});
  }, [uid]);

  return { theme, hasOverride, update, resetChat, resetAll };
}

// ---------------------------------------------------------------------------------------------
// Turning a theme into something a chat screen can use
// ---------------------------------------------------------------------------------------------

/** Black or white text, whichever is easier to read on this colour. */
export function readableOn(hex?: string): string | undefined {
  if (!hex || !/^#[0-9a-f]{6}$/i.test(hex)) return undefined;
  const n = parseInt(hex.slice(1), 16);
  const lum = (0.299 * ((n >> 16) & 255) + 0.587 * ((n >> 8) & 255) + 0.114 * (n & 255)) / 255;
  return lum > 0.6 ? '#111b21' : '#ffffff';
}

export function themeVars(t: ChatTheme): CSSProperties {
  const v: Record<string, string> = { '--chat-fs': String(TEXT_SCALE[t.size || 'normal']) };
  if (t.mine) { v['--chat-mine'] = t.mine; v['--chat-mine-fg'] = readableOn(t.mine) || '#111b21'; }
  if (t.theirs) { v['--chat-theirs'] = t.theirs; v['--chat-theirs-fg'] = readableOn(t.theirs) || '#111b21'; }
  return v as CSSProperties;
}

/** Attributes for the chat's outer box: custom colours, and forcing light or dark just for this chat. */
export function themeAttrs(t: ChatTheme): Record<string, string | undefined> {
  return {
    'data-mine-custom': t.mine ? '1' : undefined,
    'data-theirs-custom': t.theirs ? '1' : undefined,
    'data-chat-mode': t.mode === 'light' || t.mode === 'dark' ? t.mode : undefined,
  };
}

export const isPictureWallpaper = (w?: string) => !!w && (w.startsWith('http') || w.startsWith('data:'));

/** className + style for the scrolling message area. */
export function wallpaperProps(w?: string): { className: string; style: CSSProperties } {
  if (!w) return { className: '', style: {} };
  if (isPictureWallpaper(w)) {
    const cover = w.startsWith('data:') || w.includes('/chat-wallpapers/');
    return {
      className: '',
      style: cover
        ? { backgroundImage: `url(${w})`, backgroundSize: 'cover', backgroundPosition: 'center', backgroundRepeat: 'no-repeat' }
        : { backgroundImage: `url(${w})`, backgroundRepeat: 'repeat', backgroundSize: 'auto' },
    };
  }
  if (w.startsWith('#')) return { className: '', style: { backgroundColor: w } };
  return { className: w, style: {} };
}

// ---------------------------------------------------------------------------------------------
// Pictures
// ---------------------------------------------------------------------------------------------

export interface LibraryWallpaper { id: string; name: string; url: string; sort_order: number; active: boolean }

export async function fetchWallpaperLibrary(): Promise<LibraryWallpaper[]> {
  const { data, error } = await supabase.from('chat_wallpapers').select('*').eq('active', true).order('sort_order').order('created_at');
  if (error) return [];
  return (data ?? []) as LibraryWallpaper[];
}

async function uploadPicture(folder: string, file: File): Promise<string> {
  const dataUrl = await fileToWallpaper(file);                    // shrinks it to a wallpaper-sized picture first
  const blob = await (await fetch(dataUrl)).blob();
  const path = `${folder}/${Date.now()}-${Math.random().toString(36).slice(2, 8)}.jpg`;
  const { error } = await supabase.storage.from('chat-wallpapers').upload(path, blob, { contentType: 'image/jpeg', upsert: false });
  if (error) {
    // storage not set up yet: fall back to keeping the picture on this device only
    if (folder !== 'library') return dataUrl;
    throw new Error(/bucket|not found/i.test(error.message) ? 'Run 12-chat-themes.sql in Supabase first, then try again.' : error.message);
  }
  return supabase.storage.from('chat-wallpapers').getPublicUrl(path).data.publicUrl;
}

/** A member's own photo as their wallpaper. */
export const uploadMyWallpaper = (uid: string, file: File) => uploadPicture(uid, file);
/** The admin adds a picture to the church library. */
export async function addLibraryWallpaper(file: File, name: string): Promise<void> {
  const url = await uploadPicture('library', file);
  const { error } = await supabase.from('chat_wallpapers').insert({ name: name.trim(), url });
  if (error) throw new Error(/does not exist|schema cache/i.test(error.message) ? 'Run 12-chat-themes.sql in Supabase first, then try again.' : error.message);
}
export async function removeLibraryWallpaper(w: LibraryWallpaper): Promise<void> {
  const { error } = await supabase.from('chat_wallpapers').delete().eq('id', w.id);
  if (error) throw error;
  const m = w.url.match(/chat-wallpapers\/(.+)$/);
  if (m) supabase.storage.from('chat-wallpapers').remove([decodeURIComponent(m[1])]).then(() => {}, () => {});
}
