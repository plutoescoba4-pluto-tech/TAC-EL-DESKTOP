import { supabase } from '../supabase';

// Kept as `firestore-errors.ts` / `handleFirestoreError` / `OperationType` on
// purpose: every call site across ~17 components imports these exact names,
// and the calls themselves (`handleFirestoreError(err, OperationType.LIST, 'conducts')`)
// don't need to change just because the backend changed. Only the plumbing
// inside this one file moved from `firebase/auth`'s `auth.currentUser` to
// Supabase's session user.

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface DbErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
  };
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const message = error instanceof Error ? error.message : String(error);
  const errCode = (error as any)?.code;

  // Postgres/PostgREST equivalents of Firestore's "quota or offline" bucket:
  // connection drops, rate limiting, or a paused/free-tier Supabase project.
  if (
    errCode === '57014' /* statement timeout */ ||
    errCode === 'PGRST301' /* JWT expired */ ||
    message.includes('rate limit') ||
    message.includes('Failed to fetch') ||
    message.includes('NetworkError') ||
    message.includes('offline')
  ) {
    console.warn(`Supabase (${operationType} ${path || ''}) offline or rate-limited:`, message);
    return;
  }

  supabase.auth.getUser().then(({ data }) => {
    const errInfo: DbErrorInfo = {
      error: message,
      authInfo: {
        userId: data.user?.id,
        email: data.user?.email,
      },
      operationType,
      path,
    };
    console.warn('Supabase Error: ', JSON.stringify(errInfo));
  });
}
