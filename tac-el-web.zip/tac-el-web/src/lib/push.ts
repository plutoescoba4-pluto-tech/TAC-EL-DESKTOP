import { supabase } from '../supabase';
import { isNativeApp } from './target';
import { nativeState, nativeEnable, nativeSync, nativeDisable } from './nativePush';

/**
 * Browser side of notifications.
 *   - asks the person for permission (it must be a tap, never automatic)
 *   - stores this device's push address in the database so the server can reach it
 * The server side (sending) is a separate Edge Function; until it is deployed, notifications
 * still appear while the app is open (see lib/chatUnread.ts).
 *
 * iPhone: web notifications exist ONLY for an app that was added to the Home Screen (iOS 16.4+).
 */
const VAPID_PUBLIC_KEY = ((import.meta.env.VITE_VAPID_PUBLIC_KEY as string | undefined) || '').trim();

export type PushState =
  | 'needs-install'   // iPhone in Safari: add to Home Screen first
  | 'unsupported'     // this browser cannot show notifications
  | 'default'         // not asked yet
  | 'granted'
  | 'denied';

export const isIOS = () =>
  /iphone|ipad|ipod/i.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);

export const isStandalone = () =>
  window.matchMedia?.('(display-mode: standalone)').matches || (navigator as any).standalone === true;

export function getPushState(): PushState {
  if (isNativeApp()) return nativeState();                      // the Android app
  if (isIOS() && !isStandalone()) return 'needs-install';
  if (!('Notification' in window)) return 'unsupported';
  return Notification.permission as PushState;
}

/** True when the server can also reach this device while the app is closed. */
export const serverPushAvailable = () => isNativeApp() || (!!VAPID_PUBLIC_KEY && 'serviceWorker' in navigator && 'PushManager' in window);

function urlBase64ToUint8Array(base64: string): Uint8Array {
  const padding = '='.repeat((4 - (base64.length % 4)) % 4);
  const raw = atob((base64 + padding).replace(/-/g, '+').replace(/_/g, '/'));
  return Uint8Array.from([...raw].map((c) => c.charCodeAt(0)));
}

/** Makes sure this device's push address is saved for this person. Safe to call again. */
export async function syncPushSubscription(userId: string): Promise<boolean> {
  if (isNativeApp()) return nativeSync();
  if (!serverPushAvailable() || Notification.permission !== 'granted') return false;
  try {
    const reg = await navigator.serviceWorker.ready;
    let sub = await reg.pushManager.getSubscription();
    if (!sub) {
      sub = await reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: urlBase64ToUint8Array(VAPID_PUBLIC_KEY) as BufferSource });
    }
    const json = sub.toJSON() as any;
    // A phone used by two accounts belongs to whoever is signed in now, so this goes through a database function.
    const { error } = await supabase.rpc('save_push_subscription', {
      p_endpoint: sub.endpoint, p_p256dh: json.keys?.p256dh, p_auth: json.keys?.auth, p_user_agent: navigator.userAgent.slice(0, 250),
    });
    return !error;
  } catch (e) {
    console.warn('Could not save the push subscription:', e);
    return false;
  }
}

/** Call from a tap. Returns a message for the screen. */
export async function enableNotifications(userId: string): Promise<{ ok: boolean; message: string }> {
  if (isNativeApp()) return nativeEnable();
  if (!('Notification' in window)) return { ok: false, message: 'This browser cannot show notifications.' };
  const permission = await Notification.requestPermission();
  if (permission !== 'granted') {
    return { ok: false, message: 'Notifications were not allowed. You can allow them later in your browser or phone settings.' };
  }
  const saved = await syncPushSubscription(userId);
  return {
    ok: true,
    message: saved || !serverPushAvailable()
      ? 'Notifications are on.'
      : 'Notifications are on, but this device could not be registered for messages while the app is closed.',
  };
}

export async function disableNotifications(): Promise<void> {
  if (isNativeApp()) { await nativeDisable(); return; }
  try {
    const reg = await navigator.serviceWorker.getRegistration();
    const sub = await reg?.pushManager.getSubscription();
    if (sub) {
      await supabase.from('push_subscriptions').delete().eq('endpoint', sub.endpoint);
      await sub.unsubscribe();
    }
  } catch { /* nothing to remove */ }
}

/** A test notification from this device (works without the server). */
export async function showTestNotification(): Promise<void> {
  const reg = await navigator.serviceWorker.getRegistration();
  const options = { body: 'Notifications are working on this device.', icon: '/icons/icon-192.png', badge: '/icons/badge-96.png', tag: 'tac-test' };
  if (reg) await reg.showNotification('TAC-EL', options);
  else new Notification('TAC-EL', options);
}

export const NOTIFICATION_CATEGORIES: { id: string; label: string; hint: string }[] = [
  { id: 'dms', label: 'Direct messages', hint: 'When someone writes to you privately' },
  { id: 'chat', label: 'Church chat', hint: 'New messages in the group chat' },
  { id: 'notices', label: 'Notices and announcements', hint: 'New notices from the church' },
  { id: 'events', label: 'Events', hint: 'New or changed events' },
  { id: 'sermons', label: 'Sermons', hint: 'New sermons added' },
  { id: 'live_prayer', label: 'Live prayer and voice rooms', hint: 'When a live room starts' },
  { id: 'prayer_updates', label: 'Prayer request updates', hint: 'When your prayer request is marked answered' },
  { id: 'admin_messages', label: 'Messages from the church office', hint: 'Warnings, approvals and other office messages' },
];
