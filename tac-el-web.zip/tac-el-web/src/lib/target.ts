/**
 * Which app is this build?
 *   'mobile'  TAC-EL      the phone app (hosted for iPhone, wrapped with Capacitor for Android)
 *   'web'     TAC-EL Web  the computer app (browser and the desktop installers)
 *   'auto'    used while developing: decided by the device
 * Set by VITE_APP_TARGET (see .env.mobile and .env.web, and "npm run build:mobile / build:web").
 */
export type AppTarget = 'mobile' | 'web' | 'auto';
export const APP_TARGET: AppTarget = (((import.meta as any).env?.VITE_APP_TARGET as string) || 'auto') as AppTarget;

/** True inside the Capacitor Android app (not in a normal browser). */
export const isNativeApp = (): boolean => {
  try { return !!(window as any).Capacitor?.isNativePlatform?.(); } catch { return false; }
};
