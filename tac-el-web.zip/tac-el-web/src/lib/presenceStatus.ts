/** "Online" is derived from a fresh last_seen, not trusted from the `online`
 *  flag alone — the flag only flips to false if the tab got to run its
 *  cleanup, so a closed laptop / killed phone browser would otherwise show
 *  as online forever. The heartbeat in AuthContext refreshes last_seen every
 *  60s, so a 3 minute window tolerates a missed beat or two. */
export const ONLINE_WINDOW_MS = 3 * 60 * 1000;

export function isFresh(lastSeen?: string | null, windowMs = ONLINE_WINDOW_MS): boolean {
  if (!lastSeen) return false;
  const t = Date.parse(lastSeen);
  return !Number.isNaN(t) && Date.now() - t < windowMs;
}

/** WhatsApp-style: "last seen today at 14:05", "yesterday at 09:30", "12 Oct at 18:12". */
export function lastSeenLabel(lastSeen?: string | null): string {
  if (!lastSeen) return 'Offline';
  const d = new Date(lastSeen);
  if (Number.isNaN(d.getTime())) return 'Offline';
  const time = d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  const startOfDay = (x: Date) => new Date(x.getFullYear(), x.getMonth(), x.getDate()).getTime();
  const days = Math.round((startOfDay(new Date()) - startOfDay(d)) / 86400000);
  if (days <= 0) return `last seen today at ${time}`;
  if (days === 1) return `last seen yesterday at ${time}`;
  return `last seen ${d.toLocaleDateString([], { day: 'numeric', month: 'short' })} at ${time}`;
}
