import { fetchLiveToken } from './liveKit';

/**
 * Stands in for VoiceMesh (lib/voiceMesh.ts) when the LiveKit server is used: the same few calls, but the audio goes
 * through the server, so hundreds can listen while only the host and the people the host allowed can speak.
 */
export interface LiveKitMeshOptions {
  roomId: string;
  selfId: string;
  onRemoteStream: (peerId: string, stream: MediaStream | null) => void;
  onPeerError?: (peerId: string, err: unknown) => void;
  /** the server changed whether this person may speak (the host let them speak, or took it back) */
  onPermission?: (canPublish: boolean) => void;
  /** small messages from other people in the room (raised hands) */
  onData?: (fromId: string, message: any) => void;
}

export class LiveKitMesh {
  canPublish: boolean;
  private lk: any;
  private room: any;
  private opts: LiveKitMeshOptions;
  private micTrack: any = null;

  private constructor(lk: any, room: any, opts: LiveKitMeshOptions, canPublish: boolean) {
    this.lk = lk; this.room = room; this.opts = opts; this.canPublish = canPublish;
  }

  static async connect(opts: LiveKitMeshOptions): Promise<LiveKitMesh> {
    const lk = await import('livekit-client');
    const tok = await fetchLiveToken('voice', opts.roomId);
    const room = new lk.Room({ dynacast: true, adaptiveStream: false });
    const mesh = new LiveKitMesh(lk, room, opts, tok.canPublish);
    mesh.wire();
    // the server address must start with wss:// ; accept https:// too and fix it
    const url = String(tok.url || '').trim().replace(/^https:\/\//i, 'wss://').replace(/^http:\/\//i, 'ws://');
    if (!/^wss?:\/\//i.test(url)) throw new Error('The voice server address (LIVEKIT_URL secret) is missing or wrong. It must look like wss://your-project.livekit.cloud');
    try { await room.connect(url, tok.token); }
    catch (e: any) { throw new Error('Could not connect to the voice server at ' + url + '. Check the LIVEKIT_URL, LIVEKIT_API_KEY and LIVEKIT_API_SECRET secrets all belong to the same LiveKit project. (' + (e?.message || 'no details') + ')'); }
    return mesh;
  }

  private wire() {
    const { RoomEvent, Track } = this.lk;
    const room = this.room;
    room.on(RoomEvent.TrackSubscribed, (track: any, _pub: any, participant: any) => {
      if (track.kind === Track.Kind.Audio) this.opts.onRemoteStream(participant.identity, new MediaStream([track.mediaStreamTrack]));
    });
    room.on(RoomEvent.TrackUnsubscribed, (track: any, _pub: any, participant: any) => {
      if (track.kind === Track.Kind.Audio) this.opts.onRemoteStream(participant.identity, null);
    });
    room.on(RoomEvent.ParticipantDisconnected, (p: any) => this.opts.onRemoteStream(p.identity, null));
    room.on(RoomEvent.ParticipantPermissionsChanged, (_prev: any, p: any) => {
      if (p === room.localParticipant) {
        this.canPublish = !!p.permissions?.canPublish;
        this.opts.onPermission?.(this.canPublish);
      }
    });
    room.on(RoomEvent.DataReceived, (payload: Uint8Array, participant: any) => {
      try { this.opts.onData?.(participant?.identity ?? '', JSON.parse(new TextDecoder().decode(payload))); } catch { /* ignore */ }
    });
    room.on(RoomEvent.Disconnected, () => this.opts.onPeerError?.('server', new Error('Disconnected from the live server.')));
  }

  /** Starts sending this person's voice (only works if the server allows them to speak). */
  async publishMic(stream: MediaStream): Promise<void> {
    const mediaTrack = stream.getAudioTracks()[0];
    if (!mediaTrack) return;
    this.micTrack = new this.lk.LocalAudioTrack(mediaTrack);
    await this.room.localParticipant.publishTrack(this.micTrack, { source: this.lk.Track.Source.Microphone });
  }

  async stopMic(): Promise<void> {
    if (!this.micTrack) return;
    try { await this.room.localParticipant.unpublishTrack(this.micTrack); } catch { /* already gone */ }
    this.micTrack = null;
  }

  setMuted(muted: boolean) {
    if (!this.micTrack) return;
    this.micTrack.mediaStreamTrack.enabled = !muted;
    if (muted) this.micTrack.mute().catch(() => {}); else this.micTrack.unmute().catch(() => {});
  }

  /** A small message to everyone in the room (used for "raise hand"). */
  sendData(message: unknown) {
    try { this.room.localParticipant.publishData(new TextEncoder().encode(JSON.stringify(message)), { reliable: true }); } catch { /* not connected */ }
  }

  // The same shape as VoiceMesh, so the screen can use either.
  connectTo(_peerId: string) { /* the server connects everyone */ }
  removePeer(_peerId: string) { /* the server does this */ }
  destroy() { try { this.room.disconnect(); } catch { /* ignore */ } }
}
