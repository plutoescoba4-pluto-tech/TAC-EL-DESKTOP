/**
 * Records a Voice Sanctuary session by mixing every audio source in the
 * room (the host's own mic + each remote participant's stream) into one
 * track, entirely in the host's browser. There's no server in the middle —
 * the host is the one machine that already receives everyone's audio via
 * the WebRTC mesh, so it's the natural place to record from.
 *
 * Caveat worth knowing: it records what the HOST hears. Anyone who couldn't
 * connect to the host (e.g. blocked by a strict network with no TURN
 * server) won't be on the recording, same as they wouldn't be heard live.
 */
export class VoiceSessionRecorder {
  private ctx: AudioContext;
  private dest: MediaStreamAudioDestinationNode;
  private recorder: MediaRecorder;
  private chunks: Blob[] = [];
  private sources = new Map<string, MediaStreamAudioSourceNode>();
  private startedAt = Date.now();
  readonly mimeType: string;

  static pickMimeType(): string {
    const candidates = ['audio/webm;codecs=opus', 'audio/webm', 'audio/mp4', 'audio/ogg;codecs=opus'];
    return candidates.find((t) => typeof MediaRecorder !== 'undefined' && MediaRecorder.isTypeSupported(t)) || '';
  }

  constructor(localStream: MediaStream) {
    this.ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
    this.ctx.resume?.().catch(() => {}); // a suspended context records silence
    this.dest = this.ctx.createMediaStreamDestination();
    this.mimeType = VoiceSessionRecorder.pickMimeType();
    this.recorder = new MediaRecorder(this.dest.stream, this.mimeType ? { mimeType: this.mimeType } : undefined);
    this.recorder.ondataavailable = (e) => { if (e.data.size > 0) this.chunks.push(e.data); };
    // The local track is muted by default (enabled=false) and toggled by the
    // mute button — a disabled track mixes in as silence, so the recording
    // automatically respects mute with no extra wiring.
    this.addStream('local', localStream);
    this.recorder.start(5000); // flush every 5s so a crash loses seconds, not the whole prayer
  }

  addStream(id: string, stream: MediaStream) {
    this.removeStream(id);
    if (stream.getAudioTracks().length === 0) return;
    const src = this.ctx.createMediaStreamSource(stream);
    src.connect(this.dest);
    this.sources.set(id, src);
  }

  removeStream(id: string) {
    const existing = this.sources.get(id);
    if (existing) {
      try { existing.disconnect(); } catch { /* already gone */ }
      this.sources.delete(id);
    }
  }

  stop(): Promise<{ blob: Blob; durationSec: number }> {
    return new Promise((resolve) => {
      const finish = () => {
        const blob = new Blob(this.chunks, { type: this.mimeType || 'audio/webm' });
        this.sources.forEach((s) => { try { s.disconnect(); } catch { /* ignore */ } });
        this.sources.clear();
        this.ctx.close().catch(() => {});
        resolve({ blob, durationSec: Math.round((Date.now() - this.startedAt) / 1000) });
      };
      if (this.recorder.state === 'inactive') return finish();
      this.recorder.onstop = finish;
      this.recorder.stop();
    });
  }
}
