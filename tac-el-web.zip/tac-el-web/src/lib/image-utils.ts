/**
 * Media/message size ceilings.
 *
 * These used to be sized against Firestore's hard 1 MiB per-document limit
 * (650 KB raw \u2192 ~870 KB base64, safely under 900 KB). Postgres text columns
 * have no such limit, so the old 650 KB video cap was rejecting essentially
 * every real video clip — that was the actual "video sharing doesn't work"
 * bug. Raised to something a real short clip can fit under, while still
 * guarding against pathologically large uploads (there's no object storage
 * here — everything is base64 text in a column — so this isn't unlimited).
 */
export const MAX_FIRESTORE_PAYLOAD_BYTES = 9_000_000; // ~9 MB ceiling for a full message payload (base64 + metadata)
export const MAX_BINARY_FILE_BYTES = 6 * 1024 * 1024; // 6 MB raw limit for uncompressed binary files before base64 (~8 MB encoded)

/**
 * Accurately measures the serialized byte size of any Firestore mutation payload
 */
export function calculatePayloadSizeBytes(payload: any): number {
  try {
    const json = JSON.stringify(payload);
    return new Blob([json]).size;
  } catch {
    return 0;
  }
}

/**
 * Resizes and compresses an image base64 string using the Canvas API.
 * Guarantees output is compact and safe for Firestore documents (< 500KB).
 * @param base64 The original image base64 string
 * @param maxWidth Maximum width of the resized image
 * @param maxHeight Maximum height of the resized image
 * @param quality JPEG compression quality (0 to 1)
 * @returns A promise that resolves to the compressed base64 string
 */
export async function compressImage(
  base64: string, 
  maxWidth = 800, 
  maxHeight = 800, 
  quality = 0.6
): Promise<string> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.src = base64;
    img.onload = () => {
      let width = img.width;
      let height = img.height;

      // Calculate new dimensions maintain aspect ratio
      if (width > height) {
        if (width > maxWidth) {
          height = Math.round((height * maxWidth) / width);
          width = maxWidth;
        }
      } else {
        if (height > maxHeight) {
          width = Math.round((width * maxHeight) / height);
          height = maxHeight;
        }
      }

      const canvas = document.createElement('canvas');
      canvas.width = width;
      canvas.height = height;

      const ctx = canvas.getContext('2d');
      if (!ctx) {
        reject(new Error('Could not get canvas context'));
        return;
      }

      ctx.drawImage(img, 0, 0, width, height);

      // Export as compressed JPEG
      let compressedBase64 = canvas.toDataURL('image/jpeg', quality);

      // Safety fallback: if compressed image is still > 500KB, do a secondary aggressive pass
      if (compressedBase64.length > 500_000) {
        const secondaryCanvas = document.createElement('canvas');
        const scale = 0.7;
        secondaryCanvas.width = Math.round(width * scale);
        secondaryCanvas.height = Math.round(height * scale);
        const sCtx = secondaryCanvas.getContext('2d');
        if (sCtx) {
          sCtx.drawImage(canvas, 0, 0, secondaryCanvas.width, secondaryCanvas.height);
          compressedBase64 = secondaryCanvas.toDataURL('image/jpeg', Math.max(0.4, quality - 0.2));
        }
      }

      resolve(compressedBase64);
    };
    img.onerror = (err) => reject(err);
  });
}

/**
 * Reads a File object and compresses it if it is an image.
 */
export async function processFileForChat(file: File): Promise<{
  dataUrl: string;
  type: 'img' | 'vid' | 'file';
  isOverLimit?: boolean;
  sizeBytes: number;
}> {
  return new Promise((resolve, reject) => {
    const isImage = file.type.startsWith('image/');
    const isVideo = file.type.startsWith('video/');
    const type: 'img' | 'vid' | 'file' = isImage ? 'img' : isVideo ? 'vid' : 'file';

    const reader = new FileReader();
    reader.onload = async (e) => {
      try {
        let dataUrl = e.target?.result as string;
        
        if (isImage) {
          // Always compress images so they are lightweight (typically 60-150 KB)
          dataUrl = await compressImage(dataUrl, 900, 900, 0.65);
        }

        const sizeBytes = new Blob([dataUrl]).size;
        const isOverLimit = sizeBytes > MAX_FIRESTORE_PAYLOAD_BYTES;

        resolve({
          dataUrl,
          type,
          isOverLimit,
          sizeBytes
        });
      } catch (err) {
        reject(err);
      }
    };
    reader.onerror = (err) => reject(err);
    reader.readAsDataURL(file);
  });
}

