import { supabase } from '../supabase';

/**
 * Your own LiveKit server handles big voice rooms and calls. This file is the app's way of asking for permission to join
 * (the livekit-token Edge Function) and of managing a room as its host.
 * Set VITE_USE_LIVEKIT=true (in .env.mobile and .env.web) once the server and the function are ready; until then the voice
 * rooms keep working the old, small way (a few people).
 */
export const LIVEKIT_ENABLED = (((import.meta as any).env?.VITE_USE_LIVEKIT as string) || '').trim() === 'true';

export interface LiveToken { url: string; token: string; room: string; canPublish: boolean }

async function call<T = any>(body: Record<string, any>): Promise<T> {
  const { data, error } = await supabase.functions.invoke('livekit-token', { body });
  if (error) {
    const name = (error as any).name || '';
    // the request never reached the function: it is not deployed under this exact name, or there is no internet
    if (name === 'FunctionsFetchError' || /failed to send a request/i.test(String((error as any).message))) {
      throw new Error('The voice function "livekit-token" could not be reached. Check that it is deployed in Supabase with exactly that name, and that you are online.');
    }
    const res: any = (error as any).context;
    const status = res?.status as number | undefined;
    let message = 'The voice function returned an error' + (status ? ` (code ${status})` : '') + '.';
    try {
      const raw = await res?.text?.();
      let j: any = null;
      try { j = raw ? JSON.parse(raw) : null; } catch { /* not JSON */ }
      const detail = j?.error || j?.message || j?.msg || (raw ? String(raw).slice(0, 160) : '');
      if (detail) message = detail + (status ? ` (code ${status})` : '');
      if (status === 404 && /not.?found/i.test(raw || '')) message = 'The voice function "livekit-token" is not deployed in Supabase under that exact name (code 404).';
      if (status === 401 && /apikey header matched no key/i.test(raw || '')) message = 'The voice function is rejecting the app key (code 401). In Supabase open Edge Functions > livekit-token > Details and switch "Verify JWT" OFF, then try again.';
      else if (status === 401) message = 'Supabase refused the sign-in for the voice function (code 401). Sign out and in again, then try once more. ' + (detail || '');
      if (status === 500 && /boot|worker|import/i.test(raw || '')) message = 'The voice function crashed on start. Open Supabase > Edge Functions > livekit-token > Logs and send me the last error. ' + (detail || '');
    } catch { /* keep the default */ }
    throw new Error(message);
  }
  if (data && (data as any).error) throw new Error((data as any).error);
  return data as T;
}

/** kind 'voice' -> id is the voice room (live session) id; kind 'call' -> id is the call id. */
export const fetchLiveToken = (kind: 'voice' | 'call', id: string) => call<LiveToken>({ action: 'token', kind, id });

/** Host controls for a voice room. */
export const liveHost = {
  setSpeaker: (sessionId: string, userId: string, speaker: boolean) => call({ action: 'set-speaker', session_id: sessionId, user_id: userId, speaker }),
  remove: (sessionId: string, userId: string) => call({ action: 'remove', session_id: sessionId, user_id: userId }),
  endRoom: (sessionId: string) => call({ action: 'end-room', session_id: sessionId }),
};
