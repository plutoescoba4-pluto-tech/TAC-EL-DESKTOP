import { supabase } from '../supabase';

export interface OfficeInfo {
  office: string;
  label: string;
  description: string;
  sort: number;
  perms: string[];
}

/** Plain words for what each permission lets a person open. */
export const PERM_LABELS: Record<string, string> = {
  'register.view': 'View the register',
  'register.manage': 'Edit the register, photos and cards',
  'attendance.view': 'View attendance',
  'attendance.manage': 'Take attendance',
  'visitors.manage': 'Manage visitors',
  'money.access': 'Money screens',
  'money.view': 'View money reports (read only)',
  'media.manage': 'Sermons, gallery and website content',
  'assets.view': 'View the asset register',
  'assets.manage': 'Edit the asset register',
};

/** The offices and what each can do live in the database (office_catalog / office_permissions), so they can be changed there. */
export async function fetchOffices(): Promise<OfficeInfo[]> {
  const [cat, perms] = await Promise.all([
    supabase.from('office_catalog').select('*').order('sort', { ascending: true }),
    supabase.from('office_permissions').select('*'),
  ]);
  if (cat.error) return [];
  const by: Record<string, string[]> = {};
  (perms.data ?? []).forEach((p: any) => { (by[p.office] = by[p.office] || []).push(p.perm); });
  return (cat.data ?? []).map((c: any) => ({
    office: c.office, label: c.label, description: c.description ?? '', sort: c.sort ?? 0, perms: by[c.office] ?? [],
  }));
}

export async function fetchMyPerms(): Promise<string[]> {
  const { data, error } = await supabase.rpc('my_permissions');
  if (error || !Array.isArray(data)) return [];
  return data as string[];
}

export async function fetchAmRoot(): Promise<boolean> {
  const { data, error } = await supabase.rpc('am_i_root_admin');
  return !error && data === true;
}

export async function setOffices(uid: string, offices: string[]): Promise<string[]> {
  const { data, error } = await supabase.rpc('admin_set_offices', { p_user: uid, p_offices: offices });
  if (error) throw error;
  return (data as string[]) ?? offices;
}
