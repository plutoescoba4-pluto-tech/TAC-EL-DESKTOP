import type { HymnSection } from '../types';

/**
 * Turns a pasted hymn into verses and choruses.
 *
 * Parts are separated by an empty line. A part is a CHORUS when its first line is
 * "Chorus", "Refrain" (with or without a colon or brackets). A part that is only the word
 * "Chorus" means "sing the chorus again" and repeats the last chorus. Labels such as
 * "Verse 2" or "2." are removed. Everything else is a verse.
 * The admin can still change any part afterwards in the editor.
 */
const CHORUS_ONLY = /^\s*[\(\[]?\s*(?:repeat\s+)?(?:chorus|refrain)\s*[\)\]]?\s*[:.\-]?\s*$/i;
const CHORUS_WITH_TEXT = /^\s*[\(\[]?\s*(?:chorus|refrain)\s*[\)\]]?\s*[:.\-]\s*(.+)$/i;
const VERSE_LABEL_ONLY = /^\s*(?:verse|stanza|v)\.?\s*\d+\s*[:.\-)]?\s*$/i;
const LEADING_NUMBER = /^\s*\d+\s*[.)]\s*/;

export function parseHymnText(raw: string): HymnSection[] {
  const blocks = raw.replace(/\r\n/g, '\n').split(/\n\s*\n/).map((b) => b.trim()).filter(Boolean);
  const out: HymnSection[] = [];
  let lastChorus = '';
  for (const block of blocks) {
    const lines = block.split('\n');
    const first = lines[0];
    if (CHORUS_ONLY.test(first)) {
      const rest = lines.slice(1).join('\n').trim();
      if (rest) { out.push({ type: 'chorus', text: rest }); lastChorus = rest; }
      else if (lastChorus) out.push({ type: 'chorus', text: lastChorus });
      continue;
    }
    const withText = first.match(CHORUS_WITH_TEXT);
    if (withText) {
      const text = [withText[1], ...lines.slice(1)].join('\n').trim();
      out.push({ type: 'chorus', text });
      lastChorus = text;
      continue;
    }
    if (VERSE_LABEL_ONLY.test(first)) {
      const rest = lines.slice(1).join('\n').trim();
      if (rest) out.push({ type: 'verse', text: rest });
      continue;
    }
    lines[0] = first.replace(LEADING_NUMBER, '');
    out.push({ type: 'verse', text: lines.join('\n').trim() });
  }
  return out.filter((s) => s.text);
}

/** The labels the app shows: "Verse 1", "Chorus", "Verse 2", ... */
export function sectionLabels(sections: HymnSection[]): string[] {
  let v = 0;
  return sections.map((s) => (s.type === 'chorus' ? 'Chorus' : `Verse ${++v}`));
}

/** Plain readable text of the whole hymn (stored in the old "lyrics" column as a fallback). */
export function hymnPlainText(sections: HymnSection[]): string {
  const labels = sectionLabels(sections);
  return sections.map((s, i) => `${labels[i]}\n${s.text}`).join('\n\n');
}
