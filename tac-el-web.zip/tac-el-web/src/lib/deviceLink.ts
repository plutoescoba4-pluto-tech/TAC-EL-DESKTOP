import { supabase } from '../supabase';

/**
 * Linked devices: sign in on a computer by scanning a QR code with the phone that is already signed in.
 * Rules (enforced by the database and the device-link Edge Function, see 06f-linked-devices.sql):
 * the phone plus up to 2 linked devices; adding another signs the OLDEST linked device out.
 */

export interface LinkedDevice {
  id: string;
  device_name: string;
  platform: string | null;
  created_at: string;
  last_seen_at: string;
  is_current: boolean;
}

export const LINK_QR_PREFIX = 'tacel-link:';
const LINKED_FLAG = 'tac_linked_device';
export const MAX_LINKED_DEVICES = 2;

/** "Chrome on Windows", "Safari on Mac"... for the list on the phone. */
export function describeThisDevice(): { name: string; platform: string } {
  const ua = navigator.userAgent;
  const os = /windows/i.test(ua) ? 'Windows' : /android/i.test(ua) ? 'Android' : /iphone|ipad|ipod/i.test(ua) ? 'iPhone' : /mac os|macintosh/i.test(ua) ? 'Mac' : /cros/i.test(ua) ? 'Chromebook' : /linux/i.test(ua) ? 'Linux' : 'Computer';
  const browser = /edg\//i.test(ua) ? 'Edge' : /opr\/|opera/i.test(ua) ? 'Opera' : /firefox/i.test(ua) ? 'Firefox' : /chrome|crios/i.test(ua) ? 'Chrome' : /safari/i.test(ua) ? 'Safari' : 'Browser';
  return { name: `${browser} on ${os}`, platform: os };
}

/** Calls the device-link Edge Function and turns its error into a message a person can read. */
async function call<T = any>(action: string, body: Record<string, any> = {}): Promise<T> {
  const { data, error } = await supabase.functions.invoke('device-link', { body: { action, ...body } });
  if (error) {
    let message = 'Could not reach the server. Check your internet connection and try again.';
    let detail = '';
    const ctx = (error as any).context;
    if (ctx && typeof ctx.status === 'number') {
      detail = `HTTP ${ctx.status}`;
      try {
        const j = await ctx.clone?.().json?.();
        if (j?.error) message = j.error;
        else if (j?.message) detail += ` · ${j.message}`;
        else if (j?.code) detail += ` · ${j.code}`;
      } catch { /* keep the default */ }
      if (ctx.status === 404) message = 'The linking service is not installed yet (the device-link function is not deployed).';
      else if (ctx.status === 401) message = 'The linking service refused the request (check that the function is deployed with the default settings).';
      else if (ctx.status >= 500 && message.startsWith('Could not reach')) message = 'The linking service had a problem. The database file 06f-linked-devices.sql may not have been run.';
    } else {
      detail = (error as any).name || 'network error';         // no answer at all: not deployed, blocked, or offline
      message = 'Could not reach the linking service. It may not be deployed, or the internet is blocked.';
    }
    const err: any = new Error(message);
    err.detail = detail;
    throw err;
  }
  return data as T;
}

export const deviceLinkService = {
  // ---- the computer ---------------------------------------------------------------
  async createRequest(): Promise<{ requestId: string; code: string; pollSecret: string; expiresAt: string }> {
    const d = describeThisDevice();
    const r = await call<any>('create', { device_name: d.name, platform: d.platform });
    return { requestId: r.request_id, code: r.code, pollSecret: r.poll_secret, expiresAt: r.expires_at };
  },
  async poll(requestId: string, pollSecret: string): Promise<{ status: 'pending' | 'approved' | 'denied' | 'expired' | 'claimed'; tokenHash?: string }> {
    const r = await call<any>('poll', { request_id: requestId, poll_secret: pollSecret });
    return { status: r.status, tokenHash: r.token_hash };
  },
  /** Signs this computer in with the one-time token, then registers it as a linked device. */
  async completeSignIn(tokenHash: string): Promise<void> {
    const { error } = await supabase.auth.verifyOtp({ token_hash: tokenHash, type: 'magiclink' });
    if (error) throw new Error('Could not finish signing in. Please try again.');
    await deviceLinkService.registerThisDevice();
  },
  async registerThisDevice(): Promise<void> {
    const d = describeThisDevice();
    const { error } = await supabase.rpc('register_linked_device', { p_name: d.name, p_platform: d.platform, p_user_agent: navigator.userAgent });
    if (error) throw new Error(error.message);
    try { localStorage.setItem(LINKED_FLAG, '1'); } catch { /* private mode */ }
  },
  /** Linked computers ask this every minute; if the phone removed them, they sign themselves out. */
  async stillLinked(): Promise<boolean> {
    let flagged = false;
    try { flagged = localStorage.getItem(LINKED_FLAG) === '1'; } catch { /* ignore */ }
    if (!flagged) return true;                       // this is not a linked computer
    const { data, error } = await supabase.rpc('linked_device_status');
    if (error) return true;                          // offline or a hiccup: do not sign anyone out because of that
    return !!(data as any)?.registered;
  },
  clearLinkedFlag() { try { localStorage.removeItem(LINKED_FLAG); } catch { /* ignore */ } },

  // ---- the phone ------------------------------------------------------------------
  /** Reads the code out of a scanned QR (or typed text). */
  parseCode(text: string): string | null {
    const raw = text.trim().startsWith(LINK_QR_PREFIX) ? text.trim().slice(LINK_QR_PREFIX.length) : text;
    const code = raw.toUpperCase().replace(/[^A-Z0-9]/g, '');
    return code.length === 8 ? code : null;
  },
  lookup: (code: string) => call<{ device_name: string; platform: string | null; created_at: string }>('lookup', { code }),
  approve: (code: string) => call<{ ok: true; device_name: string }>('approve', { code }),
  deny: (code: string) => call<{ ok: true }>('deny', { code }),

  async list(): Promise<LinkedDevice[]> {
    const { data, error } = await supabase.rpc('my_linked_devices');
    if (error) throw new Error('Could not load your linked devices. Make sure 06f-linked-devices.sql has been run.');
    return (data as LinkedDevice[]) ?? [];
  },
  async unlink(id: string): Promise<void> {
    const { error } = await supabase.rpc('unlink_device', { p_id: id });
    if (error) throw new Error(error.message);
  },
  async unlinkAll(): Promise<void> {
    const { error } = await supabase.rpc('unlink_all_devices');
    if (error) throw new Error(error.message);
  },
};
