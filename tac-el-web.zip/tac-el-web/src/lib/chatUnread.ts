import { useSyncExternalStore } from 'react';
import { supabase } from '../supabase';
import { playMessageSound } from './chatSound';
import { chatService, META_SEP } from '../services/chatService';
import { chatSafetyService } from '../services/chatSafetyService';
import { desktopApi } from './desktop';

/**
 * App-wide chat bookkeeping, started once from the Dashboard:
 *   - unread counts, kept on the SERVER so they are right on every device
 *     (database functions chat_unread_counts / mark_global_chat_read / mark_dms_read,
 *      06-chat.sql and 06b-chat-features.sql)
 *   - "delivered" ticks: the moment a message reaches this phone it is marked delivered
 *   - muted conversations: no sound, no pop-up, and they don't add to the badge
 * If the database functions are not installed yet, it falls back to the old per-device
 * counting so the app keeps working.
 */
const lastReadKey = (uid: string, conv: string) => `tac_lastread_${uid}_${conv}`;
const ms = (iso: string) => Date.parse(iso) || 0;

function getLastRead(uid: string, conv: string): number {
  try {
    const raw = localStorage.getItem(lastReadKey(uid, conv));
    if (raw) return Number(raw);
    localStorage.setItem(lastReadKey(uid, conv), String(Date.now()));
  } catch { /* ignore */ }
  return Date.now();
}

export const GLOBAL_CONV = 'global';
export const dmConv = (otherUid: string) => `dm:${otherUid}`;

/** Call when the person opens a conversation. */
export function markConversationRead(uid: string, conv: string) {
  try { localStorage.setItem(lastReadKey(uid, conv), String(Date.now())); } catch { /* ignore */ }
  const done = () => window.dispatchEvent(new CustomEvent('tac-chat-read'));
  if (conv === GLOBAL_CONV) {
    supabase.rpc('mark_global_chat_read').then(done, done);
  } else if (conv.startsWith('dm:')) {
    supabase.rpc('mark_dms_read', { p_other: conv.slice(3) }).then(done, done);
  } else {
    done();
  }
}

/** Tell the app-wide listener that mutes changed (after muting / unmuting somebody). */
export function notifyMutesChanged() {
  window.dispatchEvent(new CustomEvent('tac-chat-mutes'));
}

interface UnreadState { global: number; dmBySender: Record<string, number>; total: number }
let state: UnreadState = { global: 0, dmBySender: {}, total: 0 };
const listeners = new Set<() => void>();
const setState = (next: Omit<UnreadState, 'total'>) => {
  state = { ...next, total: next.global + Object.values(next.dmBySender).reduce((a, b) => a + b, 0) };
  listeners.forEach((l) => l());
  desktopApi?.setBadge(state.total);   // the desktop app shows it on the dock / taskbar
};

export function useChatUnread(): UnreadState {
  return useSyncExternalStore(
    (cb) => { listeners.add(cb); return () => listeners.delete(cb); },
    () => state
  );
}

/** Starts the app-wide listener (call once from Dashboard). Returns a stop function. */
export function startChatNotifications(uid: string, getPath: () => string): () => void {
  const baseTitle = document.title.replace(/^\(\d+\)\s*/, '');
  let mutes: Record<string, string | null> = {};
  const isMuted = (target: string) => {
    if (!(target in mutes)) return false;
    const until = mutes[target];
    return until === null || ms(until) > Date.now();
  };
  const loadMutes = async () => { try { mutes = await chatSafetyService.getMutes(uid); } catch { mutes = {}; } };

  const recompute = async () => {
    let global = 0;
    let dmBySender: Record<string, number> = {};
    const { data, error } = await supabase.rpc('chat_unread_counts');
    if (!error && data && data[0]) {
      global = Number(data[0].global_unread) || 0;
      for (const [k, v] of Object.entries((data[0].dm_by_sender as Record<string, number>) || {})) dmBySender[k] = Number(v) || 0;
    } else {
      // Fallback (functions not installed yet): count on this device only.
      const lastGlobal = getLastRead(uid, GLOBAL_CONV);
      const [globalRes, dmRes] = await Promise.all([
        supabase.from('chat_messages').select('id', { count: 'exact', head: true })
          .gt('created_at', new Date(lastGlobal).toISOString()).neq('sender_id', uid),
        supabase.from('direct_messages').select('sender_id, created_at')
          .eq('recipient_id', uid).order('created_at', { ascending: false }).limit(300),
      ]);
      global = globalRes.count ?? 0;
      for (const row of dmRes.data ?? []) {
        if (ms(row.created_at) > getLastRead(uid, dmConv(row.sender_id))) {
          dmBySender[row.sender_id] = (dmBySender[row.sender_id] || 0) + 1;
        }
      }
    }
    // Muted conversations are still unread inside their chat, but don't add to the badge.
    if (isMuted('group')) global = 0;
    dmBySender = Object.fromEntries(Object.entries(dmBySender).filter(([sender]) => !isMuted(sender)));
    setState({ global, dmBySender });
    document.title = state.total > 0 ? `(${state.total}) ${baseTitle}` : baseTitle;
  };

  /** Anything that reached the server while this phone was offline counts as delivered now. */
  const catchUpDelivered = async () => {
    try {
      const { data: dms } = await supabase.from('direct_messages').select('id')
        .eq('recipient_id', uid).is('delivered_at', null).limit(200);
      if (dms?.length) await chatService.markDmsDelivered(dms.map((d: any) => d.id));
      const { data: grp } = await supabase.from('chat_messages').select('id')
        .neq('sender_id', uid).not('delivered_to', 'cs', `{${uid}}`)
        .order('created_at', { ascending: false }).limit(100);
      if (grp?.length) await chatService.markGlobalDelivered(grp.map((g: any) => g.id));
    } catch { /* ticks are best-effort */ }
  };

  const notify = (title: string, body: string) => {
    playMessageSound();
    desktopApi?.attention();
    try {
      if (document.hidden && 'Notification' in window && Notification.permission === 'granted') {
        new Notification(title, { body });
      }
    } catch { /* ignore */ }
  };

  const onIncoming = (kind: 'global' | 'dm', messageId: string, senderId: string, preview: string) => {
    if (senderId === uid) return;
    // Reached this device: that is what a grey double tick means.
    if (messageId) (kind === 'global' ? chatService.markGlobalDelivered([messageId]) : chatService.markDmsDelivered([messageId])).catch(() => {});
    const path = getPath();
    const viewing =
      !document.hidden &&
      (kind === 'global'
        ? path.startsWith('/dashboard/chat') && !path.includes('/direct/')
        : path.includes('/direct/') && path.includes(senderId));
    if (viewing) {
      markConversationRead(uid, kind === 'global' ? GLOBAL_CONV : dmConv(senderId));
      return;
    }
    if (!isMuted(kind === 'global' ? 'group' : senderId)) notify(kind === 'global' ? 'Church Chat' : 'New message', preview);
    recompute();
  };

  loadMutes().then(() => { recompute(); catchUpDelivered(); });
  const channel = supabase
    .channel(`chat-notify:${uid}`)
    .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'chat_messages' }, (p: any) =>
      onIncoming('global', p.new?.id, p.new?.sender_id, (p.new?.text || '').split(META_SEP)[0] || 'New message'))
    .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'direct_messages', filter: `recipient_id=eq.${uid}` }, (p: any) =>
      onIncoming('dm', p.new?.id, p.new?.sender_id, p.new?.text?.startsWith('__RICH__') ? 'Sent you an attachment' : p.new?.text || 'New message'))
    .subscribe();

  const onRead = () => recompute();
  const onMutes = () => { loadMutes().then(recompute); };
  window.addEventListener('tac-chat-read', onRead);
  window.addEventListener('tac-chat-mutes', onMutes);

  return () => {
    window.removeEventListener('tac-chat-read', onRead);
    window.removeEventListener('tac-chat-mutes', onMutes);
    supabase.removeChannel(channel);
    document.title = baseTitle;
    setState({ global: 0, dmBySender: {} });
  };
}
