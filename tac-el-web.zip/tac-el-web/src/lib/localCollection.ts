// Firestore had cheap per-user subcollections (users/{uid}/bookmarks,
// .../highlights, .../seek_chat, .../seek_favorites) with no schema of their
// own to define. None of these have a Postgres table yet, and unlike
// memberMemoryService's data (which only ever feeds the AI, never displayed
// as a list) these ARE shown back to the user as lists — but still only
// need to work on the device that created them for now. Implemented here as
// a small localStorage-backed "collection" so the features keep working;
// swap the internals for real `supabase.from(...)` calls once you add
// matching tables (see MIGRATION_NOTES.md) without changing any caller.

function storageKey(uid: string, name: string) {
  return `tac_local_${name}_${uid}`;
}

function readList<T extends { id: string }>(uid: string, name: string): T[] {
  try {
    const raw = localStorage.getItem(storageKey(uid, name));
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

function writeList<T>(uid: string, name: string, items: T[]) {
  try {
    localStorage.setItem(storageKey(uid, name), JSON.stringify(items));
  } catch {
    /* ignore */
  }
}

export const localCollection = {
  list<T extends { id: string }>(uid: string, name: string): T[] {
    return readList<T>(uid, name);
  },
  add<T extends Record<string, any>>(uid: string, name: string, item: T): T & { id: string } {
    const withId = { ...item, id: item.id ?? crypto.randomUUID(), createdAt: item.createdAt ?? new Date().toISOString() };
    const items = readList<any>(uid, name);
    items.unshift(withId);
    writeList(uid, name, items);
    return withId;
  },
  remove(uid: string, name: string, id: string): void {
    const items = readList<any>(uid, name).filter((i) => i.id !== id);
    writeList(uid, name, items);
  },
  clear(uid: string, name: string): void {
    writeList(uid, name, []);
  },
};
