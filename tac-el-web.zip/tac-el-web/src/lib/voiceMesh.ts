import { supabase } from '../supabase';
import type { RealtimeChannel } from '@supabase/supabase-js';

/**
 * Actual audio transport for the Voice Sanctuary: a WebRTC mesh (every
 * participant connects directly to every other participant), signaled over a
 * Supabase Realtime Broadcast channel.
 *
 * Reliability notes (round 2 fixes):
 *  - Broadcast messages are NOT queued for people who aren't subscribed yet.
 *    A person who joined a room and was still answering the microphone prompt
 *    missed offers sent to them, and nobody ever retried, so half of the
 *    pairs never got audio. Now every mesh announces itself ("hello") the
 *    moment its signaling channel is live, and the peer with the smaller id
 *    (the one allowed to offer) answers that hello with an offer.
 *  - ICE candidates that arrive before the remote description are queued and
 *    applied afterwards (they used to be thrown away).
 *  - A failed connection (e.g. wifi -> mobile data) is retried with an ICE
 *    restart instead of staying dead until the person leaves and rejoins.
 *  - A listener with no microphone can still join receive-only.
 *
 * TURN: public STUN is not enough on many mobile networks (carrier-grade
 * NAT). Add a TURN server by setting VITE_TURN_URL (comma separated
 * turn:/turns: URLs), VITE_TURN_USERNAME and VITE_TURN_CREDENTIAL.
 * A mesh also suits small rooms best (~8-10 speakers).
 */

function buildIceServers(): RTCIceServer[] {
  const servers: RTCIceServer[] = [
    { urls: 'stun:stun.l.google.com:19302' },
    { urls: 'stun:stun1.l.google.com:19302' },
  ];
  const env = ((import.meta as any).env || {}) as Record<string, string | undefined>;
  const turn = env.VITE_TURN_URL;
  if (turn) {
    servers.push({
      urls: turn.split(',').map((s) => s.trim()).filter(Boolean),
      username: env.VITE_TURN_USERNAME,
      credential: env.VITE_TURN_CREDENTIAL,
    });
  }
  return servers;
}

const MAX_ICE_RESTARTS = 3;

interface VoiceMeshOptions {
  roomId: string;
  selfId: string;
  /** May have no audio track (listen-only). */
  localStream: MediaStream;
  onRemoteStream: (peerId: string, stream: MediaStream | null) => void;
  onPeerError?: (peerId: string, err: unknown) => void;
}

export class VoiceMesh {
  private channel: RealtimeChannel;
  private peers = new Map<string, RTCPeerConnection>();
  private pendingIce = new Map<string, RTCIceCandidateInit[]>();
  private restarts = new Map<string, number>();
  private selfId: string;
  private localStream: MediaStream;
  private iceServers = buildIceServers();
  private onRemoteStream: (peerId: string, stream: MediaStream | null) => void;
  private onPeerError?: (peerId: string, err: unknown) => void;
  private ready: Promise<void>;
  private destroyed = false;

  constructor(opts: VoiceMeshOptions) {
    this.selfId = opts.selfId;
    this.localStream = opts.localStream;
    this.onRemoteStream = opts.onRemoteStream;
    this.onPeerError = opts.onPeerError;

    this.channel = supabase.channel(`voice-signal:${opts.roomId}`, {
      config: { broadcast: { self: false } },
    });
    this.channel.on('broadcast', { event: 'signal' }, ({ payload }) => {
      this.handleSignal(payload).catch((err) => this.onPeerError?.(payload?.from, err));
    });
    this.ready = new Promise((resolve) => {
      this.channel.subscribe((status) => {
        if (status === 'SUBSCRIBED') {
          resolve();
          this.announce();
        }
      });
    });
  }

  /** Tells everyone already in the channel "I'm listening now". */
  private announce() {
    if (this.destroyed) return;
    this.channel
      .send({ type: 'broadcast', event: 'signal', payload: { from: this.selfId, to: '*', kind: 'hello' } })
      .catch(() => {});
  }

  private async send(to: string, data: Record<string, any>) {
    await this.ready;
    if (this.destroyed) return;
    await this.channel.send({ type: 'broadcast', event: 'signal', payload: { from: this.selfId, to, ...data } });
  }

  private getOrCreatePeer(peerId: string): RTCPeerConnection {
    const existing = this.peers.get(peerId);
    if (existing) return existing;

    const pc = new RTCPeerConnection({ iceServers: this.iceServers });
    const audioTracks = this.localStream.getAudioTracks();
    if (audioTracks.length > 0) {
      audioTracks.forEach((track) => pc.addTrack(track, this.localStream));
    } else {
      // Listener without a microphone: still receive everyone's audio.
      pc.addTransceiver('audio', { direction: 'recvonly' });
    }

    pc.onicecandidate = (e) => {
      if (e.candidate) this.send(peerId, { kind: 'ice', candidate: e.candidate.toJSON() }).catch(() => {});
    };
    pc.ontrack = (e) => {
      this.onRemoteStream(peerId, e.streams[0] ?? null);
    };
    pc.onconnectionstatechange = () => {
      if (pc.connectionState === 'connected') {
        this.restarts.delete(peerId);
      } else if (pc.connectionState === 'failed') {
        this.onPeerError?.(peerId, new Error('Connection failed (network change or a restrictive network without a TURN server).'));
        // Only the side allowed to offer retries, so both sides never offer at once.
        if (this.selfId < peerId && this.peers.get(peerId) === pc) this.restartIce(peerId, pc);
      }
    };

    this.peers.set(peerId, pc);
    return pc;
  }

  private async restartIce(peerId: string, pc: RTCPeerConnection) {
    const n = (this.restarts.get(peerId) ?? 0) + 1;
    if (n > MAX_ICE_RESTARTS || this.destroyed) return;
    this.restarts.set(peerId, n);
    try {
      const offer = await pc.createOffer({ iceRestart: true });
      await pc.setLocalDescription(offer);
      await this.send(peerId, { kind: 'offer', sdp: offer, restart: true });
    } catch (err) {
      this.onPeerError?.(peerId, err);
    }
  }

  private async sendOffer(peerId: string, pc: RTCPeerConnection) {
    try {
      const offer = await pc.createOffer();
      await pc.setLocalDescription(offer);
      await this.send(peerId, { kind: 'offer', sdp: offer });
    } catch (err) {
      this.onPeerError?.(peerId, err);
    }
  }

  /** Call when a new participant appears in the room. Only the
   *  lexicographically-smaller uid initiates the offer (avoids "glare"). */
  async connectTo(peerId: string): Promise<void> {
    if (peerId === this.selfId || this.peers.has(peerId)) return;
    const pc = this.getOrCreatePeer(peerId);
    if (this.selfId < peerId) await this.sendOffer(peerId, pc);
  }

  private closePeer(peerId: string) {
    const pc = this.peers.get(peerId);
    if (pc) {
      pc.onconnectionstatechange = null;
      pc.close();
      this.peers.delete(peerId);
    }
    this.pendingIce.delete(peerId);
  }

  private async flushIce(peerId: string, pc: RTCPeerConnection) {
    const queued = this.pendingIce.get(peerId);
    if (!queued) return;
    this.pendingIce.delete(peerId);
    for (const c of queued) {
      try { await pc.addIceCandidate(c); } catch { /* stale candidate */ }
    }
  }

  private async handleSignal(payload: any) {
    if (!payload) return;
    const { from, kind } = payload;
    if (!from || from === this.selfId) return;

    if (kind === 'hello') {
      // A peer just became reachable. If we're the one who offers to them,
      // (re)start from a clean connection unless it's already working.
      if (this.selfId < from) {
        const old = this.peers.get(from);
        if (old && (old.connectionState === 'connected' || old.connectionState === 'connecting')) return;
        this.closePeer(from);
        await this.sendOffer(from, this.getOrCreatePeer(from));
      }
      return;
    }

    if (payload.to !== this.selfId) return;

    if (kind === 'offer') {
      let pc = this.peers.get(from);
      // A fresh offer (not an ICE restart) on a used connection means the other
      // side started over: start over too.
      if (pc && !payload.restart && (pc.remoteDescription || pc.signalingState !== 'stable')) {
        this.closePeer(from);
        pc = undefined;
      }
      pc = pc ?? this.getOrCreatePeer(from);
      await pc.setRemoteDescription(new RTCSessionDescription(payload.sdp));
      await this.flushIce(from, pc);
      const answer = await pc.createAnswer();
      await pc.setLocalDescription(answer);
      await this.send(from, { kind: 'answer', sdp: answer });
    } else if (kind === 'answer') {
      const pc = this.peers.get(from);
      if (!pc) return;
      await pc.setRemoteDescription(new RTCSessionDescription(payload.sdp));
      await this.flushIce(from, pc);
    } else if (kind === 'ice') {
      const pc = this.getOrCreatePeer(from);
      if (!pc.remoteDescription) {
        // Arrived before the offer/answer: keep it, apply after.
        const list = this.pendingIce.get(from) ?? [];
        list.push(payload.candidate);
        this.pendingIce.set(from, list);
      } else {
        try { await pc.addIceCandidate(payload.candidate); } catch { /* stale candidate */ }
      }
    }
  }

  /** Call when a participant leaves the room. */
  removePeer(peerId: string) {
    this.closePeer(peerId);
    this.restarts.delete(peerId);
    this.onRemoteStream(peerId, null);
  }

  /** Mute/unmute: actually stops the outgoing audio track. */
  setMuted(muted: boolean) {
    this.localStream.getAudioTracks().forEach((t) => { t.enabled = !muted; });
  }

  destroy() {
    this.destroyed = true;
    this.peers.forEach((pc) => { pc.onconnectionstatechange = null; pc.close(); });
    this.peers.clear();
    this.pendingIce.clear();
    supabase.removeChannel(this.channel);
  }
}
