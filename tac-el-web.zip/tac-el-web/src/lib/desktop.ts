/**
 * Talks to the desktop app shell (desktop/preload.js) when the web app is running inside it.
 * In a normal browser none of this does anything.
 */
export interface TacDesktopApi {
  isDesktop: true;
  platform: string;
  setMode: (mode: 'link' | 'main') => void;
  setBadge: (count: number) => void;
  attention: () => void;
  version: () => Promise<string>;
}

declare global {
  interface Window { tacDesktop?: TacDesktopApi }
}

export const desktopApi: TacDesktopApi | null = typeof window !== 'undefined' && window.tacDesktop ? window.tacDesktop : null;
export const isDesktopApp = !!desktopApi;
