/** Texts the app used to attach to photos, voice notes and videos ("Shared photo: IMG_0042.jpg").
 *  They are not shown under the picture or the voice player any more, like WhatsApp. */
const AUTO = /^(?:🎤\s*)?(?:voice message|captured a photo|(?:shared\s+)?(?:photo|video|image)\s*:.*)$/i;
export const isAutoCaption = (text?: string | null): boolean => !!text && AUTO.test(text.trim());
