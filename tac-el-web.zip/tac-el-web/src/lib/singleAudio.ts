// Only one voice message / preview plays at a time. Two copies playing together
// (tap Play twice, or two messages at once) sounds like an echo.
let current: HTMLAudioElement | null = null;

export function pauseOthers(el: HTMLAudioElement) {
  if (typeof document !== 'undefined') {
    document.querySelectorAll('audio').forEach((a) => { if (a !== el && !a.paused) a.pause(); });
  }
  if (current && current !== el && !current.paused) current.pause();
  current = el;
}

export function playPreview(url: string) {
  if (current) { try { current.pause(); } catch { /* ignore */ } }
  const a = new Audio(url);
  pauseOthers(a);
  a.play().catch(() => {});
}
