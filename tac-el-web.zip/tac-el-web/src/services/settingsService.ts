import { supabase } from '../supabase';
import { HomeConfig } from '../types';

// 'settings/homeConfig', 'settings/livingWord' and 'stats/global' were three
// singleton Firestore docs. site_settings (key text primary key, value
// jsonb) in your schema is built exactly for this — one row per key.
const HOME_CONFIG_KEY = 'home_config';
const LIVING_WORD_KEY = 'living_word';
const STATS_KEY = 'stats_global';

/** The saved home config can be missing fields (it is created by whichever screen saves first, and
 *  only with the fields that screen changed). Every screen reads this config and loops over
 *  `services`, so make sure it is always a list. Without this, a saved config with no
 *  `services` crashed Home with "Cannot read properties of undefined (reading 'map')". */
function normalizeHomeConfig(value: any): HomeConfig | null {
  if (!value || typeof value !== 'object') return null;
  return { ...value, services: Array.isArray(value.services) ? value.services : [] } as HomeConfig;
}

async function getSetting<T = any>(key: string): Promise<T | null> {
  const { data, error } = await supabase.from('site_settings').select('value').eq('key', key).maybeSingle();
  if (error || !data) return null;
  return data.value as T;
}

async function setSetting(key: string, value: any): Promise<void> {
  const { error } = await supabase.from('site_settings').upsert({ key, value, updated_at: new Date().toISOString() });
  if (error) throw error;
}

/** Behaves like Firestore's onSnapshot(doc, cb) for a single site_settings
 *  key: fires immediately, then again on any change. Realtime is enabled on
 *  every table in your schema's publication except site_settings, so this
 *  polls gently (every 15s) instead of opening a postgres_changes channel —
 *  cheap for a value that changes rarely (theme, service times, living word). */
function subscribeSetting<T = any>(key: string, callback: (value: T | null) => void): () => void {
  let cancelled = false;
  const poll = async () => {
    if (cancelled) return;
    const value = await getSetting<T>(key);
    if (!cancelled) callback(value);
  };
  poll();
  const interval = setInterval(poll, 15000);
  return () => {
    cancelled = true;
    clearInterval(interval);
  };
}

export const settingsService = {
  getHomeConfig: async () => normalizeHomeConfig(await getSetting<HomeConfig>(HOME_CONFIG_KEY)),
  subscribeHomeConfig: (cb: (config: HomeConfig | null) => void) =>
    subscribeSetting<HomeConfig>(HOME_CONFIG_KEY, (value) => cb(normalizeHomeConfig(value))),
  async saveHomeConfig(patch: Partial<HomeConfig>): Promise<void> {
    const current = normalizeHomeConfig(await getSetting<HomeConfig>(HOME_CONFIG_KEY)) || ({ services: [] } as unknown as HomeConfig);
    const merged = { ...current, ...patch };
    // never save a config without a services list
    if (!Array.isArray(merged.services)) merged.services = [];
    await setSetting(HOME_CONFIG_KEY, merged);
  },

  getLivingWord: () => getSetting<{ ref: string; text: string }>(LIVING_WORD_KEY),
  subscribeLivingWord: (cb: (word: { ref: string; text: string } | null) => void) =>
    subscribeSetting<{ ref: string; text: string }>(LIVING_WORD_KEY, cb),
  saveLivingWord: (word: { ref: string; text: string }) => setSetting(LIVING_WORD_KEY, word),

  getStats: () => getSetting<Record<string, any>>(STATS_KEY),
  saveStats: (stats: Record<string, any>) => setSetting(STATS_KEY, stats),

  // --- Hero slides ---------------------------------------------------------
  // The admin Hero Slideshow editor needs title/subtitle/ctaText/ctaAction
  // per slide, not just an image — richer than the real `hero_slides` table
  // (image_url/sort_order/is_active only) can hold. Rather than force-fit it
  // in and lose those fields, the full slide objects are stored as one
  // site_settings row (key='hero_slides', value=the whole array) — the same
  // shape the Firestore build used at site_content/hero_slides. If you'd
  // rather use the real per-row `hero_slides` table, add title/subtitle/cta
  // columns to it and swap this over — see MIGRATION_NOTES.md.
  async getHeroSlidesConfig<T = any>(): Promise<T[]> {
    const value = await getSetting<T[]>('hero_slides');
    return value ?? [];
  },
  subscribeHeroSlidesConfig<T = any>(callback: (slides: T[]) => void): () => void {
    return subscribeSetting<T[]>('hero_slides', (v) => callback(v ?? []));
  },
  async saveHeroSlidesConfig<T = any>(slides: T[]): Promise<void> {
    await setSetting('hero_slides', slides);
  },
};
