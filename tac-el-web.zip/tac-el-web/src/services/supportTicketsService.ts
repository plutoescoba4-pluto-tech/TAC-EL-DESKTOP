import { supabase } from '../supabase';
import { EmergencyMessage } from '../types';

// The Firebase build had two separate features that both amount to "a
// member sends a message an admin needs to see and respond to": the
// Dashboard/AdminInbox "Emergency Board" (emergencyRequests) and the
// FloatingAssistiveTab's own Help/Report form. Your schema's comment on
// support_tickets says exactly this ("The floating tab's Help/Report
// feature"), so both are mapped onto it here rather than needing a second
// table. Status naming differs slightly — mapped both ways below.

const STATUS_TO_DB: Record<EmergencyMessage['status'], string> = {
  unread: 'open',
  read: 'in_progress',
  resolved: 'resolved',
};
const STATUS_FROM_DB: Record<string, EmergencyMessage['status']> = {
  open: 'unread',
  in_progress: 'read',
  resolved: 'resolved',
};

function rowToEmergency(row: any): EmergencyMessage {
  return {
    id: row.id,
    userId: row.profile_id,
    userName: row.profiles?.full_name ?? '',
    userEmail: row.profiles?.email ?? '',
    message: row.message,
    status: STATUS_FROM_DB[row.status] ?? 'unread',
    createdAt: row.created_at,
  };
}

export const supportTicketsService = {
  async getAll(): Promise<EmergencyMessage[]> {
    const { data, error } = await supabase
      .from('support_tickets')
      .select('*, profiles(full_name, email)')
      .order('created_at', { ascending: false })
      .limit(100);
    if (error) return [];
    return (data ?? []).map(rowToEmergency);
  },

  async getUnread(): Promise<EmergencyMessage[]> {
    const { data, error } = await supabase
      .from('support_tickets')
      .select('*, profiles(full_name, email)')
      .eq('status', 'open')
      .order('created_at', { ascending: false });
    if (error) return [];
    return (data ?? []).map(rowToEmergency);
  },

  async setStatus(id: string, status: EmergencyMessage['status']): Promise<void> {
    const { error } = await supabase.from('support_tickets').update({ status: STATUS_TO_DB[status] }).eq('id', id);
    if (error) throw error;
  },

  async remove(id: string): Promise<void> {
    const { error } = await supabase.from('support_tickets').delete().eq('id', id);
    if (error) throw error;
  },

  async submit(profileId: string, message: string, type: 'help' | 'bug' = 'help'): Promise<void> {
    const { error } = await supabase.from('support_tickets').insert({ profile_id: profileId, type, message });
    if (error) throw error;
  },
};
