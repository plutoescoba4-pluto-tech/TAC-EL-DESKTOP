import { supabase } from '../supabase';
import { subscribeQuery } from '../lib/realtime';
import { Notice, Hymn, HymnSection, Sermon, GalleryItem } from '../types';
import { hymnPlainText } from '../lib/hymnParse';

// --- Sermons ---------------------------------------------------------------
function rowToSermon(row: any): Sermon {
  return {
    id: row.id,
    title: row.title,
    speaker: row.speaker ?? '',
    date: row.preached_at ?? row.created_at,
    type: row.video_url ? 'video' : row.audio_url ? 'audio' : 'message',
    videoUrl: row.video_url || undefined,
    audioUrl: row.audio_url || undefined,
    coverUrl: row.cover_url || undefined,
    linkUrl: row.link_url || undefined,
    scripture: row.scripture || undefined,
    summary: row.description || undefined,
    showOnWebsite: !!row.show_on_website,
    color: undefined,
  };
}

export const sermonsService = {
  async getSermons(): Promise<Sermon[]> {
    const { data, error } = await supabase.from('sermons').select('*').order('created_at', { ascending: false }).limit(50);
    if (error) return [];
    return (data ?? []).map(rowToSermon);
  },
  async addSermon(s: { title: string; speaker: string; date: string; videoUrl?: string; audioUrl?: string; coverUrl?: string; linkUrl?: string; scripture?: string; description?: string; showOnWebsite?: boolean }): Promise<string> {
    const row: Record<string, any> = { title: s.title, speaker: s.speaker, preached_at: s.date };
    // only send what was filled in: audio, video, cover and link are all optional
    if (s.videoUrl) row.video_url = s.videoUrl;
    if (s.audioUrl) row.audio_url = s.audioUrl;
    if (s.coverUrl) row.cover_url = s.coverUrl;
    if (s.linkUrl) row.link_url = s.linkUrl;
    if (s.scripture) row.scripture = s.scripture;
    if (s.description) row.description = s.description;
    if (s.showOnWebsite !== undefined) row.show_on_website = s.showOnWebsite;
    const { data, error } = await supabase.from('sermons').insert(row).select().single();
    if (error) throw error;
    return data.id;
  },
  /** Uploads an audio, video or cover file to the public "sermon-media" bucket and returns its link. */
  async uploadMedia(file: File, kind: 'audio' | 'video' | 'cover'): Promise<string> {
    const ext = (file.name.split('.').pop() || 'bin').toLowerCase().replace(/[^a-z0-9]/g, '') || 'bin';
    const path = `${kind}/${Date.now()}_${Math.random().toString(36).slice(2, 8)}.${ext}`;
    const { error } = await supabase.storage.from('sermon-media').upload(path, file, { contentType: file.type || undefined, upsert: false });
    if (error) throw new Error(`Could not upload "${file.name}": ${error.message}`);
    return supabase.storage.from('sermon-media').getPublicUrl(path).data.publicUrl;
  },
  async deleteSermon(id: string): Promise<void> {
    const { error } = await supabase.from('sermons').delete().eq('id', id);
    if (error) throw error;
  },
};

// --- Hymns -------------------------------------------------------------
function rowToHymn(row: any): Hymn {
  let sections: HymnSection[] = [];
  if (Array.isArray(row.sections) && row.sections.length) {
    sections = row.sections
      .filter((x: any) => x && typeof x.text === 'string' && x.text.trim())
      .map((x: any) => ({ type: x.type === 'chorus' ? 'chorus' : 'verse', text: x.text }));
  } else if (row.lyrics) {
    // Older hymns saved before verses and choruses were separate: the whole text, split by empty lines.
    sections = String(row.lyrics).split('\n\n').filter((t) => t.trim()).map((t) => ({ type: 'verse' as const, text: t }));
  }
  return {
    id: row.id,
    number: row.number ?? 0,
    title: row.title,
    sections,
    lyrics: sections.filter((x) => x.type === 'verse').map((x) => x.text),
    chorus: sections.find((x) => x.type === 'chorus')?.text,
    category: row.category || 'Worship',
  };
}

function hymnToRow(h: Partial<Hymn>, withNewColumns: boolean): Record<string, any> {
  const row: Record<string, any> = {};
  if (h.title !== undefined) row.title = h.title;
  if (h.number !== undefined) row.number = h.number;
  if (h.sections !== undefined) {
    // the old text column keeps a readable copy so nothing depends on the new columns
    row.lyrics = hymnPlainText(h.sections);
    if (withNewColumns) row.sections = h.sections;
  }
  if (withNewColumns && h.category !== undefined) row.category = h.category;
  return row;
}

const isMissingColumn = (e: any) => /sections|category|PGRST204|42703|column/i.test(`${e?.code ?? ''} ${e?.message ?? ''}`);

export const hymnsService = {
  async getHymns(): Promise<Hymn[]> {
    const { data, error } = await supabase.from('hymns').select('*').order('number', { ascending: true }).limit(500);
    if (error) return [];
    return (data ?? []).map(rowToHymn);
  },
  async addHymn(h: Omit<Hymn, 'id'>): Promise<string> {
    // Saves verses/choruses and the category. If the database has not been updated yet (06c-ids-and-hymns.sql),
    // it falls back to saving the plain text so nothing is lost.
    let res = await supabase.from('hymns').insert(hymnToRow(h, true)).select().single();
    if (res.error && isMissingColumn(res.error)) res = await supabase.from('hymns').insert(hymnToRow(h, false)).select().single();
    if (res.error) throw res.error;
    return res.data.id;
  },
  async updateHymn(id: string, h: Partial<Hymn>): Promise<void> {
    let res = await supabase.from('hymns').update(hymnToRow(h, true)).eq('id', id);
    if (res.error && isMissingColumn(res.error)) res = await supabase.from('hymns').update(hymnToRow(h, false)).eq('id', id);
    if (res.error) throw res.error;
  },
  async deleteHymn(id: string): Promise<void> {
    const { error } = await supabase.from('hymns').delete().eq('id', id);
    if (error) throw error;
  },
};

// --- Gallery -------------------------------------------------------------
function rowToGalleryItem(row: any): GalleryItem {
  return {
    id: row.id,
    src: row.image_url,
    type: 'img',
    uploadedBy: row.uploaded_by ?? undefined,
    createdAt: row.created_at,
  };
}

export const galleryService = {
  async getGallery(): Promise<GalleryItem[]> {
    const { data, error } = await supabase.from('gallery_photos').select('*').order('created_at', { ascending: false }).limit(100);
    if (error) return [];
    return (data ?? []).map(rowToGalleryItem);
  },
  subscribeGallery(callback: (items: GalleryItem[]) => void) {
    return subscribeQuery<any>(
      { table: 'gallery_photos', orderBy: { column: 'created_at', ascending: false }, limit: 6 },
      (rows) => callback(rows.map(rowToGalleryItem))
    );
  },
  async addPhoto(src: string, uploadedBy?: string): Promise<string> {
    const { data, error } = await supabase.from('gallery_photos').insert({ image_url: src, uploaded_by: uploadedBy }).select().single();
    if (error) throw error;
    return data.id;
  },
  async deletePhoto(id: string): Promise<void> {
    // .select() so a delete the database silently refused (no permission) is reported, not ignored.
    const { data, error } = await supabase.from('gallery_photos').delete().eq('id', id).select('id');
    if (error) throw error;
    if (!data || data.length === 0) throw new Error('This photo could not be deleted. Only an admin can remove gallery photos.');
  },
};

// --- Notices -------------------------------------------------------------
// Firestore notices had a free-form `status` field ('pending'/'published');
// the schema instead has a plain `approved` boolean — status is derived
// from it, not stored, so "presbytery approves" is just approved=true.
// Notices (per your schema) has no `type` column — 'gen'/'urg'/'pin' is
// packed into the body as a "[type] " prefix and parsed back out, the same
// trick used elsewhere for columns that don't exist yet.
function rowToNotice(row: any): Notice {
  const match = /^\[(gen|urg|pin)\]\s([\s\S]*)$/.exec(row.body || '');
  return {
    id: row.id,
    title: row.title,
    type: (match?.[1] as Notice['type']) || 'gen',
    body: match ? match[2] : row.body,
    author: row.created_by ?? '',
    date: row.created_at,
    createdAt: row.created_at,
  };
}

export const noticesService = {
  async getNotices(limit = 50): Promise<Notice[]> {
    const { data, error } = await supabase.from('notices').select('*').order('created_at', { ascending: false }).limit(limit);
    if (error) return [];
    return (data ?? []).map(rowToNotice);
  },
  subscribeNotices(callback: (notices: Notice[]) => void, limit = 20) {
    return subscribeQuery<any>(
      { table: 'notices', orderBy: { column: 'created_at', ascending: false }, limit },
      (rows) => callback(rows.map(rowToNotice))
    );
  },
  async getPendingNotices(): Promise<Notice[]> {
    const { data, error } = await supabase.from('notices').select('*').eq('approved', false);
    if (error) return [];
    return (data ?? []).map(rowToNotice);
  },
  async addNotice(n: { title: string; body: string; type?: Notice['type']; createdBy?: string }): Promise<string> {
    const packedBody = `[${n.type || 'gen'}] ${n.body}`;
    const { data, error } = await supabase.from('notices').insert({ title: n.title, body: packedBody, created_by: n.createdBy }).select().single();
    if (error) throw error;
    return data.id;
  },
  async approveNotice(id: string): Promise<void> {
    const { error } = await supabase.from('notices').update({ approved: true }).eq('id', id);
    if (error) throw error;
  },
  async deleteNotice(id: string): Promise<void> {
    const { error } = await supabase.from('notices').delete().eq('id', id);
    if (error) throw error;
  },
};
