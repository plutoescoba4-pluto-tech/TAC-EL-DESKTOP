import { supabase } from '../supabase';
import { subscribeQuery } from '../lib/realtime';

export interface AppNotification {
  id: string;
  profileId: string;
  type: string;
  body: string;
  read: boolean;
  createdAt: string;
}

function rowToNotification(row: any): AppNotification {
  return {
    id: row.id,
    profileId: row.profile_id,
    type: row.type,
    body: row.body,
    read: !!row.read_at,
    createdAt: row.created_at,
  };
}

export const notificationsService = {
  subscribeMyNotifications(uid: string, callback: (n: AppNotification[]) => void) {
    return subscribeQuery<any>(
      { table: 'notifications', match: { profile_id: uid }, orderBy: { column: 'created_at', ascending: false }, limit: 50 },
      (rows) => callback(rows.map(rowToNotification))
    );
  },
  async send(profileId: string, type: string, body: string): Promise<void> {
    const { error } = await supabase.from('notifications').insert({ profile_id: profileId, type, body });
    if (error) throw error;
  },
  async markRead(id: string): Promise<void> {
    const { error } = await supabase.from('notifications').update({ read_at: new Date().toISOString() }).eq('id', id);
    if (error) throw error;
  },
  async markAllRead(uid: string): Promise<void> {
    await supabase.from('notifications').update({ read_at: new Date().toISOString() }).eq('profile_id', uid).is('read_at', null);
  },
};
