import { supabase } from '../supabase';

/**
 * Club officers: the roles an admin can give a member inside ONE club, plus the club timetable and
 * club events that officers manage. Needs 11-club-officers.sql (roles, tables and permissions).
 */
export type ClubRole = 'member' | 'patron' | 'leader' | 'assistant' | 'secretary';

export const CLUB_ROLE_LABEL: Record<string, string> = {
  patron: 'Patron',
  leader: 'Leader / Chairperson',
  assistant: 'Assistant Leader',
  secretary: 'Secretary',
  mentor: 'Mentor',
  member: 'Member',
};

/** The roles that get the officer tools (post notices, timetable, events, approve members). */
export const OFFICER_ROLES = ['patron', 'leader', 'assistant', 'secretary', 'mentor'];
export const isOfficerRole = (role?: string | null): boolean => !!role && OFFICER_ROLES.includes(role);

export const DAY_NAMES = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

export interface TimetableEntry {
  id: string;
  clubId: string;
  day: number;        // 0 = Sunday
  start: string;      // "HH:MM"
  end?: string;
  title: string;
  venue?: string;
  notes?: string;
}

export interface ClubEvent {
  id: string;
  clubId: string;
  clubName?: string;
  title: string;
  description?: string;
  location?: string;
  startsAt: string;   // ISO
  endsAt?: string;
}

export interface MemberClubRole {
  clubId: string;
  role: string;
  status: string;
}

const hhmm = (t?: string | null) => (t ? String(t).slice(0, 5) : '');

function notSetUp(error: any, what: string): Error {
  const msg = String(error?.message || '');
  if (error?.code === 'PGRST202' || error?.code === 'PGRST205' || error?.code === '42P01' || /could not find|does not exist|schema cache/i.test(msg)) {
    return new Error(`${what} is not set up yet. Run 11-club-officers.sql in Supabase, then try again.`);
  }
  return new Error(msg || `Could not complete: ${what}.`);
}

export const clubOfficersService = {
  // ---------- roles (admin) ----------
  async getMemberClubRoles(profileId: string): Promise<MemberClubRole[]> {
    const { data, error } = await supabase.from('club_members').select('club_id, role, status').eq('profile_id', profileId);
    if (error) throw error;
    return (data ?? []).map((r: any) => ({ clubId: r.club_id, role: r.role, status: r.status }));
  },

  /** Admin only. role = 'none' removes the person from the club. */
  async setClubRole(profileId: string, clubId: string, role: ClubRole | 'none'): Promise<void> {
    const { error } = await supabase.rpc('admin_set_club_role', { p_profile: profileId, p_club: clubId, p_role: role });
    if (error) throw notSetUp(error, 'Club roles');
  },

  // ---------- club details (patron / admin) ----------
  async getClubDetails(clubId: string): Promise<{ name: string; description: string; color: string; meetingTime: string }> {
    const { data, error } = await supabase.from('clubs').select('*').eq('id', clubId).maybeSingle();
    if (error) throw error;
    return {
      name: data?.name ?? '',
      description: data?.description ?? '',
      color: data?.color ?? 'bg-tac-blue',
      meetingTime: data?.meeting_time ?? '',
    };
  },

  async updateClubDetails(clubId: string, d: { name: string; description: string; color: string; meetingTime: string }): Promise<void> {
    const { data, error } = await supabase
      .from('clubs')
      .update({ name: d.name.trim(), description: d.description.trim(), color: d.color, meeting_time: d.meetingTime.trim() || null })
      .eq('id', clubId)
      .select('id');
    if (error) throw notSetUp(error, 'Editing club details');
    if (!data || data.length === 0) throw new Error('You do not have permission to change this club. Only its Patron or an admin can.');
  },

  // ---------- timetable ----------
  async getTimetable(clubId: string): Promise<TimetableEntry[]> {
    const { data, error } = await supabase
      .from('club_timetable').select('*').eq('club_id', clubId)
      .order('day_of_week', { ascending: true }).order('start_time', { ascending: true });
    if (error) throw notSetUp(error, 'The club timetable');
    return (data ?? []).map((r: any) => ({
      id: r.id, clubId: r.club_id, day: r.day_of_week, start: hhmm(r.start_time), end: hhmm(r.end_time) || undefined,
      title: r.title, venue: r.venue ?? undefined, notes: r.notes ?? undefined,
    }));
  },

  async addTimetableEntry(clubId: string, authorId: string, e: { day: number; start: string; end?: string; title: string; venue?: string; notes?: string }): Promise<void> {
    const { error } = await supabase.from('club_timetable').insert({
      club_id: clubId, created_by: authorId, day_of_week: e.day, start_time: e.start, end_time: e.end || null,
      title: e.title.trim(), venue: e.venue?.trim() || null, notes: e.notes?.trim() || null,
    });
    if (error) throw notSetUp(error, 'The club timetable');
  },

  async deleteTimetableEntry(id: string): Promise<void> {
    const { data, error } = await supabase.from('club_timetable').delete().eq('id', id).select('id');
    if (error) throw error;
    if (!data || data.length === 0) throw new Error('This entry could not be deleted. Only club officers can remove it.');
  },

  // ---------- club events (shown on that club's members' calendars) ----------
  async getClubEvents(clubId: string): Promise<ClubEvent[]> {
    const since = new Date(Date.now() - 12 * 3600 * 1000).toISOString();
    const { data, error } = await supabase
      .from('club_events').select('*').eq('club_id', clubId).gte('starts_at', since).order('starts_at', { ascending: true });
    if (error) throw notSetUp(error, 'Club events');
    return (data ?? []).map((r: any) => ({
      id: r.id, clubId: r.club_id, title: r.title, description: r.description ?? undefined, location: r.location ?? undefined,
      startsAt: r.starts_at, endsAt: r.ends_at ?? undefined,
    }));
  },

  async addClubEvent(clubId: string, authorId: string, e: { title: string; startsAt: string; endsAt?: string; location?: string; description?: string }): Promise<void> {
    const { error } = await supabase.from('club_events').insert({
      club_id: clubId, created_by: authorId, title: e.title.trim(), starts_at: e.startsAt,
      ends_at: e.endsAt || null, location: e.location?.trim() || null, description: e.description?.trim() || null,
    });
    if (error) throw notSetUp(error, 'Club events');
  },

  async deleteClubEvent(id: string): Promise<void> {
    const { data, error } = await supabase.from('club_events').delete().eq('id', id).select('id');
    if (error) throw error;
    if (!data || data.length === 0) throw new Error('This event could not be deleted. Only club officers can remove it.');
  },

  /** Upcoming events of every club this person is an active member of (their club calendar). */
  async getMyClubEvents(uid: string): Promise<ClubEvent[]> {
    const { data: mem, error: e1 } = await supabase.from('club_members').select('club_id').eq('profile_id', uid).eq('status', 'active');
    if (e1 || !mem || mem.length === 0) return [];
    const ids = mem.map((m: any) => m.club_id);
    const since = new Date(Date.now() - 12 * 3600 * 1000).toISOString();
    const [{ data: ev, error: e2 }, { data: clubs }] = await Promise.all([
      supabase.from('club_events').select('*').in('club_id', ids).gte('starts_at', since).order('starts_at', { ascending: true }),
      supabase.from('clubs').select('id, name').in('id', ids),
    ]);
    if (e2) return [];
    const names: Record<string, string> = {};
    (clubs ?? []).forEach((c: any) => { names[c.id] = c.name; });
    return (ev ?? []).map((r: any) => ({
      id: r.id, clubId: r.club_id, clubName: names[r.club_id], title: r.title, description: r.description ?? undefined,
      location: r.location ?? undefined, startsAt: r.starts_at, endsAt: r.ends_at ?? undefined,
    }));
  },
};

export interface NoticeComment { id: string; noticeId: string; authorId: string; authorName: string; body: string; createdAt: string; }

export const noticeCommentsService = {
  async list(clubId: string): Promise<NoticeComment[]> {
    const { data, error } = await supabase.from('club_notice_comments').select('*').eq('club_id', clubId).order('created_at', { ascending: true });
    if (error) throw notSetUp(error, 'Notice comments');
    const ids = Array.from(new Set((data ?? []).map((r: any) => r.author_id)));
    const names: Record<string, string> = {};
    if (ids.length) {
      const { data: ps } = await supabase.from('profiles').select('id, full_name').in('id', ids);
      for (const p of ps ?? []) names[(p as any).id] = (p as any).full_name;
    }
    return (data ?? []).map((r: any) => ({ id: r.id, noticeId: r.notice_id, authorId: r.author_id, authorName: names[r.author_id] || 'Member', body: r.body, createdAt: r.created_at }));
  },
  async add(clubId: string, noticeId: string, authorId: string, body: string): Promise<void> {
    const { error } = await supabase.from('club_notice_comments').insert({ club_id: clubId, notice_id: noticeId, author_id: authorId, body: body.trim() });
    if (error) throw notSetUp(error, 'Notice comments');
  },
  async remove(id: string): Promise<void> {
    const { error } = await supabase.from('club_notice_comments').delete().eq('id', id);
    if (error) throw error;
  },
};
