import { GoogleGenAI } from "@google/genai";
import { supabase } from '../supabase';

export interface BibleVersion {
  id: string;
  name: string;
  abbreviation: string;
}

export interface BibleBook {
  id: string;
  bibleId: string;
  name: string;
  nameLong: string;
}

export interface BibleChapter {
  id: string;
  bibleId: string;
  bookId: string;
  number: string;
  reference: string;
}

export interface BibleVerse {
  id: string;
  bibleId: string;
  bookId: string;
  chapterId: string;
  number: string;
  reference: string;
  content: string;
}

export interface BibleSearchResponse {
  query: string;
  total: number;
  verses: Array<{
    id: string;
    bookId: string;
    chapterId: string;
    text: string;
    reference: string;
  }>;
}

// Minimal static list of KJV books just in case API is slow or 401
export const STATIC_KJV_BOOKS = [
  { id: 'GEN', bibleId: 'de4e12af7f28f599-01', name: 'Genesis', nameLong: 'The First Book of Moses' },
  { id: 'EXO', bibleId: 'de4e12af7f28f599-01', name: 'Exodus', nameLong: 'The Second Book of Moses' },
  { id: 'PSA', bibleId: 'de4e12af7f28f599-01', name: 'Psalms', nameLong: 'The Book of Psalms' },
  { id: 'PRO', bibleId: 'de4e12af7f28f599-01', name: 'Proverbs', nameLong: 'The Proverbs' },
  { id: 'MAT', bibleId: 'de4e12af7f28f599-01', name: 'Matthew', nameLong: 'The Gospel According to St. Matthew' },
  { id: 'JHN', bibleId: 'de4e12af7f28f599-01', name: 'John', nameLong: 'The Gospel According to St. John' },
  { id: 'ROM', bibleId: 'de4e12af7f28f599-01', name: 'Romans', nameLong: 'The Epistle of Paul to the Romans' },
  { id: 'REV', bibleId: 'de4e12af7f28f599-01', name: 'Revelation', nameLong: 'The Revelation of St. John the Divine' }
];

export const STATIC_KJV_VERSIONS = [
  { id: 'de4e12af7f28f599-01', name: 'King James (Authorised) Version', abbreviation: 'KJV' },
  { id: '06125adad2d5898a-01', name: 'American Standard Version', abbreviation: 'ASV' },
  { id: '9879dbb7cfe39e4d-01', name: 'World English Bible', abbreviation: 'WEB' }
];

export async function fetchBibleVersions(): Promise<BibleVersion[]> {
  try {
    const res = await fetch('/api/bible/bibles');
    if (!res.ok) throw new Error(`Status ${res.status}`);
    const json = await res.json();
    return json.data || STATIC_KJV_VERSIONS;
  } catch (error) {
    console.error("fetchBibleVersions", error);
    return STATIC_KJV_VERSIONS;
  }
}

export async function fetchBibleBooks(bibleId: string): Promise<BibleBook[]> {
  try {
    const res = await fetch(`/api/bible/bibles/${bibleId}/books`);
    if (!res.ok) throw new Error(`Status ${res.status}`);
    const json = await res.json();
    return json.data || STATIC_KJV_BOOKS;
  } catch (error) {
    console.error("fetchBibleBooks", error);
    return STATIC_KJV_BOOKS;
  }
}

export async function fetchBibleChapters(bibleId: string, bookId: string): Promise<BibleChapter[]> {
  try {
    const res = await fetch(`/api/bible/bibles/${bibleId}/books/${bookId}/chapters`);
    if (!res.ok) throw new Error(`Status ${res.status}`);
    const json = await res.json();
    return json.data || [{ id: `${bookId}.1`, bibleId, bookId, number: '1', reference: `${bookId} 1` }];
  } catch (error) {
    console.error("fetchBibleChapters", error);
    return [{ id: `${bookId}.1`, bibleId, bookId, number: '1', reference: `${bookId} 1` }];
  }
}

export async function fetchBibleChapterContent(bibleId: string, chapterId: string) {
  try {
    const res = await fetch(`/api/bible/bibles/${bibleId}/chapters/${chapterId}?content-type=html&include-notes=false&include-titles=true&include-chapter-numbers=true&include-verse-numbers=true&include-verse-spans=false`);
    if (!res.ok) throw new Error(`Status ${res.status}`);
    const json = await res.json();
    return json.data;
  } catch (error) {
    console.error("fetchBibleChapterContent", error);
    return null;
  }
}

export async function fetchBibleVerse(bibleId: string, verseId: string): Promise<BibleVerse | null> {
  try {
    const res = await fetch(`/api/bible/bibles/${bibleId}/verses/${verseId}?content-type=text`);
    if (!res.ok) throw new Error(`Status ${res.status}`);
    const json = await res.json();
    return json.data;
  } catch (error) {
    console.error("fetchBibleVerse", error);
    return null;
  }
}

export async function searchBible(bibleId: string, query: string): Promise<BibleSearchResponse | null> {
  try {
    const res = await fetch(`/api/bible/bibles/${bibleId}/search?query=${encodeURIComponent(query)}`);
    if (!res.ok) throw new Error(`Status ${res.status}`);
    const json = await res.json();
    return json.data;
  } catch (error) {
    console.error("searchBible", error);
    return null;
  }
}

export async function bibleChat(prompt: string, history: any[] = []) {
  try {
    const res = await fetch('/api/bible/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ prompt, history })
    });
    if (!res.ok) throw new Error(`Status ${res.status}`);
    const data = await res.json();
    return data.text;
  } catch (error) {
    console.error("bibleChat", error);
    return "I am sorry, I am having trouble connecting to my wisdom source right now. Please pray and try again later.";
  }
}

export const DEFAULT_LIVING_WORD = {
  ref: 'John 15:16',
  text: 'Ye have not chosen me, but I have chosen you, and ordained you, that ye should go and bring forth fruit, and that your fruit should remain: that whatsoever ye shall ask of the Father in my name, he may give it you.'
};

// Living Word fetcher (defaults to John 15:16 until updated by Admin in Portal)
export async function fetchDailyVerse() {
  // 'settings/livingWord' -> site_settings row with key='living_word',
  // value jsonb { ref, text }. A perfect fit for the key/value table already
  // in your schema — no new table needed for this one.
  try {
    const { data, error } = await supabase.from('site_settings').select('value').eq('key', 'living_word').maybeSingle();
    if (error) throw error;
    if (data?.value?.ref && data?.value?.text) {
      return { ref: data.value.ref, text: data.value.text };
    }
  } catch (e) {
    console.warn("Living word fetch warning, using default John 15:16", e);
  }
  return DEFAULT_LIVING_WORD;
}
