import { supabase } from '../supabase';

/**
 * Muting, blocking (with a reason that goes to the admins), chat suspension, and the
 * admin's review. All of the rules are enforced by the database (06b-chat-features.sql);
 * this file is only the app's way of calling it.
 */

export type MuteTarget = 'group' | string; // 'group' = the group chat, otherwise the other person's id

export const BLOCK_REASONS: { id: string; label: string }[] = [
  { id: 'harassment', label: 'Harassment or bullying' },
  { id: 'spam', label: 'Spam or unwanted promotion' },
  { id: 'inappropriate', label: 'Inappropriate messages or images' },
  { id: 'unwanted', label: 'Unwanted contact' },
  { id: 'other', label: 'Something else' },
];

export interface MyBlock { id: string; blockedId: string; locked: boolean; releaseAt: string | null }
export interface BlockReport {
  id: string;
  blockId: string;
  reporterId: string;
  reporterName: string;
  reportedId: string;
  reportedName: string;
  reason: string;
  note: string | null;
  evidence: { from: string; at: string; text: string }[];
  status: 'open' | 'reviewed';
  decision: any;
  adminNote: string | null;
  createdAt: string;
  decidedAt: string | null;
}
export interface Suspension { id: string; userId: string; userName: string; reason: string | null; until: string }

const friendly = (e: any): Error => new Error(e?.message || 'Something went wrong. Please try again.');

export const chatSafetyService = {
  // ---- Muting ---------------------------------------------------------------------
  /** Active mutes only: { target: mutedUntilISO | null }, null meaning "always". */
  async getMutes(uid: string): Promise<Record<string, string | null>> {
    const { data } = await supabase.from('chat_mutes').select('target, muted_until').eq('user_id', uid);
    const out: Record<string, string | null> = {};
    (data ?? []).forEach((r: any) => {
      if (!r.muted_until || new Date(r.muted_until).getTime() > Date.now()) out[r.target] = r.muted_until ?? null;
    });
    return out;
  },
  /** hours = null mutes it always. */
  async mute(uid: string, target: MuteTarget, hours: number | null): Promise<void> {
    const muted_until = hours === null ? null : new Date(Date.now() + hours * 3600_000).toISOString();
    const { error } = await supabase.from('chat_mutes').upsert({ user_id: uid, target, muted_until }, { onConflict: 'user_id,target' });
    if (error) throw friendly(error);
  },
  async unmute(uid: string, target: MuteTarget): Promise<void> {
    const { error } = await supabase.from('chat_mutes').delete().eq('user_id', uid).eq('target', target);
    if (error) throw friendly(error);
  },

  // ---- Blocking -------------------------------------------------------------------
  /** The blocks that are in force right now (the blocked person never sees this list). */
  async getMyBlocks(uid: string): Promise<MyBlock[]> {
    const { data } = await supabase
      .from('user_blocks')
      .select('id, blocked_id, locked, release_at')
      .eq('blocker_id', uid)
      .eq('status', 'active');
    return (data ?? [])
      .filter((r: any) => !r.release_at || new Date(r.release_at).getTime() > Date.now())
      .map((r: any) => ({ id: r.id, blockedId: r.blocked_id, locked: !!r.locked, releaseAt: r.release_at ?? null }));
  },
  async blockUser(blockedId: string, reason: string, note?: string): Promise<void> {
    const { error } = await supabase.rpc('block_user', { p_blocked: blockedId, p_reason: reason, p_note: note?.trim() || null });
    if (error) throw friendly(error);
  },
  async unblockUser(blockedId: string): Promise<void> {
    const { error } = await supabase.rpc('unblock_user', { p_blocked: blockedId });
    if (error) throw friendly(error);
  },

  // ---- Suspension -----------------------------------------------------------------
  /** When this person's chat pause ends, or null if they are not suspended. */
  async getMySuspensionUntil(uid: string): Promise<string | null> {
    const { data } = await supabase
      .from('chat_suspensions')
      .select('until')
      .eq('user_id', uid)
      .is('lifted_at', null)
      .gt('until', new Date().toISOString())
      .order('until', { ascending: false })
      .limit(1);
    return data && data.length ? data[0].until : null;
  },

  // ---- Admin ----------------------------------------------------------------------
  async listReports(status: 'open' | 'reviewed'): Promise<BlockReport[]> {
    const { data, error } = await supabase
      .from('block_reports')
      .select('*, reporter:profiles!reporter_id(full_name), reported:profiles!reported_id(full_name)')
      .eq('status', status)
      .order('created_at', { ascending: false })
      .limit(100);
    if (error) throw friendly(error);
    return (data ?? []).map((r: any) => ({
      id: r.id, blockId: r.block_id, reporterId: r.reporter_id, reporterName: r.reporter?.full_name ?? 'A member',
      reportedId: r.reported_id, reportedName: r.reported?.full_name ?? 'A member', reason: r.reason, note: r.note,
      evidence: Array.isArray(r.evidence) ? r.evidence : [], status: r.status, decision: r.decision, adminNote: r.admin_note,
      createdAt: r.created_at, decidedAt: r.decided_at,
    }));
  },
  async reviewReport(p: {
    reportId: string; blockAction: 'unblock' | 'keep'; keepDays?: number | null; suspendDays?: number | null; warning?: string; adminNote?: string;
  }): Promise<void> {
    const { error } = await supabase.rpc('admin_review_block_report', {
      p_report: p.reportId, p_block_action: p.blockAction, p_keep_days: p.keepDays ?? null,
      p_suspend_days: p.suspendDays ?? null, p_warning: p.warning?.trim() || null, p_admin_note: p.adminNote?.trim() || null,
    });
    if (error) throw friendly(error);
  },
  async listSuspensions(): Promise<Suspension[]> {
    const { data, error } = await supabase
      .from('chat_suspensions')
      .select('id, user_id, reason, until, user:profiles!user_id(full_name)')
      .is('lifted_at', null)
      .gt('until', new Date().toISOString())
      .order('until');
    if (error) throw friendly(error);
    return (data ?? []).map((r: any) => ({ id: r.id, userId: r.user_id, userName: r.user?.full_name ?? 'A member', reason: r.reason, until: r.until }));
  },
  async liftSuspension(userId: string): Promise<void> {
    const { error } = await supabase.rpc('admin_lift_suspension', { p_user: userId });
    if (error) throw friendly(error);
  },
};
