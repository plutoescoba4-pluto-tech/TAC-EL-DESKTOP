import { supabase } from '../supabase';
import { EventItem } from '../types';

function rowToEvent(row: any): EventItem {
  return {
    id: row.id,
    title: row.title,
    startDate: row.starts_at,
    endDate: undefined, // no end_date column yet — see MIGRATION_NOTES.md
    type: (row.type as EventItem['type']) || 'other', // no `type` column yet, defaults client-side
    summary: row.description ?? '',
    location: row.location ?? undefined,
    posterUrl: undefined, // no poster_url column yet — see MIGRATION_NOTES.md
    createdAt: row.created_at,
  };
}

export const eventsService = {
  async getEvents(): Promise<EventItem[]> {
    const { data, error } = await supabase.from('events').select('*').order('starts_at', { ascending: true });
    if (error) {
      console.warn('getEvents error:', error);
      return [];
    }
    return (data ?? []).map(rowToEvent);
  },

  async addEvent(event: Omit<EventItem, 'id' | 'createdAt'>): Promise<string> {
    const { data, error } = await supabase
      .from('events')
      .insert({
        title: event.title,
        description: event.summary,
        starts_at: event.startDate,
        location: event.location,
      })
      .select()
      .single();
    if (error) throw error;
    return data.id;
  },

  async updateEvent(id: string, event: Partial<EventItem>): Promise<void> {
    const row: Record<string, any> = {};
    if (event.title !== undefined) row.title = event.title;
    if (event.summary !== undefined) row.description = event.summary;
    if (event.startDate !== undefined) row.starts_at = event.startDate;
    if (event.location !== undefined) row.location = event.location;
    const { error } = await supabase.from('events').update(row).eq('id', id);
    if (error) throw error;
  },

  async deleteEvent(id: string): Promise<void> {
    const { error } = await supabase.from('events').delete().eq('id', id);
    if (error) throw error;
  },

  async rsvpEvent(eventId: string, user: { uid: string; name: string; email?: string }): Promise<void> {
    const { error } = await supabase
      .from('event_rsvps')
      .insert({ event_id: eventId, profile_id: user.uid });
    if (error) throw error;
  },

  async getEventRsvps(eventId: string): Promise<any[]> {
    const { data, error } = await supabase
      .from('event_rsvps')
      .select('*, profiles(full_name, email)')
      .eq('event_id', eventId);
    if (error) return [];
    return data ?? [];
  },
};
