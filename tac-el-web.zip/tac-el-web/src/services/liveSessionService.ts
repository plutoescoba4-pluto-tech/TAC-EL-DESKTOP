import { supabase } from '../supabase';
import { subscribeQuery, subscribePresence } from '../lib/realtime';
import type { RealtimeChannel } from '@supabase/supabase-js';

export interface LiveVoiceRoom {
  id: string;
  title: string;
  hostId: string;
  hostName: string;
  active: boolean;
  participantCount: number;
  participants?: Record<string, { name: string; isMuted: boolean; isSpeaking: boolean }>;
  createdAt: any;
}

function rowToRoom(row: any): LiveVoiceRoom {
  return {
    id: row.id,
    title: row.title,
    hostId: row.started_by,
    hostName: '', // resolved via profile join where needed
    active: row.is_active,
    participantCount: 0, // live count comes from the Presence channel, not this table — see subscribeParticipants
    createdAt: row.started_at,
  };
}

export const liveSessionService = {
  /** Active rooms list — persisted in `live_sessions`, refetched on change. */
  subscribeToActiveRooms(callback: (rooms: LiveVoiceRoom[]) => void) {
    return subscribeQuery<any>(
      { table: 'live_sessions', match: { is_active: true }, select: '*, profiles!started_by(full_name)' },
      (rows) => callback(rows.map((r) => ({ ...rowToRoom(r), hostName: r.profiles?.full_name ?? '' }))),
      (err) => console.warn('Voice rooms active subscription warning:', err)
    );
  },

  async startRoom(room: { title: string; hostId: string; hostName: string }): Promise<string> {
    const { data, error } = await supabase
      .from('live_sessions')
      .insert({
        title: room.title,
        session_type: 'audio',
        scope_type: 'whole_portal',
        started_by: room.hostId,
        is_active: true,
      })
      .select()
      .single();
    if (error) throw error;
    return data.id;
  },

  /** Live participant list for a room — ephemeral Realtime Presence, not a
   *  table (per your call to switch presence/voice rooms to Presence
   *  channels). Mute/speaking state updates instantly and clears the moment
   *  someone disconnects, with zero database writes. */
  subscribeParticipants(
    roomId: string,
    self: { uid: string; name: string } | null,
    callback: (participants: Record<string, { name: string; photo?: string; isMuted: boolean; isSpeaking: boolean; recording?: boolean }>) => void
  ): { channel: RealtimeChannel; unsubscribe: () => void } {
    return subscribePresence(
      `voice-room:${roomId}`,
      self ? { key: self.uid, meta: { name: self.name, isMuted: true, isSpeaking: false } } : null,
      (state) => {
        const participants: Record<string, { name: string; photo?: string; isMuted: boolean; isSpeaking: boolean; recording?: boolean }> = {};
        for (const [key, metas] of Object.entries(state)) {
          const meta = metas[0] as any;
          participants[key] = { name: meta?.name ?? '', photo: meta?.photo, isMuted: !!meta?.isMuted, isSpeaking: !!meta?.isSpeaking, recording: !!meta?.recording };
        }
        callback(participants);
      }
    );
  },

  async getActiveRoomsOlderThan(hours: number): Promise<{ id: string }[]> {
    const cutoff = new Date(Date.now() - hours * 60 * 60 * 1000).toISOString();
    const { data, error } = await supabase.from('live_sessions').select('id').eq('is_active', true).lt('started_at', cutoff);
    if (error) return [];
    return data ?? [];
  },

  async endRoom(roomId: string): Promise<void> {
    // .select() so a silently blocked update (row-level security updates 0 rows
    // without an error) is noticed instead of leaving the room "live" forever.
    const { data, error } = await supabase
      .from('live_sessions')
      .update({ is_active: false, ended_at: new Date().toISOString() })
      .eq('id', roomId)
      .select('id');
    if (error) throw error;
    if (!data || data.length === 0) throw new Error('The room could not be ended (not allowed, or it no longer exists).');
  },

  /** Clears any rooms left dangling active=true from a previous session
   *  (matches the old "sweep stale voice_rooms on mount" behavior). */
  async endAllActiveRoomsStartedBy(hostId: string): Promise<void> {
    await supabase
      .from('live_sessions')
      .update({ is_active: false, ended_at: new Date().toISOString() })
      .eq('started_by', hostId)
      .eq('is_active', true);
  },
};
