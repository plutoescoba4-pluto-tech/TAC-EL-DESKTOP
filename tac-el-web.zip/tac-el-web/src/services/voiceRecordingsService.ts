import { supabase } from '../supabase';
import { sermonsService } from './contentService';

/**
 * Voice Sanctuary recordings live in a Supabase Storage bucket, not the
 * database — a long prayer is many megabytes of audio.
 *
 *   <bucket>/pending/<timestamp>_<durationSec>_<host-slug>.<ext>   awaiting admin
 *   <bucket>/published/<same name>                                 posted/saved
 *
 * "Pending" vs "published" is just the folder, so no new table is needed.
 * Host/duration/date are encoded in the filename and parsed back out. The
 * bucket must exist and be PUBLIC (members play the audio straight from its
 * URL) — see MIGRATION_NOTES.md for the access rules it needs.
 */
export const VOICE_BUCKET = 'voice-sanctuary';

export interface PendingRecording {
  path: string;        // pending/<name>
  fileName: string;
  url: string;
  recordedAt: string;
  durationSec: number;
  hostName: string;
}

function slug(s: string) {
  return s.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 30) || 'host';
}

function parseName(fileName: string) {
  const base = fileName.replace(/\.[^.]+$/, '');
  const [ts, dur, ...host] = base.split('_');
  return {
    recordedAt: new Date(Number(ts) || Date.now()).toISOString(),
    durationSec: Number(dur) || 0,
    hostName: host.join(' ').replace(/-/g, ' ') || 'Host',
  };
}

export const voiceRecordingsService = {
  async uploadPending(blob: Blob, hostName: string, durationSec: number): Promise<void> {
    const ext = blob.type.includes('mp4') ? 'm4a' : blob.type.includes('ogg') ? 'ogg' : 'webm';
    const path = `pending/${Date.now()}_${durationSec}_${slug(hostName)}.${ext}`;
    const { error } = await supabase.storage.from(VOICE_BUCKET).upload(path, blob, {
      contentType: blob.type || 'audio/webm',
      upsert: false,
    });
    if (error) throw error;
  },

  async listPending(): Promise<PendingRecording[]> {
    const { data, error } = await supabase.storage.from(VOICE_BUCKET).list('pending', {
      limit: 100,
      sortBy: { column: 'name', order: 'desc' },
    });
    if (error) throw error;
    return (data ?? [])
      .filter((f) => f.name && !f.name.startsWith('.'))
      .map((f) => ({
        path: `pending/${f.name}`,
        fileName: f.name,
        url: supabase.storage.from(VOICE_BUCKET).getPublicUrl(`pending/${f.name}`).data.publicUrl,
        ...parseName(f.name),
      }));
  },

  /** Moves the file out of pending/ so it leaves the inbox, and returns its permanent URL. */
  async moveToPublished(rec: PendingRecording): Promise<string> {
    const dest = `published/${rec.fileName}`;
    const { error } = await supabase.storage.from(VOICE_BUCKET).move(rec.path, dest);
    if (error) throw error;
    return supabase.storage.from(VOICE_BUCKET).getPublicUrl(dest).data.publicUrl;
  },

  /** If the database insert fails after the file was moved, move it back so
   *  it doesn't vanish from the admin's inbox with nothing pointing to it. */
  async _moveBack(rec: PendingRecording) {
    await supabase.storage.from(VOICE_BUCKET).move(`published/${rec.fileName}`, rec.path).catch(() => {});
  },

  async saveToLibrary(rec: PendingRecording, title: string): Promise<void> {
    const url = await this.moveToPublished(rec);
    const { error } = await supabase.from('recordings').insert({
      title: `${rec.hostName} — ${title}`,
      session_type: 'audio',
      audio_url: url,
      duration_seconds: rec.durationSec,
    });
    if (error) {
      await this._moveBack(rec);
      throw error;
    }
  },

  async postAsSermon(rec: PendingRecording, title: string, speaker: string): Promise<void> {
    const url = await this.moveToPublished(rec);
    try {
      await sermonsService.addSermon({
        title,
        speaker,
        date: new Date(rec.recordedAt).toISOString().split('T')[0],
        audioUrl: url,
      });
    } catch (err) {
      await this._moveBack(rec);
      throw err;
    }
  },

  async discard(rec: PendingRecording): Promise<void> {
    const { error } = await supabase.storage.from(VOICE_BUCKET).remove([rec.path]);
    if (error) throw error;
  },
};
