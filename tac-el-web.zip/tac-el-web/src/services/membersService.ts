import { supabase } from '../supabase';
import { rowToProfile } from './authService';
import { UserProfile, UserRole } from '../types';

export interface Visitor {
  id: string;
  name: string;
  phone: string;
  email?: string;
  gender?: string;
  date_of_birth?: string;
  address?: string;
  ethnicity?: string;
  language?: string;
  visitDate: string;
  invitedBy?: string;
  status: 'first_timer' | 'followed_up' | 'second_timer' | 'joined_class' | 'member';
  notes?: string;
  createdAt: any;
}

// membership_applications, per your schema, is keyed by profile_id (the
// applicant must already have an auth account + profiles row) with columns
// government_id_url / tac_el_id_submitted / status. The old Firestore shape
// (raw name/email/phone/baptized/etc, status pending|interview_scheduled|
// approved|rejected) doesn't have a home there, so this keeps only what the
// new table actually stores and drops the rest — flagged in
// MIGRATION_NOTES.md in case you want those fields added to the applicant's
// profiles row instead (e.g. baptized/previousChurch as profile columns).
export interface MembershipApplication {
  id: string;
  profileId: string;
  applicantName?: string;
  tacIdSubmitted: string;
  governmentIdUrl?: string;
  status: 'pending_review' | 'kin_verified' | 'approved' | 'rejected';
  kinAiNotes?: string;
  appliedDate: string;
}

export const membersService = {
  async getAllMembers(): Promise<UserProfile[]> {
    const { data, error } = await supabase.from('profiles').select('*').order('full_name', { ascending: true }).limit(500);
    if (error) {
      console.warn('getAllMembers error:', error);
      return [];
    }
    return (data ?? []).map(rowToProfile);
  },

  async getMemberById(uid: string): Promise<UserProfile | null> {
    const { data, error } = await supabase.from('profiles').select('*').eq('id', uid).maybeSingle();
    if (error || !data) return null;
    return rowToProfile(data);
  },

  async updateMemberRole(uid: string, role: UserRole): Promise<void> {
    const { error } = await supabase.from('profiles').update({ role }).eq('id', uid);
    if (error) throw error;
  },

  /** Admin only: removes the member's profile and sign-in account (see 10-admin-delete-member.sql). */
  async deleteMember(uid: string): Promise<void> {
    const { error } = await supabase.rpc('admin_delete_member', { p_id: uid });
    if (error) {
      if ((error as any).code === 'PGRST202' || /could not find the function/i.test(error.message || '')) {
        throw new Error('Delete is not set up yet. Run 10-admin-delete-member.sql in Supabase, then try again.');
      }
      throw new Error(error.message || 'Could not delete this account.');
    }
  },

  // --- Visitor pipeline -----------------------------------------------
  // `visitors` is NOT in the pasted schema yet (first-timers by definition
  // don't have an auth account / profiles row, so it can't just be a
  // profiles filter). Wired against a `visitors` table name — add it with
  // columns matching the Visitor interface above when you're ready; until
  // then these calls will error and the pipeline screen will show empty.
  async getVisitorPipeline(): Promise<Visitor[]> {
    const { data, error } = await supabase.from('visitors').select('*').order('created_at', { ascending: false });
    if (error) {
      console.warn('getVisitorPipeline: `visitors` table not found yet — see MIGRATION_NOTES.md', error.message);
      return [];
    }
    return (data ?? []) as Visitor[];
  },

  async addVisitor(visitor: Omit<Visitor, 'id' | 'createdAt'>): Promise<string> {
    const { data, error } = await supabase.from('visitors').insert(visitor).select().single();
    if (error) throw error;
    return data.id;
  },

  async deleteVisitor(id: string): Promise<void> {
    const { error } = await supabase.from('visitors').delete().eq('id', id);
    if (error) throw error;
  },

  /** Puts the visitor into the register with a new TAC ID and removes them from the visitor list (needs SQL 22). */
  async makeVisitorMember(id: string): Promise<{ member_id: string; name: string }> {
    const { data, error } = await supabase.rpc('visitor_make_member', { p_visitor: id });
    if (error) throw error;
    return data as { member_id: string; name: string };
  },

  async updateVisitorStatus(id: string, status: Visitor['status']): Promise<void> {
    const { error } = await supabase.from('visitors').update({ status }).eq('id', id);
    if (error) throw error;
  },

  // --- Membership applications ------------------------------------------
  async getMembershipApplications(): Promise<MembershipApplication[]> {
    const { data, error } = await supabase
      .from('membership_applications')
      .select('*, profiles(full_name)')
      .order('created_at', { ascending: false });
    if (error) return [];
    return (data ?? []).map((row: any) => ({
      id: row.id,
      profileId: row.profile_id,
      applicantName: row.profiles?.full_name,
      tacIdSubmitted: row.tac_el_id_submitted,
      governmentIdUrl: row.government_id_url ?? undefined,
      status: row.status,
      kinAiNotes: row.kin_ai_notes ?? undefined,
      appliedDate: row.created_at,
    }));
  },

  async submitApplication(profileId: string, tacIdSubmitted: string, governmentIdUrl?: string): Promise<string> {
    const { data, error } = await supabase
      .from('membership_applications')
      .insert({ profile_id: profileId, tac_el_id_submitted: tacIdSubmitted, government_id_url: governmentIdUrl })
      .select()
      .single();
    if (error) throw error;
    return data.id;
  },

  async approveApplication(appId: string, memberUid: string): Promise<void> {
    const { error } = await supabase
      .from('membership_applications')
      .update({ status: 'approved', decided_at: new Date().toISOString() })
      .eq('id', appId);
    if (error) throw error;
    if (memberUid) {
      await supabase.from('profiles').update({ role: 'member', is_profile_complete: true }).eq('id', memberUid);
    }
  },
};
