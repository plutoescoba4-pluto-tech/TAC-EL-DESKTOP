import { supabase } from '../supabase';
import { authService } from './authService';
import { UserProfile } from '../types';

export interface VerificationResult {
  valid: boolean;
  profile?: UserProfile;
  message: string;
}

export const verificationService = {
  /** Renamed from autoVerifyKinId — same behavior, TAC ID naming throughout. */
  async autoVerifyTacId(tacId: string): Promise<VerificationResult> {
    const cleanId = tacId.trim().toUpperCase();
    if (!cleanId) {
      return { valid: false, message: 'Please enter a valid TAC / Member ID' };
    }

    try {
      // The person is usually signed out here, and profiles is closed to
      // signed-out users, so this goes through the email_for_tac_id() database
      // function. It only says whether the ID exists: no name, role or email
      // is revealed to someone who is not logged in.
      const email = await authService.emailForTacId(cleanId);
      if (email) {
        return { valid: true, message: 'This TAC ID is registered in the Assembly roster.' };
      }
      return {
        valid: false,
        message: 'TAC ID not found in Assembly roster. Please contact the Church Secretariat.',
      };
    } catch (e: any) {
      return {
        valid: false,
        message: e?.message || 'Verification check failed. Please check network connection.',
      };
    }
  },

  async markMemberVerified(uid: string): Promise<void> {
    await supabase
      .from('profiles')
      .update({ is_profile_complete: true })
      .eq('id', uid);
  },
};
