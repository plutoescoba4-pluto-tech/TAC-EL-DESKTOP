import { supabase } from '../supabase';
import { subscribeQuery } from '../lib/realtime';

export interface Directive {
  id: string;
  fromProfileId: string;
  fromName?: string;
  message: string;
  status: 'open' | 'acknowledged';
  createdAt: string;
}

function rowToDirective(row: any): Directive {
  return {
    id: row.id,
    fromProfileId: row.from_profile_id,
    fromName: row.profiles?.full_name,
    message: row.message,
    status: row.status,
    createdAt: row.created_at,
  };
}

export const directivesService = {
  async getDirectives(): Promise<Directive[]> {
    const { data, error } = await supabase
      .from('directives')
      .select('*, profiles!from_profile_id(full_name)')
      .order('created_at', { ascending: false });
    if (error) return [];
    return (data ?? []).map(rowToDirective);
  },
  subscribeDirectives(callback: (directives: Directive[]) => void) {
    return subscribeQuery<any>(
      { table: 'directives', orderBy: { column: 'created_at', ascending: false }, select: '*, profiles!from_profile_id(full_name)' },
      (rows) => callback(rows.map(rowToDirective))
    );
  },
  async sendDirective(fromProfileId: string, message: string): Promise<string> {
    const { data, error } = await supabase.from('directives').insert({ from_profile_id: fromProfileId, message }).select().single();
    if (error) throw error;
    return data.id;
  },
  async acknowledgeDirective(id: string): Promise<void> {
    const { error } = await supabase.from('directives').update({ status: 'acknowledged' }).eq('id', id);
    if (error) throw error;
  },
};
