// Kin AI's per-member memory (recent verses/searches/questions, so it can
// say "I see you were just reading Romans 8..."). There's no table for this
// in your schema yet — it's not user-facing data anyone else needs to read,
// so rather than block the feature it now lives in localStorage, keyed per
// device rather than per account. Add a `kin_ai_memory` table (profile_id pk,
// jsonb column) if you want it to follow the member across devices — see
// MIGRATION_NOTES.md.

export interface MemberActivity {
  lastVerseRead?: { book: string; chapter: number; verse?: number; timestamp: string };
  recentVerses: any[];
  recentSearches: string[];
  recentQuestions: { question: string; answer?: string; timestamp: string }[];
  bookmarks: any[];
  favouriteTopics: string[];
  lastSermon?: { title: string; id: string; timestamp: string };
  sessionsCount: number;
  lastActiveDate: string;
}

const MAX_HISTORY = 10;
const key = (userId: string) => `tac_member_memory_${userId}`;

function load(userId: string): MemberActivity {
  try {
    const raw = localStorage.getItem(key(userId));
    if (raw) return JSON.parse(raw);
  } catch {
    /* ignore */
  }
  return {
    recentVerses: [],
    recentSearches: [],
    recentQuestions: [],
    bookmarks: [],
    favouriteTopics: [],
    sessionsCount: 0,
    lastActiveDate: new Date().toISOString(),
  };
}

function save(userId: string, data: MemberActivity) {
  try {
    localStorage.setItem(key(userId), JSON.stringify(data));
  } catch {
    /* ignore (private browsing, storage full, etc.) */
  }
}

export const trackActivity = async (
  userId: string,
  type: 'verse' | 'search' | 'question' | 'sermon' | 'session' | 'bookmark' | 'favorite',
  data: any
) => {
  if (!userId) return;
  const mem = load(userId);
  const now = new Date().toISOString();

  switch (type) {
    case 'verse':
      mem.lastVerseRead = { ...data, timestamp: now };
      mem.recentVerses = [...mem.recentVerses, { ...data, timestamp: now }].slice(-MAX_HISTORY);
      break;
    case 'search':
      mem.recentSearches = [...mem.recentSearches, data].slice(-MAX_HISTORY);
      break;
    case 'question':
      mem.recentQuestions = [...mem.recentQuestions, { ...data, timestamp: now }].slice(-MAX_HISTORY);
      break;
    case 'sermon':
      mem.lastSermon = { ...data, timestamp: now };
      break;
    case 'session':
      mem.sessionsCount += 1;
      mem.lastActiveDate = now;
      break;
    case 'bookmark':
      mem.bookmarks = [...mem.bookmarks, data].slice(-MAX_HISTORY);
      break;
    case 'favorite':
      mem.favouriteTopics = Array.from(new Set([...mem.favouriteTopics, data])).slice(-MAX_HISTORY);
      break;
  }
  save(userId, mem);
};

export const getMemberContext = async (userId: string): Promise<string | null> => {
  if (!userId) return null;
  const data = load(userId);

  const last3Verses = data.recentVerses?.slice(-3).map((v) => `${v.book} ${v.chapter}:${v.verse || ''}`).join(', ') || 'None';
  const last3Searches = data.recentSearches?.slice(-3).join(', ') || 'None';
  const lastQuestion = data.recentQuestions?.length ? data.recentQuestions[data.recentQuestions.length - 1].question : 'None';
  const currentVerse = data.lastVerseRead ? `${data.lastVerseRead.book} ${data.lastVerseRead.chapter}` : 'None';

  return `Member context:
- Currently reading: ${currentVerse}
- Recently read: ${last3Verses}
- Recent searches: ${last3Searches}
- Last question they asked: ${lastQuestion}
- Favourite topics: ${data.favouriteTopics?.join(', ') || 'None'}
- Last sermon: ${data.lastSermon?.title || 'None'}

Use this context to give personalized, relevant answers.
Reference what they are reading when appropriate.
Feel like a personal pastor who knows them well.`;
};

export const clearMemberHistory = async (userId: string) => {
  if (!userId) return;
  save(userId, {
    recentVerses: [],
    recentSearches: [],
    recentQuestions: [],
    bookmarks: [],
    favouriteTopics: [],
    sessionsCount: 0,
    lastActiveDate: new Date().toISOString(),
  });
};
