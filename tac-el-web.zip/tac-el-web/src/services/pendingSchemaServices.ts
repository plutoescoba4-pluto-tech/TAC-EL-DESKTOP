import { supabase } from '../supabase';
import { subscribeQuery } from '../lib/realtime';
import { UpdateRequest } from '../types';

// ============================================================================
// None of the three tables below (prayer_requests, build_in_christ,
// update_requests) are in the schema you pasted. Each service here is wired
// up against the table/column names below so the *component* side of the
// migration is finished and mechanical — the moment you add a matching
// table, these start working with no further code changes. Exact columns
// expected are listed in MIGRATION_NOTES.md. Until then, reads return an
// empty list and writes throw (surfaced to the user as a normal error toast,
// not a crash).
// ============================================================================

// --- Prayer requests --------------------------------------------------
export interface PrayerRequest {
  id: string;
  userId: string;
  userName: string;
  userKinId: string; // kept as "Kin ID" internally only because it's a free-text
  title: string;
  content: string;
  confidential: boolean;
  audioVoiceNote?: string | null;
  status: 'interceding' | 'answered';
  createdAt: string;
}

export const prayerRequestsService = {
  subscribeMine(uid: string, callback: (r: PrayerRequest[]) => void) {
    return subscribeQuery<PrayerRequest>(
      { table: 'prayer_requests', match: { userId: uid }, orderBy: { column: 'createdAt', ascending: false } },
      callback,
      (err) => console.warn('prayer_requests: table not found yet — see MIGRATION_NOTES.md', err)
    );
  },
  async getRecent(limitN = 5): Promise<PrayerRequest[]> {
    const { data, error } = await supabase.from('prayer_requests').select('*').order('createdAt', { ascending: false }).limit(limitN);
    if (error) return [];
    return (data ?? []) as PrayerRequest[];
  },
  /** Everyone currently "waiting" (status='interceding') — for the
   *  admin/presbytery altar queue, so they can pray through it and clear it. */
  async getWaiting(limitN = 100): Promise<PrayerRequest[]> {
    const { data, error } = await supabase
      .from('prayer_requests')
      .select('*')
      .eq('status', 'interceding')
      .order('createdAt', { ascending: false })
      .limit(limitN);
    if (error) {
      console.warn('prayer_requests: table not found yet — see MIGRATION_NOTES.md', error.message);
      return [];
    }
    return (data ?? []) as PrayerRequest[];
  },
  async submit(request: Omit<PrayerRequest, 'id' | 'createdAt' | 'status'>): Promise<void> {
    const { error } = await supabase.from('prayer_requests').insert({ ...request, status: 'interceding' });
    if (error) throw error;
  },
  async markAnswered(id: string): Promise<void> {
    const { error } = await supabase.from('prayer_requests').update({ status: 'answered' }).eq('id', id);
    if (error) throw error;
  },
  async remove(id: string): Promise<void> {
    const { error } = await supabase.from('prayer_requests').delete().eq('id', id);
    if (error) throw error;
  },
};

// --- Build in Christ (discipleship posts) --------------------------------
export interface BuildInChristPost {
  id: string;
  title: string;
  body: string;
  category: 'Article' | 'Devotional' | 'Doctrine' | 'Foundation';
  authorId: string;
  authorName: string;
  likes: number;
  comments: number;
  externalUrl?: string;
  color?: string;
  createdAt: string;
}

export const buildInChristService = {
  async getAll(limitN = 100): Promise<BuildInChristPost[]> {
    const { data, error } = await supabase.from('build_in_christ').select('*').order('createdAt', { ascending: false }).limit(limitN);
    if (error) {
      console.warn('build_in_christ: table not found yet — see MIGRATION_NOTES.md', error.message);
      return [];
    }
    return (data ?? []) as BuildInChristPost[];
  },
  subscribeAll(callback: (posts: BuildInChristPost[]) => void, limitN = 100) {
    return subscribeQuery<BuildInChristPost>(
      { table: 'build_in_christ', orderBy: { column: 'createdAt', ascending: false }, limit: limitN },
      callback,
      (err) => console.warn('build_in_christ: table not found yet — see MIGRATION_NOTES.md', err)
    );
  },
  async add(post: Omit<BuildInChristPost, 'id' | 'createdAt'>): Promise<void> {
    const { error } = await supabase.from('build_in_christ').insert(post);
    if (error) throw error;
  },
  async remove(id: string): Promise<void> {
    const { error } = await supabase.from('build_in_christ').delete().eq('id', id);
    if (error) throw error;
  },
};

// --- Church conduct / protocol sections -----------------------------------
export interface ChurchConductRow {
  id: string;
  title: string;
  points: string[];
  category: 'general' | 'marriage' | 'youth' | 'protocol';
  lastUpdated?: string;
}

export const conductsService = {
  async getAll(): Promise<ChurchConductRow[]> {
    const { data, error } = await supabase.from('conducts').select('*').order('title', { ascending: true }).limit(50);
    if (error) {
      console.warn('conducts: table not found yet — see MIGRATION_NOTES.md', error.message);
      return [];
    }
    return (data ?? []) as ChurchConductRow[];
  },
  async add(row: Omit<ChurchConductRow, 'id'>): Promise<void> {
    const { error } = await supabase.from('conducts').insert(row);
    if (error) throw error;
  },
  async update(id: string, row: Partial<ChurchConductRow>): Promise<void> {
    const { error } = await supabase.from('conducts').update(row).eq('id', id);
    if (error) throw error;
  },
  async remove(id: string): Promise<void> {
    const { error } = await supabase.from('conducts').delete().eq('id', id);
    if (error) throw error;
  },
};
function rowIsAlreadyAppShaped(row: any): UpdateRequest {
  return row as UpdateRequest;
}

// --- Club/team tasks, gallery, chat --------------------------------------
// None of these three are in the schema either (per-team task boards, media
// archives, and internal chat). Wired against club_tasks / club_gallery /
// club_chat_messages so the component side is finished — add matching
// tables (each keyed by club_id) to light this back up.
export const clubExtrasService = {
  async getTasks(clubId: string): Promise<any[]> {
    const { data, error } = await supabase.from('club_tasks').select('*').eq('club_id', clubId).order('createdAt', { ascending: false }).limit(50);
    if (error) {
      console.warn('club_tasks: table not found yet — see MIGRATION_NOTES.md', error.message);
      return [];
    }
    return data ?? [];
  },
  async completeTask(taskId: string): Promise<void> {
    const { error } = await supabase.from('club_tasks').update({ status: 'completed' }).eq('id', taskId);
    if (error) throw error;
  },
  async addTask(clubId: string, title: string): Promise<void> {
    const { error } = await supabase.from('club_tasks').insert({ club_id: clubId, title, status: 'pending' });
    if (error) throw error;
  },
  async getGallery(clubId: string): Promise<any[]> {
    const { data, error } = await supabase.from('club_gallery').select('*').eq('club_id', clubId).order('createdAt', { ascending: false }).limit(50);
    if (error) {
      console.warn('club_gallery: table not found yet — see MIGRATION_NOTES.md', error.message);
      return [];
    }
    return data ?? [];
  },
  async addGalleryItem(clubId: string, src: string, type: 'img' | 'vid' = 'img'): Promise<void> {
    const { error } = await supabase.from('club_gallery').insert({ club_id: clubId, src, type });
    if (error) throw error;
  },
  subscribeChat(clubId: string, callback: (messages: any[]) => void) {
    return subscribeQuery<any>(
      { table: 'club_chat_messages', match: { club_id: clubId }, orderBy: { column: 'createdAt', ascending: false }, limit: 50 },
      (rows) => callback(rows.slice().reverse()),
      (err) => console.warn('club_chat_messages: table not found yet — see MIGRATION_NOTES.md', err)
    );
  },
  async sendChat(clubId: string, senderId: string, senderName: string, text: string): Promise<void> {
    const { error } = await supabase.from('club_chat_messages').insert({ club_id: clubId, senderId, senderName, text });
    if (error) throw error;
  },
};

export const updateRequestsService = {
  subscribeAll(callback: (rows: UpdateRequest[]) => void, limitN = 50) {
    return subscribeQuery<UpdateRequest>(
      { table: 'update_requests', orderBy: { column: 'createdAt', ascending: false }, limit: limitN },
      callback,
      (err) => console.warn('update_requests: table not found yet — see MIGRATION_NOTES.md', err)
    );
  },
  subscribeMine(authorId: string, callback: (rows: UpdateRequest[]) => void, limitN = 50) {
    return subscribeQuery<UpdateRequest>(
      { table: 'update_requests', match: { authorId }, orderBy: { column: 'createdAt', ascending: false }, limit: limitN },
      callback,
      (err) => console.warn('update_requests: table not found yet — see MIGRATION_NOTES.md', err)
    );
  },
  async getAll(limitN = 50): Promise<UpdateRequest[]> {
    const { data, error } = await supabase
      .from('update_requests')
      .select('*')
      .order('createdAt', { ascending: false })
      .limit(limitN);
    if (error) {
      console.warn('update_requests: table not found yet — see MIGRATION_NOTES.md', error.message);
      return [];
    }
    return (data ?? []).map(rowIsAlreadyAppShaped);
  },
  async getMine(authorId: string, limitN = 50): Promise<UpdateRequest[]> {
    const { data, error } = await supabase
      .from('update_requests')
      .select('*')
      .eq('authorId', authorId)
      .order('createdAt', { ascending: false })
      .limit(limitN);
    if (error) return [];
    return (data ?? []).map(rowIsAlreadyAppShaped);
  },
  async submit(req: Omit<UpdateRequest, 'id' | 'createdAt' | 'status'>): Promise<void> {
    const { error } = await supabase.from('update_requests').insert({ ...req, status: 'pending' });
    if (error) throw error;
  },
  async edit(id: string, patch: Partial<UpdateRequest>): Promise<void> {
    const { error } = await supabase.from('update_requests').update(patch).eq('id', id);
    if (error) throw error;
  },
  async setStatus(id: string, status: UpdateRequest['status']): Promise<void> {
    const { error } = await supabase.from('update_requests').update({ status }).eq('id', id);
    if (error) throw error;
  },
  async remove(id: string): Promise<void> {
    const { error } = await supabase.from('update_requests').delete().eq('id', id);
    if (error) throw error;
  },
};
