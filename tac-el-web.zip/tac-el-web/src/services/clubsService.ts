import { supabase } from '../supabase';
import { Team } from '../types';
import { OFFICER_ROLES } from './clubOfficersService';
import { clubApplicationsService } from './clubApplicationsService';

export interface ClubMember {
  uid: string;
  name: string;
  role: 'member' | 'patron' | 'leader' | 'assistant' | 'secretary';
  joinedAt: string;
  phone?: string;
  email?: string;
  status: 'active' | 'pending';
}

export interface ClubMeetingNote {
  id: string;
  clubId: string;
  title: string;
  content: string;
  date: string;
  authorName: string;
  authorId: string;
  createdAt: any;
}

export interface ClubInstruction {
  id: string;
  clubId: string;
  title: string;
  directive: string;
  priority: 'normal' | 'high' | 'urgent';
  issuedBy: string;       // the name, for showing
  issuedById?: string;    // the person's id, for saving
  date: string;
}

export interface ClubAttendance {
  id: string;
  clubId: string;
  date: string;
  topic?: string;
  attendeeIds: string[];
  totalPresent: number;
  recordedBy: string;
}

// `clubs` has no icon column yet — see MIGRATION_NOTES.md. Icons for
// real (non-default) clubs are picked client-side by matching name keywords.
function iconFor(name: string): string {
  const n = name.toLowerCase();
  if (n.includes('youth')) return 'Flame';
  if (n.includes('women')) return 'Heart';
  if (n.includes('men')) return 'Shield';
  if (n.includes('choir') || n.includes('music')) return 'Music';
  if (n.includes('evangel') || n.includes('mission')) return 'Globe';
  if (n.includes('protocol') || n.includes('usher')) return 'Users';
  if (n.includes('child')) return 'Smile';
  if (n.includes('media') || n.includes('tech')) return 'Video';
  return 'Users';
}

function rowToClub(row: any, memberCount: number): Team {
  return {
    id: row.id,
    name: row.name,
    icon: iconFor(row.name),
    color: row.color || 'bg-tac-blue',
    desc: row.description || '',
    members: memberCount,
  };
}

export const clubsService = {
  async isUserAnyClubLeader(uid: string): Promise<boolean> {
    const { data, error } = await supabase
      .from('club_members')
      .select('club_id')
      .eq('profile_id', uid)
      .in('role', OFFICER_ROLES)
      .eq('status', 'active')
      .limit(1);
    if (error) {
      console.error('[clubsService] isUserAnyClubLeader failed', error);
      return false;
    }
    return (data?.length ?? 0) > 0;
  },

  async getClubs(): Promise<Team[]> {
    const { data, error } = await supabase.from('clubs').select('*, club_members(count)');
    if (error) {
      console.warn('getClubs error:', error);
      return [];
    }
    if (!data || data.length === 0) return []; // only real clubs, created by an admin
    return data.map((row: any) => rowToClub(row, row.club_members?.[0]?.count ?? 0));
  },

  async joinClub(clubId: string, member: ClubMember, statement?: string): Promise<void> {
    // insert, not upsert: an upsert would overwrite an existing row, so
    // someone already in the club (or already its leader) re-applying would
    // be reset to a pending regular member.
    const { error } = await supabase
      .from('club_members')
      .insert({ club_id: clubId, profile_id: member.uid, role: 'member', status: 'pending' });
    if (error) {
      if (error.code === '23505') throw new Error("You've already applied to (or are already in) this club.");
      throw error;
    }
    // What the person wrote about themselves goes to the club's officers with the application.
    const said = (statement || '').trim();
    if (said) {
      await clubApplicationsService
        .send({ clubId, applicantId: member.uid, senderId: member.uid, kind: 'answer', body: said })
        .catch(() => { /* the application itself is saved; the note is best effort */ });
    }
  },

  /** Admin action: directly assign an existing member as a club's leader,
   *  immediately active (not pending) — matches "admin designates group
   *  leaders", not a self-service application. */
  async assignLeader(clubId: string, uid: string, _name: string): Promise<void> {
    const { error } = await supabase
      .from('club_members')
      .upsert({ club_id: clubId, profile_id: uid, role: 'leader', status: 'active' });
    if (error) throw error;
  },

  async leaveClub(clubId: string, userId: string): Promise<void> {
    await supabase.from('club_members').delete().eq('club_id', clubId).eq('profile_id', userId);
  },

  async getRoster(clubId: string): Promise<ClubMember[]> {
    if (!clubId) return [];
    const { data, error } = await supabase
      .from('club_members')
      .select('*, profiles(full_name, phone, email)')
      .eq('club_id', clubId);
    if (error) return [];
    return (data ?? []).map((row: any) => ({
      uid: row.profile_id,
      name: row.profiles?.full_name ?? '',
      role: row.role,
      joinedAt: row.joined_at,
      phone: row.profiles?.phone ?? undefined,
      email: row.profiles?.email ?? undefined,
      status: row.status,
    }));
  },

  async recordAttendance(clubId: string, attendance: Omit<ClubAttendance, 'id'>): Promise<void> {
    // club_attendance is one row per attendee per meeting (matches the RLS
    // model), not one row per meeting with an attendee-id array — so a
    // single "record attendance" call fans out to one insert per name.
    const rows = attendance.attendeeIds.map((profileId) => ({
      club_id: clubId,
      profile_id: profileId,
      meeting_date: attendance.date,
      present: true,
    }));
    if (rows.length === 0) return;
    const { error } = await supabase.from('club_attendance').insert(rows);
    if (error) throw error;
  },

  async getAttendanceHistory(clubId: string): Promise<ClubAttendance[]> {
    if (!clubId) return [];
    const { data, error } = await supabase
      .from('club_attendance')
      .select('*')
      .eq('club_id', clubId)
      .order('meeting_date', { ascending: false });
    if (error) return [];
    // Group the one-row-per-attendee rows back into one entry per meeting date.
    const byDate = new Map<string, ClubAttendance>();
    for (const row of data ?? []) {
      const existing = byDate.get(row.meeting_date);
      if (existing) {
        existing.attendeeIds.push(row.profile_id);
        existing.totalPresent += row.present ? 1 : 0;
      } else {
        byDate.set(row.meeting_date, {
          id: row.meeting_date,
          clubId,
          date: row.meeting_date,
          attendeeIds: [row.profile_id],
          totalPresent: row.present ? 1 : 0,
          recordedBy: '',
        });
      }
    }
    return Array.from(byDate.values());
  },

  async getMeetingNotes(clubId: string): Promise<ClubMeetingNote[]> {
    if (!clubId) return [];
    const { data, error } = await supabase
      .from('club_meeting_notes')
      .select('*, profiles(full_name)')
      .eq('club_id', clubId)
      .order('meeting_date', { ascending: false });
    if (error) return [];
    return (data ?? []).map((row: any) => ({
      id: row.id,
      clubId,
      title: '', // no title column yet on club_meeting_notes — folded into `note`
      content: row.note,
      date: row.meeting_date,
      authorName: row.profiles?.full_name ?? '',
      authorId: row.author_id,
      createdAt: row.created_at,
    }));
  },

  async addMeetingNote(clubId: string, note: Omit<ClubMeetingNote, 'id' | 'createdAt'>): Promise<void> {
    const combined = note.title ? `${note.title}\n${note.content}` : note.content;
    const { error } = await supabase.from('club_meeting_notes').insert({
      club_id: clubId,
      author_id: note.authorId,
      note: combined,
      meeting_date: note.date,
    });
    if (error) throw error;
  },

  async getInstructions(clubId: string): Promise<ClubInstruction[]> {
    if (!clubId) return [];
    const { data, error } = await supabase
      .from('club_instructions')
      .select('*')
      .eq('club_id', clubId)
      .order('created_at', { ascending: false });
    if (error) return [];
    const ids = Array.from(new Set((data ?? []).map((r: any) => r.from_profile_id).filter(Boolean)));
    const names: Record<string, string> = {};
    if (ids.length) {
      const { data: ps } = await supabase.from('profiles').select('id, full_name').in('id', ids);
      (ps ?? []).forEach((p: any) => { names[p.id] = p.full_name; });
    }
    return (data ?? []).map((row: any) => ({
      id: row.id,
      clubId,
      title: '',
      directive: row.message,
      priority: 'normal',
      issuedBy: names[row.from_profile_id] || 'Club leader',
      issuedById: row.from_profile_id,
      date: row.created_at,
    }));
  },

  async addInstruction(clubId: string, inst: Omit<ClubInstruction, 'id'>): Promise<void> {
    const message = inst.title ? `${inst.title}: ${inst.directive}` : inst.directive;
    const { error } = await supabase.from('club_instructions').insert({
      club_id: clubId,
      from_profile_id: inst.issuedById ?? inst.issuedBy,
      message,
    });
    if (error) throw error;
  },

  async approveRegistration(clubId: string, memberId: string): Promise<void> {
    await clubApplicationsService.decide(clubId, memberId, 'approve');
  },

  async rejectRegistration(clubId: string, memberId: string, note?: string): Promise<void> {
    await clubApplicationsService.decide(clubId, memberId, 'decline', note);
  },

  /** The clubs this person is an officer of (an admin gets every club): the tabs on the leader screens. */
  async getMyOfficerClubs(uid: string, isAdmin: boolean): Promise<Team[]> {
    const all = await clubsService.getClubs();
    if (isAdmin) return all;
    const { data, error } = await supabase.from('club_members').select('club_id').eq('profile_id', uid).eq('status', 'active').in('role', OFFICER_ROLES);
    if (error) return [];
    const ids = new Set((data ?? []).map((r: any) => r.club_id));
    return all.filter((c) => ids.has(c.id));
  },

  /** Every club this person belongs to with the role AND whether they are approved yet. */
  async getMyMembershipsDetailed(uid: string): Promise<Record<string, { role: string; status: 'active' | 'pending' }>> {
    const { data, error } = await supabase.from('club_members').select('club_id, role, status').eq('profile_id', uid);
    if (error) return {};
    const map: Record<string, { role: string; status: 'active' | 'pending' }> = {};
    for (const row of data ?? []) map[(row as any).club_id] = { role: (row as any).role, status: (row as any).status };
    return map;
  },

  /** Every club this member belongs to, as a { clubId: role } map — the
   *  replacement for the old `profile.teams` Firestore map field (no
   *  matching column on `profiles`; membership lives in `club_members`). */
  async getMyMemberships(uid: string): Promise<Record<string, 'member' | 'patron' | 'leader' | 'assistant' | 'secretary'>> {
    const { data, error } = await supabase.from('club_members').select('club_id, role').eq('profile_id', uid).eq('status', 'active');
    if (error) return {};
    const map: Record<string, any> = {};
    for (const row of data ?? []) map[row.club_id] = row.role;
    return map;
  },

  /** Current leaders of every club, keyed by club id (for the admin screen). */
  async getAllLeaders(): Promise<Record<string, { uid: string; name: string }[]>> {
    const { data, error } = await supabase
      .from('club_members')
      .select('club_id, profile_id, profiles(full_name)')
      .eq('role', 'leader')
      .eq('status', 'active');
    if (error) return {};
    const map: Record<string, { uid: string; name: string }[]> = {};
    for (const row of data ?? []) {
      (map[row.club_id] ||= []).push({ uid: row.profile_id, name: (row as any).profiles?.full_name ?? '' });
    }
    return map;
  },

  /** Takes leadership away but keeps them in the club as a regular member. */
  async removeLeader(clubId: string, uid: string): Promise<void> {
    const { error } = await supabase
      .from('club_members')
      .update({ role: 'member' })
      .eq('club_id', clubId)
      .eq('profile_id', uid);
    if (error) throw error;
  },

  async addClub(club: { name: string; description?: string; color?: string }): Promise<string> {
    const { data, error } = await supabase.from('clubs').insert(club).select().single();
    if (error) throw error;
    return data.id;
  },
};
