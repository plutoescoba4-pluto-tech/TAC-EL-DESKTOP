import { supabase } from '../supabase';
import { subscribeQuery, subscribePresence } from '../lib/realtime';
import { ChatMessage } from '../types';
import { calculatePayloadSizeBytes, MAX_FIRESTORE_PAYLOAD_BYTES } from '../lib/image-utils';
import { offloadMedia, resolveChatMedia } from '../lib/chatMedia';

/** Invisible delimiter between a message's text and its packed extras (audio, file, location, colour). */
export const META_SEP = '\u001fMETA\u001f';

const GLOBAL_SELECT =
  '*, sender:profiles!sender_id(full_name), reply_to:chat_messages!reply_to_id(text,img_url,vid_url,sender:profiles!sender_id(full_name))';

function rowToChatMessage(row: any): ChatMessage {
  // chat_messages has real columns for text/img/vid, but not audio/file/
  // location/senderColor — those are packed as a "<META_SEP>{json}"
  // suffix on `text` and split back out here. The delimiter must NOT be a null
  // character: Postgres cannot store \u0000 in a text column and rejects the
  // whole message with "unsupported Unicode escape sequence". It is an invisible
  // control character that normal typed text never contains.
  let text = row.text ?? undefined;
  let meta: any = {};
  if (text && text.includes(META_SEP)) {
    const [base, metaJson] = text.split(META_SEP);
    text = base || undefined;
    try { meta = JSON.parse(metaJson); } catch { meta = {}; }
  }
  return {
    id: row.id,
    senderId: row.sender_id,
    senderName: row.sender?.full_name ?? '',
    text,
    img: row.img_url ?? undefined,
    vid: row.vid_url ?? undefined,
    audio: meta.audio,
    file: meta.file,
    location: meta.location,
    senderColor: meta.senderColor,
    time: new Date(row.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    createdAt: row.created_at,
    replyTo: row.reply_to && (row.reply_to.id || row.reply_to.text || row.reply_to.img_url || row.reply_to.vid_url || row.reply_to.sender?.full_name)
      ? {
          sender: row.reply_to.sender?.full_name ?? meta.replyTo?.sender ?? '',
          text: row.reply_to.text ? row.reply_to.text.split(META_SEP)[0] || meta.replyTo?.text || undefined : meta.replyTo?.text,
          img: row.reply_to.img_url ?? undefined,
          vid: row.reply_to.vid_url ?? undefined,
        }
      : (meta.replyTo ? { sender: meta.replyTo.sender ?? '', text: meta.replyTo.text ?? undefined } : undefined),
    deliveredTo: row.delivered_to ?? [],
    readBy: row.read_by ?? [],
  };
}

function rowToDirectMessage(row: any): ChatMessage {
  const raw = row.text as string | null;
  let unpacked: any = { text: raw ?? undefined };
  if (raw && raw.startsWith('__RICH__')) {
    try {
      unpacked = JSON.parse(raw.slice('__RICH__'.length));
    } catch {
      unpacked = { text: raw };
    }
  }
  return {
    id: row.id,
    senderId: row.sender_id,
    senderName: row.sender?.full_name ?? '',
    text: unpacked.text ?? undefined,
    img: unpacked.img ?? undefined,
    vid: unpacked.vid ?? undefined,
    voice: unpacked.voice ?? undefined,
    location: unpacked.location ?? undefined,
    file: unpacked.file ?? undefined,
    time: new Date(row.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    createdAt: row.created_at,
    replyTo: unpacked.replyTo ?? undefined,
    // Real receipts: delivered_at is set when the message reaches the other person's
    // phone, read_at when they open the chat (06b-chat-features.sql).
    deliveredTo: row.delivered_at || row.read_at ? [row.recipient_id] : [],
    readBy: row.read_at ? [row.recipient_id] : [],
  } as ChatMessage;
}

export interface Reaction {
  messageId: string;
  userId: string;
  emoji: string;
}

interface OutgoingMessage {
  senderId: string;
  text?: string;
  img?: string;
  vid?: string;
  audio?: string;
  file?: string;
  location?: any;
  senderColor?: string;
  replyToId?: string;
  /** Small snapshot of the quoted message, so the quote still shows even if the join comes back empty. */
  replyQuote?: { sender: string; text: string };
}

function checkPayloadSize(payload: any) {
  const size = calculatePayloadSizeBytes(payload);
  if (size > MAX_FIRESTORE_PAYLOAD_BYTES) {
    throw new Error(`Message payload is too large (${Math.round(size / 1024)} KB). Limit is ${Math.round(MAX_FIRESTORE_PAYLOAD_BYTES / 1024 / 1024)} MB.`);
  }
}

export const chatService = {
  subscribeToGlobalChat(callback: (messages: ChatMessage[]) => void, messageLimit = 60) {
    let seq = 0; // a slower, older refresh must never overwrite a newer one
    return subscribeQuery<any>(
      { table: 'chat_messages', orderBy: { column: 'created_at', ascending: false }, limit: messageLimit, select: GLOBAL_SELECT },
      (rows) => {
        const mine = ++seq;
        const msgs = rows.map(rowToChatMessage).reverse();
        resolveChatMedia(msgs).catch(() => {}).finally(() => { if (mine === seq) callback(msgs); });
      },
      (err) => console.warn('Global chat subscription error:', err)
    );
  },

  async sendGlobalMessage(input: OutgoingMessage): Promise<void> {
    // Photos, videos, voice notes and files are uploaded to private storage; the row keeps a short reference.
    const scope = { type: 'group' } as const;
    const msg: OutgoingMessage = {
      ...input,
      img: await offloadMedia(input.img, input.senderId, scope),
      vid: await offloadMedia(input.vid, input.senderId, scope),
      audio: await offloadMedia(input.audio, input.senderId, scope),
      file: await offloadMedia(input.file, input.senderId, scope),
    };
    const meta: any = {};
    if (msg.audio) meta.audio = msg.audio;
    if (msg.file) meta.file = msg.file;
    if (msg.location) meta.location = msg.location;
    if (msg.senderColor) meta.senderColor = msg.senderColor;
    if (msg.replyQuote) meta.replyTo = { sender: String(msg.replyQuote.sender ?? '').slice(0, 80), text: String(msg.replyQuote.text ?? '').slice(0, 160) };
    const hasMeta = Object.keys(meta).length > 0;
    const packedText = hasMeta ? `${msg.text ?? ''}${META_SEP}${JSON.stringify(meta)}` : msg.text;

    const payload = {
      sender_id: msg.senderId,
      text: packedText,
      img_url: msg.img,
      vid_url: msg.vid,
      reply_to_id: msg.replyToId,
      delivered_to: [msg.senderId],
      read_by: [msg.senderId],
    };
    checkPayloadSize(payload);
    const { error } = await supabase.from('chat_messages').insert(payload);
    if (error) throw error;
  },

  /** Marks a batch of messages delivered + read for `uid` in ONE call.
   *  Calls the `mark_chat_messages_seen(message_ids uuid[])` database function,
   *  which appends auth.uid() to both receipt arrays atomically (the old
   *  read-then-write per message could lose receipts when two people opened
   *  the chat at once, and fired one realtime refetch per message).
   *  Falls back to the old per-message path only if the function isn't
   *  installed yet. */
  async markSeen(messageIds: string[], uid: string): Promise<void> {
    if (messageIds.length === 0) return;
    const { error } = await supabase.rpc('mark_chat_messages_seen', { message_ids: messageIds });
    if (!error) return;
    const missing = error.code === 'PGRST202' || error.code === '42883';
    if (!missing) throw error;
    for (const id of messageIds) {
      await this.markDelivered(id, uid).catch(() => {});
      await this.markRead(id, uid).catch(() => {});
    }
  },

  /** @deprecated legacy fallback used by markSeen only. */
  async markDelivered(messageId: string, uid: string): Promise<void> {
    const { data } = await supabase.from('chat_messages').select('delivered_to').eq('id', messageId).single();
    const current: string[] = data?.delivered_to ?? [];
    if (!current.includes(uid)) {
      await supabase.from('chat_messages').update({ delivered_to: [...current, uid] }).eq('id', messageId);
    }
  },

  /** @deprecated legacy fallback used by markSeen only. */
  async markRead(messageId: string, uid: string): Promise<void> {
    const { data } = await supabase.from('chat_messages').select('read_by').eq('id', messageId).single();
    const current: string[] = data?.read_by ?? [];
    if (!current.includes(uid)) {
      await supabase.from('chat_messages').update({ read_by: [...current, uid] }).eq('id', messageId);
    }
  },

  /** Typing/recording indicators via ephemeral Realtime Presence (per your
   *  call to move presence off tables) rather than the chat_presence table
   *  in your schema — nothing persisted, clears on disconnect. */
  subscribeGlobalPresence(
    self: { uid: string; name: string } | null,
    callback: (state: Record<string, { name: string; typing: boolean; recording: boolean }>) => void
  ) {
    return subscribePresence(
      'chat:global:presence',
      self ? { key: self.uid, meta: { name: self.name, typing: false, recording: false } } : null,
      (state) => {
        const out: Record<string, { name: string; typing: boolean; recording: boolean }> = {};
        for (const [key, metas] of Object.entries(state)) {
          const meta = metas[0] as any;
          out[key] = { name: meta?.name ?? '', typing: !!meta?.typing, recording: !!meta?.recording };
        }
        callback(out);
      }
    );
  },

  async deleteMessage(messageId: string): Promise<void> {
    // .select() so we can tell "deleted" from "the database silently refused" (a blocked delete returns no error).
    const { data, error } = await supabase.from('chat_messages').delete().eq('id', messageId).select('id');
    if (error) throw error;
    if (!data || data.length === 0) throw new Error('This message could not be deleted for everyone.');
  },

  /** Messages this person removed with "Delete for me" (see 09-chat-delete-for-me.sql). */
  async getHiddenIds(uid: string): Promise<string[]> {
    const { data, error } = await supabase.from('chat_message_hides').select('message_id').eq('user_id', uid);
    if (error) return [];
    return (data ?? []).map((r: any) => r.message_id);
  },

  async hideForMe(uid: string, messageId: string): Promise<void> {
    const { error } = await supabase.from('chat_message_hides').upsert(
      { user_id: uid, message_id: messageId },
      { onConflict: 'user_id,message_id', ignoreDuplicates: true }
    );
    if (error) console.warn('Delete-for-me could not be saved to the database (kept on this device):', error.message);
  },

  /** Admin "clear chat": deletes the whole church chat for everyone and reports how many messages went.
   *  Goes through a database function (14-chat-clear.sql) so the answer is honest: before, a delete that the
   *  database refused looked like success, the screen emptied, and the messages came back a moment later. */
  async clearAllMessages(): Promise<number> {
    const { data, error } = await supabase.rpc('admin_clear_chat');
    if (!error) return Number(data ?? 0);
    const missing = (error as any).code === 'PGRST202' || /could not find the function/i.test(error.message || '');
    if (!missing) throw new Error(error.message || 'Could not clear the chat.');
    // function not installed yet: try the plain delete, and check that something really went
    const del = await supabase.from('chat_messages').delete().not('id', 'is', null).select('id');
    if (del.error) throw new Error(del.error.message);
    if (!del.data || del.data.length === 0) {
      throw new Error('The database did not delete any messages. Run 14-chat-clear.sql in Supabase, make sure you are signed in as an admin, then try again.');
    }
    return del.data.length;
  },

  /** When this person last cleared a private chat for themselves (messages up to then stay hidden for them). */
  async getThreadClearedAt(uid: string, threadKey: string): Promise<number> {
    let local = 0;
    try { local = Number(localStorage.getItem(`tac_cleared_${uid}_${threadKey}`) || 0); } catch { /* ignore */ }
    const { data } = await supabase.from('chat_thread_clears').select('cleared_at').eq('user_id', uid).eq('thread_key', threadKey).maybeSingle();
    const remote = data?.cleared_at ? Date.parse(data.cleared_at) : 0;
    return Math.max(local, remote || 0);
  },

  /** "Clear for me": hide everything up to now in this chat on my side only. */
  async clearThreadForMe(uid: string, threadKey: string): Promise<number> {
    const now = Date.now();
    try { localStorage.setItem(`tac_cleared_${uid}_${threadKey}`, String(now)); } catch { /* ignore */ }
    const { error } = await supabase.from('chat_thread_clears').upsert(
      { user_id: uid, thread_key: threadKey, cleared_at: new Date(now).toISOString() }, { onConflict: 'user_id,thread_key' });
    if (error) console.warn('Clear-for-me kept on this device only (run 14-chat-clear.sql to keep it on your account):', error.message);
    return now;
  },

  // --- Direct messages ---------------------------------------------------
  // direct_messages, per your schema, has just one `text` column — no
  // img_url/vid_url/voice/location/file/reply columns like chat_messages
  // has. Rather than silently drop DM photos/voice notes/location shares,
  // richer payloads are JSON-packed into `text` behind a "__RICH__" marker
  // and unpacked on read. Add real columns to direct_messages (mirroring
  // chat_messages) if you'd rather store these properly — see
  // MIGRATION_NOTES.md.
  subscribeToDirectChat(uidA: string, uidB: string, callback: (messages: ChatMessage[]) => void, messageLimit = 60) {
    let seq = 0; // a slower, older refresh must never overwrite a newer one
    return subscribeQuery<any>(
      {
        table: 'direct_messages',
        orderBy: { column: 'created_at', ascending: false },
        limit: messageLimit,
        select: '*, sender:profiles!sender_id(full_name)',
        // Server-side: only THIS conversation. Without it the 60-row window was
        // shared by all of the user's threads and older messages vanished.
        or: `and(sender_id.eq.${uidA},recipient_id.eq.${uidB}),and(sender_id.eq.${uidB},recipient_id.eq.${uidA})`,
      },
      (rows) => {
        const mine = ++seq;
        const filtered = rows.filter(
          (r: any) =>
            (r.sender_id === uidA && r.recipient_id === uidB) || (r.sender_id === uidB && r.recipient_id === uidA)
        );
        const msgs = filtered.map(rowToDirectMessage).reverse();
        resolveChatMedia(msgs).catch(() => {}).finally(() => { if (mine === seq) callback(msgs); });
      },
      (err) => console.warn('Direct chat subscription error:', err)
    );
  },

  async sendDirectMessage(
    senderId: string,
    recipientId: string,
    input: OutgoingMessage & { voice?: string; location?: { lat: number; lng: number; url: string }; file?: string; replyTo?: ChatMessage['replyTo'] }
  ): Promise<void> {
    // Photos, videos, voice notes and files are uploaded to private storage; the row keeps a short reference.
    const scope = { type: 'dm', recipientId } as const;
    const msg = {
      ...input,
      img: await offloadMedia(input.img, senderId, scope),
      vid: await offloadMedia(input.vid, senderId, scope),
      voice: await offloadMedia((input as any).voice, senderId, scope),
      file: await offloadMedia(input.file, senderId, scope),
    };
    const hasRichFields = msg.img || msg.vid || (msg as any).voice || (msg as any).location || (msg as any).file || msg.replyTo;
    const packedText = hasRichFields
      ? `__RICH__${JSON.stringify({ text: msg.text, img: msg.img, vid: msg.vid, voice: (msg as any).voice, location: (msg as any).location, file: (msg as any).file, replyTo: msg.replyTo })}`
      : msg.text ?? '';
    const payload = { sender_id: senderId, recipient_id: recipientId, text: packedText };
    checkPayloadSize(payload);
    const { error } = await supabase.from('direct_messages').insert(payload);
    if (error) throw error;
  },

  /** Typing indicator for one DM thread (ephemeral Presence, nothing stored). */
  subscribeDmPresence(
    dmId: string,
    self: { uid: string; name: string } | null,
    callback: (state: Record<string, { typing: boolean }>) => void
  ) {
    return subscribePresence(
      `dm:${dmId}:presence`,
      self ? { key: self.uid, meta: { name: self.name, typing: false } } : null,
      (state) => {
        const out: Record<string, { typing: boolean }> = {};
        for (const [key, metas] of Object.entries(state)) out[key] = { typing: !!(metas[0] as any)?.typing };
        callback(out);
      }
    );
  },

  /** Best-effort read receipt. direct_messages needs an UPDATE policy for
   *  the recipient for this to take effect; without one it's a harmless
   *  no-op (blue ticks just won't appear — unread badges still work, they
   *  don't depend on this). */
  async markDirectRead(otherUid: string, myUid: string): Promise<void> {
    // 06b-chat-features.sql: sets read_at AND delivered_at in one go.
    const { error: rpcError } = await supabase.rpc('mark_dms_read', { p_other: otherUid });
    if (!rpcError) return;
    await supabase
      .from('direct_messages')
      .update({ read_at: new Date().toISOString() })
      .eq('sender_id', otherUid)
      .eq('recipient_id', myUid)
      .is('read_at', null);
  },

  async deleteDirectMessage(messageId: string): Promise<void> {
    const { error } = await supabase.from('direct_messages').delete().eq('id', messageId);
    if (error) throw error;
  },

  async clearDirectThread(uidA: string, uidB: string): Promise<void> {
    await supabase.from('direct_messages').delete().eq('sender_id', uidA).eq('recipient_id', uidB);
    await supabase.from('direct_messages').delete().eq('sender_id', uidB).eq('recipient_id', uidA);
  },

  // --- Delivered ticks (recorded the moment a message reaches this device) -----------
  async markGlobalDelivered(messageIds: string[]): Promise<void> {
    if (messageIds.length === 0) return;
    await supabase.rpc('mark_chat_messages_delivered', { message_ids: messageIds });
  },
  async markDmsDelivered(messageIds: string[]): Promise<void> {
    if (messageIds.length === 0) return;
    await supabase.rpc('mark_dms_delivered', { message_ids: messageIds });
  },

  // --- Reactions (one emoji per person per message) ------------------------------------
  subscribeReactions(scope: 'group' | 'dm', callback: (reactions: Reaction[]) => void) {
    return subscribeQuery<any>(
      { table: scope === 'group' ? 'chat_reactions' : 'dm_reactions', orderBy: { column: 'created_at', ascending: false }, limit: 1500 },
      (rows) => callback(rows.map((r) => ({ messageId: r.message_id, userId: r.user_id, emoji: r.emoji }))),
      (err) => console.warn('Reactions subscription error:', err)
    );
  },

  /** emoji = null removes your reaction. Reacting again with a different emoji replaces it. */
  async react(scope: 'group' | 'dm', messageId: string, userId: string, emoji: string | null): Promise<void> {
    const table = scope === 'group' ? 'chat_reactions' : 'dm_reactions';
    if (emoji === null) {
      const { error } = await supabase.from(table).delete().eq('message_id', messageId).eq('user_id', userId);
      if (error) throw error;
      return;
    }
    const { error } = await supabase.from(table).upsert({ message_id: messageId, user_id: userId, emoji }, { onConflict: 'message_id,user_id' });
    if (error) throw error;
  },
};
