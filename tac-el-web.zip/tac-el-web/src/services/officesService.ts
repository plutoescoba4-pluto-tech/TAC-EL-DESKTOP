import { supabase } from '../supabase';

export interface LedgerEntry {
  id: string;
  type: 'income' | 'expense';
  category: 'tithes' | 'offerings' | 'welfare' | 'building_project' | 'utilities' | 'honorarium' | 'maintenance' | 'other';
  amount: number;
  description: string;
  date: string;
  recordedBy: string;
  voucherNumber?: string;
  createdAt: any;
}

export interface ChurchAsset {
  id: string;
  name: string;
  category: 'audio_visual' | 'furniture' | 'instrument' | 'vehicle' | 'property' | 'electronics';
  serialNumber?: string;
  location: string;
  condition: 'excellent' | 'good' | 'fair' | 'needs_repair' | 'retired';
  purchaseDate?: string;
  valueGhs: number;
  assignedTo?: string;
  notes?: string;
  updatedAt: any;
}

/** ledger_entries has debit/credit columns rather than a signed amount +
 *  type, and no category/voucher_number columns yet (see MIGRATION_NOTES.md).
 *  Mapped here: type='income' -> credit, type='expense' -> debit; category
 *  and voucher number are folded into `description` for now so nothing is
 *  silently lost, and parsed back out on read. */
function rowToLedgerEntry(row: any): LedgerEntry {
  const isIncome = Number(row.credit) > 0;
  const match = /^\[(.+?)\]\[(.*?)\]\s*(.*)$/.exec(row.description || '');
  const category = (match?.[1] as LedgerEntry['category']) || 'other';
  const voucherNumber = match?.[2] || undefined;
  const description = match ? match[3] : row.description;
  return {
    id: row.id,
    type: isIncome ? 'income' : 'expense',
    category,
    amount: isIncome ? Number(row.credit) : Number(row.debit),
    description,
    date: row.entry_date,
    recordedBy: row.recorded_by,
    voucherNumber,
    createdAt: row.created_at,
  };
}

export const officesService = {
  async getLedgerEntries(): Promise<LedgerEntry[]> {
    const { data, error } = await supabase.from('ledger_entries').select('*').order('entry_date', { ascending: false });
    if (error) return [];
    return (data ?? []).map(rowToLedgerEntry);
  },

  async addLedgerEntry(entry: Omit<LedgerEntry, 'id' | 'createdAt'>): Promise<string> {
    const packedDescription = `[${entry.category}][${entry.voucherNumber ?? ''}] ${entry.description}`;
    const { data, error } = await supabase
      .from('ledger_entries')
      .insert({
        recorded_by: entry.recordedBy,
        description: packedDescription,
        debit: entry.type === 'expense' ? entry.amount : 0,
        credit: entry.type === 'income' ? entry.amount : 0,
        entry_date: entry.date,
      })
      .select()
      .single();
    if (error) throw error;
    return data.id;
  },

  async deleteLedgerEntry(id: string): Promise<void> {
    const { error } = await supabase.from('ledger_entries').delete().eq('id', id);
    if (error) throw error;
  },

  async getAssets(): Promise<ChurchAsset[]> {
    const { data, error } = await supabase.from('church_assets').select('*');
    if (error) return [];
    return (data ?? []).map((row: any) => ({
      id: row.id,
      name: row.name,
      category: (row.category as ChurchAsset['category']) || 'other' as any,
      serialNumber: undefined, // no serial_number column yet — see MIGRATION_NOTES.md
      location: '', // no location column yet — see MIGRATION_NOTES.md
      condition: (row.condition as ChurchAsset['condition']) || 'good',
      purchaseDate: undefined,
      valueGhs: 0, // no value column yet — see MIGRATION_NOTES.md
      assignedTo: row.custodian_id ?? undefined,
      notes: undefined,
      updatedAt: row.created_at,
    }));
  },

  async addAsset(asset: Omit<ChurchAsset, 'id' | 'updatedAt'>): Promise<string> {
    const { data, error } = await supabase
      .from('church_assets')
      .insert({
        name: asset.name,
        category: asset.category,
        quantity: 1,
        condition: asset.condition,
        custodian_id: asset.assignedTo,
      })
      .select()
      .single();
    if (error) throw error;
    return data.id;
  },

  async updateAsset(id: string, asset: Partial<ChurchAsset>): Promise<void> {
    const row: Record<string, any> = {};
    if (asset.name !== undefined) row.name = asset.name;
    if (asset.category !== undefined) row.category = asset.category;
    if (asset.condition !== undefined) row.condition = asset.condition;
    if (asset.assignedTo !== undefined) row.custodian_id = asset.assignedTo;
    const { error } = await supabase.from('church_assets').update(row).eq('id', id);
    if (error) throw error;
  },

  async deleteAsset(id: string): Promise<void> {
    const { error } = await supabase.from('church_assets').delete().eq('id', id);
    if (error) throw error;
  },
};
