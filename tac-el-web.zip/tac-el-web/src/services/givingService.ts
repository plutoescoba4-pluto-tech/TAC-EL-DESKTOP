import { supabase } from '../supabase';
import { Donation } from '../types';

export interface PaystackTransaction {
  reference: string;
  amount: number;
  email: string;
  name: string;
  phone?: string;
  type: 'offering' | 'tithe' | 'welfare' | 'pledge' | 'project' | 'other';
  network?: 'MTN' | 'Vodafone' | 'AirtelTigo' | 'Card';
  status: 'success' | 'pending' | 'failed';
  date: string;
}

export interface Pledge {
  id: string;
  userId: string;
  userName: string;
  userEmail: string;
  projectTitle: string;
  targetAmount: number;
  amountPaid: number;
  dueDate: string;
  status: 'active' | 'fulfilled' | 'overdue';
  createdAt: any;
}

/** Maps a giving_transactions row + fund name to the app's Donation shape.
 *  `type` used to be a free string on the Firestore doc; here it comes from
 *  the linked `funds.name`, lowercased to match Donation['type']. */
function rowToDonation(row: any): Donation {
  const fundName = (row.funds?.name || '').toLowerCase();
  // Exact matches, not substring: "Seed Offering" contains "offering" and
  // would otherwise be silently counted as a plain Offering.
  const type: Donation['type'] =
    fundName === 'tithe' ? 'tithe' : fundName === 'offering' ? 'offering' : fundName === 'welfare' ? 'welfare' : 'other';
  return {
    id: row.id,
    userId: row.profile_id ?? 'guest',
    userName: row.profiles?.full_name ?? 'Guest',
    amount: Number(row.amount),
    type,
    date: row.created_at,
    createdAt: row.created_at,
  };
}

async function getFundIdByName(name: string): Promise<string | null> {
  // Exact (case-insensitive) match first — "Seed Offering" contains the
  // substring "Offering", so a pure substring search risks filing a plain
  // Offering entry under Seed Offering (or vice versa) depending on row
  // order. Falls back to substring match for looser callers.
  const exact = await supabase.from('funds').select('id').ilike('name', name).maybeSingle();
  if (exact.data?.id) return exact.data.id;
  const { data } = await supabase.from('funds').select('id').ilike('name', `%${name}%`).limit(1).maybeSingle();
  return data?.id ?? null;
}

/** Your schema only seeds Tithe/Offering/Building Fund/Missions/Thanksgiving
 *  — no Welfare or Seed Offering fund. Creating one on the fly only works
 *  for an admin session (funds insert is admin-only per your RLS); a
 *  non-admin treasurer recording a Welfare/Seed entry before an admin has
 *  ever created that fund will get a clear error instead of having their
 *  entry silently miscategorized under Offering. */
export async function ensureFundExists(name: string): Promise<string> {
  const existing = await getFundIdByName(name);
  if (existing) return existing;
  const { data, error } = await supabase.from('funds').insert({ name }).select('id').single();
  if (error) {
    throw new Error(`The "${name}" fund doesn't exist yet and couldn't be created automatically (admin-only). Ask an admin to open this screen once first, or add it directly in the database.`);
  }
  return data.id;
}

export const givingService = {
  async recordDonation(
    // `type` is widened from Donation['type'] to any fund name: the manual
    // treasury entry form records against funds beyond tithe/offering/welfare
    // (Seed Offering, Building Fund, Missions, Thanksgiving), looked up by
    // exact name below.
    donation: Omit<Donation, 'id' | 'createdAt' | 'type'> & { type: string; reference?: string; channel?: string }
  ): Promise<string> {
    // No silent fallback to "Offering" if the requested fund doesn't exist —
    // that used to quietly miscategorize Welfare/Seed entries. Callers that
    // need a fund that might not exist yet should call ensureFundExists()
    // first (the manual entry form below does this).
    const fundId = await getFundIdByName(donation.type);
    if (!fundId) {
      throw new Error(`No "${donation.type}" fund found in the database. Ask an admin to add it (see ensureFundExists in givingService.ts).`);
    }
    // method must be one of ('momo','card','bank_transfer') per your schema's
    // check constraint — there's no 'cash' option yet, even though physical
    // cash counted after a service is the most common form of giving for an
    // in-person treasury register. Sent as 'cash' anyway (the semantically
    // correct value) rather than silently mislabeling it 'momo' forever —
    // if your constraint doesn't allow it yet, this throws a clear error
    // instead of quietly corrupting the data. Add 'cash' to the constraint
    // (`alter table giving_transactions drop constraint giving_transactions_method_check,
    // add constraint giving_transactions_method_check check (method in
    // ('momo','card','bank_transfer','cash'));`) to enable it.
    const method =
      donation.channel === 'card' ? 'card' :
      donation.channel === 'bank' ? 'bank_transfer' :
      donation.channel === 'cash' ? 'cash' :
      'momo';
    const { data, error } = await supabase
      .from('giving_transactions')
      .insert({
        profile_id: donation.userId === 'guest' ? null : donation.userId,
        fund_id: fundId,
        amount: donation.amount,
        method,
        paystack_reference: donation.reference,
        status: 'success',
      })
      .select()
      .single();
    if (error) {
      if (method === 'cash' && (error.message?.includes('check constraint') || error.code === '23514')) {
        throw new Error("Your database doesn't accept 'cash' as a giving method yet — see the comment in givingService.ts for the one-line fix.");
      }
      throw error;
    }
    return data.id;
  },

  async getUserDonations(userId: string): Promise<Donation[]> {
    const { data, error } = await supabase
      .from('giving_transactions')
      .select('*, funds(name), profiles(full_name)')
      .eq('profile_id', userId)
      .order('created_at', { ascending: false });
    if (error) {
      console.warn('getUserDonations error:', error);
      return [];
    }
    return (data ?? []).map(rowToDonation);
  },

  async getAllDonations(): Promise<Donation[]> {
    const { data, error } = await supabase
      .from('giving_transactions')
      .select('*, funds(name), profiles(full_name)')
      .order('created_at', { ascending: false });
    if (error) return [];
    return (data ?? []).map(rowToDonation);
  },

  async createPledge(pledge: Omit<Pledge, 'id' | 'createdAt'>): Promise<string> {
    const { data, error } = await supabase
      .from('pledges')
      .insert({
        profile_id: pledge.userId,
        campaign_name: pledge.projectTitle,
        pledged_amount: pledge.targetAmount,
        fulfilled_amount: pledge.amountPaid || 0,
      })
      .select()
      .single();
    if (error) throw error;
    return data.id;
  },

  async getPledges(userId?: string): Promise<Pledge[]> {
    let q = supabase.from('pledges').select('*, profiles(full_name, email)').order('created_at', { ascending: false });
    if (userId) q = q.eq('profile_id', userId);
    const { data, error } = await q;
    if (error) return [];
    return (data ?? []).map((row: any) => ({
      id: row.id,
      userId: row.profile_id,
      userName: row.profiles?.full_name ?? '',
      userEmail: row.profiles?.email ?? '',
      projectTitle: row.campaign_name,
      targetAmount: Number(row.pledged_amount),
      amountPaid: Number(row.fulfilled_amount),
      dueDate: '', // no due_date column yet — see MIGRATION_NOTES.md
      status: Number(row.fulfilled_amount) >= Number(row.pledged_amount) ? 'fulfilled' : 'active',
      createdAt: row.created_at,
    }));
  },

  async updatePledgePayment(pledgeId: string, additionalAmount: number): Promise<void> {
    const { data: existing, error: fetchErr } = await supabase
      .from('pledges')
      .select('fulfilled_amount, pledged_amount')
      .eq('id', pledgeId)
      .single();
    if (fetchErr) throw fetchErr;
    const newPaid = Number(existing.fulfilled_amount || 0) + additionalAmount;
    const { error } = await supabase.from('pledges').update({ fulfilled_amount: newPaid }).eq('id', pledgeId);
    if (error) throw error;
  },
};
