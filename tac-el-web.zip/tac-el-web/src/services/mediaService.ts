import { supabase } from '../supabase';

export interface PrayerRecording {
  id: string;
  title: string;
  audioUrl: string;
  durationSeconds: number;
  authorId: string;
  authorName: string;
  createdAt: any;
}

export const mediaService = {
  /** `recordings`, per your schema, has no author_id/author_name columns —
   *  it's built for content the admin publishes (sermons/hymns-style),
   *  not per-user prayer recordings. Author is folded into the title as
   *  "Name — Title" so nothing is silently dropped; split back out on read.
   *  Add author columns to `recordings` (or a separate table) if you want
   *  this tracked properly — see MIGRATION_NOTES.md. */
  async savePrayerRecording(recording: Omit<PrayerRecording, 'id' | 'createdAt'>): Promise<string> {
    const packedTitle = recording.authorName ? `${recording.authorName} — ${recording.title}` : recording.title;
    const { data, error } = await supabase
      .from('recordings')
      .insert({
        title: packedTitle,
        session_type: 'audio',
        audio_url: recording.audioUrl,
        duration_seconds: recording.durationSeconds,
      })
      .select()
      .single();
    if (error) throw error;
    return data.id;
  },

  async getPrayerRecordings(): Promise<PrayerRecording[]> {
    const { data, error } = await supabase
      .from('recordings')
      .select('*')
      .eq('session_type', 'audio')
      .order('recorded_at', { ascending: false });
    if (error) return [];
    return (data ?? []).map((row: any) => {
      const [maybeAuthor, ...rest] = String(row.title).split(' — ');
      const hasAuthor = rest.length > 0;
      return {
        id: row.id,
        title: hasAuthor ? rest.join(' — ') : row.title,
        authorName: hasAuthor ? maybeAuthor : '',
        authorId: '',
        audioUrl: row.audio_url,
        durationSeconds: row.duration_seconds ?? 0,
        createdAt: row.recorded_at,
      };
    });
  },

  async deletePrayerRecording(id: string): Promise<void> {
    const { error } = await supabase.from('recordings').delete().eq('id', id);
    if (error) throw error;
  },
};
