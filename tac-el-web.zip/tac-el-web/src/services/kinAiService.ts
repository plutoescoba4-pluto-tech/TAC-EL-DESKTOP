import { GoogleGenAI } from '@google/genai';

export interface KinAiMessage {
  role: 'user' | 'assistant';
  content: string;
}

export const kinAiService = {
  async askKin(prompt: string, contextHistory: KinAiMessage[] = []): Promise<string> {
    try {
      const apiKey = process.env.GEMINI_API_KEY || (import.meta as any).env?.VITE_GEMINI_API_KEY;
      if (!apiKey) {
        return this.getFallbackSpiritualResponse(prompt);
      }

      const ai = new GoogleGenAI({ apiKey });
      const systemInstruction = `You are Kin AI, the knowledgeable and pastoral spiritual assistant for The Apostolic Church Ghana (TAC-EL - East Legon Assembly). 
Your role is to offer biblical encouragement, cross-reference scriptures, explain church conduct and Apostolic doctrines (Beliefs in God the Father, Son, and Holy Ghost, baptism of the Holy Ghost with speaking in tongues, divine healing, sanctification, tithes and offerings), and help members locate hymns, scriptures, and sermons with reverent, uplifting grace. Keep responses concise, warm, pastoral, and grounded in the King James / NIV Bible.`;

      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: [
          { role: 'user', parts: [{ text: `${systemInstruction}\n\nUser Question: ${prompt}` }] }
        ]
      });

      return response.text || 'May the grace of our Lord Jesus Christ be with you. How else may I assist your spiritual walk today?';
    } catch (err) {
      console.warn('Kin AI API error, falling back:', err);
      return this.getFallbackSpiritualResponse(prompt);
    }
  },

  getFallbackSpiritualResponse(prompt: string): string {
    const p = prompt.toLowerCase();
    if (p.includes('peace') || p.includes('worry') || p.includes('anxious') || p.includes('fear')) {
      return `Philippians 4:6-7 — "Be careful for nothing; but in every thing by prayer and supplication with thanksgiving let your requests be made known unto God. And the peace of God, which passeth all understanding, shall keep your hearts and minds through Christ Jesus." Trust in His unfailing sovereignty!`;
    }
    if (p.includes('tithe') || p.includes('give') || p.includes('offering')) {
      return `Malachi 3:10 — "Bring ye all the tithes into the storehouse, that there may be meat in mine house, and prove me now herewith, saith the LORD of hosts, if I will not open you the windows of heaven, and pour you out a blessing, that there shall not be room enough to receive it." In TAC-EL, giving supports kingdom building and welfare.`;
    }
    if (p.includes('holy ghost') || p.includes('tongues') || p.includes('spirit')) {
      return `Acts 2:4 — "And they were all filled with the Holy Ghost, and began to speak with other tongues, as the Spirit gave them utterance." The Apostolic Church Ghana upholds the baptism and active gifts of the Holy Spirit for every believer.`;
    }
    if (p.includes('healing') || p.includes('sick')) {
      return `James 5:14-15 — "Is any sick among you? let him call for the elders of the church; and let them pray over him, anointing him with oil in the name of the Lord: And the prayer of faith shall save the sick." Reach out to our Presbytery and Elders for prayer.`;
    }
    return `Grace and peace to you in the Name of Jesus Christ. "The LORD bless thee, and keep thee: The LORD make his face shine upon thee, and be gracious unto thee: The LORD lift up his countenance upon thee, and give thee peace." (Numbers 6:24-26).`;
  }
};
