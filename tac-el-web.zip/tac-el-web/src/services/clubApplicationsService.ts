import { supabase } from '../supabase';

/**
 * Club applications: the conversation between a person who applied and the club's officers
 * (questions, interview invitations, answers), and the approve / decline decision.
 * Needs 13-club-applications.sql.
 */
export type AppMessageKind = 'answer' | 'question' | 'interview' | 'note' | 'declined';

export interface AppMessage {
  id: string;
  clubId: string;
  applicantId: string;
  senderId: string;
  senderName?: string;
  kind: AppMessageKind;
  body: string;
  interviewAt?: string;
  interviewPlace?: string;
  createdAt: string;
}

export interface MyApplication {
  clubId: string;
  clubName: string;
  status: 'pending' | 'declined';
  declinedNote?: string;
  messages: AppMessage[];
}

const row = (r: any): AppMessage => ({
  id: r.id, clubId: r.club_id, applicantId: r.applicant_id, senderId: r.sender_id,
  senderName: r.sender?.full_name ?? undefined, kind: r.kind, body: r.body ?? '',
  interviewAt: r.interview_at ?? undefined, interviewPlace: r.interview_place ?? undefined, createdAt: r.created_at,
});

function friendly(error: any, what: string): Error {
  const msg = String(error?.message || '');
  if (error?.code === 'PGRST202' || error?.code === 'PGRST205' || error?.code === '42P01' || /could not find|does not exist|schema cache/i.test(msg)) {
    return new Error(`${what} is not set up yet. Run 13-club-applications.sql in Supabase, then try again.`);
  }
  return new Error(msg || `Could not complete: ${what}.`);
}

export const clubApplicationsService = {
  /** One applicant's conversation for one club (officers see everything, the applicant sees their own). */
  async getThread(clubId: string, applicantId: string): Promise<AppMessage[]> {
    if (!clubId || !applicantId) return [];
    const { data, error } = await supabase
      .from('club_application_messages')
      .select('*, sender:profiles!club_application_messages_sender_id_fkey(full_name)')
      .eq('club_id', clubId).eq('applicant_id', applicantId)
      .order('created_at', { ascending: true });
    if (error) {
      // fall back without the name join (the relationship name can differ)
      const retry = await supabase.from('club_application_messages').select('*').eq('club_id', clubId).eq('applicant_id', applicantId).order('created_at', { ascending: true });
      if (retry.error) return [];
      return (retry.data ?? []).map(row);
    }
    return (data ?? []).map(row);
  },

  async send(m: { clubId: string; applicantId: string; senderId: string; kind: 'answer' | 'question' | 'interview' | 'note'; body: string; interviewAt?: string; interviewPlace?: string }): Promise<void> {
    const body = m.body.trim();
    if (m.kind !== 'interview' && !body) throw new Error('Please type a message first.');
    const { error } = await supabase.from('club_application_messages').insert({
      club_id: m.clubId, applicant_id: m.applicantId, sender_id: m.senderId, kind: m.kind, body,
      interview_at: m.interviewAt || null, interview_place: m.interviewPlace?.trim() || null,
    });
    if (error) throw friendly(error, 'Application messages');
  },

  async decide(clubId: string, applicantId: string, action: 'approve' | 'decline', note?: string): Promise<void> {
    const { error } = await supabase.rpc('club_decide_application', { p_club: clubId, p_applicant: applicantId, p_action: action, p_note: note ?? null });
    if (error) throw friendly(error, 'Approving applications');
  },

  /** The person's own waiting applications and recent declines, with the conversation for each. */
  async getMyApplications(uid: string): Promise<MyApplication[]> {
    const [{ data: pend }, { data: declined }] = await Promise.all([
      supabase.from('club_members').select('club_id, clubs(name)').eq('profile_id', uid).eq('status', 'pending'),
      supabase.from('club_application_messages').select('club_id, body, created_at, clubs(name)').eq('applicant_id', uid).eq('kind', 'declined').order('created_at', { ascending: false }).limit(5),
    ]);
    const out: MyApplication[] = [];
    for (const p of pend ?? []) {
      out.push({ clubId: (p as any).club_id, clubName: (p as any).clubs?.name ?? 'Club', status: 'pending', messages: await clubApplicationsService.getThread((p as any).club_id, uid) });
    }
    const pendingIds = new Set(out.map((o) => o.clubId));
    const seen = new Set<string>();
    for (const d of declined ?? []) {
      const id = (d as any).club_id;
      if (pendingIds.has(id) || seen.has(id)) continue;   // applied again since: show the new application instead
      seen.add(id);
      out.push({ clubId: id, clubName: (d as any).clubs?.name ?? 'Club', status: 'declined', declinedNote: (d as any).body || undefined, messages: [] });
    }
    return out;
  },
};
