import { supabase } from '../supabase';
import { isDesktopApp } from '../lib/desktop';
import { UserProfile, UserRole } from '../types';
import { isFresh } from '../lib/presenceStatus';

/**
 * Maps a `profiles` table row (snake_case, per the Supabase schema) to the
 * app's UserProfile shape (camelCase) so components don't need to change.
 */
function rowToProfile(row: any): UserProfile {
  return {
    uid: row.id,
    name: row.full_name,
    email: row.email ?? '',
    role: row.role as UserRole,
    office: row.office ?? null,
    offices: Array.isArray(row.offices) ? row.offices : (row.office ? [row.office] : []),
    phone: row.phone ?? undefined,
    picUrl: row.pic_url ?? undefined,
    joinedDate: row.created_at,
    // Derived, not just the stored flag — see lib/presenceStatus.ts.
    online: !!row.online && isFresh(row.last_seen),
    lastSeen: row.last_seen ?? undefined,
    userId: row.tac_el_id ?? undefined, // "TAC ID" in the UI, tac_el_id in the DB
    occupation: row.occupation ?? undefined,
    dateOfBirth: row.date_of_birth ?? undefined,
    isProfileComplete: !!row.is_profile_complete,
    // color / teams / chatBg have no column yet in the current schema —
    // see MIGRATION_NOTES.md. Left undefined for now; UI already treats
    // them as optional.
  };
}

/** Reverse of rowToProfile, for inserts/updates. Only includes defined keys. */
function profileToRow(p: Partial<UserProfile>): Record<string, any> {
  const row: Record<string, any> = {};
  if (p.name !== undefined) row.full_name = p.name;
  if (p.email !== undefined) row.email = p.email;
  if (p.role !== undefined) row.role = p.role;
  if (p.office !== undefined) row.office = p.office;
  if (p.phone !== undefined) row.phone = p.phone;
  if (p.picUrl !== undefined) row.pic_url = p.picUrl;
  if (p.online !== undefined) row.online = p.online;
  if (p.userId !== undefined) row.tac_el_id = p.userId;
  if (p.occupation !== undefined) row.occupation = p.occupation;
  if (p.dateOfBirth !== undefined) row.date_of_birth = p.dateOfBirth;
  if (p.isProfileComplete !== undefined) row.is_profile_complete = p.isProfileComplete;
  return row;
}

export const authService = {
  /** Google sign-in (redirect flow: the browser leaves and comes back with the
   *  session). A new account is ALWAYS created as a plain member. If the person
   *  came in through the Admin / Presbytery screen, the role they want and the
   *  passcode they typed are held in sessionStorage just long enough to survive
   *  the redirect; AuthContext then asks the `claim-role` Edge Function to
   *  verify the passcode on the server (see consumePendingClaim / claimRole). */
  async signInWithGoogle(wantedRole: UserRole = 'member', passcode?: string): Promise<void> {
    if (isDesktopApp) throw new Error('Google sign-in is not available in the desktop app. Use your email and password, or sign in with your phone.');
    try {
      localStorage.removeItem('tac_pending_role'); // old key from earlier builds
      if (wantedRole === 'admin' || wantedRole === 'presbytery') {
        sessionStorage.setItem('tac_pending_claim', JSON.stringify({ role: wantedRole, passcode: passcode ?? '' }));
      } else {
        sessionStorage.removeItem('tac_pending_claim');
      }
    } catch {
      /* storage unavailable (private mode) — the person just lands as a member */
    }
    const { error } = await supabase.auth.signInWithOAuth({
      provider: 'google',
      options: { redirectTo: window.location.origin },
    });
    if (error) throw error;
  },

  /** One-shot read (and delete) of the role claim stashed by signInWithGoogle. */
  consumePendingClaim(): { role: 'admin' | 'presbytery'; passcode: string } | null {
    try {
      const raw = sessionStorage.getItem('tac_pending_claim');
      sessionStorage.removeItem('tac_pending_claim');
      if (!raw) return null;
      const v = JSON.parse(raw);
      if (v.role === 'admin' || v.role === 'presbytery') return { role: v.role, passcode: String(v.passcode || '') };
    } catch {
      /* ignore */
    }
    return null;
  },

  /** Asks the server to promote the signed-in user to admin/presbytery.
   *  The passcode is checked by the `claim-role` Edge Function (a rotatable
   *  secret), never in the browser. Body: { role, passcode }. Returns the new
   *  role. Throws an Error whose message is safe to show to the person. */
  async claimRole(role: 'admin' | 'presbytery', passcode: string): Promise<UserRole> {
    const { data, error } = await supabase.functions.invoke('claim-role', { body: { role, passcode: (passcode || '').trim() } });
    if (error) {
      let msg = 'Could not verify the passcode. Please try again.';
      try {
        const body = await (error as any).context?.json?.();
        if (body?.error) msg = body.error;
        else if (/not found/i.test(String(body?.message || body?.code || ''))) {
          msg = 'The passcode service is not set up yet (the claim-role function is missing in Supabase).';
        }
      } catch {
        if ((error as any)?.name === 'FunctionsFetchError') msg = 'Could not reach the passcode service. Check your internet and try again.';
      }
      throw new Error(msg);
    }
    return (data?.role ?? role) as UserRole;
  },

  /** TAC ID -> email, for people who are NOT signed in yet. Calls the
   *  `email_for_tac_id(tac_id)` database function (profiles itself is closed to
   *  logged-out users). Returns null when the ID doesn't exist. */
  async emailForTacId(tacId: string): Promise<string | null> {
    const { data, error } = await supabase.rpc('email_for_tac_id', { tac_id: tacId.trim().toUpperCase() });
    if (error) {
      if (/too many/i.test(error.message || '')) throw new Error(error.message);
      throw new Error('Could not look up that TAC ID right now. Please log in with your email address.');
    }
    return (data as string | null) ?? null;
  },

  /** Called once, after any sign-in, if no profiles row exists yet for this
   *  auth user (new Google account, or first login after email-confirm).
   *  See AuthContext for where this gets invoked. */
  async createProfileForNewUser(
    uid: string,
    email: string,
    name: string,
    _ignoredRole?: UserRole // kept so old callers compile; new accounts are always members
  ): Promise<UserProfile> {
    // role and tac_el_id are NOT sent: the database makes everyone a member and
    // generates the TAC ID. (Sending role:'admin' here used to be a way in.)
    const newRow = {
      id: uid,
      full_name: name,
      email,
      is_profile_complete: true,
      online: true,
    };
    // details typed on the sign-up form (kept in the account until the first login)
    let extraRow: Record<string, any> = {};
    try {
      const { data: u } = await supabase.auth.getUser();
      const md: any = u?.user?.user_metadata || {};
      extraRow = profileToRow({ ...(md.phone ? { phone: md.phone } : {}), ...(md.occupation ? { occupation: md.occupation } : {}) } as any) || {};
      delete extraRow.role; delete extraRow.office; delete extraRow.tac_el_id;
    } catch { /* optional */ }
    const { data, error } = await supabase.from('profiles').insert({ ...newRow, ...extraRow }).select().single();
    if (error && (error as any).code === '23505') {
      // Someone (the sign-up form, or a database trigger) already made it a moment ago: use that one.
      if (Object.keys(extraRow).length) await supabase.from('profiles').update(extraRow).eq('id', uid);
      const { data: existing, error: readError } = await supabase.from('profiles').select('*').eq('id', uid).single();
      if (readError) throw readError;
      return rowToProfile(existing);
    }
    if (error) throw error;
    return rowToProfile(data);
  },

  async getCurrentUserProfile(uid: string): Promise<UserProfile | null> {
    const cacheKey = `tac_profile_${uid}`;
    let data: any = null, error: any = null;
    try {
      ({ data, error } = await supabase.from('profiles').select('*').eq('id', uid).maybeSingle());
    } catch (e) { error = e; }
    if (error) {
      console.warn('Failed to get user profile:', error);
      // No internet: open with the last saved copy of the profile instead of acting like nobody is signed in.
      try { const saved = localStorage.getItem(cacheKey); if (saved) return JSON.parse(saved) as UserProfile; } catch { /* ignore */ }
      return null;
    }
    if (!data) return null;
    const profile = rowToProfile(data);
    try { localStorage.setItem(cacheKey, JSON.stringify(profile)); } catch { /* storage full or blocked: fine */ }
    return profile;
  },

  async login(email: string, password: string) {
    const { data, error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) throw error;
    return data.user;
  },

  async register(
    email: string,
    password: string,
    name: string,
    _ignoredRole: UserRole = 'member', // always a member at sign-up; elevated roles go through claimRole()
    extra?: Partial<UserProfile>
  ): Promise<UserProfile> {
    // The form details travel with the account, so the profile can be filled in on first login
    // (when email confirmation is on there is no session yet, and a logged-out visitor cannot write a profile).
    const { data: signUpData, error: signUpError } = await supabase.auth.signUp({
      email,
      password,
      options: {
        // the confirmation link opens the same site the person signed up on (the address must also be in Supabase > Authentication > URL Configuration > Redirect URLs)
        emailRedirectTo: window.location.origin,
        data: { full_name: name, phone: extra?.phone ?? null, occupation: extra?.occupation ?? null },
      },
    });
    if (signUpError) throw signUpError;
    const uid = signUpData.user?.id;
    if (!uid || !signUpData.session) {
      // Email confirmation is required before the session (and therefore
      // auth.uid()) exists — the profile row gets created on first login
      // instead, via AuthContext. Surface this so the UI can show
      // "check your email" rather than silently doing nothing.
      throw new Error('CONFIRM_EMAIL_SENT');
    }

    const row = {
      id: uid,
      full_name: name,
      email,
      is_profile_complete: true,
      online: true,
      ...profileToRow(extra ?? {}),
    };
    // Never let the browser choose these (the database owns them).
    delete (row as any).role;
    delete (row as any).office;
    delete (row as any).tac_el_id;
    let { data, error } = await supabase.from('profiles').insert(row).select().single();
    if (error && (error as any).code === '23505') {
      // A profile row already exists (the database made one when the account was created): fill it in instead.
      const { id: _id, ...rest } = row as any;
      ({ data, error } = await supabase.from('profiles').update(rest).eq('id', uid).select().single());
    }
    if (error) throw error;
    return rowToProfile(data);
  },

  // ---- Confirm a new email account with the 6-digit code that was emailed ------------------------
  /** Checks the code from the sign-up email. On success the person is signed in; the profile is created by AuthContext. */
  async verifySignupCode(email: string, code: string): Promise<string> {
    const { data, error } = await supabase.auth.verifyOtp({ email: email.trim(), token: code.trim(), type: 'signup' });
    if (error) throw new Error('That code is not right, or it has expired. Ask for a new one.');
    const uid = data.user?.id;
    if (!uid) throw new Error('The code was accepted but no account came back. Try logging in.');
    return uid;
  },

  /** Sends a fresh sign-up code. */
  async resendSignupCode(email: string): Promise<void> {
    const { error } = await supabase.auth.resend({ type: 'signup', email: email.trim() });
    if (error) {
      if (/rate|seconds|too many/i.test(error.message)) throw new Error('Please wait a minute before asking for another code.');
      throw new Error('We could not send a new code. Check the email address and try again.');
    }
  },

  async updateProfile(uid: string, data: Partial<UserProfile>): Promise<void> {
    const { error } = await supabase.from('profiles').update(profileToRow(data)).eq('id', uid);
    if (error) throw error;
  },

  // ---- Forgot password, by a 6-digit code sent to the member's email -------------------------
  // 1) requestResetCode   2) resetPasswordWithCode (checks the code, then sets the new password)
  // The email template in Supabase must show the code (see SETUP-EMAIL-CODES.md).

  /** Sends the code. Accepts the email OR the member's TAC ID. Returns the email, partly hidden, for the screen. */
  async requestResetCode(identifier: string): Promise<{ email: string; masked: string }> {
    const raw = identifier.trim();
    if (!raw) throw new Error('Enter your email or TAC ID.');
    let email = raw;
    if (!raw.includes('@')) {
      const found = await authService.emailForTacId(raw);
      if (!found) throw new Error('We could not find that TAC ID. Try your email address instead.');
      email = found;
    }
    // shouldCreateUser:false => this can never create an account, it only emails people who already have one.
    const { error } = await supabase.auth.signInWithOtp({ email, options: { shouldCreateUser: false } });
    if (error) {
      if (/rate|seconds|too many/i.test(error.message)) throw new Error('Please wait a minute before asking for another code.');
      throw new Error('We could not send a code to that address. Check it and try again.');
    }
    const [user, domain] = email.split('@');
    return { email, masked: `${user.slice(0, 1)}${'*'.repeat(Math.max(2, user.length - 1))}@${domain}` };
  },

  /** Checks the code (which signs the person in) and sets the new password straight away. */
  async resetPasswordWithCode(email: string, code: string, newPassword: string): Promise<void> {
    if (newPassword.length < 6) throw new Error('Choose a password of at least 6 characters.');
    const { error } = await supabase.auth.verifyOtp({ email, token: code.trim(), type: 'email' });
    if (error) throw new Error('That code is not right, or it has expired. Ask for a new one.');
    const { error: updateError } = await supabase.auth.updateUser({ password: newPassword });
    if (updateError) throw new Error(updateError.message);
  },

  async logout(): Promise<void> {
    const { data: userData } = await supabase.auth.getUser();
    const uid = userData.user?.id;
    if (uid) {
      await supabase
        .from('profiles')
        .update({ online: false, last_seen: new Date().toISOString() })
        .eq('id', uid)
        .then(() => {}, () => {});
    }
    try { if (uid) localStorage.removeItem(`tac_profile_${uid}`); } catch { /* ignore */ }
    await supabase.auth.signOut();
  },
};

export { rowToProfile, profileToRow };
