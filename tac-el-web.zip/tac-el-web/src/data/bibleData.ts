export interface BibleVerse {
  number: number;
  text: string;
}

export interface BibleChapter {
  book: string;
  chapter: number;
  verses: BibleVerse[];
}

export interface BibleVersionContent {
  id: string;
  name: string;
  books: {
    [bookName: string]: {
      chapters: {
        [chapterNumber: number]: BibleChapter;
      };
    };
  };
}

export const BIBLE_BOOKS = [
  "Genesis", "Exodus", "Leviticus", "Numbers", "Deuteronomy", 
  "Joshua", "Judges", "Ruth", "1 Samuel", "2 Samuel", 
  "1 Kings", "2 Kings", "1 Chronicles", "2 Chronicles", "Ezra", 
  "Nehemiah", "Esther", "Job", "Psalms", "Proverbs", 
  "Ecclesiastes", "Song of Solomon", "Isaiah", "Jeremiah", "Lamentations", 
  "Ezekiel", "Daniel", "Hosea", "Joel", "Amos", 
  "Obadiah", "Jonah", "Micah", "Nahum", "Habakkuk", 
  "Zephaniah", "Haggai", "Zechariah", "Malachi",
  "Matthew", "Mark", "Luke", "John", "Acts", 
  "Romans", "1 Corinthians", "2 Corinthians", "Galatians", "Ephesians", 
  "Philippians", "Colossians", "1 Thessalonians", "2 Thessalonians", "1 Timothy", 
  "2 Timothy", "Titus", "Philemon", "Hebrews", "James", 
  "1 Peter", "2 Peter", "1 John", "2 John", "3 John", 
  "Jude", "Revelation"
];

export const BIBLE_CHAPTER_COUNTS: { [book: string]: number } = {
  "Genesis": 50, "Exodus": 40, "Leviticus": 27, "Numbers": 36, "Deuteronomy": 34,
  "Joshua": 24, "Judges": 21, "Ruth": 4, "1 Samuel": 31, "2 Samuel": 24,
  "1 Kings": 22, "2 Kings": 25, "1 Chronicles": 29, "2 Chronicles": 36, "Ezra": 10,
  "Nehemiah": 13, "Esther": 10, "Job": 42, "Psalms": 150, "Proverbs": 31,
  "Ecclesiastes": 12, "Song of Solomon": 8, "Isaiah": 66, "Jeremiah": 52, "Lamentations": 5,
  "Ezekiel": 48, "Daniel": 12, "Hosea": 14, "Joel": 3, "Amos": 9,
  "Obadiah": 1, "Jonah": 4, "Micah": 7, "Nahum": 3, "Habakkuk": 3,
  "Zephaniah": 3, "Haggai": 2, "Zechariah": 14, "Malachi": 4,
  "Matthew": 28, "Mark": 16, "Luke": 24, "John": 21, "Acts": 28,
  "Romans": 16, "1 Corinthians": 16, "2 Corinthians": 13, "Galatians": 6, "Ephesians": 6,
  "Philippians": 4, "Colossians": 4, "1 Thessalonians": 5, "2 Thessalonians": 3, "1 Timothy": 6,
  "2 Timothy": 4, "Titus": 3, "Philemon": 1, "Hebrews": 13, "James": 5,
  "1 Peter": 5, "2 Peter": 3, "1 John": 5, "2 John": 1, "3 John": 1,
  "Jude": 1, "Revelation": 22
};

export const bibleData: { [versionId: string]: BibleVersionContent } = {
  KJV: {
    id: "KJV",
    name: "King James Version",
    books: {
      Genesis: {
        chapters: {
          1: {
            book: "Genesis",
            chapter: 1,
            verses: [
              { number: 1, text: "In the beginning God created the heaven and the earth." },
              { number: 2, text: "And the earth was without form, and void; and darkness was upon the face of the deep. And the Spirit of God moved upon the face of the waters." },
              { number: 3, text: "And God said, Let there be light: and there was light." },
              { number: 4, text: "And God saw the light, that it was good: and God divided the light from the darkness." },
              { number: 5, text: "And God called the light Day, and the darkness he called Night. And the evening and the morning were the first day." },
              { number: 6, text: "And God said, Let there be a firmament in the midst of the waters, and let it divide the waters from the waters." },
              { number: 7, text: "And God made the firmament, and divided the waters which were under the firmament from the waters which were above the firmament: and it was so." },
              { number: 8, text: "And God called the firmament Heaven. And the evening and the morning were the second day." },
              { number: 9, text: "And God said, Let the waters under the heaven be gathered together unto one place, and let the dry land appear: and it was so." },
              { number: 10, text: "And God called the dry land Earth; and the gathering together of the waters called he Seas: and God saw that it was good." },
              { number: 11, text: "And God said, Let the earth bring forth grass, the herb yielding seed, and the fruit tree yielding fruit after his kind, whose seed is in itself, upon the earth: and it was so." },
              { number: 12, text: "And the earth brought forth grass, and herb yielding seed after his kind, and the tree yielding fruit, whose seed was in itself, after his kind: and God saw that it was good." },
              { number: 13, text: "And the evening and the morning were the third day." },
              { number: 14, text: "And God said, Let there be lights in the firmament of the heaven to divide the day from the night; and let them be for signs, and for seasons, and for days, and years:" },
              { number: 15, text: "And let them be for lights in the firmament of the heaven to give light upon the earth: and it was so." },
              { number: 16, text: "And God made two great lights; the greater light to rule the day, and the lesser light to rule the night: he made the stars also." },
              { number: 17, text: "And God set them in the firmament of the heaven to give light upon the earth," },
              { number: 18, text: "And to rule over the day and over the night, and to divide the light from the darkness: and God saw that it was good." },
              { number: 19, text: "And the evening and the morning were the fourth day." },
              { number: 20, text: "And God said, Let the waters bring forth abundantly the moving creature that hath life, and fowl that may fly above the earth in the open firmament of heaven." },
              { number: 21, text: "And God created great whales, and every living creature that moveth, which the waters brought forth abundantly, after their kind, and every winged fowl after his kind: and God saw that it was good." },
              { number: 22, text: "And God blessed them, saying, Be fruitful, and multiply, and fill the waters in the seas, and let fowl multiply in the earth." },
              { number: 23, text: "And the evening and the morning were the fifth day." },
              { number: 24, text: "And God said, Let the earth bring forth the living creature after his kind, cattle, and creeping thing, and beast of the earth after his kind: and it was so." },
              { number: 25, text: "And God made the beast of the earth after his kind, and cattle after their kind, and every thing that creepeth upon the earth after his kind: and God saw that it was good." },
              { number: 26, text: "And God said, Let us make man in our image, after our likeness: and let them have dominion over the fish of the sea, and over the fowl of the air, and over the cattle, and over all the earth, and over every creeping thing that creepeth upon the earth." },
              { number: 27, text: "So God created man in his own image, in the image of God created he him; male and female created he them." },
              { number: 28, text: "And God blessed them, and God said unto them, Be fruitful, and multiply, and replenish the earth, and subdue it: and have dominion over the fish of the sea, and over the fowl of the air, and over every living thing that moveth upon the earth." },
              { number: 29, text: "And God said, Behold, I have given you every herb bearing seed, which is upon the face of all the earth, and every tree, in the which is the fruit of a tree yielding seed; to you it shall be for meat." },
              { number: 30, text: "And to every beast of the earth, and to every fowl of the air, and to every thing that creepeth upon the earth, wherein there is life, I have given every green herb for meat: and it was so." },
              { number: 31, text: "And God saw every thing that he had made, and, behold, it was very good. And the evening and the morning were the sixth day." }
            ]
          },
          2: {
            book: "Genesis",
            chapter: 2,
            verses: [
              { number: 1, text: "Thus the heavens and the earth were finished, and all the host of them." },
              { number: 2, text: "And on the seventh day God ended his work which he had made; and he rested on the seventh day from all his work which he had made." },
              { number: 3, text: "And God blessed the seventh day, and sanctified it: because that in it he had rested from all his work which God created and made." },
              { number: 4, text: "These are the generations of the heavens and of the earth when they were created, in the day that the LORD God made the earth and the heavens." },
              { number: 5, text: "And every plant of the field before it was in the earth, and every herb of the field before it grew: for the LORD God had not caused it to rain upon the earth, and there was not a man to till the ground." },
              { number: 6, text: "But there went up a mist from the earth, and watered the whole face of the ground." },
              { number: 7, text: "And the LORD God formed man of the dust of the ground, and breathed into his nostrils the breath of life; and man became a living soul." },
              { number: 8, text: "And the LORD God planted a garden eastward in Eden; and there he put the man whom he had formed." }
            ]
          }
        }
      },
      Exodus: {
        chapters: {
          1: {
            book: "Exodus",
            chapter: 1,
            verses: [
              { number: 1, text: "Now these are the names of the children of Israel, which came into Egypt; every man and his household came with Jacob." },
              { number: 2, text: "Reuben, Simeon, Levi, and Judah," },
              { number: 3, text: "Issachar, Zebulun, and Benjamin," },
              { number: 4, text: "Dan, and Naphtali, Gad, and Asher." },
              { number: 5, text: "And all the souls that came out of the loins of Jacob were seventy souls: for Joseph was in Egypt already." },
              { number: 6, text: "And Joseph died, and all his brethren, and all that generation." },
              { number: 7, text: "And the children of Israel were fruitful, and increased abundantly, and multiplied, and waxed exceeding mighty; and the land was filled with them." },
              { number: 8, text: "Now there arose up a new king over Egypt, which knew not Joseph." }
            ]
          },
          2: {
            book: "Exodus",
            chapter: 2,
            verses: [
              { number: 1, text: "And there went a man of the house of Levi, and took to wife a daughter of Levi." },
              { number: 2, text: "And the woman conceived, and bare a son: and when she saw him that he was a goodly child, she hid him three months." },
              { number: 3, text: "And when she could not longer hide him, she took for him an ark of bulrushes, and daubed it with slime and with pitch, and put the child therein; and she laid it in the flags by the river's brink." }
            ]
          }
        }
      }
    }
  },
  NIV: {
    id: "NIV",
    name: "New International Version",
    books: {
      Genesis: {
        chapters: {
          1: {
            book: "Genesis",
            chapter: 1,
            verses: [
              { number: 1, text: "In the beginning God created the heavens and the earth." },
              { number: 2, text: "Now the earth was formless and empty, darkness was over the surface of the deep, and the Spirit of God was hovering over the waters." },
              { number: 3, text: "And God said, 'Let there be light,' and there was light." },
              { number: 4, text: "God saw that the light was good, and he separated the light from the darkness." },
              { number: 5, text: "God called the light 'day,' and the darkness he called 'night.' And there was evening, and there was morning—the first day." }
            ]
          }
        }
      }
    }
  },
  ASW: {
    id: "ASW",
    name: "Akuapem Twi",
    books: {
      Genesis: {
        chapters: {
          1: {
            book: "Genesis",
            chapter: 1,
            verses: [
              { number: 1, text: "Mfiase no Onyankopɔn bɔɔ ɔsoro ne asase." },
              { number: 2, text: "Na asase no yɛ kwa, na hwee nni so; na esum wɔ bun no ani so, na Onyankopɔn Honhom nam nsuo no ani so." },
              { number: 3, text: "Na Onyankopɔn kae sɛ: Ma ɛnyɛ hann! Na ɛyɛɛ hann." },
              { number: 4, text: "Na Onyankopɔn huu hann no sɛ eye; na Onyankopɔn paapaam hann ne esum no mu." },
              { number: 5, text: "Na Onyankopɔn frɛɛ hann no sɛ Awia, na esum no nso ɔfrɛɛ no Anadwo. Na adekyee ne adesa yɛɛ ɛda a ɛdi kan." },
              { number: 6, text: "Na Onyankopɔn kae sɛ: Ma wim nna nsuo no ntam, ma ɛmpaapaam nsuo no mu." },
              { number: 7, text: "Na Onyankopɔn yɛɛ wim no, na ɔpaapaam nsuo a ɛwɔ wim ase ne nsuo a ɛwɔ wim atifi no mu; na ɛyɛɛ saa." },
              { number: 8, text: "Na Onyankopɔn frɛɛ wim no sɛ Ɔsoro. Na adekyee ne adesa yɛɛ ɛda a ɛtɔ so mmienu." }
            ]
          },
          2: {
            book: "Genesis",
            chapter: 2,
            verses: [
              { number: 1, text: "Na wɔawie ɔsoro ne asase ne nea ɛwɔ mu nyinaa." },
              { number: 2, text: "Na ɛda a ɛtɔ so nson no, na Onyankopɔn awie n'adwuma a ɔyɛe no." }
            ]
          }
        }
      }
    }
  },
  BSW: {
    id: "BSW",
    name: "Asante Twi",
    books: {
      Genesis: {
        chapters: {
          1: {
            book: "Genesis",
            chapter: 1,
            verses: [
              { number: 1, text: "Mfiase no Onyankopɔn bɔɔ ɔsoro ne asase." },
              { number: 2, text: "Na asase no yɛ kwa, na hwee nni so; na esum wɔ bun no ani so, na Onyankopɔn Honhom nam nsuo no ani so." },
              { number: 3, text: "Na Onyankopɔn kae sɛ: Ma ɛnyɛ hann! Na ɛyɛɛ hann." },
              { number: 4, text: "Na Onyankopɔn huu hann no sɛ eye; na Onyankopɔn paapaam hann ne esum no mu." },
              { number: 5, text: "Na Onyankopɔn frɛɛ hann no sɛ Awia, na esum no nso ɔfrɛɛ no Anadwo. Na adekyee ne adesa yɛɛ ɛda a ɛdi kan." }
            ]
          }
        }
      }
    }
  },
  GAB: {
    id: "GAB",
    name: "Ga Bible",
    books: {
      Genesis: {
        chapters: {
          1: {
            book: "Genesis",
            chapter: 1,
            verses: [
              { number: 1, text: "Shishijee mli lɛ Nyɔŋmɔ bɔ ŋwɛi kɛ shikpɔŋ lɛ." },
              { number: 2, text: "Ni shikpɔŋ lɛ kɛ ehiɛ egbɛ ni eji eflo; ni dibɔ pii kã bu lɛ hiɛ, ni Nyɔŋmɔ Mumɔ lɛ hẽra nuji lɛ ahiɛ." },
              { number: 3, text: "Ni Nyɔŋmɔ kɛɛ: ‘La aba!’ Ni la ba." },
              { number: 4, text: "Ni Nyɔŋmɔ na la lɛ akɛ ohi; ni Nyɔŋmɔ gba la lɛ kɛ dibɔ lɛ amli." },
              { number: 5, text: "Ni Nyɔŋmɔ tsɛ la lɛ akɛ Shwane, ni dibɔ lɛ tsɛ lɛ akɛ Nyɔŋ. Ni gbɛkɛ ba ni mako ba, klɛŋklɛŋ gbi lɛ nɛ." }
            ]
          }
        }
      }
    }
  }
};
