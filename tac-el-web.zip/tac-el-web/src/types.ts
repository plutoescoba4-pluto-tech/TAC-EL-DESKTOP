export type UserRole = 'member' | 'presbytery' | 'admin';

/** A church office — separate from role. A Treasurer is still role: 'member',
 *  with this field layered on top. Distinct from `occupation` (secular job). */
export type UserOffice = string | null;

export interface UserProfile {
  uid: string;
  name: string;
  email: string;
  role: UserRole;
  office?: UserOffice;
  /** every office the person holds (set only by the root administrator) */
  offices?: string[];
  phone?: string;
  picUrl?: string;
  color?: string;
  joinedDate: string;
  online: boolean;
  lastSeen?: string;
  teams?: Record<string, 'member' | 'mentor'>;
  
  // Mandatory fields for mobile app
  userId?: string; // Church Member ID
  occupation?: string; // secular job/profession — NOT a church office, see UserOffice
  dateOfBirth?: string;
  isProfileComplete?: boolean;
  chatBg?: string; // Custom chat background URL or color
}

export interface Notice {
  id: string;
  title: string;
  type: 'gen' | 'urg' | 'pin';
  body: string;
  author: string;
  date: string;
  eventDate?: string; // Optional field for calendar integration
  createdAt: string;
}

export interface HomeConfig {
  id: string;
  theme: string;
  motto: string;
  logoUrl?: string;
  services: Array<{ label: string; time: string; id: string }>;
  announcement?: string;
  heroUrl?: string;
  heroSlides?: string[];
  churchTheme?: string;
  themeScripture?: string;
  
  // Church Information (Admin Updated)
  churchInfo?: {
    location?: string;
    bankDetails?: Array<{ bankName: string; accountName: string; accountNumber: string }>;
    transferAccounts?: Array<{ provider: string; details: string }>;
    contactEmail?: string;
    contactPhone?: string;
  };
}

export interface ChurchConduct {
  id: string;
  title: string;
  points: string[];
  category: 'general' | 'marriage' | 'youth' | 'protocol';
  lastUpdated?: any;
}

export interface HymnSection {
  type: 'verse' | 'chorus';
  text: string;
}

export interface Hymn {
  id: string;
  number: number;
  title: string;
  /** Verses and choruses in singing order. This is what the app shows. */
  sections: HymnSection[];
  /** Derived from sections (verse texts only). Kept for older code. */
  lyrics: string[];
  /** Derived from sections (the first chorus). Kept for older code. */
  chorus?: string;
  category: string;
}

export interface Sermon {
  id: string;
  title: string;
  speaker: string;
  date: string;
  type: string;
  videoUrl?: string;
  audioUrl?: string;
  coverUrl?: string;
  linkUrl?: string;
  scripture?: string;
  summary?: string;
  showOnWebsite?: boolean;
  color?: string;
}

export interface EventItem {
  id: string;
  title: string;
  startDate: string; // ISO string
  endDate?: string;
  type: 'service' | 'conference' | 'meeting' | 'other';
  summary: string;
  location?: string;
  posterUrl?: string;
  createdAt: any;
}

export interface GalleryItem {
  id: string;
  src: string;
  type: 'img' | 'vid';
  uploadedBy?: string;
  createdAt: string;
}

export interface Team {
  id: string;
  name: string;
  icon: string;
  color: string;
  desc: string;
  members: number; // For summary display
  memberIds?: string[]; // Actual UIDs
}

export interface TeamTask {
  id: string;
  title: string;
  desc: string;
  status: 'pending' | 'completed';
  assignedTo?: string[];
  dueDate?: string;
  createdAt: any;
}

export interface TeamNotice {
  id: string;
  title: string;
  body: string;
  authorId: string;
  authorName: string;
  createdAt: any;
}

export interface ChatMessage {
  id: string;
  senderId: string;
  senderName: string;
  text?: string;
  img?: string;
  vid?: string;
  voice?: string;
  audio?: string;
  file?: string;
  location?: { lat: number; lng: number; url: string } | string;
  senderColor?: string;
  time: string;
  createdAt: any; // Timestamp
  replyTo?: {
    sender: string;
    text?: string;
    img?: string;
    vid?: string;
  };
  /** WhatsApp-style read receipts. deliveredTo/readBy include the sender's own
   *  uid by default (a message is "delivered/read" to yourself the instant you
   *  send it). Ticks are computed from these: 1 gray = sent, 2 gray = delivered
   *  to at least one other person, 2 blue = read by at least one other person.
   *  (Waiting for literally every group member would rarely resolve in a large
   *  church-wide chat, so "at least one other recipient" is the practical
   *  standard most large-group chat apps use — not "read by everyone".) */
  deliveredTo?: string[];
  readBy?: string[];
}

export interface Donation {
  id: string;
  userId: string;
  userName: string;
  amount: number;
  type: 'offering' | 'tithe' | 'welfare' | 'other';
  date: string;
  createdAt: any;
}

export interface UpdateRequest {
  id: string;
  title: string;
  body: string;
  type: 'gen' | 'urg' | 'pin';
  imgUrl?: string;
  fileUrl?: string;
  authorId: string;
  authorName: string;
  status: 'pending' | 'exported' | 'rejected';
  createdAt: any;
}

export interface EmergencyMessage {
  id: string;
  userId: string;
  userName: string;
  userEmail: string;
  message: string;
  status: 'unread' | 'read' | 'resolved';
  createdAt: any;
}
