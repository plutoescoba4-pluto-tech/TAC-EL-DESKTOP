import { createClient } from '@supabase/supabase-js';

// The project URL and the anon key are PUBLIC by design (they are visible in any website that uses
// Supabase; the database rules protect the data). They are built in as a fallback so the app can
// never start blank just because .env.local was not found. A value in .env.local still wins.
// NEVER put the service_role key or any other secret here.
const FALLBACK_URL = 'https://simukqrfgdcntrkjcwtq.supabase.co';
const FALLBACK_ANON_KEY =
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InNpbXVrcXJmZ2RjbnRya2pjd3RxIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTA0MzE3MzgsImV4cCI6MjEwNjAwNzczOH0.-ZBSxfP_8qKnRE_fHL2n_4nFZpq5nOaunhvzAWTtjTI';

const supabaseUrl = ((import.meta.env.VITE_SUPABASE_URL as string) || FALLBACK_URL).trim();
const supabaseAnonKey = ((import.meta.env.VITE_SUPABASE_ANON_KEY as string) || FALLBACK_ANON_KEY).trim();

if (!import.meta.env.VITE_SUPABASE_URL || !import.meta.env.VITE_SUPABASE_ANON_KEY) {
  console.warn('[supabase] .env.local was not found or is incomplete; using the built-in project values.');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  // always the church tables, whatever order the exposed schemas are listed in Supabase
  db: { schema: 'public' },
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true,
  },
  realtime: {
    params: {
      eventsPerSecond: 10,
    },
  },
});

// Convenience re-export so the rest of the app can do `import { supabase } from '../supabase'`
// everywhere `import { db, auth } from '../firebase'` used to be.
export default supabase;
